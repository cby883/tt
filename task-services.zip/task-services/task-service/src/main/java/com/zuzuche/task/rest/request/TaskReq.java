package com.zuzuche.task.rest.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.HashMap;

/**
 * @desc: 常规短信
 * @author: panqiong
 * @date: 2018/9/26
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ApiModel(value = "任务")
public class TaskReq {

    @ApiModelProperty(value = "任务id,如果上游不传,snowflack",required = false)
    private String taskId ;

    @ApiModelProperty(value = "任务类型  1:http调用任务",required = false)
    private int typeId;

    @ApiModelProperty(value = "调用url",required = true)
    private String url;


    @ApiModelProperty(value = "http method",required = true)
    private String method;


    @ApiModelProperty(value = "优先级 1:高优先级队列  2:普通队列",required = true)
    private int priority;


    @ApiModelProperty(value = "重试策略id 暂未实现",required = false)
    private int retryStrategy;


    @ApiModelProperty(value = "重试最大次数 暂未实现",required = false)
    private int retryMaxCount;

    @ApiModelProperty(value = "参数   json格式",required = true)
    private String params;

}
