package com.zuzuche.task.service.http;
import com.zuzuche.commons.base.resp.Status;
import com.zuzuche.commons.base.resp.StatusServiceException;
import com.zuzuche.task.cache.TaskConfigCache;
import com.zuzuche.task.enums.TaskConfigEnum;
import com.zuzuche.task.listener.HttpTaskCommonListener;
import com.zuzuche.task.listener.HttpTaskHighListener;
import com.zuzuche.task.listener.TaskExeResultListener;
import com.zuzuche.task.listener.TaskRetryPrepareListener;
import com.zuzuche.task.mapper.TaskConfigMapper;
import com.zuzuche.task.service.TaskConfigService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

/**
 * @desc: http结果处理
 * @author: panqiong
 * @date: 2018-12-18
 */
@Slf4j
@Service
public class HttpTaskConfigServiceImpl implements TaskConfigService {

    private static long expireTime = 24*60*60;

    @Autowired
    TaskConfigService taskConfigService;
    @Autowired
    TaskConfigCache taskConfigCache;
    @Autowired
    TaskConfigMapper taskConfigMapper;
    @Autowired
    HttpTaskCommonListener httpTaskCommonListener;
    @Autowired
    HttpTaskHighListener httpTaskHighListener;
    @Autowired
    TaskExeResultListener taskExeResultListener;
    @Autowired
    TaskRetryPrepareListener taskRetryPrepareListener;
    @Override
    public boolean updateByConfigKey(String configKey,int configValue) {
        if(StringUtils.isBlank(configKey)||configValue<=0){
            return false;
        }else{
            int count=taskConfigMapper.updateByConfigKey(configKey,configValue,LocalDateTime.now());
            if(count>=1){
                return true;
            }else{
                return false;
            }
        }
    }
    @Override
   public void updateRate(TaskConfigEnum taskConfigEnum,int rate){
       //数据校验
       if(rate<0){
           throw new StatusServiceException(Status.PARAMS_OUT_OF_RANGE_ERROR,"速率参数不正确");
       }
       switch (taskConfigEnum){
           case COMMONS_RATE:{
               //更新数据库的配置
               boolean flag=updateByConfigKey(TaskConfigEnum.COMMONS_RATE.topicName(),rate);
               //更新成功，重新加载配置
               if(flag){
                   if(taskConfigCache.setConfigValue(TaskConfigEnum.COMMONS_RATE.topicName(),rate)){
                       httpTaskHighListener.reload();
                       return ;
                   }
               }
               throw new StatusServiceException(Status.BUSY,"速率加载失败");
           }
           case HIGH_RATE:{
               //更新数据库的配置
               boolean flag=updateByConfigKey(TaskConfigEnum.HIGH_RATE.topicName(),rate);
               //更新成功，重新加载配置
               if(flag){
                   if(taskConfigCache.setConfigValue(TaskConfigEnum.HIGH_RATE.topicName(),rate)){
                       httpTaskHighListener.reload();
                       return ;
                   }
               }
               throw new StatusServiceException(Status.BUSY,"速率加载失败");
           }
           case RETRY_RATE:{
               //更新数据库的配置
               boolean flag=updateByConfigKey(TaskConfigEnum.RETRY_RATE.topicName(),rate);
               //更新成功，重新加载配置
               if(flag){
                   if(taskConfigCache.setConfigValue(TaskConfigEnum.RETRY_RATE.topicName(),rate)){
                       taskRetryPrepareListener.reload();
                       return ;
                   }
               }
               throw new StatusServiceException(Status.BUSY,"速率加载失败");
           }
           case RESULT_RATE:{
               //更新数据库的配置
               boolean flag=updateByConfigKey(TaskConfigEnum.RESULT_RATE.topicName(),rate);
               //更新成功，重新加载配置
               if(flag){
                   if(taskConfigCache.setConfigValue(TaskConfigEnum.RESULT_RATE.topicName(),rate)){
                       taskExeResultListener.reload();
                       return ;
                   }
               }
               throw new StatusServiceException(Status.BUSY,"速率加载失败");
           }
           default:throw new StatusServiceException(Status.PARAMS_OUT_OF_RANGE_ERROR,"队列不存在");
       }
   }

}
