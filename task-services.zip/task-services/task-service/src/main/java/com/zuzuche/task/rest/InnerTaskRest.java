package com.zuzuche.task.rest;

import com.zuzuche.commons.base.resp.RespResult;
import com.zuzuche.task.rest.request.TaskReq;
import com.zuzuche.task.rest.response.TaskResp;
import com.zuzuche.task.service.TaskService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @desc: 暴露给外部业务部门
 * @author: panqiong
 * @date: 2019-10-11
 */
@RestController
@RequestMapping("/inner")
@Slf4j
@Api(value = "task", description = "任务", tags = {"task"})
public class InnerTaskRest {

    @Autowired
    TaskService taskService;


    /**
     * 同步推送,入队成功才会返回
     * 提供给上游服务调用
     * @param req
     * @return
     */
    @PostMapping("/syn/submit")
    @ApiOperation(value = "同步推送任务", notes = "同步任务,短信入队(kafka)成功后才会返回")
    public RespResult<TaskResp> send(TaskReq req) {
        return taskService.send(req);
    }
}

