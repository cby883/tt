package com.zuzuche.task.rest;

import com.zuzuche.commons.base.resp.RespResult;
import com.zuzuche.task.cache.RetryStrategyCache;
import com.zuzuche.task.cache.TaskTypeCache;
import com.zuzuche.task.rest.response.PushStatusRsp;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @desc: 账户信息管理
 * @author: panqiong
 * @date: 2018/10/31
 */
@RestController
@RequestMapping("/account")
@Slf4j
@Api(value = "account", description = "供应商账户信息", tags = {"account"})
public class CacheRest {

    @Autowired
    TaskTypeCache taskTypeCache;


    @Autowired
    RetryStrategyCache retryStrategyCache;

    /**
     * 重新载入缓存
     * @param
     * @return
     */
    @GetMapping("/reload")
    @ApiOperation(value = "重新加载本地缓存", notes = "刷新本地缓存")
    public RespResult<PushStatusRsp> refreshCache() {
        retryStrategyCache.reload();
        return RespResult.success();
    }




}
