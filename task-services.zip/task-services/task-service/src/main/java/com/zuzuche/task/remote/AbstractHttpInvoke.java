package com.zuzuche.task.remote;

import com.zuzuche.commons.base.util.CollectionUtil;
import com.zuzuche.commons.base.util.JsonUtil;
import com.zuzuche.task.common.utils.OkHttpUtil;
import lombok.extern.slf4j.Slf4j;
import okhttp3.Response;
import org.springframework.http.*;
import org.springframework.web.client.HttpClientErrorException;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * @desc: 抽象http调用父类,feign解析不方便,直接采用resttamplate
 * @author: panqiong
 * @date: 2018/11/5
 */
@Slf4j
public abstract class AbstractHttpInvoke {



    protected String postForm(String url,Map params)throws IOException {
        if(log.isDebugEnabled()){
            log.debug("[request]url:"+url);
        }
        Response result = OkHttpUtil.post(url,params);

        String content = result.body().string();
        if(log.isDebugEnabled()){
            String paramStr = null;
            if(CollectionUtil.isNotEmpty(params)){
                paramStr = JsonUtil.mapToString(params);
            }
            log.debug("[response] \n->[url]:"+url+"\n->[param]"+paramStr+""+"\n->[method]:postForm"+"\n->[result]:"+content);
        }
        if(!result.isSuccessful()){
            throw new HttpClientErrorException(HttpStatus.valueOf(result.code()));
        }
        return content;
    }

    protected String get(String url) throws IOException {
        if(log.isDebugEnabled()){
            log.debug("[request]url:"+url);
        }
        Map headers = new HashMap();
        headers.put(HttpHeaders.COOKIE,"allow_test_ip=1,header_code=1");

        Response result = OkHttpUtil.getWithHeaders(url,headers);
        String content = result.body().string();
        if(log.isDebugEnabled()){
            log.debug("[response] \n->[url]:"+url+"\n->[param]"+""+"\n->[method]:get"+"\n->[result]:"+content);
        }
        if(!result.isSuccessful()){
            throw new HttpClientErrorException(HttpStatus.valueOf(result.code()));
        }
        return content;
    }

//    protected String get(String url) throws IOException {
//        if(log.isDebugEnabled()){
//            log.debug("[request]url:"+url);
//        }
//        String result="";
//        OkHttpClient client = new OkHttpClient();
//        Request request = new Request.Builder()
//                .url(url)
//                .get()
//                .addHeader(HttpHeaders.COOKIE,"allow_test_ip=1,header_code=1")
//                .build();
//        Response response = client.newCall(request).execute();
//        result =  response.body().string();
//        if(log.isDebugEnabled()){
//            log.debug("[response] \n->[url]:"+url+"\n->[param]"+""+"\n->[result]:"+result);
//        }
//        return result;
//    }

    /**
     * 额外的header设置 比如编码
     * @param header
     */
    protected abstract void setHeader(HttpHeaders header);


    public static void main(String[] args) {
//        String url ="http://www.baidu.com/gogogo";
//        HashMap param = new HashMap();
//        param.put("helo","xxxx");
//        param.put("good","moning");
//
//        if(log.isDebugEnabled()){
//            log.debug("[request]url:"+url+" param:"+param.toString());
//        }
//        StringBuilder paramsBuilder = new StringBuilder("");
//        if(param!=null&&param.size()>0){
//            param.forEach((k,v)->{
//                if(StringUtil.isEmpty(paramsBuilder.toString())){
//                    paramsBuilder.append(k).append("=").append(v);
//                }else{
//                    paramsBuilder.append("&").append(k).append("=").append(v);
//                }
//            });
//        }
//        if(url.contains("?")){
//            url = url+"&"+paramsBuilder.toString();
//        }else{
//            url = url+"?"+paramsBuilder.toString();
//        }
//
//        System.out.println("url = " + url);
    }
}
