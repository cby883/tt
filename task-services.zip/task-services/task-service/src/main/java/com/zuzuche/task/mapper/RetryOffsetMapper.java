package com.zuzuche.task.mapper;

import com.zuzuche.commons.mybatis.BaseMapper;
import com.zuzuche.task.entity.RetryOffset;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

/**
 * @desc: 重试offset控制,严格注意并发一致性问题
 * @author: pan
 * @date: 2019-01-14
 */
@Repository
public interface RetryOffsetMapper extends BaseMapper<RetryOffset> {
    /**
     * 查询offset
     * @param offsetKey
     * @return
     */
    RetryOffset queryByOffsetKey(String offsetKey);

    /**
     * 提交偏移量
     * @param offsetKey
     * @param offsetValue
     * @return
     */
    int commitOffsetValue(@Param("offsetKey") String offsetKey, @Param("offsetValue") int offsetValue);

    int selectByOffset(@Param("offsetKey")String offsetKey);
}