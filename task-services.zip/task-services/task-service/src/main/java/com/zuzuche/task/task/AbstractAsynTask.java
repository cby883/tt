package com.zuzuche.task.task;

import com.google.common.base.Splitter;
import com.netflix.hystrix.exception.HystrixRuntimeException;
import com.zuzuche.kafka.sentry.EventDto;
import com.zuzuche.kafka.sentry.SentryReport;
import com.zuzuche.kafka.sentry.SourceEventDto;
import com.zuzuche.task.cache.RetryStrategyCache;
import com.zuzuche.task.common.utils.PerformUtil;
import com.zuzuche.task.dto.ResultDto;
import com.zuzuche.task.dto.TaskDto;
import com.zuzuche.task.entity.RetryStrategy;
import com.zuzuche.task.filter.Filter;
import com.zuzuche.task.filter.FilterManager;
import com.zuzuche.task.service.KafkaService;
import com.zuzuche.task.service.RetryStrategyService;
import com.zuzuche.task.service.TaskResultService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.Instant;
import java.util.List;

/**
 * @desc: 抽象的发送任务 定义了发送任务的模板操作逻辑
 * @author: panqiong
 * @date: 2018/10/26
 */
@Slf4j
public abstract class  AbstractAsynTask implements Runnable{

    @Autowired
    KafkaService kafkaService;

    @Autowired
    SentryReport sentryReport;

    @Autowired
    FilterManager filterManager;

    @Autowired
    TaskResultService executeResultService;

    @Autowired
    RetryStrategyCache retryStrategyCache;

    @Autowired
    RetryStrategyService retryStrategyService;

    TaskDto task;

    AbstractAsynTask(TaskDto task){
        this.task = task;
    }

    /**
     * 发送任务
     * 1.执行过滤器链
     * 2.调用供应商api
     * 3.收尾工作
     */
    @Override
    public void run() {

        try{
            // 1. 前置处理
            if(!beforeExecute(task)){
                return;
            }
            long start = Instant.now().toEpochMilli();
            // 模拟发送
            // resulDto = this.mockSendHttp(sms);
            ResultDto resulDto = execute(task);
            long end = Instant.now().toEpochMilli();
            PerformUtil.logTime("execute-"+task.getTaskId(),start,end);

            // 3.重试准备,先检查是否命中重试规则
            boolean retry = retryStrategyService.isNeedRetry(resulDto.getSysCode(),task.getRetryStrategy());
            if(retry){
                retryPrepare(resulDto,task);
            }

            // 4.其他工作
            afterExecute(resulDto);
        }catch(HystrixRuntimeException e){
            log.error("[runtask]任务执行发生异常:",e.getMessage(),e);
            ResultDto dto = ResultDto.builder()
                    .sysCode(-3)
                    .sysMessage("HystrixRuntimeException")
                    .taskId(task.getTaskId())
                    .timestamp(Instant.now().toEpochMilli())
                    .build();
            afterExecute( dto);
        }catch (Exception e){
            log.error("[runtask]任务执行发生异常:",e.getMessage(),e);
            ResultDto dto = ResultDto.builder()
                    .taskId(task.getTaskId())
                    .sysCode(-1)
                    .sysMessage("Exception")
                    .timestamp(Instant.now().toEpochMilli())
                    .build();
            afterExecute( dto);
        }
    }


    /**
     * 重试相关工作
     * @param resulDto
     * @param task
     */
    protected abstract void retryPrepare(ResultDto resulDto, TaskDto task);


    /**
     * 过滤器集合
     * @param task
     */
    public boolean beforeExecute(TaskDto task){

        List<Filter> filters = filterManager.getFilters();
        if(CollectionUtils.isEmpty(filters)){
            return true;
        }
        for(Filter filter : filters){
            boolean isContinue = filter.doFilter(task);
            if(!isContinue){
                return isContinue;
            }
        }
        return true;
    }



    /**
     * 调用供应商的接口
     * @param sms
     * @return
     */
    public abstract ResultDto execute(TaskDto sms);


    /**
     * 发送供应商后的收尾工作
     * 0.设置号码和md5(内容)到redis中,用作判重  同步处理
     * 1.上报监控系统kafka  同步处理
     * 2.更新库表发送状态  送进kafka后续处理
     * 3.回调上游服务  kafka通知 不再搞http回调
     */
    public void afterExecute(ResultDto dto){
        // 上报监控系统
        reportToSentry(dto);
        // 发送到kafka 供后续耗时处理
        kafkaService.sendToResultTopic(dto);
        // finishWorker.push(dto);
    }




    /**
     * 上报数据给监控系统
     * @param dto
     */
    public void reportToSentry(ResultDto dto) {
        EventDto eventDto = EventDto.builder()
                .metric("httptask_execute_status_total")
                .time(dto.getTimestamp())
                .value(1)
                .addLabel("status",0 == dto.getSysCode()?"success":"failure")
                // 是否是重试
                .addLabel("isretry",0 == dto.getRetryNo()?"N":"Y")
                .build();
        sentryReport.incrCounter(eventDto);
    }


}
