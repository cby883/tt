package com.zuzuche.task.worker;

import com.google.common.util.concurrent.RateLimiter;
import com.lmax.disruptor.BlockingWaitStrategy;
import com.lmax.disruptor.dsl.ProducerType;
import com.zuzuche.task.dto.HttpResultDto;
import com.zuzuche.task.dto.ResultDto;
import com.zuzuche.task.entity.RetryTaskResult;
import com.zuzuche.task.mapper.RetryTaskResultMapper;
import com.zuzuche.task.service.TaskResultService;
import com.zuzuche.threadpool.ThreadPoolExecutorFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.util.CallerBlocksPolicy;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * 每个worker内置了disruptor做内存队列
 * 重试的结果队列,直接采用内存队列处理了
 * @author pan
 */
@Slf4j
@Component
public class RetryResultWorker<T> extends AbstractWorker<T> {

    /**
     * 限速 保护db
     */
    private static RateLimiter rateLimiter = RateLimiter.create(15);

    @Autowired
    RetryTaskResultMapper retryTaskResultMapper;


    /**
     * 可以在这里修改disruptor队列相关配置
     */
    public RetryResultWorker() {
        super(
                WorkerConfig.builder()
                .bufferSize(1024)
                .producerType(ProducerType.MULTI)
                .strategy(new BlockingWaitStrategy())
                .consumeExecutor(ThreadPoolExecutorFactory.create(
                        ThreadPoolExecutorFactory.Config.builder()
                                .corePoolSize(2)
                                .maximumPoolSize(4)
                                .keepAliveTime(5)
                                .workQueue(new SynchronousQueue<>())
                                .unit(TimeUnit.MINUTES)
                                .handler(new ThreadPoolExecutor.CallerRunsPolicy())
                                .threadPoolName("retryResultDisruptorConsume-pool")
                                .build()))
                .build()
        );
    }


    /**
     * 重试结果处理
     * 如果成功,入库重试表,
     * 如果失败,判断是否需要重新发到重试准备队列
     * @param object
     */
    @Override
    public void consume(T object){
        rateLimiter.acquire();
        HttpResultDto dto = (HttpResultDto)object;

        //保存重试结果
        RetryTaskResult retryTaskResult = RetryTaskResult.builder()
                .resultContent(dto.getResultContent())
                .retryNo(dto.getRetryNo())
                .taskId(dto.getTaskId())
                .createTime(LocalDateTime.now())
                .httpCode(dto.getHttpCode())
                .sysCode(dto.getSysCode())
                .sysMessage(dto.getSysMessage())
                .timeCost(dto.getTimeCost())
                .build();
        retryTaskResultMapper.insert(retryTaskResult);

    }




}
