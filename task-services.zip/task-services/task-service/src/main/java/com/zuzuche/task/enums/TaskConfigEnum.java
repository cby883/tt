package com.zuzuche.task.enums;

import com.zuzuche.commons.base.constants.BaseEnum;

/**
 * desc:速率配置枚举类
 *
 * @author keriezhang
 * @date 2016/10/31
 */
public enum TaskConfigEnum implements BaseEnum<Integer> {
    /**
     * 普通队列配置key
     */
    COMMONS_RATE(1,"http_task_common_topic"),
    /**
     * 优先队列配置Key
     */
    HIGH_RATE(2,"http_task_high_topic"),
    /**
     * 结果队列配置key
     */
    RESULT_RATE(3,"task_execute_result_topic"),
    /**
     * 重试队列配置Key
     */
    RETRY_RATE(4,"task_retry_prepare_topic");
    int code;
    String topicName;
    private TaskConfigEnum(int code,String topicName){
        this.code=code;
        this.topicName=topicName;
    }
    public String topicName(){
        return topicName;
    }
    @Override
    public Integer code() {
        return code;
    }}
