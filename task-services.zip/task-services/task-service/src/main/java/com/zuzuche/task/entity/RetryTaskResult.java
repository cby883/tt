package com.zuzuche.task.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Table;
import java.time.LocalDateTime;

/**
 * @desc: 重试结果记录
 * @author: pan
 * @date: 2019-01-14
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "retry_task_result")
public class RetryTaskResult {
    private int id;

    private long taskId;

    private int httpCode;

    private int sysCode;

    private String sysMessage;

    private long timeCost;

    private LocalDateTime createTime;

    private LocalDateTime updateTime;

    private int retryNo;

    private String resultContent;

}