package com.zuzuche.task.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "http_task_log")
public class HttpTaskLog {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    
    private long taskId;

    private int typeId;

    private String url;

    private String method;

    private String params;

    private int priority;

    private int retryStrategy;

    private int retryMaxCount;

    private LocalDateTime createTime;


}