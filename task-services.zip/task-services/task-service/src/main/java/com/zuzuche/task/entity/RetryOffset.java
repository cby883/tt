package com.zuzuche.task.entity;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Table;

/**
 * @desc: 保存重试表的offset偏移量
 * @author: pan
 * @date: 2019-01-14
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "retry_offset")
public class RetryOffset {

    private int id;
    /**
     * key
     */
    private String offsetKey;
    /**
     * 对应 retry_task_plan_hour表的id
     */
    private Integer offsetValue;


}