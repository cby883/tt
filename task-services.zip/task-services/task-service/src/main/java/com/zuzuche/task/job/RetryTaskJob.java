package com.zuzuche.task.job;

import com.zuzuche.commons.base.util.CollectionUtil;
import com.zuzuche.commons.redis.RedisLock;
import com.zuzuche.task.common.constant.Constants;
import com.zuzuche.task.entity.RetryOffset;
import com.zuzuche.task.entity.RetryTaskPlanHour;
import com.zuzuche.task.mapper.RetryOffsetMapper;
import com.zuzuche.task.mapper.RetryTaskPlanHourMapper;
import com.zuzuche.task.service.http.HttpRetryServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

/**
 * @desc: 重试执行job
 * @author: panqiong
 * @date: 2019-01-14
 */
@Component
@Slf4j
public class RetryTaskJob {
    private static String RETRY_TASK_LOCK_KEY = "TASK:RETRY_TASK_LOCK_KEY";
    @Autowired
    RetryTaskPlanHourMapper planHourMapper;

    @Autowired
    RetryOffsetMapper retryOffsetMapper;

    @Autowired
    HttpRetryServiceImpl httpRetryService;

    /**
     *  每30秒
     */
    @Scheduled(cron = "*/50 * * * * ?")
    public void execute(){
        RedisLock redisLock = new RedisLock(RETRY_TASK_LOCK_KEY);
        if(redisLock.lock()){
            // 获取到锁

            try{
                // 读取重发偏移量 假设偏移量为1 ,那么代表id为1的这条数据已经处理,所以取新数据应该是 id>1
                RetryOffset offset = retryOffsetMapper.queryByOffsetKey(Constants.RETRY_HOUR_PLAN_OFFSET_KEY);

                int offsetValue = offset.getOffsetValue();

                // 读取重试计划表数据
                List<RetryTaskPlanHour> planList = planHourMapper.poll(offsetValue,100, LocalDateTime.now());
                // 没有计划任务 直接返回
                if(CollectionUtil.isEmpty(planList)){
                    return;
                }
                // 处理这批次重试计划
                httpRetryService.executeRetry(planList);
                // 更新重发偏移量
                ///int maxId = planList.stream().max(Comparator.comparing(RetryTaskPlanHour::getId)).get().getId();
                //int maxId = planList.stream().map(e->e.getId()).max(Integer::max).get();
                int maxId = planList.stream().mapToInt(RetryTaskPlanHour::getId).max().getAsInt();

                retryOffsetMapper.commitOffsetValue(Constants.RETRY_HOUR_PLAN_OFFSET_KEY,maxId);

            }catch (Exception e){
                log.error("[RetryTaskJob]处理异常:",e.getMessage(),e);
            }finally {
                redisLock.unlock();
            }



        }

    }


    public static void main(String[] args) {

        List<Integer> intlist = Arrays.asList(1,2,3,4,5,6);
        int maxId1 = intlist.stream().max(Integer::max).get();
        System.out.println("maxId1 = " + maxId1);


        int maxId = intlist.stream().mapToInt(Integer::intValue).max().getAsInt();
        System.out.println("maxId = " + maxId);

        int maxid = intlist.stream().max(Comparator.comparing(Integer::intValue)).get();
        System.out.println("maxId = " + maxId);
        System.out.println("maxid = " + maxid);

    }
}
