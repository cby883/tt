package com.zuzuche.task.common.constant;

import com.zuzuche.commons.base.constants.BaseEnum;

/**
 * @desc:
 * @author: panqiong
 * @date: 2018/10/24
 */
public class Constants {

    public static String RETRY_HOUR_PLAN_OFFSET_KEY = "retry_hour_plan_offset_key";


    /**
     * 发送供应商编码
     */
    public enum OutboundState implements BaseEnum<String> {
        成功("0"),

        异常("-1"),

        被过滤器拦截("-2");

        private String code;

        OutboundState(String code) {
            this.code = code;
        }

        @Override
        public String code() {
            return code;
        }

    }



}
