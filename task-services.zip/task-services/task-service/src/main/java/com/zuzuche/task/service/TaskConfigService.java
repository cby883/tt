package com.zuzuche.task.service;

import com.zuzuche.commons.base.resp.RespResult;
import com.zuzuche.task.dto.ResultDto;
import com.zuzuche.task.enums.TaskConfigEnum;
import org.apache.ibatis.annotations.Param;

import java.time.LocalDateTime;

/**
 * @desc: 更新配置运行速率
 *
 * @author: chen
 * @date: 2018/12/17
 */
public interface TaskConfigService {

    /**
     * desc:根据configKey做速率更新
     * @param configKey
     * @param configValue
     * @return
     */
    boolean updateByConfigKey(@Param("configKey") String configKey,@Param("configValue") int configValue);

    /**
     * desc:更新速率
     * @param taskConfigEnum
     * @param rate
     * @return
     */
    void updateRate(TaskConfigEnum taskConfigEnum,int rate);
}
