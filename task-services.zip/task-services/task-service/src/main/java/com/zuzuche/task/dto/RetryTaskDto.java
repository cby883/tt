package com.zuzuche.task.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * @desc: 重试dto父类
 * @author: panqiong
 * @date: 2019-01-15
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class RetryTaskDto {

    /**
     * 任务id
     */
    private long taskId;

    /**
     * 执行结果
     */
    private int sysCode;

    /**
     * 执行结果
     */
    private String sysMessage;

    /**
     * 重试策略 0:不重试 1 立即重试1次 其他四位数代表重试策略 如1001
     */
    private int retryStrategy;
    /**
     * 重试最大次数
     */
    private int retryMaxCount;
    /**
     * 重试时间
     */
    private LocalDateTime retryTime;

    /**
     * 已重试次数 默认0开始
     */
    private int retryNo;


}
