package com.zuzuche.task.service;

import com.zuzuche.task.dto.ResultDto;
import com.zuzuche.task.entity.HttpTaskResult;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @desc: 任务执行结果处理服务
 *
 * @author: panqiong
 * @date: 2018/12/17
 */
public interface TaskResultService {

    /**
     * 处理
     * @param resultDto
     */
    void process(ResultDto resultDto);

    /*
    根据状态和时间区间查询结果表
     */
    List<HttpTaskResult> queryBySysCodeAndTime(int sysCode,String beginTime, String endTime);
}
