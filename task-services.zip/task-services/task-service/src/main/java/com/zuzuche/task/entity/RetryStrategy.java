package com.zuzuche.task.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Table;
import java.time.LocalDateTime;

/**
 * @desc: 重试策略
 * @author: pan
 * @date: 2019-01-14
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "retry_strategy")
public class RetryStrategy {
    private int id;

    private int intervalSec;

    private int maxCount;

    private String hitTerm;

    private LocalDateTime createTime;

    private LocalDateTime updateTime;

    private int validState;


}