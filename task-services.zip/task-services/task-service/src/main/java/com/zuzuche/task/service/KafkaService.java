package com.zuzuche.task.service;

import com.zuzuche.task.dto.HttpRetryTaskDto;
import com.zuzuche.task.dto.ResultDto;
import com.zuzuche.task.dto.RetryTaskDto;
import com.zuzuche.task.dto.TaskDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import java.time.Instant;

/**
 * @desc: kafka相关处理
 * @author: panqiong
 * @date: 2018/10/25
 */
@Service

@Slf4j
public class KafkaService {


    /**
     * 普通优先级任务队列
     */
    public static final String HTTP_TASK_COMMON_TOPIC = "http_task_common_topic";

    /**
     * 高优先级任务队列
     */
    public static final String HTTP_TASK_HIGH_TOPIC = "http_task_high_topic";


    /**
     * 任务执行结果队列
     */
    public static final String TASK_EXECUTE_RESULT_TOPIC= "task_execute_result_topic";


    /**
     * 重试准备队列
     */
    public static final String TASK_RETRY_PREPARE_TOPIC= "task_retry_prepare_topic";




    @Autowired
    KafkaTemplate kafkaTemplate;


    /**
     * 执行结果
     * @param resultDto
     */
    public void sendToResultTopic(ResultDto resultDto){

        kafkaTemplate.send(TASK_EXECUTE_RESULT_TOPIC,resultDto);
    }

    /**
     * 发送到重试队列
     * @param retryTaskDto
     */
    public void sendToRetryQueue(RetryTaskDto retryTaskDto){
        kafkaTemplate.send(TASK_RETRY_PREPARE_TOPIC,retryTaskDto);
    }


}
