package com.zuzuche.task.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.HashMap;

/**
 * @desc:
 * @author: panqiong
 * @date: 2018-12-18
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class HttpTaskDto extends TaskDto{
    /**
     * http 调用url
     */
    private String url;
    /**
     * http方法
     */
    private String method;
    /**
     * http调用参数
     */
    private HashMap params;

}
