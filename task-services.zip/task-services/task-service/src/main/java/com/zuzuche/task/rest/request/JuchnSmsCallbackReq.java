package com.zuzuche.task.rest.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @desc: 巨辰短信上行回调接口
 * @author: panqiong
 * @date: 2018/10/17
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class JuchnSmsCallbackReq {


    private List<Uplink> uplinks;



    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class Uplink {
        private String port;
        private String phone;
        private String accesscode;
        private String msg;
    }
}
