package com.zuzuche.task.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Table;
import java.time.LocalDateTime;

/**
 * @desc: 重试计划表 小时间隔
 * @author: pan
 * @date: 2019-01-14
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "retry_task_plan_hour")
public class RetryTaskPlanHour {
    private int id;

    private String taskId;

    private LocalDateTime retryTime;

    private LocalDateTime createTime;

    private int retryStrategy;

    private int retryNo;

}