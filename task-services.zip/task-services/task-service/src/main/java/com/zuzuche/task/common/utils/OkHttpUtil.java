package com.zuzuche.task.common.utils;

import com.zuzuche.commons.base.util.JsonUtil;
import okhttp3.*;
import okhttp3.FormBody.Builder;
import org.apache.commons.collections.MapUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.Assert;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * 功能：HTTP请求的工具类 <br/>
 * 详细：实现 HTTP GET，HTTP POST 请求
 * 异常抛出去,自行处理
 */
public class OkHttpUtil {

	private static final Logger logger = LoggerFactory.getLogger(com.zuzuche.commons.base.util.OkHttpUtil.class);

	private static final OkHttpClient httpClient;

	/**
	 * 默认的 user-agent
	 */
	public static final String USER_AGENT = "Mozilla/5.0 (Windows; U; Windows NT 5.1; zh-CN; rv:1.9.2) Gecko/20100115 Firefox/3.6";

	/**
	 * 实现默认的编码
	 */
	public static final String DEFAULT_CHARSET = "utf-8";

	private static final Map<String, String> DEFAULT_HEADERS = new HashMap<>(4);

	static {
		httpClient = new OkHttpClient.Builder()
				.connectTimeout(10, TimeUnit.SECONDS)
				.readTimeout(30, TimeUnit.SECONDS)
				.writeTimeout(30, TimeUnit.SECONDS)
				.followRedirects(true)
				.followSslRedirects(true)
				.connectionPool(new ConnectionPool())
				.build();

		DEFAULT_HEADERS.put("User-agent", USER_AGENT);
		DEFAULT_HEADERS.put("Connection", "close");
	}

	/**
	 * 用 UTF-8 编码进行 HTTP GET 请求
	 * 
	 * @param url
	 *            地址，不能为空
	 * @return
	 */
	public static Response get(String url) throws IOException{
		return get(url, DEFAULT_CHARSET, null, DEFAULT_HEADERS);
	}

	public static Response post(String url) throws IOException{
		return postForm(url, DEFAULT_CHARSET, null, DEFAULT_HEADERS);
	}
	
	/**
	 *  post  application-type =application/x-www-form-urlencoded
	 * @param url
	 * @param params
	 * @return
	 */
	public static Response post(String url, Map<String, String> params) throws IOException{
		return postForm(url, DEFAULT_CHARSET, params, DEFAULT_HEADERS);
	}
	
	
	/**
	 * post  application-type = application/json
	 * @param url
	 * @param params
	 * @return
	 */
	public static Response postJson(String url, Object params) throws IOException{
		return postJson(url, DEFAULT_CHARSET, params, DEFAULT_HEADERS);
	}
	
	
	
	/**
	 * 用 UTF-8 编码进行 HTTP GET 请求
	 *
	 * @param url
	 *            地址
	 * @param params
	 *            参数表，不能为空
	 * @return
	 */
	public static Response get(String url, Map<String, String> params)throws IOException {
		return get(url, DEFAULT_CHARSET, params, DEFAULT_HEADERS);
	}

	/**
	 * 用 UTF-8 编码进行 HTTP GET 请求
	 *
	 * @param url
	 *            地址
	 *            参数表，不能为空
	 * @return
	 */
	public static Response getWithHeaders(String url, Map<String, String> headers)throws IOException {
		return get(url, DEFAULT_CHARSET, null, headers);
	}

	/**
	 * 实现 HTTP GET
	 * 
	 * @param url
	 *            地址，不能为空
	 * @param charset
	 *            编码，比如 utf-8，不能为空
	 * @param params
	 *            参数表，可以为null或empty
	 * @param headers
	 *            HTTP HEADER 参数表，可以为null
	 * @return
	 */
	private static Response get(String url, String charset, Map<String, ?> params, Map<String, String> headers) throws IOException{
		Assert.notNull(url, "url不能为空");
		String fullUrl = contactUrl(url, charset, params);
		Request.Builder builder = new Request.Builder();
		builder.get().url(fullUrl);
		if (headers != null && headers.size() > 0) {
			for (Map.Entry<String, String> entry : headers.entrySet()) {
				builder.addHeader(entry.getKey(), entry.getValue());
			}
		}
		Request request = builder.build();
		Call call = httpClient.newCall(request);

		Response response = call.execute();

		return response;
	}
	
	/**
	 * 实现 HTTP POST
	 * 
	 * @param url
	 *            地址，不能为空
	 * @param charset
	 *            编码，比如 utf-8，不能为空
	 * @param params
	 *            参数表，可以为null或empty
	 * @param headers
	 *            HTTP HEADER 参数表，可以为null
	 * @return
	 */
	private static Response postJson(String url, String charset, Object params, Map<String, String> headers) throws IOException{
		Assert.notNull(url, "url不能为空");
		// 把请求的内容字符串转换为json
		RequestBody body = RequestBody.create(MediaType.parse("application/json; charset=utf-8"), JsonUtil.objToStr(params));
		// RequestBody formBody = new FormEncodingBuilder()
		Request request = new Request.Builder().url(url).post(body).build();
		Response response = httpClient.newCall(request).execute();

		return response;


	}
	
	/**
	 * 实现 HTTP POST
	 * 
	 * @param url
	 *            地址，不能为空
	 * @param charset
	 *            编码，比如 utf-8，不能为空
	 * @param params
	 *            参数表，可以为null或empty
	 * @param headers
	 *            HTTP HEADER 参数表，可以为null
	 * @return
	 */
	private static Response postForm(String url, String charset, Map<String, ?> params, Map<String, ?> headers) throws IOException{
		Assert.notNull(url, "url不能为空");
		Builder builder = new Builder();
		if (MapUtils.isNotEmpty(params)) {
			params.forEach((k, v) -> builder.add(k, String.valueOf(v)));
		}
		FormBody formBody = builder.build();
		Request request = new Request.Builder().url(url).post(formBody).build();

		Response response = httpClient.newCall(request).execute();

		return response;
	}

	/**
	 * 将 params 参数拼接到指定url上
	 *
	 * @param url
	 *            URL，不能为空
	 * @param charset
	 *            编码，比如 utf-8，不能为空
	 * @param params
	 *            参数表，可以为空
	 * @return
	 */
	private static  String contactUrl(String url, String charset, Map<String, ?> params) throws UnsupportedEncodingException {
		if (params == null || params.isEmpty()) {
			return url;
		}
		StringBuilder result = new StringBuilder(128);
		result.append(url);
		if (url.indexOf("?") < 0) {
			result.append("?");
		}
		for (Map.Entry<String, ?> entry : params.entrySet()) {
			result.append(entry.getKey()).append("=").append(URLEncoder.encode(String.valueOf(entry.getValue()), charset)).append("&");
		}

		result.setLength(result.length() - 1);
		return result.toString();
	}

}
