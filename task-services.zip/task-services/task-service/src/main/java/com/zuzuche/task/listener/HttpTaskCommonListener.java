package com.zuzuche.task.listener;

import com.google.common.util.concurrent.RateLimiter;
import com.zuzuche.commons.base.util.JsonUtil;
import com.zuzuche.logback.util.MDCUtil;
import com.zuzuche.task.cache.TaskConfigCache;
import com.zuzuche.task.cache.TaskTypeCache;
import com.zuzuche.task.dto.HttpTaskDto;
import com.zuzuche.task.enums.TaskConfigEnum;
import com.zuzuche.task.executors.CommonExecutor;
import com.zuzuche.task.service.KafkaService;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;
import java.util.concurrent.RejectedExecutionException;

/**
 * @desc: 常规任务
 * @author: panqiong
 * @date: 2018/11/8
 */
@Component
@Slf4j
public class HttpTaskCommonListener implements InitializingBean {


    private static RateLimiter rateLimiter ;


    @Autowired
    KafkaService kafkaService;

    @Autowired
    TaskTypeCache taskTypeCache;


    @Autowired
    CommonExecutor commonExecutor;

    @Autowired
    TaskConfigCache configCache;

    /**
     * 注意:
     *  - 如果消息处理超时,spring默认最多会重新处理三次
     *  - 如果对消息保障性要求高,发生异常要预警,可以把处理失败的消息转发到dlq队列
     *  - 优雅退出应用,不然会可能丢失已消费未处理的消息
     * 短信下发队列
     * @param consumer
     */
    @KafkaListener(topics = KafkaService.HTTP_TASK_COMMON_TOPIC)
    public void consume(ConsumerRecord<String, String> consumer) {
        MDCUtil.set();
        if(log.isDebugEnabled()){
            log.debug("[receive http_task_common_topic]:" +consumer.value());
        }
        rateLimiter.acquire();

        try{

            // 1个短信实体
            HttpTaskDto sms = JsonUtil.stringToObj(consumer.value(),HttpTaskDto.class);
            // 下行业务处理
            commonExecutor.handle(sms);

        }catch (RejectedExecutionException e){
            log.error("[拒绝策略触发-http_task_common_topic]message:"+consumer.value(),e.getMessage(),e);
            // 发送到dlq队列 并预警人工接入
            //kafkaService.sendToDlq(consumer.value());
        }catch (Exception e){
            // 发送到dlq队列 并预警人工接入
            log.error("[处理出现异常-http_task_common_topic]message:"+consumer.value(),e.getMessage(),e);
            //kafkaService.sendToDlq(consumer.value());
        }finally {
            MDCUtil.clear();
        }


    }



    @Override
    public void afterPropertiesSet() throws Exception {
        reload();
    }
    public void reload() {
        if(configCache.containsKey(TaskConfigEnum.COMMONS_RATE.topicName())){
            int rate = configCache.get(TaskConfigEnum.COMMONS_RATE.topicName());
            rateLimiter = RateLimiter.create(rate);
        }else{
            // 默认速度
            rateLimiter = RateLimiter.create(50);
        }
    }
}
