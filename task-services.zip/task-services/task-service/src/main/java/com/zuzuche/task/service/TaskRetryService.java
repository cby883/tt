package com.zuzuche.task.service;

import com.zuzuche.task.dto.RetryTaskDto;
import com.zuzuche.task.dto.TaskDto;
import com.zuzuche.task.entity.RetryTaskPlanHour;
import org.springframework.stereotype.Service;

import java.util.List;


/**
 * @desc: 重试任务服务类
 * @author: panqiong
 * @date: 2019-01-14
 */
public interface TaskRetryService {


    /**
     * 目前重试只需要支持以小时为单位
     * @param retryDto
     */
    void createRetryPlan(RetryTaskDto retryDto);

    /**
     * 执行重试
     * @param planList
     */
    void executeRetry(List<RetryTaskPlanHour> planList);
}
