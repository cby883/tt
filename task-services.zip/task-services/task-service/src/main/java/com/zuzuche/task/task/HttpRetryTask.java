package com.zuzuche.task.task;

import com.zuzuche.commons.base.util.JsonUtil;
import com.zuzuche.commons.base.util.StringUtil;
import com.zuzuche.task.dto.HttpResultDto;
import com.zuzuche.task.dto.HttpRetryTaskDto;
import com.zuzuche.task.entity.HttpTaskLog;
import com.zuzuche.task.entity.RetryTaskPlanHour;
import com.zuzuche.task.mapper.HttpTaskLogMapper;
import com.zuzuche.task.remote.HttpInvoker;
import com.zuzuche.task.remote.dto.InvokeStats;
import com.zuzuche.task.remote.dto.InvokerInfo;
import com.zuzuche.task.service.KafkaService;
import com.zuzuche.task.service.RetryStrategyService;
import com.zuzuche.task.worker.RetryResultWorker;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import java.time.Instant;
import java.util.HashMap;

/**
 * @desc: 重试
 * @author: panqiong
 * @date: 2019-01-14
 */
@Slf4j
@Component("HttpRetryTask")
@Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class HttpRetryTask implements Runnable{

    @Autowired
    HttpInvoker httpInvoker;

    @Autowired
    HttpTaskLogMapper httpTaskLogMapper;

    RetryTaskPlanHour planTask;

    @Autowired
    RetryResultWorker worker;

    @Autowired
    RetryStrategyService retryStrategyService;

    @Autowired
    KafkaService kafkaService;


    HttpRetryTask(RetryTaskPlanHour planTask){
        this.planTask = planTask;
    }



    @Override
    public void run() {
        // 查询原始任务参数
        HttpTaskLog originTask = httpTaskLogMapper.queryByTaskId(planTask.getTaskId());

        // 准备调用参数
        HashMap param = null;
        if(StringUtil.isNotEmpty(originTask.getParams())){
            param = JsonUtil.stringToObj(originTask.getParams(),HashMap.class);
        }
        InvokerInfo invoker = InvokerInfo.builder()
                .url(originTask.getUrl())
                .params(param)
                .method(originTask.getMethod())
                .build();
        // 调用接口
        InvokeStats result = httpInvoker.invoke(invoker);

        // 封装重试结果对象
        HttpResultDto resultDto = formHttpResultDto(originTask, result);

        // 判断是否失败,失败的话 ,是否需要再转发到task_retry_prepare_topic
        int retryNo = planTask.getRetryNo();
        boolean retry = retryStrategyService.isNeedRetry(result.getSysCode(),planTask.getRetryStrategy(),retryNo);
        if(retry){
            // 封装重试实体转发到重试计划队列
            HttpRetryTaskDto retryTaskDto = new HttpRetryTaskDto();
            retryTaskDto.setTaskId(originTask.getTaskId());
            retryTaskDto.setRetryMaxCount(originTask.getRetryMaxCount());
            retryTaskDto.setRetryStrategy(originTask.getRetryStrategy());
            retryTaskDto.setSysCode(resultDto.getSysCode());
            retryTaskDto.setSysMessage(resultDto.getSysMessage());

            retryTaskDto.setRetryNo(retryNo);
            kafkaService.sendToRetryQueue(retryTaskDto);
        }

        // 重试结果入队内存队列 用于保存重试结果
        // 如果队列满 阻塞
        worker.push(resultDto);


    }

    private HttpResultDto formHttpResultDto(HttpTaskLog originTask, InvokeStats result) {
        HttpResultDto resultDto = new HttpResultDto();
        // 重试次数编号
        resultDto.setRetryNo(planTask.getRetryNo());
        resultDto.setSysCode(result.getSysCode());
        resultDto.setSysMessage(result.getSysMessage());
        resultDto.setTaskId(originTask.getTaskId());
        resultDto.setTimeCost(result.getTimeCost());
        resultDto.setTimestamp(Instant.now().toEpochMilli());
        resultDto.setTypeId(originTask.getTypeId());
        resultDto.setResultContent(result.getResult());
        return resultDto;
    }
}
