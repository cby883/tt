package com.zuzuche.task.rest.response;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @desc: 推送用户状态报告实体
 * @author: panqiong
 * @date: 2018/10/24
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ApiModel(value = "推送用户状态报告")
public class PushStatusRsp {
    @ApiModelProperty(value = "报告id",required = false)
    private int reportId;

    @ApiModelProperty(value = "任务id",required = false)
    private String taskId;

    @ApiModelProperty(value = "手机号码",required = false)
    private String mobile;

    @ApiModelProperty(value = "1:已投递用户  2:投递出现其它状况",required = false)
    private String status;

}
