package com.zuzuche.task.service;

import com.google.common.base.Splitter;
import com.zuzuche.task.cache.RetryStrategyCache;
import com.zuzuche.task.dto.ResultDto;
import com.zuzuche.task.dto.TaskDto;
import com.zuzuche.task.entity.RetryStrategy;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @desc:
 * @author: panqiong
 * @date: 2019-01-15
 */
@Service
@Slf4j
public class RetryStrategyService {

    @Autowired
    RetryStrategyCache retryStrategyCache;

    /**
     * 是否需要重试
     * @param sysCode
     * @param retryStrategyId
     * @return
     */
    public boolean isNeedRetry(int sysCode, int retryStrategyId,int retryNo){
        // 执行成功的 无需重试直接返回
        if(sysCode == 0 ){
            return false;
        }
        // 0 不重试
        if(retryStrategyId == 0 ){
            return false;
        }

        // 判断是否命中策略中的term
        RetryStrategy retryStrategy = retryStrategyCache.getById(retryStrategyId);
        // 无匹配的策略
        if(retryStrategy == null){
            log.error("[isNeedRetry]重试策略不存在 id:"+retryStrategyId);
            return false;
        }

        if(retryNo >= retryStrategy.getMaxCount()){
            log.error("[isNeedRetry]已到最大重试次数 id:"+retryStrategyId);
            return false;
        }

        List<String> termList = Splitter.on(",").splitToList(retryStrategy.getHitTerm());
        if(termList.contains(String.valueOf(sysCode))){
            return true;
        }else{
            return false;
        }
    }

    /**
     * 是否需要重试
     * @param sysCode
     * @param retryStrategyId
     * @return
     */
    public boolean isNeedRetry(int sysCode, int retryStrategyId){
        return this.isNeedRetry(sysCode,retryStrategyId,0);
    }
}
