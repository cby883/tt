package com.zuzuche.task.task;

import com.zuzuche.task.dto.*;
import com.zuzuche.task.remote.HttpInvoker;
import com.zuzuche.task.remote.dto.InvokeStats;
import com.zuzuche.task.remote.dto.InvokerInfo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.time.Instant;


/**
 * @desc: http调用任务
 *        原型模式
 * @author: panqiong
 * @date: 2018/10/26
 */
@Slf4j
@Component("HttpInvokeTask")
@Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class HttpInvokeTask extends AbstractAsynTask {


    @Autowired
    HttpInvoker httpInvoker;

    HttpInvokeTask(TaskDto task) {
        super(task);
    }

    /**
     * 命中了重试规则 才会调用
     * 这里都是首次准备重试
     * 准备重试的工作
     * @param resulDto
     * @param task
     */
    @Override
    protected void retryPrepare(ResultDto resulDto, TaskDto task) {
        HttpTaskDto taskDto = (HttpTaskDto)task;
        // 封装重试相关转发到重试队列
        HttpRetryTaskDto retryTaskDto = new HttpRetryTaskDto();
//        retryTaskDto.setMethod(taskDto.getMethod());
//        retryTaskDto.setParams(taskDto.getParams());
//        retryTaskDto.setUrl(taskDto.getUrl());

        retryTaskDto.setTaskId(task.getTaskId());
        retryTaskDto.setRetryMaxCount(taskDto.getRetryMaxCount());
        retryTaskDto.setRetryStrategy(task.getRetryStrategy());

        retryTaskDto.setSysCode(resulDto.getSysCode());
        retryTaskDto.setSysMessage(resulDto.getSysMessage());

        retryTaskDto.setRetryNo(0);
        kafkaService.sendToRetryQueue(retryTaskDto);
        
    }



    /**
     * 过滤器链
     */
    @Override
    public boolean beforeExecute(TaskDto task) {
        return super.beforeExecute( task);
    }

    /**
     * 发送给供应商
     */
    @Override
    public HttpResultDto execute(TaskDto task){

        HttpTaskDto taskDto = (HttpTaskDto)task;

        InvokerInfo invoker = InvokerInfo.builder()
                .url(taskDto.getUrl())
                .params(taskDto.getParams())
                .method(taskDto.getMethod())
                .build();
        // 调用接口
        InvokeStats result = httpInvoker.invoke(invoker);

        // 封装返回对象
        HttpResultDto resultDto = new HttpResultDto();
        resultDto.setRetryNo(task.getRetryNo());
        resultDto.setSysCode(result.getSysCode());
        resultDto.setSysMessage(result.getSysMessage());
        resultDto.setTaskId(task.getTaskId());
        resultDto.setTimeCost(result.getTimeCost());
        resultDto.setTimestamp(Instant.now().toEpochMilli());
        resultDto.setTypeId(task.getTypeId());
        resultDto.setResultContent(result.getResult());
        return resultDto;


    }


}
