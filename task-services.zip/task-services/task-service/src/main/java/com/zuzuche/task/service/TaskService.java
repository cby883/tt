package com.zuzuche.task.service;

import com.zuzuche.commons.base.resp.RespResult;
import com.zuzuche.commons.base.resp.Status;
import com.zuzuche.commons.base.resp.StatusServiceCnException;
import com.zuzuche.commons.base.util.JsonUtil;
import com.zuzuche.commons.base.util.StringUtil;
import com.zuzuche.commons.redis.SnowflakeIdUtil;
import com.zuzuche.task.dto.HttpTaskDto;
import com.zuzuche.task.rest.request.TaskReq;
import com.zuzuche.task.rest.response.TaskResp;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Service;
import org.springframework.util.concurrent.ListenableFuture;

import java.util.HashMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

/**
 * @desc:
 * @author: panqiong
 * @date: 2019-10-11
 */
@Service
@Slf4j
public class TaskService {
    @Autowired
    KafkaTemplate<String, String> kafkaTemplate;

    @Autowired
    SnowflakeIdUtil snowflakeIdUtil;


    public RespResult<TaskResp> send(TaskReq req) {
        long taskId = snowflakeIdUtil.nextId();

        HashMap params = null;
        if(StringUtil.isNotEmpty(req.getParams())){
            params = JsonUtil.stringToObj(req.getParams(),HashMap.class);
        }


        HttpTaskDto taskDto = new HttpTaskDto();
        taskDto.setMethod(req.getMethod());
        taskDto.setParams(params);
        taskDto.setPriority(req.getPriority());
        taskDto.setRetryMaxCount(req.getRetryMaxCount());
        taskDto.setRetryStrategy(req.getRetryStrategy());
        taskDto.setUrl(req.getUrl());
        taskDto.setTaskId(taskId);
        taskDto.setTypeId(req.getTypeId());


        //默认普通队列
        String topicName = KafkaService.HTTP_TASK_COMMON_TOPIC;
        //高优先级队列
        if(req.getPriority()==1){
            topicName = KafkaService.HTTP_TASK_HIGH_TOPIC;
        }


        // 送进kafka 根据mobile选择分区
        ListenableFuture<SendResult<String, String>> future =  kafkaTemplate.send(topicName,String.valueOf(taskId), JsonUtil.objToStr(taskDto));

        try {
            future.get(5, TimeUnit.SECONDS);
            /// log.info("[synsend推送结果]:"+sendResult.toString());
        } catch (InterruptedException e) {
            log.error("[synsend推送kafka异常]:",e.getMessage(),e);
            throw new StatusServiceCnException(Status.BUSY,"推送入队发生异常 InterruptedException");
        } catch (ExecutionException e) {
            log.error("[synsend推送kafka异常]:",e.getMessage(),e);
            throw new StatusServiceCnException(Status.BUSY,"推送入队发生异常 ExecutionException");
        } catch (TimeoutException e){
            log.error("[synsend推送kafka异常]:",e.getMessage(),e);
            throw new StatusServiceCnException(Status.BUSY,"推送入队发生异常 TimeoutException");
        }
        // 同步入队 并返回taskId
        return RespResult.success(new TaskResp(taskId));
    }
}
