package com.zuzuche.task.mapper;

import com.zuzuche.commons.mybatis.BaseMapper;
import com.zuzuche.task.entity.RetryTaskResult;
import org.springframework.stereotype.Repository;

/**
 * @desc:
 * @author: pan
 * @date: 2019-01-14
 */
@Repository
public interface RetryTaskResultMapper extends BaseMapper<RetryTaskResult> {

}