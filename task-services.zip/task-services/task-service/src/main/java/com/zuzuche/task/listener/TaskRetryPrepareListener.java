package com.zuzuche.task.listener;

import com.google.common.util.concurrent.RateLimiter;
import com.zuzuche.logback.util.MDCUtil;
import com.zuzuche.task.cache.TaskConfigCache;
import com.zuzuche.task.dto.RetryTaskDto;
import com.zuzuche.task.enums.TaskConfigEnum;
import com.zuzuche.task.service.KafkaService;
import com.zuzuche.task.service.TaskRetryService;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import java.util.concurrent.RejectedExecutionException;

/**
 * 失败的任务如果重试策略不为0的 ,会直接发到这个topic
 * 在这里进行重试策略逻辑,消费这个消息创建重试时间计划
 * @desc: 失败的任务需要重试
 * @author: panqiong
 * @date: 2019-01-14
 */
@Component
@Slf4j
public class TaskRetryPrepareListener implements InitializingBean {

    private static RateLimiter rateLimiter = RateLimiter.create(15);


    @Autowired
    TaskRetryService taskRetryService;

    @Autowired
    TaskConfigCache configCache;

    @KafkaListener(topics = KafkaService.TASK_RETRY_PREPARE_TOPIC)
    public void consume(ConsumerRecord<String, RetryTaskDto> consumer) {
        MDCUtil.set();
        if(log.isDebugEnabled()){
            log.debug("[receive task_retry_queue_topic]:" +consumer.value());
        }
        rateLimiter.acquire();
        try{
            RetryTaskDto retryDto = consumer.value();

            // 创建重试计划
            taskRetryService.createRetryPlan(retryDto);

        }catch (RejectedExecutionException e){
            log.error("[拒绝策略触发-task_retry_prepare_topic]message:"+consumer.value(),e.getMessage(),e);
            // 发送到dlq队列 并预警人工接入
        }catch (Exception e){
            // 发送到dlq队列 并预警人工接入
            log.error("[处理出现异常-task_retry_prepare_topic]message:"+consumer.value(),e.getMessage(),e);
        }

        MDCUtil.clear();
    }

    @Override
    public void afterPropertiesSet() throws Exception {
       reload();
    }

    public void reload() {
        if(configCache.containsKey(TaskConfigEnum.RETRY_RATE.topicName())){
            int rate = configCache.get(TaskConfigEnum.RETRY_RATE.topicName());
            rateLimiter = RateLimiter.create(rate);
        }else{
            // 默认速度
            rateLimiter = RateLimiter.create(50);
        }
    }
}
