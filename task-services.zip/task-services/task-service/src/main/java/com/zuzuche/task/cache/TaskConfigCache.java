package com.zuzuche.task.cache;

import com.google.common.collect.Maps;
import com.zuzuche.commons.base.resp.Status;
import com.zuzuche.commons.base.resp.StatusServiceCnException;
import com.zuzuche.task.entity.TaskConfig;
import com.zuzuche.task.mapper.TaskConfigMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
/**
 *
 * @author bingyi
 * @date 2019/08/13
 */
@Component
@Slf4j
public class TaskConfigCache implements InitializingBean {

    @Autowired
    TaskConfigMapper taskConfigMapper;
    private static Map<String,Integer> configMap=new HashMap<>(16);

    @Override
    public void afterPropertiesSet() throws Exception {
          load();
    }

    public boolean containsKey(String key){
        return configMap.containsKey(key);
    }

    public int get(String key){
        return configMap.get(key);
    }
    /**
     * 载入配置到内存
     */
    private void load(){
        log.info("[初始化本地缓存TaskConfigCache] ");
        List<TaskConfig> list = taskConfigMapper.selectAll();
        if(CollectionUtils.isEmpty(list)){
            log.error("[重要] 没有配置队列运行速率配置!!!");
            throw new StatusServiceCnException(Status.OBJECT_NOT_EXIST,"[重要] 没有配置队列运行速率配置!!!");
        }
        list.stream().forEach(e->configMap.put(e.getConfigKey(),e.getConfigValue()));
    }

    public boolean setConfigValue(String configKey,int configValue){
        if(!configMap.containsKey(configKey)){
            return false;
        }
        try {
            configMap.put(configKey,configValue);
            return true;
        }catch (Exception e){
            log.error("【taskConfigCache】队列运行速率设置错误");
            return false;
        }

    }
}
