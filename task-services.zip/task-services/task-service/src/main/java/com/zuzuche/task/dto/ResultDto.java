package com.zuzuche.task.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @desc: 任务执行结果
 * @author: panqiong
 * @date: 2018/10/27
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ResultDto {

    private long taskId;
    private int typeId;
    private int sysCode;
    private String sysMessage;
    private long timeCost;
    private long timestamp;
    /**
     * 默认0 表示首次调用 1表示第一次重试
     */
    private int retryNo;

}
