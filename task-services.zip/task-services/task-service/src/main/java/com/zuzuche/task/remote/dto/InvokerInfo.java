package com.zuzuche.task.remote.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.HashMap;

/**
 * @desc: http调用参数
 * @author: panqiong
 * @date: 2019-01-15
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class InvokerInfo {
    /**
     * http 调用url
     */
    private String url;
    /**
     * http方法
     */
    private String method;
    /**
     * http调用参数
     */
    private HashMap params;
}
