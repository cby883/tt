package com.zuzuche.task.mapper;

import com.zuzuche.commons.mybatis.BaseMapper;
import com.zuzuche.task.entity.RetryStrategy;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @desc:
 * @author: pan
 * @date: 2019-01-14
 */
@Repository
public interface RetryStrategyMapper extends BaseMapper<RetryStrategy> {

    List<RetryStrategy> queryAll();
}