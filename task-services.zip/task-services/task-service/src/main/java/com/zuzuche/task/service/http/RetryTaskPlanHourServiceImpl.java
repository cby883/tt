package com.zuzuche.task.service.http;

import com.zuzuche.commons.base.util.CollectionUtil;
import com.zuzuche.task.entity.RetryTaskPlanHour;
import com.zuzuche.task.mapper.RetryTaskPlanHourMapper;
import com.zuzuche.task.service.RetryOffsetService;
import com.zuzuche.task.service.RetryTaskPlanHourService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Slf4j
@Service
public class RetryTaskPlanHourServiceImpl implements RetryTaskPlanHourService {
    @Autowired
    RetryTaskPlanHourMapper retryTaskPlanHourMapper;
    @Autowired
    RetryOffsetService retryOffsetService;
    @Override
    public void batchInsertRetry(List<RetryTaskPlanHour> retryTaskPlanHours) {
        if(CollectionUtil.isEmpty(retryTaskPlanHours)){
            return ;
        }else{

            /*
            装载计划表中不重复的任务到内存中
             */
            List<RetryTaskPlanHour> retryLoad=new ArrayList<>();

            /*
            根据offset和taskId来移除重试计划表中重复的task
             */
            for(RetryTaskPlanHour retryTaskPlanHour:retryTaskPlanHours){
                if(CollectionUtil.isEmpty(retryTaskPlanHourMapper.isExist(retryOffsetService.qryValueByOffsetKey("retry_hour_plan_offset_key"),retryTaskPlanHour.getTaskId()))){
                    retryLoad.add(retryTaskPlanHour);
                }
            }
            /*
            移除完后进行插入操作
             */
            if(CollectionUtil.isEmpty(retryLoad)) {
                return ;
            }
            retryTaskPlanHourMapper.batchinsertRetry(retryLoad);

        }
    }
}
