package com.zuzuche.task.mapper;

import com.zuzuche.task.entity.TaskConfig;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;
import tk.mybatis.mapper.common.BaseMapper;

import java.time.LocalDateTime;
/**
 *
 * @author bingyi
 * @date 2019/08/13
 */
@Repository
public interface TaskConfigMapper extends BaseMapper<TaskConfig> {

    /**
     * 查询
     * @param configKey
     * @return
     */
    TaskConfig queryOffset(@Param("configKey") String configKey);

    /**
     *desc:
     * @param configKey
     * @param configValue
     * @param updateTime
     * @return
     */
    int updateByConfigKey(@Param("configKey") String configKey,@Param("configValue") int configValue, @Param("updateTime") LocalDateTime updateTime);
}
