package com.zuzuche.task.remote;

import com.zuzuche.task.remote.dto.InvokeStats;
import com.zuzuche.task.remote.dto.InvokerInfo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;

import java.net.SocketTimeoutException;
import java.nio.charset.Charset;
import java.time.Instant;
import java.util.Arrays;

/**
 * @desc:
 * @author: panqiong
 * @date: 2018-12-18
 */
@Component
@Slf4j
public class HttpInvoker extends AbstractHttpInvoke{
    /**
     * 额外的header设置 比如编码
     *
     * @param header
     */
    @Override
    protected void setHeader(HttpHeaders header) {
        header.setAcceptCharset(Arrays.asList(Charset.forName("UTF-8")));
        header.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        header.set(HttpHeaders.COOKIE,"allow_test_ip=1,header_code=1");
    }



    public InvokeStats invoke(InvokerInfo invoker){
        InvokeStats stats = InvokeStats.builder().build();
        long start = Instant.now().toEpochMilli();

        try {
            if(HttpMethod.GET.name().equalsIgnoreCase(invoker.getMethod())){
                // get方法调用
                //String reslt = super.get(taskDto.getUrl(),taskDto.getParams());
                //String reslt = super.getExchange(taskDto.getUrl());
                String reslt = super.get(invoker.getUrl());
                stats.setResult(reslt);
            }else {
                // 默认以post方法
                String reslt = super.postForm(invoker.getUrl(),invoker.getParams());
                stats.setResult(reslt);
            }
            stats.setSysCode(0);
            stats.setSysMessage("成功");
        }catch (HttpClientErrorException e){
            stats.setSysCode(e.getStatusCode().value());
            stats.setSysMessage("http状态码异常");
            log.error("[invoke error]",e.getMessage(),e);
        }catch(SocketTimeoutException e){
            stats.setSysCode(-2);
            stats.setSysMessage("接口调用超时");
            log.error("[invoke error]",e.getMessage(),e);
        }catch (Exception e){
            stats.setSysCode(-1);
            stats.setSysMessage("接口调用异常");
            log.error("[invoke error]",e.getMessage(),e);
        }
        long end = Instant.now().toEpochMilli();
        stats.setTimeCost(end-start);

        return stats;
    }


}
