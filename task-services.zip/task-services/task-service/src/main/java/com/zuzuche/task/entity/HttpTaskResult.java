package com.zuzuche.task.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Table;
import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "http_task_result")
public class HttpTaskResult {
    private int id;

    private long taskId;

    private int httpCode;

    private int sysCode;

    private String sysMessage;

    private String resultContent;

    private long timeCost;

    private LocalDateTime createTime;

    private LocalDateTime updateTime;

    private int retryNo;

}