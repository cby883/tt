package com.zuzuche.task.service.http;

import com.zuzuche.task.entity.RetryOffset;
import com.zuzuche.task.mapper.RetryOffsetMapper;
import com.zuzuche.task.service.RetryOffsetService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class RetryOffsetServiceImpl implements RetryOffsetService {
    @Autowired
    RetryOffsetMapper retryOffsetMapper;
    /*
    根据偏移键key查询偏移值value
     */
    @Override
    public int qryValueByOffsetKey(String offsetKey) {
        int retryOffset1=0;
        retryOffset1=retryOffsetMapper.selectByOffset(offsetKey);
        return retryOffset1;
    }
}
