package com.zuzuche.task.executors;

import com.zuzuche.task.cache.TaskTypeCache;
import com.zuzuche.task.common.utils.SpringBeanFactory;
import com.zuzuche.task.dto.TaskDto;
import com.zuzuche.task.task.AbstractAsynTask;
import com.zuzuche.threadpool.ThreadPoolExecutorFactory;
import org.springframework.integration.util.CallerBlocksPolicy;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.TimeUnit;

/**
 * @desc: 重试线程池
 * @author: panqiong
 * @date: 2019-01-14
 */
public class RetryExecutor extends AbstractExecutor {

    public RetryExecutor(){
        super(
                ThreadPoolExecutorFactory.Config.builder()
                        .corePoolSize(10)
                        .maximumPoolSize(20)
                        .keepAliveTime(2)
                        .workQueue(new ArrayBlockingQueue<>(100))
                        .unit(TimeUnit.MINUTES)
                        .handler(new CallerBlocksPolicy(600*1000))
                        .threadPoolName("commonExecutor")
                        .build()
        );
    }



    /**
     *
     * @param task
     */
    @Override
    public AbstractAsynTask packingThreadTask(TaskDto task) {
        // 获取一个实例化的原型任务对象 这里要根据任务类型取对应的任务
        String taskClazz = TaskTypeCache.getTaskClazz(task.getTypeId());
        AbstractAsynTask invokeTask = (AbstractAsynTask) SpringBeanFactory.getBean(taskClazz,task);
        return invokeTask;
    }
}
