package com.zuzuche.task.mapper;

import com.zuzuche.commons.mybatis.BaseMapper;
import com.zuzuche.task.entity.HttpTaskLog;
import org.springframework.stereotype.Repository;

/**
 * http任务日志
 * @author pan
 */
@Repository
public interface HttpTaskLogMapper extends BaseMapper<HttpTaskLog> {

    /**
     * 根据taskId查询
     * @param taskId
     * @return
     */
    HttpTaskLog queryByTaskId(String taskId);
}