package com.zuzuche.task.remote.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @desc: http调用结果
 * @author: panqiong
 * @date: 2018-12-18
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class InvokeStats {
    private int sysCode;

    private String sysMessage;
    /**
     * 接口相应结果
     */
    private String result;
    /**
     * 接口耗时 毫秒
     */
    private long timeCost;



}
