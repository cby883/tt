package com.zuzuche.task.executors;

import com.zuzuche.commons.base.resp.Status;
import com.zuzuche.commons.base.resp.StatusServiceCnException;
import com.zuzuche.commons.base.util.CollectionUtil;
import com.zuzuche.commons.base.util.JsonUtil;
import com.zuzuche.commons.redis.SnowflakeIdUtil;
import com.zuzuche.task.dto.HttpTaskDto;
import com.zuzuche.task.dto.TaskDto;
import com.zuzuche.task.entity.HttpTaskLog;
import com.zuzuche.task.mapper.HttpTaskLogMapper;
import com.zuzuche.task.task.AbstractAsynTask;
import com.zuzuche.threadpool.ThreadPoolExecutorFactory;
import io.swagger.models.HttpMethod;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.LocalDateTime;
import java.util.concurrent.*;

/**
 * @desc: 短信下行服务 模板模式抽象类
 * @author: panqiong
 * @date: 2018/10/25
 */
@Slf4j
public abstract class AbstractExecutor {


    @Autowired
    HttpTaskLogMapper taskLogMapper;
    /**
     * 线程池
     * 溢出策略 最长阻塞主线程60秒后抛出异常
     */
    private ExecutorService executorService ;

    @Autowired
    SnowflakeIdUtil snowflakeIdUtil;

    /**
     * @param confg
     */
    public AbstractExecutor(ThreadPoolExecutorFactory.Config confg){
        //初始化线程池
        executorService = ThreadPoolExecutorFactory.create(confg);

    }


    /**
     * 下行逻辑处理
     * 1.持久化数据,统一实现. 持久化数据放在主流程 .数据消费后尽快入库,增强可靠性 ,吞吐率不是重点,先保证可靠性.如果要提高吞吐能力,入库放在异步流程
     * 2.将短信包装成task
     * 3.提交task到线程池
     * @param taskDto
     */
    public void handle(TaskDto taskDto) throws RejectedExecutionException{
        if(taskDto.getTaskId()==0){
            // 设置taskid
            taskDto.setTaskId(snowflakeIdUtil.nextId());
        }
        // 同步保存db 没有做异步
        saveToDb(taskDto);
        // 将短信包装成线程任务 task
        AbstractAsynTask threadTask = packingThreadTask(taskDto);

        executorService.submit(threadTask);
    }



    /**
     * 保存至数据库
     * @param task
     */
    protected void saveToDb(TaskDto task) {
        // 如果是http调度任务
        if(task instanceof HttpTaskDto){
            HttpTaskDto taskDto = (HttpTaskDto)task;
            String pureUrl = taskDto.getUrl();
            String paramStr = "";
            //如果是get方法 截取param是保存
            if(HttpMethod.GET.name().equalsIgnoreCase(taskDto.getMethod())){
                if(taskDto.getUrl().contains("?")){
                    String[] urls = taskDto.getUrl().split("\\?");
                    pureUrl = taskDto.getUrl().split("\\?")[0];
                    if(urls.length>1){
                        paramStr = taskDto.getUrl().split("\\?")[1];
                    }
                }
            }else{
                if(CollectionUtil.isNotEmpty( taskDto.getParams())){
                    paramStr = JsonUtil.mapToString(taskDto.getParams());
                }
            }

            HttpTaskLog log = HttpTaskLog.builder()
                    .method(taskDto.getMethod())
                    .params(paramStr)
                    .priority(taskDto.getPriority())
                    .retryMaxCount(taskDto.getRetryMaxCount())
                    .retryStrategy(taskDto.getRetryStrategy())
                    .taskId(taskDto.getTaskId())
                    .createTime(LocalDateTime.now())
                    .url(pureUrl)
                    .build();
            taskLogMapper.insert(log);

        }else{
            throw new StatusServiceCnException(Status.OPERATION_NOT_SUPPORT,"不支持的task类型");
        }
    }

    /**
     * 打包发送任务  将sms包装成task
     * @param sms
     * @return 任务
     */
    public abstract AbstractAsynTask packingThreadTask(TaskDto sms);




    protected void printException(Runnable r, Throwable t) {
        if (t == null && r instanceof Future<?>) {
            try {
                Future<?> future = (Future<?>) r;
                if (future.isDone()){
                    future.get();
                }
            } catch (CancellationException ce) {
                t = ce;
            } catch (ExecutionException ee) {
                t = ee.getCause();
            } catch (InterruptedException ie) {
                Thread.currentThread().interrupt(); // ignore/reset
            }
        }
        if (t != null){
            log.error(t.getMessage(), t);
        }

    }


}
