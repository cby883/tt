package com.zuzuche.task.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Table;
import java.time.LocalDateTime;
/**
 *
 * @author bingyi
 * @date 2019/08/13
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "task_config")
public class TaskConfig {
    private String id;

    private String configKey;

    private int configValue;

    private LocalDateTime createTime;

    private LocalDateTime updateTime;

    private String remark;
}
