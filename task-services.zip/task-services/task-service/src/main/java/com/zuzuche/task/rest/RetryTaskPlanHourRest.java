package com.zuzuche.task.rest;

import com.zuzuche.commons.base.resp.RespResult;
import com.zuzuche.commons.base.util.CollectionUtil;
import com.zuzuche.task.entity.HttpTaskResult;
import com.zuzuche.task.entity.RetryTaskPlanHour;
import com.zuzuche.task.service.RetryTaskPlanHourService;
import com.zuzuche.task.service.TaskResultService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

/**
 * @desc: 重试计划接口
 * @author: bingyi
 */
@RestController
@RequestMapping("/retryTask")
@Slf4j
@Api(value = "retryTask", description = "重试任务计划", tags = {"retryTask"})
public class RetryTaskPlanHourRest {
    @Autowired
    RetryTaskPlanHourService retryTaskPlanHourService;
    @PostMapping("/insertRetryTaskList")
    @ApiOperation(value = "批量插入重试结果", notes = "批量插入重试结果")
    public RespResult batchInsertRetryList(@RequestBody List<RetryTaskPlanHour> retryTaskPlanHours){
        if(CollectionUtil.isEmpty(retryTaskPlanHours)){
            return RespResult.error("数据不能为空");
        }
        try {
            retryTaskPlanHourService.batchInsertRetry(retryTaskPlanHours);
            return RespResult.success();
        }catch (Exception e){
            log.error(e.getMessage());
            return RespResult.error(e.getMessage());
        }

    }

    @PostMapping("/insertRetryTask")
    @ApiOperation(value = "插入重试结果", notes = "插入单条重试结果")
    public RespResult batchInsertRetry(@RequestBody RetryTaskPlanHour retryTaskPlanHours){
        if(retryTaskPlanHours==null){
            return  RespResult.error("数据不能为空");
        }
        try {
            List<RetryTaskPlanHour> list=new ArrayList<>();
            list.add(retryTaskPlanHours);
            retryTaskPlanHourService.batchInsertRetry(list);
            return RespResult.success();
        }catch (Exception e){
            log.error(e.getMessage());
            return RespResult.error(e.getMessage());
        }

    }
}
