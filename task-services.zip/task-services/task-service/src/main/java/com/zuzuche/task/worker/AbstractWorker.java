package com.zuzuche.task.worker;

import com.lmax.disruptor.*;
import com.lmax.disruptor.dsl.Disruptor;
import com.lmax.disruptor.dsl.ProducerType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import reactor.core.Disposable;

import java.util.concurrent.*;

/**
 * 这个使用disruptor做queue
 * @author pan
 */
@Slf4j
public abstract class AbstractWorker<T> implements InitializingBean ,Disposable {

    private static final Logger logger = LoggerFactory.getLogger(AbstractWorker.class);

    protected Disruptor<Element> disruptor;

    /**
     * 消费阻塞策略
     */
    private  BlockingWaitStrategy strategy;

    /**
     * 消费者线程池
     */
    private ExecutorService consumeExecutor;

    /**
     * 队列大小
     */
    private  int bufferSize = 4096;

    /**
     * 生产者方式
     */
    private  ProducerType producerType;

    /**
     * 生产者的线程工厂
     */
    private ThreadFactory threadFactory = (runnable)->new Thread(runnable, "disrptProduceThread");

    /**
     *  RingBuffer生产工厂,初始化RingBuffer的时候使用
     *
     */
    private EventFactory<Element> factory = ()->  new Element();

    /**
     * 默认构造函数 指定默认的初始化策略
     */
    public AbstractWorker(WorkerConfig config){
        this.strategy = config.strategy;
        this.consumeExecutor  = config.consumeExecutor;
        this.bufferSize=config.bufferSize;
        this.producerType = config.producerType;
    }

    /**
     *  入队
     * @param t
     */
    public  void push(T t) {

        RingBuffer<Element> ringBuffer = disruptor.getRingBuffer();
        ringBuffer.publishEvent((event, sequence) -> event.setValue(t));
    }


    /**
     * 初始化diruptor
     * @return
     */
    private Disruptor initDisruptor(){


        disruptor = new Disruptor<>(factory, bufferSize, consumeExecutor);
        // 创建disruptor，采用多生产者模式
        disruptor = new Disruptor(factory, bufferSize, threadFactory, producerType, strategy);
        // 设置 处理Event的handler
        disruptor.handleEventsWith((element,sequence,endOfBatch)->{
            // logger.info("disruptor element: " + element.getValue());
            T dto = element.getValue();
            try {
                assert dto != null;
                consume(dto);
            } catch (Exception e) {
                logger.error("[handleEventsWith] Exception",e);
            } finally {

            }
        });

        return disruptor;
    }

    private void start(){
        // 启动disruptor的线程
        disruptor.start();
    }




    public void shutdown(){
        if(disruptor!=null){
            log.info("[DisruptorWorker]准备关闭处理程序,等待队列中剩余数据处理完成");
            disruptor.shutdown();
            log.info("[DisruptorWorker]disruptor已经关闭,准备关闭线程池");
            consumeExecutor.shutdown();
            log.info("[DisruptorWorker]disruptor消费线程池已经关闭");
        }

    }

    /**
     * 初始化
     * @throws Exception
     */
    @Override
    public void afterPropertiesSet() throws Exception {
        initDisruptor();
        start();
    }

    /**
     * 关闭前清理
     */
    @Override
    public void dispose() {
        shutdown();
    }

    @Override
    public boolean isDisposed() {
        return false;
    }

    /**
     * 队列占位元素对象
     */
    public class Element {
        private T value;

        public T getValue() {
            return value;
        }

        public Element setValue(T value) {
            this.value = value;
            return this;
        }
    }


    /**
     * 消费队列消息工作
     * @param dto
     */
    public abstract void consume(T dto);



    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class WorkerConfig{
        /**
         * 消费阻塞策略
         */
        private BlockingWaitStrategy strategy;
        /**
         * 消费线程池
         */
        private ExecutorService consumeExecutor;

        /**
         * 队列长度
         */
        private int bufferSize;

        /**
         * 生产类型
         */
        private ProducerType producerType;
    }

}
