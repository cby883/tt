package com.zuzuche.task.service.http;

import com.zuzuche.task.dto.HttpResultDto;
import com.zuzuche.task.dto.ResultDto;
import com.zuzuche.task.entity.HttpTaskResult;
import com.zuzuche.task.mapper.HttpTaskResultMapper;
import com.zuzuche.task.service.KafkaService;
import com.zuzuche.task.service.TaskResultService;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.List;

/**
 * @desc: http结果处理
 * @author: panqiong
 * @date: 2018-12-18
 */
@Slf4j
@Component
public class HttpResultServiceImpl implements TaskResultService {

    private static long expireTime = 24*60*60;

    @Autowired
    StringRedisTemplate redisTemplate;


    @Autowired
    KafkaService kafkaService;

    @Autowired
    HttpTaskResultMapper taskResultMapper;

    /**
     * 如果是首次调用结果 直接保存
     * 如果是重试调用结果 update
     * @param rdto
     */
    @Override
    public void process(ResultDto rdto) {
        try{
            HttpResultDto hdto = (HttpResultDto)rdto;
            if(rdto.getRetryNo()==0){
                HttpTaskResult result = HttpTaskResult.builder()
                        .sysCode(hdto.getSysCode())
                        .sysMessage(hdto.getSysMessage())
                        .httpCode(0)
                        .createTime(LocalDateTime.now())
                        .taskId(hdto.getTaskId())
                        .timeCost(hdto.getTimeCost())
                        .updateTime(LocalDateTime.now())
                        .resultContent(hdto.getResultContent())
                        .build();
                taskResultMapper.insert(result);
            }else{
                // 只更新这几个字段即可
                taskResultMapper.updateByTaskId(String.valueOf(hdto.getTaskId()), hdto.getSysCode(),  hdto.getSysMessage(),hdto.getRetryNo(),LocalDateTime.now());
            }

        }catch (Exception e){
            log.error("[HttpTaskResult-process]保存http任务处理结果异常:",e.getMessage(),e);
        }
    }

    @Override
    public List<HttpTaskResult> queryBySysCodeAndTime(int sysCode, String beginTime, String endTime) {
        return taskResultMapper.queryBySysCodeAndTime(sysCode,beginTime,endTime);
    }


}
