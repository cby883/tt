package com.zuzuche.task.mapper;

import com.zuzuche.commons.mybatis.BaseMapper;
import com.zuzuche.task.entity.HttpTaskResult;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

/**
 * 任务执行结果
 * @author pan
 */
@Repository
public interface HttpTaskResultMapper extends BaseMapper<HttpTaskResult> {

    /**
     * 根据taskId更新
     *
     * @param taskId
     * @param sysCode
     * @param sysMessage
     * @param retryNo
     * @param updateTime
     * @return
     */
    int updateByTaskId(@Param("taskId") String taskId, @Param("sysCode") int sysCode, @Param("sysMessage") String sysMessage, @Param("retryNo") int retryNo, @Param("updateTime") LocalDateTime updateTime);

    /**
     * 根据sysCode和时间区间查询
     * @return
     */
    List<HttpTaskResult> queryBySysCodeAndTime(@Param("sysCode") int sysCode,@Param("beginTime") String beginTime,@Param("endTime") String endTime);
}