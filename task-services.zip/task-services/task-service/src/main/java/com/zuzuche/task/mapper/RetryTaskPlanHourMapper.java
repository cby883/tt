package com.zuzuche.task.mapper;

import com.zuzuche.commons.mybatis.BaseMapper;
import com.zuzuche.task.entity.HttpTaskResult;
import com.zuzuche.task.entity.RetryTaskPlanHour;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

/**
 * @desc: 该表的数据retry_time是和id一样有序的,是按固定时间间隔为1小时的计划插入
 * @author: pan
 * @date: 2019-01-14
 */
@Repository
public interface RetryTaskPlanHourMapper extends BaseMapper<RetryTaskPlanHour> {

    /**
     * 取出时间到的执行的计划 主键id就是offset
     * @param beginId 偏移量
     * @param maxNum 一次取出的最大数量,但不一定会有这么多
     * @param nowTime 当前时间
     * @return
     */
    List<RetryTaskPlanHour> poll(@Param("beginId") int beginId, @Param("maxNum") int maxNum, @Param("nowTime") LocalDateTime nowTime);

    /*
    批量插入重试计划，自动更新重试时间
     */
    void batchinsertRetry(@Param("retryTaskPlanHours") List<RetryTaskPlanHour> retryTaskPlanHours);

    /*
    判断taskId是否已经存在于重试计划表中
     */
    List<RetryTaskPlanHour> isExist(@Param("offset") int offerset,@Param("taskId") String taskId);
}