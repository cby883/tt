package com.zuzuche.task.rest;

import com.zuzuche.commons.base.resp.RespResult;
import com.zuzuche.task.cache.RetryStrategyCache;
import com.zuzuche.task.cache.TaskConfigCache;
import com.zuzuche.task.cache.TaskTypeCache;
import com.zuzuche.task.enums.TaskConfigEnum;
import com.zuzuche.task.rest.response.PushStatusRsp;
import com.zuzuche.task.service.TaskConfigService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Update;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * @desc: 账户信息管理
 * @author: chen
 * @date: 2018/10/31
 */
@RestController
@RequestMapping("/taskConfig")
@Slf4j
@Api(value = "taskConfig", description = "加载运行速率", tags = {"taskConfig"})
public class TaskConfigRest {

    @Autowired
    TaskConfigService taskConfigService;
    @Autowired
    TaskConfigCache taskConfigCache;
    /**
     * 重新载入缓存
     * @param
     * @return
     */
    @GetMapping("/reloadCommonsLimiter")
    @ApiOperation(value = "重新加载普通队列运行速率", notes = "重新加载普通队列运行速率")
    public RespResult reloadCommonsRateLimiter(@ApiParam(value = "rate速率大于0")@RequestParam(value = "rate") int rate) {
         taskConfigService.updateRate(TaskConfigEnum.COMMONS_RATE,rate);
         return RespResult.success();
    }

    /**
     * 重新载入缓存
     * @param
     * @return
     */
    @GetMapping("/reloadHighLimiter")
    @ApiOperation(value = "重新加载优先队列运行速率", notes = "重新加载优先队列运行速率")
    public RespResult reloadHighRateLimiter(@ApiParam(value = "rate速率大于0")@RequestParam(value = "rate") int rate) {
        taskConfigService.updateRate(TaskConfigEnum.HIGH_RATE,rate);
        return RespResult.success();
    }

    /**
     * 重新载入缓存
     * @param
     * @return
     */
    @GetMapping("/reloadRetryLimiter")
    @ApiOperation(value = "重新加载重试队列运行速率", notes = "重新加载重试队列运行速率")
    public RespResult reloadRetryRateLimiter(@ApiParam(value = "rate速率大于0")@RequestParam(value = "rate") int rate) {
        taskConfigService.updateRate(TaskConfigEnum.RETRY_RATE,rate);
        return RespResult.success();
    }

    /**
     * 重新载入缓存
     * @param
     * @return
     */
    @GetMapping("/reloadResultLimiter")
    @ApiOperation(value = "重新加载结果队列运行速率", notes = "重新加载结果队列运行速率")
    public RespResult reloadResultRateLimiter(@ApiParam(value = "rate速率大于0")@RequestParam(value = "rate") int rate) {
         taskConfigService.updateRate(TaskConfigEnum.RESULT_RATE,rate);
         return RespResult.success();
    }
}
