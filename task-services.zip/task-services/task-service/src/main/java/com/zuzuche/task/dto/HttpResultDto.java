package com.zuzuche.task.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * @desc: http 任务执行结果
 * @author: panqiong
 * @date: 2018-12-18
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class HttpResultDto extends ResultDto {

    /**
     * http编码
     */
    private int httpCode;

    /**
     * 返回结果
     */
    private String resultContent;





}
