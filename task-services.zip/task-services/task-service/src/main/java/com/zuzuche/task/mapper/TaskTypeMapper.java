package com.zuzuche.task.mapper;

import com.zuzuche.commons.mybatis.BaseMapper;
import com.zuzuche.task.entity.TaskType;
import org.springframework.stereotype.Repository;

/**
 * 任务类型
 * @author pan
 */
@Repository
public interface TaskTypeMapper extends BaseMapper<TaskType> {

}