package com.zuzuche.task.executors;

import com.zuzuche.task.cache.TaskTypeCache;
import com.zuzuche.task.common.utils.SpringBeanFactory;
import com.zuzuche.task.dto.TaskDto;
import com.zuzuche.task.task.AbstractAsynTask;
import com.zuzuche.task.task.HttpInvokeTask;
import com.zuzuche.threadpool.ThreadPoolExecutorFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.integration.util.CallerBlocksPolicy;
import org.springframework.stereotype.Component;

import java.util.concurrent.*;

/**
 * @desc: 巨辰的工作线程池
 * @author: panqiong
 * @date: 2018/10/28
 */
@Component
@Slf4j
public class CommonExecutor extends AbstractExecutor {



    public CommonExecutor(){
        super(
                ThreadPoolExecutorFactory.Config.builder()
                .corePoolSize(20)
                .maximumPoolSize(25)
                .keepAliveTime(2)
                .workQueue(new ArrayBlockingQueue<>(100))
                .unit(TimeUnit.MINUTES)
                .handler(new CallerBlocksPolicy(600*1000))
                .threadPoolName("commonExecutor")
                .build()
        );
    }



    /**
     *
     * @param task
     */
    @Override
    public AbstractAsynTask packingThreadTask(TaskDto task) {
        // 获取一个实例化的原型任务对象 这里要根据任务类型取对应的任务
        String taskClazz = TaskTypeCache.getTaskClazz(task.getTypeId());
        AbstractAsynTask invokeTask = (AbstractAsynTask)SpringBeanFactory.getBean(taskClazz,task);
        return invokeTask;
    }
}
