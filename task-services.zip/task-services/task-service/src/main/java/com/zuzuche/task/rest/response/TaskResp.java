package com.zuzuche.task.rest.response;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @desc:
 * @author: panqiong
 * @date: 2018/9/26
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ApiModel(value = "短信下行响应")
public class TaskResp {

    /**
     * 任务id
     */
    @ApiModelProperty(value = "任务id,如果上游不传,则会默认生成一个",required = false)
    private long taskId;


}
