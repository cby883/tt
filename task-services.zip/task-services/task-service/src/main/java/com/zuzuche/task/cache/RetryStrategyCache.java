package com.zuzuche.task.cache;

import com.google.common.collect.Maps;
import com.zuzuche.commons.base.resp.Status;
import com.zuzuche.commons.base.resp.StatusServiceCnException;
import com.zuzuche.task.entity.RetryStrategy;
import com.zuzuche.task.entity.TaskType;
import com.zuzuche.task.mapper.RetryStrategyMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @desc: retry策略缓存
 * @author: panqiong
 * @date: 2019-01-14
 */
@Component
@Slf4j
public class RetryStrategyCache implements InitializingBean {
    @Autowired
    RetryStrategyMapper retryStrategyMapper;


    /***
     * key:accountId
     * value:账户信息
     */
    private static Map<Integer, RetryStrategy> map = new HashMap<>(16);



    public RetryStrategy getById(int id){
        if(map.containsKey(id)){
            return map.get(id);
        }
        return null;
    }

    /**
     * 载入配置到内存
     */
    private void load(){
        log.info("[初始化本地缓存retryStrategyCache] ");
        List<RetryStrategy> list = retryStrategyMapper.queryAll();
        if(CollectionUtils.isEmpty(list)){
            log.error("[重要] 没有配置重试策略!!!");
            throw new StatusServiceCnException(Status.OBJECT_NOT_EXIST,"[重要] 没有配置重试策略!!!");
        }
        map = Maps.uniqueIndex(list, e->e.getId());
    }

    public synchronized void reload(){
        this.load();
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        load();
    }
}
