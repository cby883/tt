package com.zuzuche.task.service;

public interface RetryOffsetService {
    int qryValueByOffsetKey(String OffsetKey);
}
