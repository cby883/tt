package com.zuzuche.task.service.http;

import com.zuzuche.task.cache.RetryStrategyCache;
import com.zuzuche.task.common.utils.SpringBeanFactory;
import com.zuzuche.task.dto.HttpRetryTaskDto;
import com.zuzuche.task.dto.RetryTaskDto;
import com.zuzuche.task.dto.TaskDto;
import com.zuzuche.task.entity.RetryStrategy;
import com.zuzuche.task.entity.RetryTaskPlanHour;
import com.zuzuche.task.mapper.RetryTaskPlanHourMapper;
import com.zuzuche.task.service.TaskRetryService;
import com.zuzuche.task.task.AbstractAsynTask;
import com.zuzuche.task.task.HttpRetryTask;
import com.zuzuche.threadpool.ThreadPoolExecutorFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * @desc:
 * @author: panqiong
 * @date: 2019-01-14
 */
@Service
@Slf4j
public class HttpRetryServiceImpl implements TaskRetryService {

    @Autowired
    RetryStrategyCache retryStrategyCache;

    @Autowired
    RetryTaskPlanHourMapper retryTaskPlanMapper;


    /**
     * 上行短信同步线程池
     * 溢出策略 最长阻塞主线程60秒后抛出异常
     */
    private static ExecutorService retryExecutor = ThreadPoolExecutorFactory.create(
            ThreadPoolExecutorFactory.Config.builder()
                    .corePoolSize(5)
                    .maximumPoolSize(5)
                    .keepAliveTime(5)
                    .workQueue(new ArrayBlockingQueue<>(100))
                    .unit(TimeUnit.MINUTES)
                    .handler(new ThreadPoolExecutor.CallerRunsPolicy())
                    .threadPoolName("httpTaskRetry")
                    .build());




    /**
     * 消费prepare topic 用于创建重试计划
     * 创建首次重试计划
     * @param retryDto
     */
    @Override
    public void createRetryPlan(RetryTaskDto retryDto){
        HttpRetryTaskDto retryTaskDto = (HttpRetryTaskDto)retryDto;
        // 立即重试 默认30秒后
        int strategyId = retryDto.getRetryStrategy();
        // 重试次数+1
        int retryNo = retryTaskDto.getRetryNo()+1;

        // 根据策略id查询具体的重试间隔
        RetryStrategy strategy = retryStrategyCache.getById(strategyId);
        if(strategy==null){
            log.error("[RetryStrategyCache]重试策略不存在 id:"+strategyId);
            return ;
        }
        // 重试间隔 秒
        int intervalSec = strategy.getIntervalSec();

        // 重试次数
        int maxCount = strategy.getMaxCount()<retryDto.getRetryMaxCount()?strategy.getMaxCount():retryDto.getRetryMaxCount();

        if(retryNo>maxCount){
            log.warn("[createRetryPlan]taskId:"+retryDto.getTaskId()+" 已经达到最大重试次数,不再创建下一次重试计划");
            return;
        }

        // 保存重试时间计划
        RetryTaskPlanHour plan = RetryTaskPlanHour.builder()
                .retryNo(retryNo)
                .retryStrategy(strategyId)
                .retryTime(LocalDateTime.now().plusSeconds(intervalSec))
                .createTime(LocalDateTime.now())
                .taskId(String.valueOf(retryTaskDto.getTaskId()))
                .build();
        retryTaskPlanMapper.insert(plan);
    }

    /**
     * 执行重试计划
     * 该方法由定时任务调用
     * @param planList
     */
    @Override
    public void executeRetry(List<RetryTaskPlanHour> planList) {
        planList.stream().forEach(plan->{
            HttpRetryTask retryTask =  SpringBeanFactory.getBean(HttpRetryTask.class,plan);
            retryExecutor.submit(retryTask);
        });
    }



}
