package com.zuzuche.task.cache;

import com.google.common.collect.Maps;
import com.zuzuche.commons.base.resp.Status;
import com.zuzuche.commons.base.resp.StatusServiceCnException;
import com.zuzuche.task.entity.TaskType;
import com.zuzuche.task.mapper.TaskTypeMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @desc: 任务类型缓存
 * @author: panqiong
 * @date: 2018/11/8
 */
@Component
@Slf4j
public class TaskTypeCache implements InitializingBean {


    @Autowired
    TaskTypeMapper mapper;

    /***
     * key:accountId
     * value:账户信息
     */
    private static Map<Integer, TaskType> taskMap = new HashMap<>(16);


    public static TaskType getByTypeId(int typeId){
        return taskMap.get(typeId);
    }

    public static String getTypeName(int typeId){
        if(taskMap.containsKey(typeId)){
            return taskMap.get(typeId).getTypeName();
        }else{
            throw new StatusServiceCnException(Status.OBJECT_NOT_EXIST,"typeID不存在:"+typeId);
        }
    }

    public static String getTaskClazz(int typeId){
        if(taskMap.containsKey(typeId)){
            return taskMap.get(typeId).getClazz();
        }else{
            throw new StatusServiceCnException(Status.OBJECT_NOT_EXIST,"typeID不存在:"+typeId);
        }
    }
    /**
     * 载入配置到内存
     */
    private void load(){
        log.info("[初始化本地缓存TaskTypeCache] ");
        List<TaskType> list = mapper.selectAll();
        if(CollectionUtils.isEmpty(list)){
            log.error("[重要] 没有配置任务处理类型!!!");
            throw new StatusServiceCnException(Status.OBJECT_NOT_EXIST,"[重要] 没有配置任务处理类型!!!");
        }
        taskMap = Maps.uniqueIndex(list, e->e.getId());
    }

    public synchronized void reload(){
        this.load();
    }



    @Override
    public void afterPropertiesSet() throws Exception {
        load();
    }
}
