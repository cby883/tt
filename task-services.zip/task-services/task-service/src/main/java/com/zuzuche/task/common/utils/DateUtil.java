package com.zuzuche.task.common.utils;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * @desc:
 * @author: panqiong
 * @date: 2018/8/29
 */
public class DateUtil {
    public static String pattern_1="yyyy-MM-dd HH:mm:ss";

    public static String pattern_2="yyyyMMddHHmmss";

    public static String pattern_3="yyMMddHHmmss";

    public static String getCurrentTime(String pattern){
        return LocalDateTime.now().format(DateTimeFormatter.ofPattern(pattern));
    }



}
