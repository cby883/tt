package com.zuzuche.task.filter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * @desc:
 * @author: panqiong
 * @date: 2018/10/26
 */
@Component
public class FilterManager {

    @Autowired(required = false)
    List<Filter> filters;

    /**
     * 获取所有过滤器
     * @return
     */
    public List<Filter> getFilters(){
//        Map<String,Filter> map = SpringBeanFactory.getBeansOfType(Filter.class);
//        List<Filter> filters = map.values().stream().collect(Collectors.toList());
        return filters;
    }
}
