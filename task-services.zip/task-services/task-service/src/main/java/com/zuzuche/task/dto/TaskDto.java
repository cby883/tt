package com.zuzuche.task.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @desc:
 * @author: panqiong
 * @date: 2018-12-18
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class TaskDto {
    /**
     * 任务id
     */
    private long taskId;

    /**
     * 任务类型id
     */
    private int typeId;


    private int priority;
    /**
     * 重试策略 0:不重试 1 立即重试1次 其他四位数代表重试策略 如1001
     */
    private int retryStrategy;
    /**
     * 重试最大次数
     */
    private int retryMaxCount;

    /**
     * 重试编码
     */
    private int retryNo;

}
