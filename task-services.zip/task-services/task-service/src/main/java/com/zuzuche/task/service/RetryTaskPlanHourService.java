package com.zuzuche.task.service;

import com.zuzuche.task.entity.RetryTaskPlanHour;

import java.util.List;

public interface RetryTaskPlanHourService {
    void batchInsertRetry(List<RetryTaskPlanHour> retryTaskPlanHours);
}
