package com.zuzuche.task.rest;

import com.zuzuche.commons.base.resp.RespResult;
import com.zuzuche.task.entity.HttpTaskResult;
import com.zuzuche.task.service.TaskResultService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @desc: 任务结果接口
 * @author: bingyi
 */
@RestController
@RequestMapping("/taskResult")
@Slf4j
@Api(value = "taskResult", description = "任务结果", tags = {"taskResult"})
public class TaskResultRest {
    @Autowired
    TaskResultService taskResultService;
    @PostMapping("/qryBySyscode")
    @ApiOperation(value = "根据状态查询任务运行结果集", notes = "时间区间格式为：yyyy-MM-dd HH-mm-sss,时间为空默认查询全部")
    public RespResult<List<HttpTaskResult>> queryBySysCodeAndTime(@RequestParam("sysCode") int sysCode, @RequestParam("beginTime") String beginTime, @RequestParam("endTime") String endTime){
        List<HttpTaskResult> list=null;
        list=taskResultService.queryBySysCodeAndTime(sysCode,beginTime,endTime);
        return RespResult.success(list);
    }
}
