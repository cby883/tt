package com.zuzuche;

import com.zuzuche.task.dto.HttpTaskDto;
import com.zuzuche.task.dto.TaskDto;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.apache.kafka.common.serialization.StringSerializer;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.HashMap;
import java.util.Properties;

/**
 * @desc:
 * @author: panqiong
 * @date: 2018/11/12
 */
public class TestProducer2 {
    public static KafkaProducer<String, TaskDto> producer = null;

    public static void main(String[] args) throws Exception {

        System.out.println("Press CTRL-C to stop generating data");


        // add shutdown hook
        Runtime.getRuntime().addShutdownHook(new Thread() {
            public void run() {
                System.out.println("Shutting Down");
                if (producer != null){
                    producer.close();
                }

            }
        });


        //JsonSerializer<SourceEvent> eventSerializer = new JsonSerializer<>();

        // Configuring producer
        Properties props = new Properties();

        props.put("bootstrap.servers", "192.168.100.96:9092");
        props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG,com.zuzuche.kafka.serializer.JsonSerializer.class);
        // Starting producer
        producer = new KafkaProducer<>(props);
        long iter = 1;
        // Start generating events, stop when CTRL-C
        long start = LocalDateTime.now().toEpochSecond(ZoneOffset.ofHours(8));
        long mobile = 12110001000l;
        while (iter<2) {
            iter= iter+2;
            String taskId = String.valueOf(iter);
            HashMap map = new HashMap();
            map.put("userId","jack");
            map.put("pwd","123456");
            HttpTaskDto task = new HttpTaskDto();
            task.setMethod("post");
            task.setParams(map);
            task.setPriority(2);
            task.setRetryMaxCount(3);
            task.setRetryStrategy(1);
            task.setUrl("www.baidu.com");

            ProducerRecord<String, TaskDto> record = new ProducerRecord("task_asyn_common_topic",task);

            producer.send(record, (RecordMetadata r, Exception e) -> {
//                System.out.println("record = " + record.toString());
                if (e != null) {
                    System.out.println("Error producing to topic " + r.topic());
                    e.printStackTrace();
                }
            });


            Thread.sleep(5);
        }
        long end = LocalDateTime.now().toEpochSecond(ZoneOffset.ofHours(8));
        System.out.println("end = " + (end-start));
    }
}
