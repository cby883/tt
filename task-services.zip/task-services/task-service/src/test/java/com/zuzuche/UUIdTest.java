package com.zuzuche;

import java.util.UUID;

/**
 * @desc:
 * @author: panqiong
 * @date: 2018/10/23
 */
public class UUIdTest {

    public static void main(String[] args) {
        String id = UUID.randomUUID().toString();
        String id2 = UUID.fromString("fuck").toString();
        System.out.println("id = " + id+" length:"+id.length());
        System.out.println("id2 = " + id+" length:"+id.length());
    }
}
