package com.zuzuche;
import com.zuzuche.task.entity.TaskConfig;
import com.zuzuche.task.mapper.TaskConfigMapper;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.sql.Time;
import java.time.LocalDateTime;

@RunWith(SpringRunner.class)
@SpringBootTest
public class TaskConfigTest {
//    @Autowired
//    TaskConfigMapper taskConfigMapper;
//    @Test
//    public void queryOffset(){
//           TaskConfig taskConfig=taskConfigMapper.queryOffset("aa");
//           System.out.println(taskConfig);
//    }
//    @Test
//    public void updateOffset(){
//           taskConfigMapper.updateOffset("aa","33", LocalDateTime.now());
//           System.out.println("测试成功");
//    }
}
