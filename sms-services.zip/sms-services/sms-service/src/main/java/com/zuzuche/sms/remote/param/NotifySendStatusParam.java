package com.zuzuche.sms.remote.param;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @desc: 通知上游短信业务服务发送供应商状态
 * @author: panqiong
 * @date: 2018/10/24
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class NotifySendStatusParam {

    @Builder.Default
    private String i = "SmsMt-upRequestStatusByTaskId";

    /**
     * md5
     */
    private String token;

    private String t;

    /**
     * 任务主键id
     */
    private String taskId;

    /**
     * 手机号码 ,号隔开
     */
    private String mobiles;

    /**
     * 提交到供应商的请求状态，1表示成功，2表示失败，3表示未请求
     */
    private String status;


}
