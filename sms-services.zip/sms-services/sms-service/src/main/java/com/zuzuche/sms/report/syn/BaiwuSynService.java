package com.zuzuche.sms.report.syn;

import com.zuzuche.sms.common.utils.PerformUtil;
import com.zuzuche.sms.entity.ProviderAccountInfo;
import com.zuzuche.sms.entity.SmsInbound;
import com.zuzuche.sms.entity.StatusReport;
import com.zuzuche.sms.remote.BaiwuPullApi;
import com.zuzuche.sms.remote.dto.PostDeliverMsgDto;
import com.zuzuche.sms.remote.dto.PostReportDto;
import com.zuzuche.sms.remote.param.PostDeliverMsgParam;
import com.zuzuche.sms.remote.param.PostReportParam;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @desc: 百唔的拉取服务
 * @author: panqiong
 * @date: 2018/11/7
 */
@Service("baiwuSynService")
@Slf4j
public class BaiwuSynService extends AbstractSynService {

    private static String PULL_NUM = "500";

    @Autowired
    BaiwuPullApi baiwuPullApi;

    @Override
    protected List<StatusReport> doInvokeStatusReportApi(ProviderAccountInfo account) {
        Integer accountId = account.getAccountId();
        String name = account.getAccountName();
        String pwd = account.getAccountPwd();
        PostReportParam param = PostReportParam.builder()
                .corpId(name)
                .userId(name)
                .corpPwd(pwd)
                .build();

        long start = Instant.now().toEpochMilli();
        PostReportDto dto = baiwuPullApi.postReport(param);
        if(log.isDebugEnabled()){
            log.debug("[response]"+dto.toString());
        }
        long end = Instant.now().toEpochMilli();
        PerformUtil.logTime("baiwuPullApi.postReport",start,end);
        if("0".equals(dto.getCode())) {
            if (CollectionUtils.isEmpty(dto.getReportList())) {
                log.warn("[BaiwuSynService]:accountName:" + account.getAccountName() + " 本次拉取List为空");
                return null;
            }
            log.info("[BaiwuSynService]:accountName:" + account.getAccountName() + " 拉取到状态记录 " + dto.getReportList().size() + " 条");

            List<StatusReport> list = dto.getReportList().stream()
                    .map(report ->
                            StatusReport.builder()
                                    .batchNo(report.getMsgId())
                                    .createTime(LocalDateTime.now())
                                    .phone(report.getMobile())
                                    .recvTime(report.getReportTime())
                                    .status(transfer(report.getErr()))
                                    .accountId(accountId)
                                    .build()
                    ).collect(Collectors.toList());
            return list;
        }
        return null;
    }

    /**
     * 转换成统一的成功标识
     * @param status
     * @return
     */
    private String transfer(String status){
        String sucCode1 = "0";
        String sucCode2 = "000";
        String success = "DELIVRD";
        if(sucCode1.equals(status)||sucCode2.equals(status)){
            return success;
        }else{
            return status;
        }

    }

    @Override
    protected List<SmsInbound> doInvokeInboundApi(ProviderAccountInfo account) {
        Integer accountId = account.getAccountId();
        String name = account.getAccountName();
        String pwd = account.getAccountPwd();
        PostDeliverMsgParam param = PostDeliverMsgParam.builder()
                .corpId(name)
                .userId(name)
                .corpPwd(pwd)
                .build();

        long start = Instant.now().toEpochMilli();
        PostDeliverMsgDto dto = baiwuPullApi.postDeliverMsg(param);
        if(log.isDebugEnabled()){
            log.debug("[response]"+dto.toString());
        }
        long end = Instant.now().toEpochMilli();
        PerformUtil.logTime("baiwuPullApi.postDeliverMsg",start,end);

        if("0".equals(dto.getCode())) {
            if(CollectionUtils.isEmpty(dto.getDeliverList())){
                log.debug("[BaiwuSynService]:accountName:"+account.getAccountName()+" 本次拉取List为空");
                return null;
            }
            log.info("[BaiwuSynService]:accountName:"+account.getAccountName()+" 拉取上行短信 "+dto.getDeliverList().size()+" 条");

            List<SmsInbound> list = dto.getDeliverList().stream()
                    .map(msg ->
                            SmsInbound.builder()
                                    .msg(msg.getContent())
                                    .createTime(LocalDateTime.now())
                                    .phone(msg.getMobile())
                                    .port(msg.getExt())
                                    .accountId(accountId)
                                    .build()
                    ).collect(Collectors.toList());

            return list;
            // 发送kafka队列 供上游需要订阅的服务收听
        }
        return null;
    }
}
