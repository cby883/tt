package com.zuzuche.sms.mapper;

import com.zuzuche.commons.mybatis.BaseMapper;
import com.zuzuche.sms.entity.SmsOutbound;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Set;

/**
 * The interface Sms outbound mapper.
 *
 * @author panqiong
 * @desc ~
 * @date 20181019
 */
@Repository
public interface SmsOutboundMapper extends BaseMapper<SmsOutbound> {
    /**
     * 更新发送记录
     *
     * @param batchNo    the batch no
     * @param respCode   the resp code
     * @param extra      the extra
     * @param taskId     the task id
     * @param accountId  the account id
     * @param updateTime the update time
     */
    int updateResultByTaskId(@Param("batchNo") String batchNo, @Param("respCode") String respCode, @Param("logId") String extra, @Param("taskId") String taskId, @Param("accountId") int accountId, @Param("updateTime")  LocalDateTime updateTime);


    /**
     * 根据batchNo查询
     *
     * @param batchNo the batch no
     * @return sms outbound
     */
    SmsOutbound queryByBatchNo(String batchNo);


    /**
     * 根据taskId查询
     *
     * @param taskId the task id
     * @return sms outbound
     */
    SmsOutbound queryByTaskId(String taskId);

    /**
     * 查询集合
     *
     * @param batchNoList the batch no list
     * @return list
     */
    List<SmsOutbound> queryByBatchNoList(@Param("batchNoList") Set<String> batchNoList);


    /**
     * 查询目前最大的TaskId
     *
     * @return long
     */
    long queryMaxTaskId();
}