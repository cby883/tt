package com.zuzuche.sms.remote.param;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @desc:
 * @author: panqiong
 * @date: 2018/11/12
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SendInterBatchParam {
    /**
     * 用户在253云通讯平台上申请的API账号
     */
    private String account;

    /**
     * 用户在253云通讯平台上申请的API账号对应的API密钥
     */
    private String password;

    /**
     * 短信内容。长度不能超过536个字符
     */
    private String msg;

    /**
     * 手机号码。多个手机号码使用英文逗号分隔
     */
    private String mobile;


    @Override
    public String toString() {
        return "SendInterBatchParam{" +
                "account='" + account + '\'' +
                ", msg='" + msg + '\'' +
                ", mobile='" + mobile + '\'' +
                '}';
    }
}
