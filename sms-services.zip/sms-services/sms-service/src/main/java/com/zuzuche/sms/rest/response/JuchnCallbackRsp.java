package com.zuzuche.sms.rest.response;

/**
 * @desc:
 * @author: panqiong
 * @date: 2018/10/17
 */

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class JuchnCallbackRsp {

    private int result;

}
