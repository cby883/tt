package com.zuzuche.sms.remote.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.checkerframework.common.value.qual.ArrayLen;

import java.util.List;

/**
 * @desc: 创蓝状态报告拉取
 * @author: panqiong
 * @date: 2018/11/12
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PullMoDto {
    /**
     * 请求状态。0成功，其他状态为失败
     */
    private String ret;
    private String error;
    private List<Mo> result;


    @Data
    @Builder
    @AllArgsConstructor
    @NoArgsConstructor
    public static class Mo{
        /**
         * 系统通道码
         */
        private String spCode;
        /**
         * 上行时间，格式yyMMddHHmm
         */
        private String moTime;
        /**
         * 上行内容
         */
        private String messageContent;
        /**
         * 运营商通道码
         */
        private String destCode;
        /**
         * 上行手机号码
         */
        private String mobile;

    }
}
