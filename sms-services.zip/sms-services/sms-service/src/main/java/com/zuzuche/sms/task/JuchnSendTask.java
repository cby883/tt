package com.zuzuche.sms.task;

import com.netflix.hystrix.exception.HystrixRuntimeException;
import com.zuzuche.sms.cache.ProviderAccountCache;
import com.zuzuche.sms.dto.InvokeResultDto;
import com.zuzuche.sms.dto.SmsDto;
import com.zuzuche.sms.entity.ProviderAccountInfo;
import com.zuzuche.sms.remote.JuchnPushApi;
import com.zuzuche.sms.remote.dto.ShortMessageDto;
import com.zuzuche.sms.remote.param.ShortMessageParam;
import com.zuzuche.sms.service.KafkaService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.web.client.ResourceAccessException;

import java.time.Instant;


/**
 * @desc: 巨辰的发送任务实现类
 * 原型模式
 * @author: panqiong
 * @date: 2018/10/26
 */
@Slf4j
@Component
@Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class JuchnSendTask extends AbstractSendTask {

    @Autowired
    JuchnPushApi pushApi;


    @Autowired
    KafkaService kafkaService;

    JuchnSendTask(SmsDto sms) {
        super(sms);
    }


    /**
     * 过滤器链
     */
    @Override
    public boolean beforeSend(SmsDto sms) {
        return super.beforeSend(sms);
    }

    /**
     * 发送给供应商
     */
    @Override
    public InvokeResultDto invokeApi(SmsDto sms) {
        // 取账号密码
        ProviderAccountInfo account = ProviderAccountCache.getAccountById(sms.getAccountId());
        ShortMessageParam param = ShortMessageParam.builder()
                .msg(sms.getContent())
                .needstatus("true")
                .username(account.getAccountName())
                .passwd(account.getAccountPwd())
                .phone(sms.getMobile())
                .build();


        // 调用推送接口 这个接口方法用hystrix包装
        ShortMessageDto  smdto = pushApi.shortMessage(param);


        // 封装返回对象
        InvokeResultDto resultDto = InvokeResultDto.builder()
                .bachNo(smdto.getBatchno())
                .extra(smdto.getLogid())
                .respCode(smdto.getRespcode())
                .taskId(sms.getTaskId())
                .mobiles(sms.getMobile())
                .md5Content(sms.getMd5Content())
                .timestamp(Instant.now().toEpochMilli())
                .providerId(account.getProviderId())
                .build();

        return resultDto;

    }


}
