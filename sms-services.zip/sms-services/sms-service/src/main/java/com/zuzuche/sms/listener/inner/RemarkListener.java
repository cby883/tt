package com.zuzuche.sms.listener.inner;

import com.google.common.util.concurrent.RateLimiter;
import com.zuzuche.logback.util.MDCUtil;
import com.zuzuche.sms.cache.SmsConfigCache;
import com.zuzuche.sms.dto.MtDto;
import com.zuzuche.sms.remote.IntersectionRemote;
import com.zuzuche.sms.remote.RemarkRemote;
import com.zuzuche.sms.remote.param.SendRemarkParam;
import com.zuzuche.sms.service.KafkaService;
import com.zuzuche.sms.service.SmsMtService;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * 功能：总备注消费监听器.
 * 详细：
 *
 * @author Created on 2019.03.15 by chaodian
 */
@Component
@Slf4j
public class RemarkListener implements InitializingBean {
    private static final String RATE_KEY = "remark_topic_rate";

    private static RateLimiter rateLimiter;

    @Autowired
    KafkaService kafkaService;

    @Autowired
    SmsConfigCache configCache;

    @Autowired
    SmsMtService smsMtService;

    @Autowired
    RemarkRemote remote;

    @KafkaListener(topics = KafkaService.REMARK_TOPIC)
    public void consume(ConsumerRecord<String, MtDto> consumer) {
        MDCUtil.set();
        if(log.isDebugEnabled()){
            log.debug("[receive remark_topic]:" +consumer.value());
        }

        rateLimiter.acquire();
        try {
            MtDto mtDto = consumer.value();
            Map<String, SendRemarkParam.SendRemarkItem> remarkMaps = smsMtService.genSmsRemark(mtDto);
            SendRemarkParam param = SendRemarkParam.builder()
                    .remarkMaps(remarkMaps)
                    .build();
            remote.addRemarkMulti(param);
        } catch (Exception e){
            // 发送到dlq队列 并预警人工接入
            log.error("[总备注消息处理出现异常-remark_topic_topic]message:"+consumer.value(),e.getMessage(),e);
        } finally {
            MDCUtil.clear();
        }
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        if(configCache.containsKey(RATE_KEY)){
            int rate = Integer.parseInt(configCache.get(RATE_KEY));
            rateLimiter = RateLimiter.create(rate);
        }else{
            // 默认速度
            rateLimiter = RateLimiter.create(5);
        }
    }


}
