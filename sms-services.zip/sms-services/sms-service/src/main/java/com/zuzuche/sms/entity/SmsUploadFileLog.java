package com.zuzuche.sms.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.integration.annotation.Default;

import javax.persistence.Id;
import javax.persistence.Table;
import java.time.LocalDateTime;
/**
 * desc:短信上传文件实体类
 *
 * @author bingyi
 * @date 2019/10/30
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
@Table(name = "zuzuche_sms_db.sms_upload_file_log")
public class SmsUploadFileLog {
    @Id
    private Integer id;

    private String saveUrl;

    private String suffix;

    private long fileSize;

    private LocalDateTime updateTime;

    private String updatePeople;

    private String tab;

    private LocalDateTime uploadTime;

    private String remark;

    private String creator;

    private int deleted;

    private String fileName;

    private String importPhoneBatch;

    /**
     * 文件的手机号条数
     */
    private int sendCount;
    /**
     * 保存在本地的文件名
     */
    private String saveFileName;

    /**
     * 是否在到数据库中有记录，0为已导入，1为未导入
     */
    private int recorded;

    /**
     * 短信文件的类型
     * 1短信数量大的且不带变量替换的
     * 2短信数量小的且带变量替换的
     */
    private int fileType;
}