package com.zuzuche.sms.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * 功能：The type Sms template text.
 * 详细：
 *
 * @author Created on 2019.02.14 by chaodian
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SmsTemplateText {
    /**
     * 语言版本
     */
    private String language;

    /**
     * 模板内容
     */
    private String content;
}