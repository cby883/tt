package com.zuzuche.sms.cache;

import com.google.common.collect.*;
import com.zuzuche.commons.base.resp.Status;
import com.zuzuche.commons.base.resp.StatusServiceCnException;
import com.zuzuche.sms.entity.ProviderAccountInfo;
import com.zuzuche.sms.mapper.ProviderAccountInfoMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import javax.annotation.concurrent.ThreadSafe;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;
import java.util.stream.Collectors;

/**
 * @desc: 供应商账户数据缓存 即配置信息 本地缓存
 * @author: panqiong
 * @date: 2018/10/22
 */
@Slf4j
@Component("ProviderAccountCache")
@ThreadSafe
public class ProviderAccountCache implements InitializingBean,ConfigCache {

    private ReentrantLock lock = new ReentrantLock();

    @Autowired
    ProviderAccountInfoMapper mapper;
    /***
     * key:accountId
     * value:账户信息
     */
    private static Map<Integer,ProviderAccountInfo> accountInfoMap = new HashMap<>(16);

    /**
     * key:providerId
     * value:账户列表List
     */
    private static ListMultimap<Integer,ProviderAccountInfo> providerListMap = ArrayListMultimap.create();

    /**
     *
     * @param accountId
     * @return
     */
    public static boolean contains(int accountId){
        return accountInfoMap.containsKey(accountId);
    }

    /**
     * 根据Id获取账户信息
     * @param accountId
     * @return
     */
    public static ProviderAccountInfo getAccountById(int accountId){
        return accountInfoMap.get(accountId);
    }

    /**
     * 根据Id获取账户信息
     * @param providerId
     * @return
     */
    public static List<ProviderAccountInfo> getListByProviderId(int providerId){
        return providerListMap.get(providerId);
    }

    /**
     * 返回整个账户列表
     * @return
     */
    public static ListMultimap<Integer,ProviderAccountInfo> getProviderListMap(){
        return providerListMap;
    }

    /**
     * 获取所有账户列表
     * @return
     */
    public static List<ProviderAccountInfo> getAllAccountList(){
        return accountInfoMap.values().stream().collect(Collectors.toList());
    }


    /**
     * 通过账户名和供应商id获取具体的供应商account.
     *
     * @param accountName the account name
     * @param providerId  the provider id
     * @return the account by name and provider id
     */
    public static ProviderAccountInfo getAccountByNameAndProviderId(String accountName, int providerId) {
        List<ProviderAccountInfo> accounts = getListByProviderId(providerId);
        if (CollectionUtils.isEmpty(accounts)) {
            log.error("找不到该供应商"+providerId+"的account列表");
            throw new StatusServiceCnException(Status.OBJECT_NOT_EXIST,"找不到该供应商"+providerId+"的account列表");
        }

        ProviderAccountInfo account = accounts.stream()
                .filter(item -> item.getAccountName().equals(accountName))
                .findFirst()
                .orElse(null);
        if (account == null) {
            log.error("通过accountName"+accountName+"找不到该account信息");
            throw new StatusServiceCnException(Status.OBJECT_NOT_EXIST,"通过accountName"+accountName+"找不到该account信息");
        }

        return account;
    }


    /**
     * 载入配置到内存
     */
    private void load() {
        List<ProviderAccountInfo> list = mapper.queryAllAccountList();
        if(CollectionUtils.isEmpty(list)){
            log.error("[重要] 没有配置供应商账户信息!!!");
            throw new StatusServiceCnException(Status.OBJECT_NOT_EXIST,"[重要] 没有配置供应商账户信息!!!");
        }
        accountInfoMap = Maps.uniqueIndex(list,e->e.getAccountId());

        ListMultimap<Integer,ProviderAccountInfo> tempMap =  ArrayListMultimap.create();
        list.stream()
                .forEach(account->tempMap.put(account.getProviderId(),account));
        providerListMap = tempMap;

    }

    /**
     * 重新载入配置
     * 线程安全
     */
    public synchronized boolean reload(){

        try{
            load();
            return true;
        }catch (Exception e){
            log.error("【ProviderAccountCache】配置刷新失败",e.getMessage(),e);
            return false;
        }
    }

    /**
     * 初始化配置信息
     * @throws Exception
     */
    @Override
    public void afterPropertiesSet() throws Exception {
        load();
    }


    @Override
    public boolean refresh() {
        return reload();
    }
}
