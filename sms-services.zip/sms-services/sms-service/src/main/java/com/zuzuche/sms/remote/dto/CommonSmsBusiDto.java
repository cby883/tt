package com.zuzuche.sms.remote.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @desc:
 * @author: panqiong
 * @date: 2018/10/24
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CommonSmsBusiDto {
    private boolean status;
    private String msg;
    private String code;
    private String data;
}
