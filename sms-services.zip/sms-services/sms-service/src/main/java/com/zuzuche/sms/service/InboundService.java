package com.zuzuche.sms.service;

import com.zuzuche.commons.base.resp.Status;
import com.zuzuche.commons.base.resp.StatusServiceCnException;
import com.zuzuche.commons.base.util.StringUtil;
import com.zuzuche.commons.redis.RedisLock;
import com.zuzuche.sms.cache.InboundOffsetCache;
import com.zuzuche.sms.cache.ProviderAccountCache;
import com.zuzuche.sms.cache.PushStatusOffsetCache;
import com.zuzuche.sms.entity.ProviderAccountInfo;
import com.zuzuche.sms.entity.SmsInbound;
import com.zuzuche.sms.mapper.SmsInboundMapper;
import com.zuzuche.sms.rest.response.RetriveInboundSmsRsp;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

/**
 * @desc: 上行短信查询服务
 * @author: panqiong
 * @date: 2018/10/24
 */
@Service
public class InboundService {

    @Autowired
    InboundOffsetCache inboundOffsetCache;

    @Autowired
    StringRedisTemplate redisTemplate;

    @Autowired
    SmsInboundMapper smsInboundMapper;

    /**
     * 查询上行短信列表
     * @return
     */
    public List<RetriveInboundSmsRsp> queryInboundSmsList() {

        RedisLock lock = new RedisLock(redisTemplate,InboundOffsetCache.RETRIVE_INBOUND_OFFSET_KEY);
        if(lock.lock()){
            // 从redis获取最新的offset 即id
            try{

                String id = inboundOffsetCache.get();
                if(StringUtil.isEmpty(id)){
                    throw new StatusServiceCnException(Status.OBJECT_NOT_EXIST,"上行拉取的offset丢失,需要检查重新设置offset");
                }
                List<SmsInbound> list = smsInboundMapper.queryListByIdLimit(id,200);
                // 填充数据 并转换数据对象
                List<RetriveInboundSmsRsp> rspList = enrichAndTransform(list);

                if(CollectionUtils.isNotEmpty(list)){
                    // 设置最大的id 作为offset 存储到redis
                    int maxId = list.stream().mapToInt(e->e.getId()).max().getAsInt();
                    inboundOffsetCache.set(String.valueOf(maxId));
                }

                return rspList;
            }finally {
                lock.unlock();
            }
        }
        return null;

    }

    /**
     * 填充和转换数据
     * @param list
     * @return
     */
    private List<RetriveInboundSmsRsp> enrichAndTransform(List<SmsInbound> list) {
        if(CollectionUtils.isEmpty(list)){
            return null;
        }
        List<RetriveInboundSmsRsp> rspList = list.stream().map(e->{
            ProviderAccountInfo accountInfo = ProviderAccountCache.getAccountById(e.getAccountId());

            return RetriveInboundSmsRsp.builder()
                    .accountId(e.getAccountId())
                    .accountType(accountInfo.getAccountType())
                    .content(e.getMsg())
                    .mobile(e.getPhone())
                    .port(e.getPort())
                    .smsId(e.getId())
                    .time(e.getCreateTime())
                    .build();

        }).collect(Collectors.toList());
        return rspList;
    }



}
