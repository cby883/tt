package com.zuzuche.sms.remote.param;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * 功能：Telecom CM短信请求接口提交参数.
 * 详细：
 *
 * @author Created on 2019.09.04 by chaodian
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PostCmSmsParam {
    private CmMessages messages;

    /**
     * CM短信提交的协议主体
     */
    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class CmMessages {
        /**
         * 权限token
         */
        private CmAuth authentication;

        /**
         * 发送的短信消息列表
         */
        private List<CmMsg> msg;
    }


    /**
     * 功能：权限.
     * 详细：
     *
     * @author Created on 2019.09.04 by chaodian
     */
    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class CmAuth {
        /**
         * CM的账户token，对应provider_account_info表的account_name
         */
        private String producttoken;
    }

    /**
     * 功能：消息主体.
     * 详细：
     *
     * @author Created on 2019.09.04 by chaodian
     */
    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class CmMsg {
        /**
         * 发送给到用户手机终端显示的号码串，但是发到中国手机号码会被转成数字
         */
        @Builder.Default
        private String from = "test";

        /**
         * 批量的手机号码列表
         */
        private List<CmMobile> to;

        /**
         * 长短信最少 1 段
         */
        @Builder.Default
        private int minimumNumberOfMessageParts = 1;

        /**
         * 长短信最长 8 段
         */
        @Builder.Default
        private int maximumNumberOfMessageParts = 8;

        /**
         * 短信内容主体
         */
        private CmBody body;

        /**
         * 此次短信提交批次号
         */
        private String reference;
    }

    /**
     * 功能：手机号码.
     * 详细：
     *
     * @author Created on 2019.09.04 by chaodian
     */
    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class CmMobile {
        /**
         * 手机号码，00作前缀
         */
        private String number;
    }

    /**
     * 功能：短信内容主体.
     * 详细：
     *
     * @author Created on 2019.09.04 by chaodian
     */
    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class CmBody {
        /**
         * 短信内容 , auto表示自动检测该内容是否含 UNICODE
         */
        @Builder.Default
        private String type = "auto";

        /**
         * 具体短信内容，需要带上签名
         */
        private String content;
    }

}
