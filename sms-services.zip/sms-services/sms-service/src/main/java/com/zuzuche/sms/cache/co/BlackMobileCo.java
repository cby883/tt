package com.zuzuche.sms.cache.co;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 功能：黑名单手机信息.
 * 详细：
 *
 * @author Created on 2019.03.16 by chaodian
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class BlackMobileCo {
    /**
     * 手机号
     */
    private String mobile;

    /**
     * 短信性质集合，多个以英文都逗号分割，如1,2,3，表示该手机的普通、营销、验证码都属黑名单，为空ornull也表示普通、营销、验证码都属黑名单
     */
    private String smsTypes;

    /**
     * 短信业务方集合, 多个以英文逗号分割, 如car_rent,poi
     */
    private String fromTypes;
}
