package com.zuzuche.sms.remote;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.zuzuche.commons.base.util.JsonUtil;
import com.zuzuche.sms.remote.dto.MiaoxinPullReportDto;
import com.zuzuche.sms.remote.dto.PostHxSmsDto;
import com.zuzuche.sms.remote.param.MiaoxinPullParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;

import java.nio.charset.Charset;
import java.util.Arrays;

/**
 * @desc: 秒信的拉取状态报告
 * @author: chenbingyi
 * @date: 2019/12/17
 */
@Service
@Slf4j
public class MiaoXinPullApi extends AbstractHttpInvoke {

    @Value(value = "${provider.miaoxin.pullurl}")
    private String pullurl;


    /**
     * 额外的header设置 比如编码
     *
     * @param header
     */
    @Override
    protected void setHeader(HttpHeaders header) {
        header.setAcceptCharset(Arrays.asList(Charset.forName("UTF-8")));
    }


    /**
     * 1、获取签名值
     * 2、调用供应商短信接口
     * 3、封装返回体
     *
     * @param param
     * @return
     */
    @HystrixCommand(groupKey = "miaoXinApiGroup", commandKey = "miaoXinPull")
    public MiaoxinPullReportDto pullSmsReport(MiaoxinPullParam param) {
        //拉取状态报告
        String result = super.postForm(pullurl, param);
        MiaoxinPullReportDto dto = null;
        //转换DTO
        try {
            dto = JsonUtil.stringToObj(result, MiaoxinPullReportDto.class);
        } catch (Exception e) {
            log.error("[秒信状态报告拉取jsons转换异常]:{}",result,e.getMessage(),e);
            return null;
        }

        return dto;
    }
}
