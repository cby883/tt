package com.zuzuche.sms.mapper;

import com.zuzuche.commons.mybatis.BaseMapper;
import com.zuzuche.sms.entity.SupplierConfig;

/**
 * The interface Supplier config mapper.
 */
public interface SupplierConfigMapper extends BaseMapper<SupplierConfig> {
}