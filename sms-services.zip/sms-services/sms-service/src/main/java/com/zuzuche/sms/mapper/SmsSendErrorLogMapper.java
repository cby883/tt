package com.zuzuche.sms.mapper;

import com.zuzuche.commons.mybatis.BaseMapper;
import com.zuzuche.sms.entity.SmsSendErrorLog;


/**
 * The interface Sms send error log mapper.
 */
public interface SmsSendErrorLogMapper extends BaseMapper<SmsSendErrorLog> {
}