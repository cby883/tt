package com.zuzuche.sms.rest.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.validator.constraints.Range;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.constraints.NotBlank;

/**
 * desc:批量发送请求dto
 *
 * @author bingyi
 * @date 2019/10-31
 * @blame Android Team
 */
@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
@ApiModel(value = "文件上传接口")
public class BatchNormalSmsReq {

    @ApiModelProperty(value = "文件",required = true)
    @NotBlank(message = "文件不能为空")
    private MultipartFile file;

    @ApiModelProperty(value = "短信内容", required = true)
    @NotBlank(message = "短信内容不能为空")
    private String content;

    @ApiModelProperty(value = "短信类型，1为普通短信，2为营销短信，3为验证码", required = true)
    @Range(min = 1, max = 3, message = "短信类型不合法, 1为普通短信，2为营销短信，3为验证码")
    private int type;

    @ApiModelProperty(value = "国家类型，1表示国内，2表示国际", required = true)
    @Range(min = 1, max = 2, message = "国家类型不合法, 1表示国内，2表示国际")
    private int regionType;

    @ApiModelProperty(value = "签名类型，1表示【租租车】签名，2表示【探途】签名，3表示【全球购骑士卡】签名，4表示【邮政小马达车务】签名，5表示【易挪车】，6表示【品优拼】，默认为1")
    @Builder.Default
    private int signType = 1;

    @ApiModelProperty(value = "短信发送者，不传默认为system")
    @Builder.Default
    private String admin = "system";

    @ApiModelProperty(value = "发送短信携带的额外参数json串，可携带验证码code、短信发送时间sendTime等，该参数可配合batch使用")
    private String extraParam;

    @ApiModelProperty(value = "来自上层业务名称，如car_rent表示国际租车")
    private String from;

    @ApiModelProperty(value = "来自上层业务唯一标识，如from为car_rent时，uniqueId可为订单号")
    private String uniqueId;

    /**
     * 是否模拟 true的话将不会真实发送
     */
    @ApiModelProperty(value = "是否只是模拟,不真实发送")
    @Builder.Default
    private Boolean mock = false;
    /**
     * 是否模拟 true的话将会真实发送
     */
    @ApiModelProperty(value = "是否真实发送")
    @Builder.Default
    private Boolean realSend = false;




}
