package com.zuzuche.sms.remote.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @desc: 秒信短信发送DTO
 * @author: bingyi
 * @date: 2019/12/13
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MiaoxinPushDto {
    /**
     * 请求状态。0成功，其他状态为失败
     */
    private int code;
    private String msg;
    /**
     * 总数量
     */
    private int total;

    /**
     * 推送结果
     */
    private List<Result> result;

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public  class Result{
        /**
         * 提交id号
         */
        @JsonFormat(pattern = "order_id")
        private String orderId;
        /**
         * 手机号
         */
        @JsonFormat(pattern = "mobile")
        private String mobile;
        /**
         * 错误详情
         */
        private int code;
        /**
         * 短信发送时间
         */
        @JsonFormat(pattern = "received_time")
        private String receivedTime;
        /**
         *
         */
        private String msg;
    }
}
