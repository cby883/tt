package com.zuzuche.sms.remote;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.zuzuche.commons.base.util.JsonUtil;
import com.zuzuche.commons.base.util.StringUtil;
import com.zuzuche.sms.remote.dto.PostHxSmsDto;
import com.zuzuche.sms.remote.dto.PullSmsReportDto;
import com.zuzuche.sms.remote.dto.PullSmsUplinkDto;
import com.zuzuche.sms.remote.param.PullSmsReportParam;
import com.zuzuche.sms.remote.param.PullSmsUplinkParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;
import org.springframework.web.client.ResourceAccessException;

import java.nio.charset.Charset;
import java.util.Arrays;

/**
 * @desc:
 * @author: panqiong
 * @date: 2018/11/9
 */
@Component
@Slf4j
public class JuchnPullApi extends AbstractHttpInvoke{

    @Value("${provider.juchn.pullurl}")
    private String pullurl ;


    /**
     * 额外的header设置 比如编码
     *
     * @param header
     */
    @Override
    protected void setHeader(HttpHeaders header) {
        header.setAcceptCharset(Arrays.asList(Charset.forName("UTF-8")));
    }


    /**
     * 群发接口状态报告拉取，
     * 要求接口使用方提出需求，由后台管理人员配置对应的账号信息，方能使用。
     * 拉取方式支持POST/GET方式（请求参数为如下）。
     * 状态报告响应由batchno与phone确定唯一性，提供接口使用方唯一性索引的作用。
     * 接口使用方拉取请求间隔不能小于10ms，拉取报告的时效为6小时内，每次拉取最大1000，
     * 单线程拉取，否则拉取不成功。
     * @param param
     * @return
     */
    @HystrixCommand(groupKey = "juchnApiGroup", commandKey="pullSmsReport")
    public PullSmsReportDto pullSmsReport(PullSmsReportParam param){
        String api = "/smsreport";
        String url = pullurl+api;
        String result;
        try {
            result = super.postForm(url,param);
        }catch (ResourceAccessException e){
            log.error("[JuchnPullApi-pullSmsReport]接口resource异常",e.getMessage(),e);
            return PullSmsReportDto.builder()
                    .respcode(-90)
                    .respdesc("接口resource异常")
                    .build();
        } catch (Exception e) {
            // 接口失败 在这里处理
            log.error("[JuchnPullApi-pullSmsReport]接口调用异常 ",e.getMessage(),e);
            return new PullSmsReportDto(-98,"接口调用异常");
        }

        try {
            PullSmsReportDto dto = JsonUtil.stringToObj(result,PullSmsReportDto.class);
            return dto;
        } catch (Exception e) {
            log.error("[拉取巨辰状态报告]解析返回的响应json报错 接口相应内容result:"+result);
            PullSmsReportDto dto = PullSmsReportDto.builder()
                    .respcode(-99)
                    .respdesc("json解析异常")
                    .build();
            return dto;
        }
    }


    /**
     * 群发接口上行短信拉取，要求接口使用方提出需求，由后台管理人员配置对应的账号信息，方能使用。
     * 拉取方式支持POST/GET方式（请求参数为如下）。
     * 上行短信由port与phone确定唯一性，提供接口使用方唯一性索引的作用。
     * 接口使用方拉取请求间隔不能小于10ms，拉取的时效为6小时内，
     * 每次拉取最大1000，单线程拉取，否则拉取不成功。
     * 请求的URL地址：http://www.qybor.com:5555/smsuplink
     * @param param
     * @return
     */
    @HystrixCommand(groupKey = "juchnApiGroup", commandKey="pullSmsuplink")
    public PullSmsUplinkDto pullSmsuplink(PullSmsUplinkParam param){
        String api = "/smsuplink";
        String url = pullurl+api;
        String result;
        // 异常处理
        try {
            result = super.postForm(url,param);
        }catch (ResourceAccessException e){
            log.error("[JuchnPullApi-pullSmsuplink]接口resource异常",e.getMessage(),e);
            return PullSmsUplinkDto.builder()
                    .respcode(-90)
                    .respdesc("接口resource异常")
                    .build();
        }  catch (Exception e) {
            // 接口失败 在这里处理
            log.error("[JuchnPullApi-pullSmsuplink]接口调用异常 ",e.getMessage(),e);
            return new PullSmsUplinkDto(-98,"接口调用异常");
        }
        // 解析json
        try {
            PullSmsUplinkDto dto = JsonUtil.stringToObj(result,PullSmsUplinkDto.class);
            return dto;
        } catch (Exception e) {
            log.error("[拉取巨辰上行短信]解析返回的响应json报错 接口相应内容result:"+result);
            PullSmsUplinkDto dto = PullSmsUplinkDto.builder()
                    .respcode(-99)
                    .respdesc("json解析异常")
                    .build();
            return dto;
        }
    }
}
