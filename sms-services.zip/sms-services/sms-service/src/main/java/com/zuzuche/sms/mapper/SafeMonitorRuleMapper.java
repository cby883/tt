package com.zuzuche.sms.mapper;

import com.zuzuche.commons.mybatis.BaseMapper;
import com.zuzuche.sms.entity.SafeMonitorRule;

import java.util.List;

/**
 * The interface Safe monitor rule mapper.
 */
public interface SafeMonitorRuleMapper extends BaseMapper<SafeMonitorRule> {
    /**
     * desc:
     * @return
     */
    public List<SafeMonitorRule> qureyAll();
}