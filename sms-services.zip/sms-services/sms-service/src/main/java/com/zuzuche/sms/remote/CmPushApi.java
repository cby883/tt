package com.zuzuche.sms.remote;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.zuzuche.commons.base.util.JsonUtil;
import com.zuzuche.sms.remote.dto.PostCmSmsDto;
import com.zuzuche.sms.remote.param.PostCmSmsParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;
import org.springframework.web.client.ResourceAccessException;

import java.nio.charset.Charset;
import java.util.Arrays;

@Component
@Slf4j
public class CmPushApi extends AbstractHttpInvoke {
    @Value("${provider.cm.pushurl}")
    private String pushurl ;

    /**
     * 额外的header设置 比如编码
     *
     * @param header
     */
    @Override
    protected void setHeader(HttpHeaders header) {
        header.setAcceptCharset(Arrays.asList(Charset.forName("UTF-8")));
    }

    /**
     * TelecomCm供应商短信发送请求.
     * 1. 批次号reference需要自己带上，用task_id
     * 2. 多个手机号码提交，如果有一个号码异常，返回的errorCode也为异常，但仍然需要认为此次提交正常，异常的手机需要自定义生成状态报告录入
     * 3. 具体得到errorCode和messageErrorCode需要参考https://docs.cmtelecom.com/en/api/business-messaging-api/1.0/index#responses-errors
     * 4. 短信内容含有Unicode字符，发到国际号码的短信也会按照国内的67和70标准切割，注意最小1段，最长8段，所以需要产品运营发送的短信内容不宜过长
     * 5. 短信发送的号码，格式如008618819490467，86虽为区号，但是需要加上前缀00，否则发送不出去
     *
     * @param param the param
     * @return the post cm sms dto
     * @throws ResourceAccessException the resource access exception
     */
    @HystrixCommand(groupKey = "CmGroup", commandKey = "postCmSms")
    public PostCmSmsDto send(PostCmSmsParam param) throws ResourceAccessException {
        String result = super.postJson(pushurl, param);

        try {
            PostCmSmsDto dto = JsonUtil.stringToObj(result, PostCmSmsDto.class);
            return dto;
        } catch (Exception e) {
            log.error("[Cm发送短信接口]解析返回的响应json报错 接口相应内容result:"+result, e.getMessage(), e);
            PostCmSmsDto dto = PostCmSmsDto.builder()
                    .errorCode("-99")
                    .details("json解析异常")
                    .build();
            return dto;
        }
    }
}
