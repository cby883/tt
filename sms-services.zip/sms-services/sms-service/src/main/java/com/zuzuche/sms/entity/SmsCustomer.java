package com.zuzuche.sms.entity;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Id;
import javax.persistence.Table;

/**
 * 功能：The type Sms customer.
 * 详细：
 *
 * @author Created on 2019.01.31 by chaodian
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "zuzuche_sms_db.sms_customer_tbl")
public class SmsCustomer {
    @Id
    private Integer id;

    private String sign;

    private String name;

    private String admin;

    /**
     * 营销短信发送次数拦截阈值
     */
    private int mkInterceptFreq;

    /**
     * 是否开启营销短信发送限制开关
     */
    private int hasOpenMkFreq;

    /**
     * 营销短信发送限制时间间隔，单位为秒
     */
    private int mkFreqDuration;

    private Integer updateTime;
}