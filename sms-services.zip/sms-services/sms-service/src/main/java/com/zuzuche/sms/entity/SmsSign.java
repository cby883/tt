package com.zuzuche.sms.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Table;

/**
 * 功能：The type Sms mt market.
 * 详细：
 *
 * @author Created on 2019.01.31 by chaodian
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "zuzuche_sms_db.sms_sign_tbl")
public class SmsSign {
    private Integer id;

    private Short val;

    private String name;

    private String allFormatNames;

    private Integer addTime;

    private int deleted;
}