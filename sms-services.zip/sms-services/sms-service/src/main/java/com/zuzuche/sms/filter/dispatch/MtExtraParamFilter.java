package com.zuzuche.sms.filter.dispatch;


import com.zuzuche.sms.cache.SupplierConfigCache;
import com.zuzuche.sms.common.enums.SmsEncodingType;
import com.zuzuche.sms.common.enums.SmsRegionType;
import com.zuzuche.sms.dto.ExtraParamDto;
import com.zuzuche.sms.dto.MtDto;
import com.zuzuche.sms.filter.MtFilter;
import com.zuzuche.sms.service.ExtraParamService;
import com.zuzuche.sms.service.KafkaService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 功能：额外参数处理器
 * 详细：
 *
 * @author bingyi
 * @blame
 */
@Component
@Slf4j
@Order(10)
public class MtExtraParamFilter implements MtFilter {
    @Autowired
    ExtraParamService extraParamService;
    @Override
    public boolean doFilter(MtDto mtDto) {
        //获取额外参数
        ExtraParamDto extraParamDto = ExtraParamService.jsonTransfer(mtDto.getExtraParam());
        //填充模板id
        extraParamService.transferTempId(mtDto,extraParamDto);
        //返回
        return true;
    }
}
