package com.zuzuche.sms.task;


import com.zuzuche.kafka.sentry.EventDto;
import com.zuzuche.kafka.sentry.SentryReport;
import com.zuzuche.sms.cache.TaskIdGenCache;
import com.zuzuche.sms.common.enums.SmsType;
import com.zuzuche.sms.dto.MtDto;
import com.zuzuche.sms.filter.FilterManager;
import com.zuzuche.sms.filter.MtFilter;
import com.zuzuche.sms.service.KafkaService;
import com.zuzuche.sms.service.SmsMtService;
import com.zuzuche.sms.service.SupplierMatchService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.List;

/**
 * 功能：业务下行短信的实现发送任务类.
 * 详细：
 *
 * @author Created on 2019.03.01 by chaodian
 */
@Slf4j
@Component
@Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class MtDispatchTask implements Runnable {
    /**
     * The Sms mt service.
     */
    @Autowired
    SmsMtService smsMtService;

    /**
     * The Kafka service.
     */
    @Autowired
    KafkaService kafkaService;

    /**
     * The Supplier match service.
     */
    @Autowired
    SupplierMatchService supplierMatchService;

    /**
     * The Filter manager.
     */
    @Autowired
    FilterManager filterManager;

    @Autowired
    TaskIdGenCache taskIdGenCache;

    @Autowired
    SentryReport sentryReport;

    /**
     * 不允许回调的总备注签名类型，3表示骑士卡
     */
    private final static int REMARK_CALLBACK_NOT_ALLOWED_SIGN = 3;

    /**
     * The Sms.
     */
    MtDto sms;


    /**
     * Instantiates a new Mt send task.
     *
     * @param sms the sms
     */
    MtDispatchTask(MtDto sms){
        this.sms = sms;
    }

    @Override
    public void run() {
        try {
            // 短信处理、 拦截过滤
            // 过滤完后，没有可以发的手机号，则此次发送也中断
            if (!executeFilters(sms)) {
                return;
            }
            // 获取taskId
            sms.setTaskId(taskIdGenCache.increGetStr());
            // 获取完taskId，先入库，入库后再推送进供应商队列，保证确保数据可靠
            smsMtService.saveToMtDb(sms);
            // 将短信转换成SmsDto, 推送进供应商队列
            smsMtService.dispatch(sms);
            // 记录短信的请求次数
            smsMtService.addMobileFreq(sms);
            // 非营销短信才需要回调通知其他相关系统
            if (sms.getType() != SmsType.营销.code() && sms.getSignType() != REMARK_CALLBACK_NOT_ALLOWED_SIGN) {
                // 将业务短信推进总备注队列
                smsMtService.noticeRemark(sms);
            }
            // 将业务短信推进主站的订单短信日志队列, 兼容旧流程
            smsMtService.noticeOrderSmsLog(sms);
            // 监控埋点
            reportToSentry(sms);
        } catch (Exception e) {
            log.error("[mt/listen]kafka消费mt短信异常:", e.getMessage(), e);
        }
    }

    /**
     * 上报数据给监控系统
     * @param dto
     */
    private void reportToSentry(MtDto dto) {
        EventDto eventDto = EventDto.builder()
                .metric("sms_dispatch_total")
                .time(Instant.now().toEpochMilli())
                .value(1)
                .addLabel("smsType",String.valueOf(dto.getType()))
                .build();
        sentryReport.incrCounter(eventDto);
        ///kafkaService.sendToSentry(eventDto);
    }



    /**
     * 执行所有过滤器，如果最后短信返回的没有手机号码，则此次发送中断, 过滤器执行顺序如下.
     * 1. MtTemplateFilter   模板替换
     * 2. MtSignContentFilter  短信签名内容处理
     * 3. ErrFormatMobileFilter 手机号码格式校验
     * 4. MtWhiteMobileFilter 白名单绕过
     * 5. MtBlackMobileFilter 黑名单拦截
     * 6. HighFreqMobileFilter 发送频率过快拦截
     * 7. MtSupplierMatchFilter 供应商匹配
     * 8. MtContentBuildFilter 匹配供应商后的短信完整内容构造
     * 9. MtContentCountFilter 短信内容计数处理
     * 10. MtAccountIdMatchFilter 供应商账户号id匹配
     *
     * @param sms the sms
     */
    private boolean executeFilters(MtDto sms) {
        List<MtFilter> filters = filterManager.getMtFilters();
        if(CollectionUtils.isEmpty(filters)){
            return true;
        }

        boolean status = true;
        for(MtFilter filter : filters){
            status = filter.doFilter(sms);
            // 有一个过滤器返回false，则中断下面的过滤器
            if(!status){
                log.info("被拦截后中断不可发送，　短信数据如下:" + sms.toString());
                return false;
            }
        }

        return true;
    }


}
