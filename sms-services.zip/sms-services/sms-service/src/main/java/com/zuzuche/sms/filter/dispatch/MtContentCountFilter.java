package com.zuzuche.sms.filter.dispatch;


import com.zuzuche.sms.cache.SupplierConfigCache;
import com.zuzuche.sms.common.enums.SmsEncodingType;
import com.zuzuche.sms.common.enums.SmsRegionType;
import com.zuzuche.sms.dto.MtDto;
import com.zuzuche.sms.filter.MtFilter;
import com.zuzuche.sms.service.KafkaService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 功能：短信内容计数处理过滤器.
 * 详细：
 *
 * @author Created on 2019.03.20 by chaodian
 */
@Component
@Slf4j
@Order(9)
public class MtContentCountFilter implements MtFilter {
    @Autowired
    SupplierConfigCache supplierConfigCache;

    @Autowired
    KafkaService kafkaService;

    private static final String GSM_REGEX_PATTER = "^([\\x00-\\x7f]|€)+$";
    private static final String GSM_EXTENSION = "[\\^|{}~€\\[\\]]";
    /**
     * 正则匹配，静态类
     */
    private static final Pattern SMS_CONTENT_PATTERN = Pattern.compile(GSM_REGEX_PATTER);
    private static final Pattern SMS_EXTENSION_PATTER = Pattern.compile(GSM_EXTENSION);


    @Override
    public boolean doFilter(MtDto mtDto) {
        //初始化发送条数
        int sendCount;
        //根据内容获取编码方式
        SmsEncodingType smsEncodingType = contentEncodingType(mtDto);
        //获取短信内容长度
        int length = count(mtDto.getContent(), smsEncodingType);
        //获取发送记录条数
        sendCount = sendCount(length, smsEncodingType);
        //设置发送条数
        mtDto.setSendCount(sendCount);
        //返回
        return true;
    }

    private int sendCount(int contentLen, SmsEncodingType smsEncodingType) {
        if (contentLen <= smsEncodingType.getUnixMaxCount()) {
            return 1;
        } else {
            return (int) Math.ceil((double) contentLen / (double) smsEncodingType.getUnixCutCount());
        }
    }

    private SmsEncodingType contentEncodingType(MtDto mtDto) {
        if (mtDto.getRegionType() == SmsRegionType.国际.code()) {
            //如果是国际短信，根据内容匹配编码
            Matcher matcher = SMS_CONTENT_PATTERN.matcher(mtDto.getContent());
            if (matcher.matches()) {
                return SmsEncodingType.SMS_GSM;
            }
        }
        //默认返回unicode编码字符
        return SmsEncodingType.SMS_UNICODE;
    }

    private int count(String content, SmsEncodingType smsEncodingType) {
        int len = content.length();

        //如果为GSM编码
        if (smsEncodingType.code().equals(SmsEncodingType.SMS_GSM.code())) {
            //GSM的拓展码数量
            int expand = 0;
            Matcher matcher = SMS_EXTENSION_PATTER.matcher(content);
            while (matcher.find()) {
                expand++;
            }

            len += expand;
        }
        //返回
        return len;
    }

}
