package com.zuzuche.sms.remote.param;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @desc:
 * @author: panqiong
 * @date: 2018/10/17
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PullSmsReportParam {
    /**
     * 账号名
     */
    private String username;

    /**
     * 账号密码｛32位MD5（账号密码+datatime）
     */
    private String passwd;

    /**
     * 时间:格式为 2018-05-28 12:00:00
     */
    private String datetime;

    /**
     * 获取状态报告最大的数量（不超过系统设置的最大值）
     */
    private String num;


    @Override
    public String toString() {
        return "PullSmsReportParam{" +
                "username='" + username + '\'' +
                ", datetime='" + datetime + '\'' +
                ", num='" + num + '\'' +
                '}';
    }
}


