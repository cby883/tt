package com.zuzuche.sms.rest.request;

import com.alibaba.fastjson.annotation.JSONField;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 功能：卓越恒信供应商状态报告回调接口.
 * 详细：
 *
 * @author Created on 2019.06.28 by chaodian
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@ApiModel(value = "卓越恒信供应商状态报告回调接口")
public class HengxinStatusCallbackReq {

    @ApiModelProperty(value = "用户子账户id")
    private String accountId;

    /**
     * 多个短信回执状态，json格式，格式如:
     *
     * [{"batchId": 364181930926235648, "msgId":146319620805382144,"recvTime"
     * :1509688207,"status":"DELIVRD"},{"batchId" : 364181930926235648, "msgId":342393993709377403,,"recvTime
     * me":1509688207,"status":"DELIVRD"}]
     *
     */
    @ApiModelProperty(value = "多个短信回执状态，json格式")
    private String result;
}
