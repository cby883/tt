package com.zuzuche.sms.cache;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;

import java.util.List;

/**
 * @desc: 重复短信拦截相关的cache
 * @author: panqiong
 * @date: 2019-02-27
 */
public class DupilcatedFilterCache {

    /**
     * field:md5
     * value:mobile
     */
    private static String DUPLICATED_SMS_HASH_KEY = "SMS:DUPLICATED_SMS_HASH_KEY";

    @Autowired
    RedisTemplate redisTemplate;

    /**
     * @param fieldKeyList md5列表
     * @return
     */
    public List<String> multiGet(List<String> fieldKeyList){
        // 重复号码集合
        List<String> duList = redisTemplate.opsForHash().multiGet(DUPLICATED_SMS_HASH_KEY,fieldKeyList);

        return duList;
    }
}
