package com.zuzuche.sms.rest.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.validator.constraints.Range;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;

/**
 * 功能：对接业务方的根据模板发送短信请求信息.
 * 详细：
 *
 * @author Created on 2019.01.30 by chaodian
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ApiModel(value = "对接业务方的根据模板发送短信请求信息")
public class MtTemplateReq {
    @ApiModelProperty(value = "手机号码字符串，多个手机号用英文逗号分隔，如18819490467或18819490467,13643071993，若regionType为2，则mobiles的手机需要国别号+手机号如1-3433030426,1-333995667(不符合规范会被过滤不发)", required = true)
    @NotBlank(message = "手机号码不能为空")
    private String mobiles;

    @ApiModelProperty(value = "短信模板id")
    private String tempId;

    @ApiModelProperty(value = "模板标识")
    private String tempUid;

    @ApiModelProperty(value = "替换短信模板的变量json，格式如{\"[username]\" : '张先生', \"[order_id]\" : '233431',...}，注意包括中括号一并当作键值")
    private String variables;

    @ApiModelProperty(value = "模板语言版本，目前只有zh-cn(简体中文)、zh-hk(香港繁体)、zh-tw(台湾繁体)，如果是英文版本或其他语言版本，先另建模板指定zh-cn")
    @Builder.Default
    private String language = "zh-cn";

    @ApiModelProperty(value = "国家类型，1表示国内，2表示国际", required = true)
    @Range(min = 1, max = 2, message = "国家类型不合法, 1表示国内，2表示国际")
    private int regionType;

    @ApiModelProperty(value = "签名类型，1表示【租租车】签名，2表示【探途】签名，3表示【全球购骑士卡】签名，4表示【邮政小马达车务】签名，5表示【易挪车】，6表示【品优拼】，默认为1")
    @Builder.Default
    private int signType = 1;

    @ApiModelProperty(value = "自定义命名批次号，如某次双十二营销短信shuang_shi_er")
    private String batch;

    @ApiModelProperty(value = "短信发送者，不传默认为system")
    @Builder.Default
    private String admin = "system";

    @ApiModelProperty(value = "发送短信携带的额外参数json串，可携带验证码code、短信发送时间sendTime等，该参数可配合batch使用")
    private String extraParam;

    @ApiModelProperty(value = "来自上层业务名称，如car_rent表示国际租车")
    private String from;

    @ApiModelProperty(value = "来自上层业务唯一标识，如from为car_rent时，uniqueId可为订单号")
    private String uniqueId;

    /**
     * 是否模拟 true的话将不会真实发送
     */
    @ApiModelProperty(value = "是否只是模拟,不真实发送")
    @Builder.Default
    private Boolean mock = false;

    /**
     * 是否模拟 true的话将会真实发送
     */
    @ApiModelProperty(value = "是否真实发送")
    @Builder.Default
    private Boolean realSend = false;
}
