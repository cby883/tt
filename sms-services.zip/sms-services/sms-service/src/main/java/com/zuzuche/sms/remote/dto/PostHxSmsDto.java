package com.zuzuche.sms.remote.dto;

import com.alibaba.fastjson.annotation.JSONField;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * 功能：卓越恒信短信供应商发送接口请求返回.
 * 详细：
 *
 * @author Created on 2019.06.27 by chaodian
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PostHxSmsDto {
    /**
     * 返回状态码.
     *
     * 0: 成功加入发送个队列
     * 11: account参数错误
     * 12: mobile参数不能为空
     * 13: mobile个数过多
     * 14: 号码包含非数字字符
     * 15: 号码长度错误
     * 16: content参数错误
     * 17: 签名为空，内容必须带有【】格式的签名
     * 18： 无法校验签名(secret)值
     * 22:  签名校验失败(secret值不匹配)
     */
    private String code;

    /**
     * 返回数据
     */
    private SmsData data;

    /**
     * 返回提示
     */
    private String message;

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class SmsData {
        /**
         * 短信提交的批次号，作为回执所用
         */
        @JSONField(name = "batch_id")
        private String batchId;

        /**
         * 号码列表提交返回的详情列表
         */
        private List<Detail> details;
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    private static class Detail {
        /**
         * 单个短信的唯一id
         */
        @JSONField(name = "msg_id")
        private String msgId;

        /**
         * 单个手机号
         */
        private String mobile;
    }
}
