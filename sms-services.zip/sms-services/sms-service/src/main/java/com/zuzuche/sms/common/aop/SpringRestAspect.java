package com.zuzuche.sms.common.aop;

import com.zuzuche.commons.base.annotation.Check;
import com.zuzuche.commons.base.resp.RespResult;
import com.zuzuche.commons.base.resp.Status;
import com.zuzuche.commons.base.resp.StatusServiceException;
import com.zuzuche.commons.base.util.HibernateValidateUtil;
import com.zuzuche.commons.base.util.JsonUtil;
import com.zuzuche.sms.common.context.ContextThread;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.stereotype.Component;

import java.lang.reflect.Parameter;

/**
 * spring rest层aop
 *
 * @author lizhifeng
 */
@Aspect
@Component
@Slf4j
public class SpringRestAspect {


    @Pointcut("bean(*Rest)")
    public void pointcut1() {

    }


    @Before(value = "pointcut1()")
    public void before(JoinPoint point) {
        //log.info(point.getSignature() + " called...");
    }

    @Around(value = "pointcut1()")
    public Object around(ProceedingJoinPoint pjp) throws Throwable {
        RespResult respResult;
        RespResult aopValidateResult = validateArgs(pjp);
        if (aopValidateResult.getCode() != Status.SUCCESS.code()) {
            log.info("aop 参数校验失败:{}", aopValidateResult.getMessage());
            return aopValidateResult;
        }
        Object object;
        try {
            //避免正常抛出的业务异常在aop打印异常链路信息
            object = pjp.proceed();
        } catch (StatusServiceException e) {

            log.info("exception:{}-{}", ContextThread.getFullRequestUrl(), e.getMessage());
            return RespResult.error(e.getCode(), e.getMessage());
        } catch (Exception e) {
            //先打印e.getMessage(),后打印e,否则堆栈信息无法出来
            log.error("exception:{}-{}-{}", ContextThread.getFullRequestUrl(), e.getMessage(), e);
            return RespResult.error(Status.BUSY);
        }
        if (object instanceof RespResult) {
            respResult = (RespResult) object;
            if (log.isDebugEnabled()) {
                log.info("请求执行完毕，执行结果如下:\n{}", JsonUtil.objToStr(respResult));
            }

        }
        return object;
    }


    protected RespResult validateArgs(ProceedingJoinPoint pjp) {
        MethodSignature signature = (MethodSignature) pjp.getSignature();

        //目前是验证所有参数，后期可以给check注解指定验证参数，这里暂时不实现。
        // 在方法上添加注解，不在方法参数添加注解的原因是swagger和方法参数上的注解不兼容，这里做了妥协
        if (signature.getMethod().getAnnotation(Check.class) != null) {
            Object[] args = pjp.getArgs();
            RespResult respResult;
            //获取方法参数
            Parameter[] parameters = signature.getMethod().getParameters();
            if (parameters != null && parameters.length > 0) {
                for (int i = 0; i < args.length; i++) {
                    Parameter parameter = parameters[0];
                    respResult = HibernateValidateUtil.aopValidate(args[i]);
                    if (respResult != null && respResult.getCode() == Status.PARAMS_FORMAT_ERROR.code()) {
                        return respResult;
                    }
                }
            }
        }

        return RespResult.success();
    }


}
