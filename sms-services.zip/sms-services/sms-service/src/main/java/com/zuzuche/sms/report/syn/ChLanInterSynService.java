package com.zuzuche.sms.report.syn;

import com.zuzuche.commons.base.util.StringUtil;
import com.zuzuche.sms.common.utils.DateUtil;
import com.zuzuche.sms.common.utils.PerformUtil;
import com.zuzuche.sms.entity.ProviderAccountInfo;
import com.zuzuche.sms.entity.SmsInbound;
import com.zuzuche.sms.entity.StatusReport;
import com.zuzuche.sms.remote.ChuangLanInterApi;
import com.zuzuche.sms.remote.dto.PullMoInterDto;
import com.zuzuche.sms.remote.dto.PullReportInterDto;
import com.zuzuche.sms.remote.param.PullMoParam;
import com.zuzuche.sms.remote.param.PullReportParam;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @desc: 创蓝的国际账号同步数据服务
 * @author: panqiong
 * @date: 2018/11/12
 */
@Service("chLanInterSynService")
@Slf4j
public class ChLanInterSynService extends AbstractSynService{

    private static String PULL_NUM = "500";

    private static String SUCCESS_RET = "0";

    @Autowired
    ChuangLanInterApi chLanInterApi;



    @Override
    protected List<StatusReport> doInvokeStatusReportApi(ProviderAccountInfo account) {
        int accountId = account.getAccountId();
        String name = account.getAccountName();
        String pwd = account.getAccountPwd();
        PullReportParam param = PullReportParam.builder()
              .account(name)
                .password(pwd)
                .count(PULL_NUM)
                .build();
        long start = Instant.now().toEpochMilli();
        PullReportInterDto dto = chLanInterApi.pullReport(param);
        if(log.isDebugEnabled()){
            log.debug("[response]"+dto.toString());
        }
        long end = Instant.now().toEpochMilli();
        PerformUtil.logTime("chLanInterApi.pullReport",start,end);
        if(SUCCESS_RET.equals(dto.getCode())) {
            if (CollectionUtils.isEmpty(dto.getResult())) {
                log.warn("[ChLanInterStatusReportJob]:accountName:" + account.getAccountName() + " 本次拉取List为空");
                return null;
            }
            log.info("[ChLanInterStatusReportJob]:accountName:" + account.getAccountName() + " 拉取到状态记录 " + dto.getResult().size() + " 条");

            List<StatusReport> list = dto.getResult().stream()
                    .map(report ->
                            StatusReport.builder()
                                    // 这里返回msgId 是调用发送接口返回的msgId
                                    .batchNo(report.getMsgid())
                                    .createTime(LocalDateTime.now())
                                    .phone(report.getMobile())
                                    .recvTime(UTCtoCST(report.getReportTime()))
                                    .status(report.getStatus())
                                    .accountId(accountId)
                                    .build()
                    ).collect(Collectors.toList());
            return list;
        }
        return null;

    }


    @Override
    protected List<SmsInbound> doInvokeInboundApi(ProviderAccountInfo account) {
        int accountId = account.getAccountId();
        String name = account.getAccountName();
        String pwd = account.getAccountPwd();
        PullMoParam param = PullMoParam.builder()
                .account(name)
                .password(pwd)
                .count(PULL_NUM)
                .build();

        long start = Instant.now().toEpochMilli();
        PullMoInterDto dto = chLanInterApi.pullMo(param);
        if(log.isDebugEnabled()){
            log.debug("[response]"+dto.toString());
        }
        long end = Instant.now().toEpochMilli();
        PerformUtil.logTime("chLanInterApi.pullMo",start,end);

        if(SUCCESS_RET.equals(dto.getCode())) {
            if(CollectionUtils.isEmpty(dto.getResult())){
                log.warn("[ChLanInterInboundJob]:accountName:"+account.getAccountName()+" 本次拉取List为空");
                return null;
            }
            log.info("[ChLanInterInboundJob]:accountName:"+account.getAccountName()+" 拉取上行短信 "+dto.getResult().size()+" 条");

            List<SmsInbound> list = dto.getResult().stream()
                    .map(report ->
                            SmsInbound.builder()
                                    .msg(report.getMsg())
                                    .createTime(LocalDateTime.now())
                                    .phone(report.getMobile())
                                    .port("")
                                    .accountId(accountId)
                                    .build()
                    ).collect(Collectors.toList());

            return list;
            // 发送kafka队列 供上游需要订阅的服务收听

        }
        return null;
    }

    /**
     * 秒转换时间格式
     * @return
     */
//    private String secondTrans(String sc){
//        try{
//            Long seconds = Long.parseLong(sc);
//            LocalDateTime startTime = LocalDateTime.ofEpochSecond(seconds,0, ZoneOffset.ofHours(8)) ;
//            String datestr = startTime.format(DateTimeFormatter.ofPattern(DateUtil.PATTERN_1));
//            return datestr;
//        }catch (Exception e){
//            log.error("[报告日期转换异常]reportTime:"+sc);
//            return sc;
//        }
//
//
//    }

    /**
     * CST可视为美国、澳大利亚、古巴或中国的标准时间,北京时间与utc时间相差8小时
     * @param utc
     * @return
     */
    private static String UTCtoCST(String utc){

        try{
            if(StringUtil.isEmpty(utc)){
                log.warn("[报告日期为空,直接填充当前的系统时间]reportTime:"+utc);
                return DateUtil.getCurrentTime(DateUtil.PATTERN_1);
            }
            ZonedDateTime zdt  = ZonedDateTime.parse(utc);
            LocalDateTime localDateTime = zdt.toLocalDateTime();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            return formatter.format(localDateTime.plusHours(8));
        }catch (Exception e){
            log.error("[报告日期转换异常]reportTime:"+utc);
            return utc;
        }

    }

    public static void main(String[] args) {
        String d = "2019-09-29T01:59:00.000Z";
        String d2 = "2018-07-03T10:18:58.000Z";
        System.out.println("args = " + UTCtoCST(d));
        System.out.println("args = " + UTCtoCST(d2));
    }


}
