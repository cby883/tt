package com.zuzuche.sms.common.utils;

import com.google.common.util.concurrent.RateLimiter;

/**
 * @desc: 令牌桶限流算法,RateLimiter会按照一定的频率往桶里扔令牌，
 * 线程拿到令牌才能执行，比如你希望自己的应用程序QPS不要超过1000，
 * 那么RateLimiter设置1000的速率后，就会每秒往桶里扔1000个令牌
 * @author: panqiong
 * @date: 2018/10/30
 */
public class GuavaRateLimiter {
    private static RateLimiter rateLimiter = RateLimiter.create(2);


    public static void acquire(){
        double time = rateLimiter.acquire();
    }


}
