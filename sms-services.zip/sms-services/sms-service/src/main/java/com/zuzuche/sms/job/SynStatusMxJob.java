package com.zuzuche.sms.job;

import com.zuzuche.commons.base.util.StringUtil;
import com.zuzuche.commons.redis.DistributeJobExecutor;
import com.zuzuche.commons.redis.RedisLock;
import com.zuzuche.logback.util.MDCUtil;
import com.zuzuche.sms.cache.ProviderAccountCache;
import com.zuzuche.sms.cache.SmsClassConfigCache;
import com.zuzuche.sms.common.utils.SpringBeanFactory;
import com.zuzuche.sms.entity.SmsClassConfig;
import com.zuzuche.sms.report.syn.SynService;
import com.zuzuche.threadpool.ThreadPoolExecutorFactory;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.text.MessageFormat;
import java.util.Set;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * @desc: 从秒信供应商同步上行短信
 * @author: bingyi
 * @date: 2018/11/8
 */
@Component
@Slf4j
public class SynStatusMxJob {
    /**
     * 状态报告同步线程池
     * 溢出策略 最长阻塞主线程60秒后抛出异常
     */
    private static ExecutorService executor = ThreadPoolExecutorFactory.create(
            ThreadPoolExecutorFactory.Config.builder()
                    .corePoolSize(4)
                    .maximumPoolSize(4)
                    .keepAliveTime(5)
                    .workQueue(new ArrayBlockingQueue<>(10))
                    .unit(TimeUnit.MINUTES)
                    .handler(new ThreadPoolExecutor.CallerRunsPolicy())
                    .threadPoolName("synStatusMXReport-pool")
                    .build());

    private static final String MX_REDIS_KEY = "SMS:SYN_STATUS_MX_REPORT_KEY_8_";

    private static int providerId = 8;
    @Autowired
    StringRedisTemplate redisTemplate;

    /**
     * 每30秒
     */
    @Scheduled(cron = "*/5 * * * * ?")
    public void execute() {
        MDCUtil.set();
        RedisLock redisLock = new RedisLock(MX_REDIS_KEY);
        executor.submit(() -> {
            if (redisLock.lock()) {
                try {
                    SmsClassConfig synClazz = SmsClassConfigCache.getByProviderId(providerId);
                    String beanName = synClazz.getSynServiceClass();
                    if (StringUtil.isNotBlank(beanName)) {
                        SynService synService = (SynService) SpringBeanFactory.getBean(beanName);
                        synService.synStatusReport(providerId);
                    }
                } catch (Exception e) {
                    log.error("[状态报告同步任务执行报错] providerId:" + providerId, e.getMessage(), e);
                }finally {
                    redisLock.unlock();
                }
            }
        });
        MDCUtil.clear();
    }


}
