package com.zuzuche.sms.remote.param;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @desc:teleSign短信请求参数
 * @author: bingyi
 * @date: 2018/09/05
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TeleSignPushParam {

    /**
     * 手机号码
     */
    private String phone_number;
    /**
     * 此参数指定消息中发送的流量类型。您可以提供以下值之一 -
     *
     * OTP（一次性密码）
     * ARN（提醒，提醒和通知）
     * MKT（营销流量）
     */
    @Builder.Default
    private String message_type="ARN";
    /**
     * 短信内容
     */
    private String message;

//    /**
//     * senderId
//     */
//    @JSONField(name = "sender_id")
//    private String sender_id;

    /**
     * 额外参数
     */
    @JSONField(name = "external_id")
    private String external_id;
}
