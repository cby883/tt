package com.zuzuche.sms.mapper;

import com.zuzuche.commons.mybatis.BaseMapper;
import com.zuzuche.sms.entity.SmsClassConfig;

import java.util.List;

/**
 * @desc:
 * @author: panqiong
 * @date: 2018/11/8
 */
public interface SmsClassConfigMapper extends BaseMapper<SmsClassConfig> {

    /**
     * 查询所有
     * @return
     */
    List<SmsClassConfig> queryAllClassConfigList();
}
