package com.zuzuche.sms.listener.provider;

import com.google.common.util.concurrent.RateLimiter;
import com.zuzuche.logback.util.MDCUtil;
import com.zuzuche.sms.cache.SmsConfigCache;
import com.zuzuche.sms.dto.SmsDto;
import com.zuzuche.sms.executors.TeleSignExecutor;
import com.zuzuche.sms.report.syn.JuchnSynService;
import com.zuzuche.sms.service.KafkaService;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import java.util.concurrent.RejectedExecutionException;

/**
 * @desc:teleSign
 * @author: bingyi
 * @date: 2019/09/10
 */
@Component
@Slf4j
public class TeleSignOutBoundListener implements InitializingBean {

    private static String RATE_KEY = "teleSign_outbound_topic_rate";


    private static RateLimiter rateLimiter;


    @Autowired
    KafkaService kafkaService;

    @Autowired
    SmsConfigCache configCache;


    @Autowired
    TeleSignExecutor outboundExecutor;

    /**
     * 注意:
     * - 如果消息处理超时,spring默认最多会重新处理三次
     * - 如果对消息保障性要求高,发生异常要预警,可以把处理失败的消息转发到dlq队列
     * - 优雅退出应用,不然会可能丢失已消费未处理的消息
     * 短信下发队列
     *
     * @param consumer
     */
    @KafkaListener(topics = KafkaService.TELESIGN_SMS_OUTBOUND_TOPIC)
    public void consume(ConsumerRecord<String, SmsDto> consumer) {
        MDCUtil.set();
        if (log.isDebugEnabled()) {
            log.debug("[receive teleSign_outbound_topic_rate]:" + consumer.value());
        }

        rateLimiter.acquire();
        try {
            // 1个短信实体
            SmsDto sms = consumer.value();
            // 下行业务处理
            outboundExecutor.handle(sms);

        } catch (RejectedExecutionException e) {
            log.error("[teleSign线程池拒绝策略触发-teleSign_outbound_topic_rate]message:" + consumer.value(), e.getMessage(), e);
        } catch (Exception e) {
            log.error("[teleSign消息处理出现异常-teleSign_outbound_topic_rate]message:" + consumer.value(), e.getMessage(), e);
        } finally {
            MDCUtil.clear();
        }

    }


    @Override
    public void afterPropertiesSet() throws Exception {
        if (configCache.containsKey(RATE_KEY)) {
            int rate = Integer.parseInt(configCache.get(RATE_KEY));
            rateLimiter = RateLimiter.create(rate);
        } else {
            // 默认速度
            rateLimiter = RateLimiter.create(50);
        }
    }
}
