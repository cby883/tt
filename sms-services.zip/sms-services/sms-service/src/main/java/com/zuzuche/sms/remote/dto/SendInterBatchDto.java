package com.zuzuche.sms.remote.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @desc:
 * @author: panqiong
 * @date: 2018/11/12
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SendInterBatchDto {
    /**
     * 状态码
     */
    private String code;

    /**
     *   "messageId": "I6428061_1712261459_40"
     */
    private RData data;


    private String message;


    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    @Data
    public static class RData{
        private String messageId;
    }

}
