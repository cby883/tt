package com.zuzuche.sms.remote.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @desc:
 * @author: panqiong
 * @date: 2018/11/7
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SmsCountDto {
    private String code;
    private String count;
}
