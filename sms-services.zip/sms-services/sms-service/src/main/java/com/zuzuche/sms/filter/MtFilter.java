package com.zuzuche.sms.filter;


import com.zuzuche.sms.dto.MtDto;

/**
 * 业务短信过滤器接口.
 * @author Chaodian
 * @date  2019-02-28
 */
public interface MtFilter {

    /**
     * 过滤器统一入口方法
     *
     * @param mtDto the mt dto
     * @return boolean
     */
    boolean doFilter(MtDto mtDto);
}
