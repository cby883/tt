package com.zuzuche.sms.listener.inner;

import com.google.common.util.concurrent.RateLimiter;
import com.zuzuche.logback.util.MDCUtil;
import com.zuzuche.sms.cache.SmsConfigCache;
import com.zuzuche.sms.common.enums.RateLimiterKeyTypes;
import com.zuzuche.sms.dto.BlockedSmsDto;
import com.zuzuche.sms.service.BlockSmsService;
import com.zuzuche.sms.service.KafkaService;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @desc: 重复短信处理
 * @author: panqiong
 * @date: 2018/10/29
 */
@Component
@Slf4j
public class BlockedSmsListener  {

    private static String RATE_KEY = "blocked_sms_topic_rate";
    /**
     * 消费限速,每秒5个
     */
    private static RateLimiter rateLimiter ;


    @Autowired
    SmsConfigCache configCache;

    @Autowired
    BlockSmsService blockSmsService;



    /**
     * 注意:
     *  - 如果消息处理超时,spring默认最多会重新处理三次
     *  - 发生异常要预警,把处理失败的消息转发到dlq队列
     *  - 优雅退出应用,不然会可能丢失消息未处理
     *  重复短信处理,这些消息是由 filters 送进去的
     * @param consumer
     */
    @KafkaListener(topics = KafkaService.BLOCKED_SMS_TOPIC)
    public void consume(ConsumerRecord<String, BlockedSmsDto> consumer) {
        log.info("[receive blocked_sms_topic]:" +consumer.value());
        rateLimiter=configCache.getLimiter(RateLimiterKeyTypes.BLOCKED_SMS_TOPIC_RATE);
        rateLimiter.acquire();

        BlockedSmsDto blockSms = consumer.value();
        blockSmsService.process(blockSms);
    }
}
