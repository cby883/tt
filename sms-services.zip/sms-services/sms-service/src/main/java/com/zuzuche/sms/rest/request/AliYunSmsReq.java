package com.zuzuche.sms.rest.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * desc:阿里云消息请求参数
 *
 * @author bingyi
 * @date 2019/08/20
 */
@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
@ApiModel(value = "阿里云短信请求实体")
public class AliYunSmsReq {
    /**
     * 任务id 自己需要保存这个 跟踪这个批次需要
     * 上游没有传的话会自动生成一个
     */
    @ApiModelProperty(value = "taskId")
    private String taskId ;
    /**
     * 签名类型
     */
    @ApiModelProperty(value = "signType")
    private int signType ;

    /**
     * 手机号码
     */
    @ApiModelProperty(value = "mobile")
    private String mobile;

    /**
     * 短信内容
     */
    @ApiModelProperty(value = "content")
    private String content;

    /**
     * md5后的content
     */
    @ApiModelProperty(value = "md5Content")
    private String md5Content;


    /**
     * 短信供应商id
     */
    @ApiModelProperty(value = "accountId")
    private Integer accountId;

    /**
     * 权限认证签名 md5(secret+time)
     */
    @ApiModelProperty(value = "authKey")
    private String authKey;

    /**
     * 时间 秒 ,用于权限认证签名
     */
    private long time;

    /**
     * 是否模拟 true的话将不会真实发送
     */
    @Builder.Default
    @ApiModelProperty(value = "mock")
    private boolean mock = true;

    /**
     * 模拟超时，该值表示重试到第n次才不会超时，0表示不会出现超时
     */
    @Builder.Default
    private int mockTimeOutUntilRetryNo = 0;

    /**
     * 重试前的短信供应商id，用于短信下发供应商失败重试用
     */
    @ApiModelProperty(value = "parentAccountId")
    private Integer parentAccountId;

    /**
     * 当前重试第n次，0表示没有重试过
     */
    @Builder.Default
    private int retryNo = 0;

    /**
     * 提交供应商的返回响应码
     */
    private String respCode;

    /**
     * 提交供应商的批次号
     */
    private String batchNo;
}
