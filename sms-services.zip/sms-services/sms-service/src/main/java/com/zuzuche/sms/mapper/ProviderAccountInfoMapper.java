package com.zuzuche.sms.mapper;

import com.zuzuche.commons.mybatis.BaseMapper;
import com.zuzuche.sms.entity.ProviderAccountInfo;

import java.util.List;

/**
 * @desc ~
 * @author panqiong
 * @date 20181019
 */
public interface ProviderAccountInfoMapper  extends BaseMapper<ProviderAccountInfo> {

    /**
     * 查询所有有效配置
     * @return
     */
    List<ProviderAccountInfo> queryAllAccountList();
}