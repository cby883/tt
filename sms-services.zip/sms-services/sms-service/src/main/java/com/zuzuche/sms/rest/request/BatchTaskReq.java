package com.zuzuche.sms.rest.request;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.Id;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import java.time.LocalDateTime;

/**
 * desc:批次短信任务请求体
 *
 * @author bingyi
 * @date 2019/11/13
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
@ApiModel(value = "批量任务查询请求体")
public class BatchTaskReq {

    @ApiModelProperty(value = "任务id(默认不传，则查询全部",required = false)
    private Integer id;

    @ApiModelProperty(value = "（必传）开始时间，默认格式为：yyyy-MM-dd",required = true)
    private String startTime;

    @ApiModelProperty(value = "（必传）结束时间，默认格式为：yyyy-MM-dd",required = true)
    private String endTime;
    @ApiModelProperty(value = "默认从第一页开始")
    @Min(value = 1,message = "页面，最小为1")
    @Builder.Default
    private int page=1;

    @ApiModelProperty(value = "默认分页大小10")
    @Max(value = 1000,message = "分页大小，最大允许1000")
    @Builder.Default
    private int pageSize=10;


}