package com.zuzuche.sms.report.callback;

import com.zuzuche.commons.base.util.JsonUtil;
import com.zuzuche.sms.common.utils.DateUtil;
import com.zuzuche.sms.entity.ProviderAccountInfo;
import com.zuzuche.sms.entity.StatusReport;
import com.zuzuche.sms.rest.request.HengxinStatusCallbackReq;
import com.zuzuche.sms.vo.HengxinStatusCallbackDetail;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 功能：卓越恒信供应商的数据回调服务层.
 * 详细：
 *
 * @author Created on 2019.06.28 by chaodian
 */
@Service("hengxinCallbackService")
@Slf4j
public class HengxinCallbackService extends AbstractCallbackService{

    @Override
    protected List<StatusReport> doAnalyzeCallbackStatusReport(ProviderAccountInfo account, Object statusReportData) {
        // 先强制转换下类型
        HengxinStatusCallbackReq statusReports = (HengxinStatusCallbackReq) statusReportData;
        List<HengxinStatusCallbackDetail> details = JsonUtil.stringToObjList(statusReports.getResult(), HengxinStatusCallbackDetail.class);

        List<StatusReport> statusReportList = details.stream()
                .map(detail ->
                        StatusReport.builder()
                                // 这里返回的uid 就是我们传过去的taskId
                                .batchNo(detail.getBatchId())
                                .createTime(LocalDateTime.now())
                                .phone(detail.getMobile())
                                .recvTime(dateTrans(detail.getRecvTime()))
                                .status(detail.getStatus())
                                .accountId(account.getAccountId())
                                .build()
                        ).collect(Collectors.toList());


        return statusReportList;
    }


    /**
     * 时间格式转换
     * @return string
     */
    private String dateTrans(String origin){
        try{
            String date = new SimpleDateFormat(DateUtil.PATTERN_1).format(new Date(Long.valueOf(origin) * 1000));
            return date;
        }catch (Exception e){
            log.error("[报告日期转换异常]reportTime:"+origin);
            return origin;
        }
    }
}
