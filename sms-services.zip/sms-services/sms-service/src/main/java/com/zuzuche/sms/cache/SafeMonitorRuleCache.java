package com.zuzuche.sms.cache;

import com.google.common.base.Splitter;
import com.zuzuche.commons.base.util.JsonUtil;
import com.zuzuche.commons.base.util.StringUtil;
import com.zuzuche.sms.cache.co.SafeMonitorRuleCo;
import com.zuzuche.sms.entity.SafeMonitorRule;
import com.zuzuche.sms.mapper.SafeMonitorRuleMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 功能： 拦截安全规则配置缓存层.
 * 详细：
 *
 * @author Created on 2019.03.07 by chaodian
 */
@Component("SafeMonitorRuleCache")
@Slf4j
public class SafeMonitorRuleCache implements InitializingBean, ConfigCache {

    /**
     * 敏感词过滤标识（不可变动）
     */
    private static final String SENSITIVE_WORDS_FUNC = "sensitiveWordsFiltering";
    /**
     * 敏感词集
     */
    List<String> sensitive=new ArrayList<>(16);

    @Autowired
    SafeMonitorRuleMapper mapper;

    private static Map<String, SafeMonitorRuleCo> configMap = new HashMap<>(20);

    public boolean containsKey(String key) {
        return configMap.containsKey(key);
    }

    public SafeMonitorRuleCo get(String key) {
        return configMap.get(key);
    }

    /**
     * 检查是否拦截监控规则开启.
     * <p>
     * 1. 加载不到拦截监控规则，默认为开启
     * 2. 加载得到拦截监控规则，并且规则状态为1也标识开启
     *
     * @param key 规则名
     * @return boolean
     */
    public boolean checkIsSafeMonitorOpen(String key) {
        SafeMonitorRuleCo co = get(key);
        return co == null || co.getStatus() == 1;
    }


    @Override
    public void afterPropertiesSet() throws Exception {
        load();
    }


    /**
     * 载入配置到内存
     */
    public synchronized void load() {
        List<SafeMonitorRule> list = mapper.qureyAll();
        Map<String, SafeMonitorRuleCo> configMapTemp = new HashMap<>(20);
        if (CollectionUtils.isNotEmpty(list)) {
            list.stream().forEach(e -> {
                if(e.getFunc().equalsIgnoreCase(SENSITIVE_WORDS_FUNC)){
                    //存在敏感词配置，
                    if(StringUtil.isNotBlank(e.getDesc())){
                        try {
                            List<String> sensitiveTemp=Splitter.on("||").splitToList(e.getDesc());
                            sensitive=sensitiveTemp;
                        } catch (Exception e1) {
                            log.error("【敏感词配置格式错误，请检查】",e1.getMessage(),e1);
                        }
                    }else{
                        sensitive=null;
                    }
                }
                SafeMonitorRuleCo co = SafeMonitorRuleCo.builder()
                        .ruleName(e.getFunc())
                        .status(e.getStatus())
                        .desc(e.getDesc())
                        .build();
                SafeMonitorRuleCo.RuleFrequency frequency = JsonUtil.stringToObj(
                        e.getExtraParam(),
                        SafeMonitorRuleCo.RuleFrequency.class
                );
                co.setRuleFrequency(frequency);

                configMapTemp.put(e.getFunc(), co);
            });
        }

        configMap = configMapTemp;

    }

    @Override
    public boolean refresh() {
        try {
            load();
            return true;
        } catch (Exception e) {
            log.error("【SafeMonitorRuleCache】配置刷新失败",e.getMessage(),e);
            return false;
        }
    }

    /**
     * 返回敏感词
     * @return
     */
    public List<String> getSensitive(){
        return sensitive;
    }
}
