package com.zuzuche.sms.dto;

import com.zuzuche.kafka.message.BaseMessage;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * 功能：状态报告dto
 * 详细：
 *
 * @author bingyi
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class StatusReportDto extends BaseMessage {
    private int id;

    private String batchNo;

    private String phone;

    private String status;

    private String recvTime;

    private LocalDateTime createTime;

    private int accountId;

    private String enQueueTime;

    private int enQueueCount;
}
