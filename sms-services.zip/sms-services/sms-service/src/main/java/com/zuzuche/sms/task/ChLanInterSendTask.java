package com.zuzuche.sms.task;

import com.zuzuche.sms.cache.ProviderAccountCache;
import com.zuzuche.sms.dto.InvokeResultDto;
import com.zuzuche.sms.dto.SmsDto;
import com.zuzuche.sms.entity.ProviderAccountInfo;
import com.zuzuche.sms.remote.ChuangLanInterApi;
import com.zuzuche.sms.remote.param.SendInterBatchParam;
import com.zuzuche.sms.remote.dto.SendInterBatchDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.time.Instant;

/**
 * @desc: 创蓝国际短信发送任务
 * @author: panqiong
 * @date: 2018/11/15
 */
@Slf4j
@Component
@Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class ChLanInterSendTask extends AbstractSendTask{

    @Autowired
    ChuangLanInterApi chuangLanInterApi;

    ChLanInterSendTask(SmsDto sms) {
        super(sms);
    }


    /**
     * 过滤器链
     */
    @Override
    public boolean beforeSend(SmsDto sms) {
        return super.beforeSend( sms);
    }


    /**
     * 调用供应商的接口
     *
     * @param sms
     * @return
     */
    @Override
    public InvokeResultDto invokeApi(SmsDto sms) {

        // 取账号密码
        ProviderAccountInfo account = ProviderAccountCache.getAccountById(sms.getAccountId());

        SendInterBatchParam sendParam = SendInterBatchParam.builder()
                .account(account.getAccountName())
                .password(account.getAccountPwd())
                .msg(sms.getContent())
                .mobile(sms.getMobile())
                .build();
        SendInterBatchDto smdto = chuangLanInterApi.sendBatch(sendParam);

        String batchNo = "";
        if(smdto.getData()!=null){
            batchNo = smdto.getData().getMessageId();
        }
        // 封装返回对象
        InvokeResultDto resultDto = InvokeResultDto.builder()
                // 用自己的taskId做batchNo 回调会返回这个id
                .bachNo(batchNo)
                .extra(sms.getTaskId())
                .respCode(smdto.getCode())
                .taskId(sms.getTaskId())
                .mobiles(sms.getMobile())
                .md5Content(sms.getMd5Content())
                .timestamp(Instant.now().toEpochMilli())
                .providerId(account.getProviderId())
                .build();


        return resultDto;
    }
}
