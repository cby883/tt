/**
 * 
 */
package com.zuzuche.sms.common.utils;

import com.zuzuche.commons.base.util.StringUtil;
import com.zuzuche.sms.dto.InvokeResultDto;

import java.security.MessageDigest;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/** 
 * 时间转换类
 * @author bingyi
 * @datetime 2011-10-13 
 */  
public class TimeUtil {
    public final static String DEFAULT_PATTERN="yyyy-MM-dd HH:mm:ss";
    /**
     *
     * @param pattern
     * @return
     */
    public static String nowOfPatter(String pattern){
            if(StringUtil.isBlank(pattern)){
                //设置默认值
                pattern=DEFAULT_PATTERN;
            }
            LocalDateTime now=LocalDateTime.now();
            DateTimeFormatter dateTimeFormat=DateTimeFormatter.ofPattern(pattern);
            String time=dateTimeFormat.format(now);
            return time;
    }
}  
