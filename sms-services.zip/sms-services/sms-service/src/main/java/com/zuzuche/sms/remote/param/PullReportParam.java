package com.zuzuche.sms.remote.param;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @desc:
 * @author: panqiong
 * @date: 2018/11/12
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PullReportParam {
    private String account;
    private String password;
    /**
     * 拉取个数（最大500，默认20），选填
     */
    private String count;

    @Override
    public String toString() {
        return "PullReportParam{" +
                "account='" + account + '\'' +
                ", count='" + count + '\'' +
                '}';
    }
}
