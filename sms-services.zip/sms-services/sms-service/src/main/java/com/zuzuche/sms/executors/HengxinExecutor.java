package com.zuzuche.sms.executors;

import com.zuzuche.sms.common.utils.SpringBeanFactory;
import com.zuzuche.sms.dto.SmsDto;
import com.zuzuche.sms.task.AbstractSendTask;
import com.zuzuche.sms.task.HengxinSendTask;
import com.zuzuche.threadpool.ThreadPoolExecutorFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * 功能：卓越恒信的工作线程池.
 * 详细：
 *
 * @author Created on 2019.06.27 by chaodian
 */
@Component
@Slf4j
public class HengxinExecutor extends AbstractOutboundExecutor{


    public HengxinExecutor(){
        super(
                ThreadPoolExecutorFactory.Config.builder()
                        .corePoolSize(20)
                        .maximumPoolSize(25)
                        .keepAliveTime(2)
                        .workQueue(new ArrayBlockingQueue<>(100))
                        .unit(TimeUnit.MINUTES)
                        .handler(new ThreadPoolExecutor.CallerRunsPolicy())
                        .threadPoolName("HengxinExecutor")
                        .build()
        );
    }

    /**
     *
     * @param sms
     */
    @Override
    public AbstractSendTask packingSendTask(SmsDto sms) {
        // 获取一个实例化的原型任务对象
        HengxinSendTask hengxinSendTask = SpringBeanFactory.getBean(HengxinSendTask.class,sms);

        return hengxinSendTask;
    }
}
