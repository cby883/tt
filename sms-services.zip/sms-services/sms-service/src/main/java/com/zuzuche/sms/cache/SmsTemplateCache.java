package com.zuzuche.sms.cache;

import com.zuzuche.commons.base.constants.BaseEnum;
import com.zuzuche.commons.base.resp.PhpResult;
import com.zuzuche.commons.base.resp.Status;
import com.zuzuche.commons.base.resp.StatusServiceCnException;
import com.zuzuche.commons.base.util.JsonUtil;
import com.zuzuche.commons.base.util.StringUtil;
import com.zuzuche.commons.redis.CacheExpires;
import com.zuzuche.sms.common.enums.SmsType;
import com.zuzuche.sms.remote.SmsTemplateRemote;
import com.zuzuche.sms.remote.dto.SmsTemplateDto;
import com.zuzuche.sms.remote.param.PhpParam;
import com.zuzuche.sms.vo.SmsTemplateText;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;


/**
 * 功能：The type Sms template cache.
 * 详细：
 *
 * @author Created on 2019.02.14 by chaodian
 */
@Component("SmsTemplateCache")
@Slf4j
public class SmsTemplateCache implements InitializingBean,ConfigCache {
    /**
     * 每个key为模板id的哈希键名
     */
    private final static String SMS_ID_TEMPLATES_KEY = "SMS::ID_TEMPLATES";

    /**
     * 每个key为模板标识的哈希键名
     */
    private final static String SMS_UID_TEMPLATES_KEY = "SMS::UID_TEMPLATES";

    /**
     * 保存在内存的模板id与短信类型map
     */
    private static Map<String, Integer> smsIdTemplateTypeMap = new HashMap<>();

    /**
     * 保存在内存的模板Uid与短信类型map
     */
    private static Map<String, Integer> smsUidTemplateTypeMap = new HashMap<>();

    @Autowired
    private StringRedisTemplate redisTemplate;

    @Autowired
    private SmsTemplateRemote smsTemplateRemote;

    /**
     * 是否存在某个模板id与短信类型映射的key
     * @param key the key
     * @return boolean
     */
    private boolean containsTempIdTypeKey(String key){
        return smsIdTemplateTypeMap.containsKey(key);
    }

    /**
     * Gets type by temp id.
     *
     * @param key the key
     * @return the type by temp id
     */
    public Integer getTypeByTempId(String key) {
        if (containsTempIdTypeKey(key)) {
            return smsIdTemplateTypeMap.get(key);
        } else {
            return null;
        }
    }

    /**
     * 是否存在某个模板Uid与短信类型映射的key
     * @param key the key
     * @return boolean
     */
    private boolean containsTempUIdTypeKey(String key){
        return smsUidTemplateTypeMap.containsKey(key);
    }

    /**
     * Gets type by temp u id.
     *
     * @param key the key
     * @return the type by temp u id
     */
    public Integer getTypeByTempUId(String key) {
        if (containsTempUIdTypeKey(key)) {
            return smsUidTemplateTypeMap.get(key);
        } else {
            return null;
        }
    }


    /**
     * 获取并缓存短信模板.
     *
     * 每个key为模板id, value为Dto的模板内容text
     */
    public synchronized void setAllIdTemplates() {
        PhpResult<List<SmsTemplateDto>> phpResult = smsTemplateRemote.getAllTemplates(new PhpParam());

        if (CollectionUtils.isEmpty(phpResult.getData())) {
            log.error("通过接口请求找不到短信模板");
            return;
        }

        Map<String, String> smsIdTemplates = new HashMap<>();
        Map<String, Integer> idTemplateTypeMap = new HashMap<>();
        phpResult.getData().forEach(temp -> {
            if (temp.getSendType() != null) {
                SmsType smsType = BaseEnum.parse(SmsType.class, temp.getSendType());
                if (smsType != null) {
                    idTemplateTypeMap.put(temp.getTempId(), smsType.code());
                }
            }

            smsIdTemplates.put(temp.getTempId(), JsonUtil.objToStr(temp.getText()));
        });

        // 直接整个map更新替换
        smsIdTemplateTypeMap = idTemplateTypeMap;

        redisTemplate.opsForHash().putAll(SMS_ID_TEMPLATES_KEY, smsIdTemplates);
        redisTemplate.expire(SMS_ID_TEMPLATES_KEY, CacheExpires.IN_12HOUR, TimeUnit.SECONDS);
    }

    /**
     * 获取并缓存短信模板.
     *
     * 每个key为模板标识, value为Dto的模板内容text
     */
    public synchronized void setAllUidTemplates() {
        PhpResult<List<SmsTemplateDto>> phpResult = smsTemplateRemote.getAllTemplates(new PhpParam());

        Map<String, String> smsUIdTemplates = new HashMap<>();
        Map<String, Integer> uidTemplateTypeMap = new HashMap<>();
        phpResult.getData().forEach(temp -> {
            if (StringUtil.isNotBlank(temp.getTempUid())) {
                smsUIdTemplates.put(temp.getTempUid(), JsonUtil.objToStr(temp.getText()));

                if (temp.getSendType() != null) {
                    SmsType smsType = BaseEnum.parse(SmsType.class, temp.getSendType());
                    if (smsType != null) {
                        uidTemplateTypeMap.put(temp.getTempUid(), smsType.code());
                    }
                }
            }
        });

        // 直接将整个map更新替换
        smsUidTemplateTypeMap = uidTemplateTypeMap;

        if (smsUIdTemplates.isEmpty()) {
            log.error("通过接口请求找不到有模板标识的短信模板");
            return;
        }

        redisTemplate.opsForHash().putAll(SMS_UID_TEMPLATES_KEY, smsUIdTemplates);
        redisTemplate.expire(SMS_UID_TEMPLATES_KEY, CacheExpires.IN_12HOUR, TimeUnit.SECONDS);
    }

    /**
     * 获取具体的短信模板内容
     * @param cacheKey redis键的key名
     * @param id redis哈希键的field的key名
     * @param language 语言版本
     * @return string
     */
    private String getTemplateContent(String cacheKey, String id, String language) {
        String templateStr = (String) redisTemplate.opsForHash().get(cacheKey, id);
        List<SmsTemplateText> templateTextList = JsonUtil.stringToObjList(templateStr, SmsTemplateText.class);

        if (templateTextList == null) {
            return "";
        }


        String content = templateTextList.stream().filter(item -> item.getLanguage().equals(language))
                .map(SmsTemplateText::getContent)
                .findFirst().orElse(null);

        if (StringUtil.isEmpty(content)) {
            return "";
        }

        return content;
    }

    /**
     * 通过模板主键id和语言版本获取具体的模板内容.
     *
     * @param tempId   the temp id
     * @param language the language
     * @return the template by id
     */
    public String getTemplateById(String tempId, String language) {
        if (!redisTemplate.opsForHash().hasKey(SMS_ID_TEMPLATES_KEY, tempId)) {
            setAllIdTemplates();
        }

        return getTemplateContent(SMS_ID_TEMPLATES_KEY, tempId, language);
    }


    /**
     * 通过模板标识和语言版本获取具体的模板内容.
     *
     * @param tempUid  the temp uid
     * @param language the language
     * @return the template by u id
     */
    public String getTemplateByUId(String tempUid, String language) {
        if (!redisTemplate.opsForHash().hasKey(SMS_UID_TEMPLATES_KEY, tempUid)) {
            setAllUidTemplates();
        }

        return getTemplateContent(SMS_UID_TEMPLATES_KEY, tempUid, language);
    }

    @Override
    public boolean refresh() {
        try {
            setAllIdTemplates();
            setAllUidTemplates();
            return true;
        } catch (Exception e) {
            log.error("【SmsTemplateCache】配置刷新失败",e.getMessage(),e);
            return false;
        }
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        try {
            setAllIdTemplates();
            setAllUidTemplates();
        } catch (Exception e) {
            log.error("【SmsTemplateCache】配置刷新失败",e.getMessage(),e);
            throw e;
        }
    }
}
