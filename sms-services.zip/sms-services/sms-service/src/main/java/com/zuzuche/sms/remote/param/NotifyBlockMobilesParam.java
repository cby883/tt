package com.zuzuche.sms.remote.param;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @desc: 通知上游短信业务服务发送供应商状态
 * @author: panqiong
 * @date: 2018/10/24
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class NotifyBlockMobilesParam {

    @Builder.Default
    private String i = "SmsMt-callBackErrMobiles";
    /**
     * md5
     */
    private String token;


    private String t;

    /**
     * 任务主键id
     */
    private String taskId;

    /**
     * 拦截类型 参考Constant.filterTypes
     */
    private String type;

    /**
     * 多个用,隔开
     */
    private String mobiles;


}
