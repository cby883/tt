package com.zuzuche.sms.listener.smstype;

import com.google.common.util.concurrent.RateLimiter;
import com.zuzuche.logback.util.MDCUtil;
import com.zuzuche.sms.cache.SmsConfigCache;
import com.zuzuche.sms.common.enums.RateLimiterKeyTypes;
import com.zuzuche.sms.dto.MtDto;
import com.zuzuche.sms.executors.VerifyMtExecutor;
import com.zuzuche.sms.service.KafkaService;
import com.zuzuche.sms.service.SmsMtService;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import java.util.concurrent.RejectedExecutionException;

/**
 * 功能：下行验证码短信消费监听器.
 * 详细：
 *
 * @author Created on 2019.02.14 by chaodian
 */
@Component
@Slf4j
public class VerifyMtListener  {
    private static final String RATE_KEY = "sms_verify_topic_rate";

    private static RateLimiter rateLimiter;

    /**
     * The Kafka service.
     */
    @Autowired
    KafkaService kafkaService;

    /**
     * The Sms mt service.
     */
    @Autowired
    SmsMtService smsMtService;

    /**
     * The Config cache.
     */
    @Autowired
    SmsConfigCache configCache;

    /**
     * The Mt executor.
     */
    @Autowired
    VerifyMtExecutor mtExecutor;

    /**
     * Consume.
     *
     * @param consumer the consumer
     */
    @KafkaListener(topics = KafkaService.VERIFY_MT_TOPIC)
    public void consume(ConsumerRecord<String, MtDto> consumer) {
        MDCUtil.set();
        if(log.isDebugEnabled()){
            log.debug("[receive sms_verify_topic]:" +consumer.value());
        }
        rateLimiter=configCache.getLimiter(RateLimiterKeyTypes.SMS_VERIFY_TOPIC_RATE);
        rateLimiter.acquire();
        try {
            // 1个短信实体
            MtDto sms = consumer.value();
            // 下行短信业务处理
            mtExecutor.handle(sms);
        } catch (RejectedExecutionException e){
            log.error("[验证码线程池拒绝策略触发-sms_verify_topic]message:"+consumer.value(),e.getMessage(),e);
        } catch (Exception e){
            // 发送到dlq队列 并预警人工接入
            log.error("[验证码通知消息处理出现异常-sms_verify_topic]message:"+consumer.value(),e.getMessage(),e);
        } finally {
            MDCUtil.clear();
        }
    }
}
