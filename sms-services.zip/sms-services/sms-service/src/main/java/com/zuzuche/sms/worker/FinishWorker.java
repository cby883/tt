package com.zuzuche.sms.worker;

import com.lmax.disruptor.BlockingWaitStrategy;
import com.lmax.disruptor.dsl.ProducerType;
import com.zuzuche.sms.dto.InvokeResultDto;
import com.zuzuche.sms.service.SendResultService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.util.CallerBlocksPolicy;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * 每个worker内置了disruptor做queue
 *
 * 推送供应商之后的收尾工作
 *
 * 回调上游的php接口太慢了,处理不过来,队列很快就满了.所以先屏蔽了 ,改用kafka队列
 * @author pan
 * ///@Component
 */
@Slf4j
public class FinishWorker<T> extends AbstractWorker<T> {


    @Autowired
    SendResultService sendResultService;


    /**
     * 可以在这里修改disruptor队列相关配置
     */
    public FinishWorker() {
        super(
                WorkerConfig.builder()
                .bufferSize(4096)
                .producerType(ProducerType.MULTI)
                .strategy(new BlockingWaitStrategy())
                .consumeExecutor(new ThreadPoolExecutor( 2,
                    4,
                    5,
                    TimeUnit.MINUTES,
                    new ArrayBlockingQueue<>(10), new CallerBlocksPolicy(60*1000)))
                .build()
        );
    }


    /**
     * 发送供应商后的收尾工作
     * 0.设置号码和md5(内容)到redis中,用作判重
     * 1.上报监控系统
     * 2.更新库表发送状态
     * 3.回调上游服务 后续要改成kafka通知 不再搞http回调
     */
    @Override
    public void consume(T object){

        InvokeResultDto dto = (InvokeResultDto)object;

        sendResultService.process(dto);

    }




}
