package com.zuzuche.sms.executors;

import com.zuzuche.sms.cache.ProviderAccountCache;
import com.zuzuche.sms.common.utils.SpringBeanFactory;
import com.zuzuche.sms.dto.SmsDto;
import com.zuzuche.sms.entity.ProviderAccountInfo;
import com.zuzuche.sms.task.AbstractSendTask;
import com.zuzuche.sms.task.ChLanInterSendTask;
import com.zuzuche.sms.task.ChLanSendTask;
import com.zuzuche.threadpool.ThreadPoolExecutorFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.integration.util.CallerBlocksPolicy;
import org.springframework.stereotype.Component;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * @desc: 创蓝工作线程组
 * @author: panqiong
 * @date: 2018/11/12
 */
@Component
@Slf4j
public class ChLanExecutor extends AbstractOutboundExecutor{

    public ChLanExecutor() {
        super(ThreadPoolExecutorFactory.Config.builder()
                .corePoolSize(20)
                .maximumPoolSize(25)
                .keepAliveTime(5)
                .workQueue(new ArrayBlockingQueue<>(100))
                .unit(TimeUnit.MINUTES)
                .handler(new ThreadPoolExecutor.CallerRunsPolicy())
                .threadPoolName("ChLanExecutor")
                .build()
        );
    }



    /**
     * 打包发送任务  将sms包装成task
     * @param sms
     */
    @Override
    public AbstractSendTask packingSendTask(SmsDto sms)  {

        ProviderAccountInfo accountInfo = ProviderAccountCache.getAccountById(sms.getAccountId());
        // 创蓝的国际短信和国内短信 要分开任务
        //int domestic = 1;
        int international = 2;
        // 如果是创蓝国际短信  返回一个国际短信发送任务
        if(accountInfo.getAreaType()==international){
            return SpringBeanFactory.getBean(ChLanInterSendTask.class,sms);
        }else{
            return SpringBeanFactory.getBean(ChLanSendTask.class,sms);
        }


    }
}
