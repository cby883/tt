package com.zuzuche.sms.job;
import com.zuzuche.commons.base.util.StringUtil;
import com.zuzuche.commons.redis.DistributeJobExecutor;
import com.zuzuche.commons.redis.RedisLock;
import com.zuzuche.logback.util.MDCUtil;
import com.zuzuche.sms.cache.ProviderAccountCache;
import com.zuzuche.sms.cache.SmsClassConfigCache;
import com.zuzuche.sms.common.enums.SmsBatchSendTaskType;
import com.zuzuche.sms.common.utils.SpringBeanFactory;
import com.zuzuche.sms.entity.SmsBatchTask;
import com.zuzuche.sms.entity.SmsClassConfig;
import com.zuzuche.sms.mapper.SmsBatchTaskMapper;
import com.zuzuche.sms.report.syn.SynService;
import com.zuzuche.sms.service.BatchTaskContainerService;
import com.zuzuche.sms.task.SmsBatchSendTask;
import com.zuzuche.threadpool.ThreadPoolExecutorFactory;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.text.MessageFormat;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * @desc: 文件批量发送定时器(筛选出处于已就绪状态的任务)
 * @author: bingyi
 * @date: 2019/11/07
 */
@Component
@Slf4j
public class SmsBatchTaskJob  {
    /**
     * 任务线程池
     */
    ExecutorService executorService=ThreadPoolExecutorFactory.create(
            ThreadPoolExecutorFactory.Config.builder()
                    .corePoolSize(5)
                    .maximumPoolSize(10)
                    .keepAliveTime(5)
                    .workQueue(new ArrayBlockingQueue<>(50))
                    .unit(TimeUnit.MINUTES)
                    .handler(new ThreadPoolExecutor.CallerRunsPolicy())
                    .threadPoolName("SmsBatchTaskExecutor")
                    .build()
    );
    @Autowired
    SmsBatchTaskMapper smsBatchTaskMapper;
    @Autowired
    BatchTaskContainerService batchTaskContainerService;
    private static final String SMS_BATCH_TASK_SMS_KEY="SMS_BATCH_TASK_SMS_KEY_1_";
    /**
     *  每一分钟执行一遍
     */
    @Scheduled(cron = "0 */1 * * * ?")
    public void execute(){
        MDCUtil.set();
        RedisLock redisLock=new RedisLock(SMS_BATCH_TASK_SMS_KEY);
        try {
            if(redisLock.lock()){
                try {
                    //获取就绪的任务列表
                    List<SmsBatchTask> list=smsBatchTaskMapper.selectStatusAndPlanTime(SmsBatchSendTaskType.SMS_BATCH_SEND_TASK_TYPE_READY.code(),
                            LocalDateTime.now());
                    //加载到本地running状态容器中
                    List<SmsBatchTask> newList=batchTaskContainerService.add(list);
                    //加载任务到线程池中
                    pushInTaskExecutor(newList);
                } finally {
                    //释放锁
                    redisLock.unlock();
                }
            }
        } catch (Exception e) {
            log.error("【SmsBatchTaskJob】批量发送定时器出错",e.getMessage(),e);
        }
        MDCUtil.clear();
    }

    /**
     *
     * @param list
     */
    private void pushInTaskExecutor(List<SmsBatchTask> list){
        list.forEach(e->{
            executorService.execute(packingTask(e.getId()));
        });
    }

    private SmsBatchSendTask packingTask(int taskId){
        return SpringBeanFactory.getBean(SmsBatchSendTask.class,taskId);
    }
}
