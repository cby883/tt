package com.zuzuche.sms.service;

import com.google.common.base.Joiner;
import com.google.common.base.Splitter;
import com.google.common.util.concurrent.RateLimiter;
import com.zuzuche.commons.base.constants.BaseEnum;
import com.zuzuche.commons.base.resp.Status;
import com.zuzuche.commons.base.resp.StatusServiceCnException;
import com.zuzuche.commons.base.util.BeanConverter;
import com.zuzuche.commons.base.util.CollectionUtil;
import com.zuzuche.commons.base.util.StringUtil;
import com.zuzuche.kafka.message.BaseMessage;
import com.zuzuche.sms.cache.*;
import com.zuzuche.sms.common.constant.Constants;
import com.zuzuche.sms.common.enums.*;
import com.zuzuche.sms.common.utils.Md5Util;
import com.zuzuche.sms.common.utils.PerformUtil;
import com.zuzuche.sms.dto.*;
import com.zuzuche.sms.entity.*;
import com.zuzuche.sms.mapper.SmsMtMapper;
import com.zuzuche.sms.mapper.SmsMtMarketMapper;
import com.zuzuche.sms.mapper.SmsSendErrorLogMapper;
import com.zuzuche.sms.remote.param.SendRemarkParam;
import com.zuzuche.sms.rest.request.MtReq;
import com.zuzuche.sms.rest.request.MtTemplateReq;
import com.zuzuche.sms.rest.request.RefreshSmsMtConfigReq;
import com.zuzuche.sms.rest.response.MtResp;
import com.zuzuche.threadpool.ThreadPoolExecutorFactory;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Service;
import org.springframework.util.concurrent.ListenableFuture;

import java.time.Instant;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.*;
import java.util.concurrent.*;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * 功能：业务方调用的下行短信处理.
 * 详细：
 *
 * @author Created on 2019.01.30 by chaodian
 */
@Service
@Slf4j
public class SmsMtService implements InitializingBean {
    @Autowired
    KafkaTemplate<String, BaseMessage> kafkaTemplate;

    @Autowired
    BlackWiteMobileCache blackWiteMobileCache;

    @Autowired
    SmsSignCache smsSignCache;

    @Autowired
    SafeMonitorRuleCache safeMonitorRuleCache;

    @Autowired
    SmsTemplateCache smsTemplateCache;

    @Autowired
    SupplierConfigCache supplierConfigCache;

    @Autowired
    SupplierMatchRuleCache supplierMatchRuleCache;

    @Autowired
    SmsMtMapper smsMtMapper;

    @Autowired
    SmsMtMarketMapper smsMtMarketMapper;

    @Autowired
    SmsSendErrorLogMapper sendErrorLogMapper;

    @Autowired
    AccountIdBakPolicyCache accountIdBakPolicyCache;

    @Autowired
    KafkaService kafkaService;

    /**
     * The High freq mobile cache.
     */
    @Autowired
    HighFreqMobileCache highFreqMobileCache;

    @Autowired
    SmsConfigCache configCache;

    @Autowired
    RefreshConfigService refreshConfigService;

    @Value("${envi}")
    String smsEnv;

    /**
     * 短信生产环境的配置标识
     */
    private static final String SMS_ENV_PRD = "prd";

    /**
     * mt插表速率限制
     */
    private static RateLimiter rateLimiter;

    /**
     * 插入mt的数据表的速率key
     */
    private static final String SMS_MT_INSERT_DB_RATE = "sms_mt_insert_db_rate";

    /**
     * 国际租车业务方名称
     */
    private static final String CAR_RENT_FROM_NAME = "car_rent";

    /**
     * POI的业务方名称
     */
    private static final String POI_FROM_NAME = "poi";


    /**
     * 短信redis频率设置线程池
     */
    private static ExecutorService freqExecutor = ThreadPoolExecutorFactory
            .create(ThreadPoolExecutorFactory.Config.builder()
                    .corePoolSize(300)
                    .maximumPoolSize(300)
                    .keepAliveTime(5)
                    .workQueue(new ArrayBlockingQueue<>(1000))
                    .unit(TimeUnit.MINUTES)
                    .handler(new ThreadPoolExecutor.CallerRunsPolicy())
                    .threadPoolName("highFreqIncreSetExecutor")
                    .build());

    /**
     * 初始化mt插表速率
     */
    @Override
    public void afterPropertiesSet() throws Exception {
        if (configCache.containsKey(SMS_MT_INSERT_DB_RATE)) {
            int rate = Integer.parseInt(configCache.get(SMS_MT_INSERT_DB_RATE));
            rateLimiter = RateLimiter.create(rate);
        } else {
            rateLimiter = RateLimiter.create(100);
        }
    }

    /**
     * 通过模板发送短信
     *
     * @param req
     * @return
     */
    public MtResp sendWithTemplate(MtTemplateReq req) {
        long start = Instant.now().toEpochMilli();
        List<String> mobiles = getMobileList(req.getMobiles());
        if (StringUtil.isBlank(req.getTempId()) && StringUtil.isBlank(req.getTempUid())) {
            throw new StatusServiceCnException(Status.PARAMS_IS_BLANK, "必须传tempId或者tempUid");
        }
        MtDto mtDto = formMtDto(req, mobiles);
        pushMtIntoQueue(mtDto,null);
        long end = Instant.now().toEpochMilli();
        MtResp mtResp = buildMtRespByMobiles(mobiles);
        PerformUtil.logTime("mt/sendByTemplate", start, end);
        return mtResp;
    }

    /**
     * 判断短信是否模拟提交，不真是发送
     *
     * @return boolean
     */
    private boolean checkIsSmsMock() {
        return !SMS_ENV_PRD.equals(smsEnv);
    }

    /**
     * 格式化根据内容下发的短信信息.
     *
     * @param req     the req
     * @param mobiles the mobiles
     * @return the mt dto
     */
    public MtDto formMtDto(MtReq req, List<String> mobiles) {
        MtDto mtDto = MtDto.builder()
                .mobiles(Joiner.on(",").join(mobiles))
                .content(req.getContent())
                .type(req.getType())
                .regionType(req.getRegionType())
                .signType(req.getSignType())
                .admin(req.getAdmin())
                .extraParam(req.getExtraParam())
                .from(req.getFrom())
                .uniqueId(req.getUniqueId())
                .mock(!req.getRealSend() && checkIsSmsMock())
                .mockTimeOutUntilRetryNo(req.getMockTimeOutUntilRetryNo())
                .build();
        if (StringUtil.isNotBlank(req.getBatch())) {
            mtDto.setBatch(Md5Util.string2MD5(req.getBatch()));
        }

        return mtDto;
    }

    /**
     * 格式化根据模板下发的短信信息.
     *
     * @param req     the req
     * @param mobiles the mobiles
     * @return the mt dto
     */
    public MtDto formMtDto(MtTemplateReq req, List<String> mobiles) {
        // 模板的短信类型由模板配置决定
        Integer sendType;
        if (StringUtil.isNotBlank(req.getTempId())) {
            sendType = smsTemplateCache.getTypeByTempId(req.getTempId());
        } else if (StringUtil.isNotBlank(req.getTempUid())) {
            sendType = smsTemplateCache.getTypeByTempUId(req.getTempUid());
        } else {
            sendType = SmsType.普通通知.code();
        }

        MtDto mtDto = MtDto.builder()
                .mobiles(Joiner.on(",").join(mobiles))
                .tempId(req.getTempId())
                .tempUid(req.getTempUid())
                .variables(req.getVariables())
                .language(req.getLanguage())
                .type(sendType != null ? sendType : SmsType.普通通知.code())
                .regionType(req.getRegionType())
                .signType(req.getSignType())
                .admin(req.getAdmin())
                .extraParam(req.getExtraParam())
                .from(req.getFrom())
                .uniqueId(req.getUniqueId())
                .mock(!req.getRealSend() && checkIsSmsMock())
                .useTemplate(1)
                .build();
        if (StringUtil.isNotBlank(req.getBatch())) {
            mtDto.setBatch(Md5Util.string2MD5(req.getBatch()));
        }

        return mtDto;
    }

    /**
     * 将下行短信推送入队.
     *
     * @param mtDto the mt dto
     * @param exTopicName
     */
    public void pushMtIntoQueue(MtDto mtDto,String exTopicName) {
        if (StringUtil.isNotBlank(mtDto.getUniqueId()) && StringUtil.isBlank(mtDto.getFrom())) {
            throw new StatusServiceCnException(Status.PARAMS_IS_BLANK, "传uniqueId的同时必须指定from参数");
        }

        SmsType smsType = BaseEnum.parse(SmsType.class, mtDto.getType());
        if (smsType == null) {
            throw new StatusServiceCnException(Status.OBJECT_NOT_EXIST, "没有找到该短信类型的配置");
        }
        String topicName =StringUtil.isBlank(exTopicName)?smsType.getTopic():exTopicName;

        // 由于国际短信，需要根据区号去选择供应商, 因此识别到是国际，就进行根据区号进行拆分
        List<MtDto> list;
        if (mtDto.getRegionType() == SmsRegionType.国际.code()) {
            List<MtDto> tempList = breakingMtDto(mtDto);
            list = splitInterMtDtoList(tempList);
        } else {
            list = breakingMtDto(mtDto);
        }

        if (list == null || CollectionUtils.isEmpty(list)) {
            throw new StatusServiceCnException(Status.BUSY, "解析后短信信息为空");
        }

        //拆分后推送进队列
        list.stream().forEach(item -> {
            // 送进kafka 根据mobile选择分区
            ListenableFuture<SendResult<String, BaseMessage>> future = kafkaTemplate.send(topicName, StringUtil.join(item.getMobiles(), ","), item);

            try {
                future.get(5, TimeUnit.SECONDS);
                // log.info("[mt/send推送结果]:"+future.toString());
            } catch (InterruptedException e) {
                log.error("[mt/send推送kafka异常]:", e.getMessage(), e);
                Thread.currentThread().interrupt();
                throw new StatusServiceCnException(Status.BUSY, "推送入队发生异常 InterruptedException");
            } catch (ExecutionException e) {
                log.error("[mt/send推送kafka异常]:", e.getMessage(), e);
                throw new StatusServiceCnException(Status.BUSY, "推送入队发生异常 ExecutionException");
            } catch (TimeoutException e) {
                log.error("[mt/send推送kafka异常]:", e.getMessage(), e);
                throw new StatusServiceCnException(Status.BUSY, "推送入队发生异常 TimeoutException");
            } catch (Exception e) {
                log.error("[mt/send推送kafka异常]:", e.getMessage(), e);
                throw new StatusServiceCnException(Status.BUSY, "推送入队发生异常 Exception");
            }
        });
    }

    /**
     * 将国际短信再进一步根据区号进行拆分.
     *
     * @param tempMtDtoList 未拆分前的短信列表
     * @return the list
     */
    private List<MtDto> splitInterMtDtoList(List<MtDto> tempMtDtoList) {
        // 初始化最后拆分的国际短信列表
        List<MtDto> mtDtoList = new ArrayList<>();

        tempMtDtoList.forEach(tempMtDto -> {
            // 初始化根据区号映射的手机列表
            Map<String, List<String>> mobileMap = new HashMap<>(16);
            // 对手机进行拆分，以英文逗号进行分割拆分
            List<String> phoneList = StringUtil.asList(tempMtDto.getMobiles());
            for (String interMobile : phoneList) {
                // 每个手机号码再根据-进行拆分，得到下标0为区号，1为手机号码
                List<String> mobileSplitedList = Splitter.on("-").splitToList(interMobile);
                // 默认为86国内
                String areaCode = "86";
                try {
                    if (StringUtil.isNotBlank(mobileSplitedList.get(0))) {
                        areaCode = mobileSplitedList.get(0);
                    }
                } catch (IndexOutOfBoundsException e) {
                    log.warn("切割国际手机获取区号出错:" + interMobile, e, e.getMessage());
                }

                // 下面对区号为key的map进行处理，将所有同个区号的完整手机放入同一个key作为一个list
                if (mobileMap.containsKey(areaCode)) {
                    List<String> tempMobileList = mobileMap.get(areaCode);
                    tempMobileList.add(interMobile);
                    mobileMap.put(areaCode, tempMobileList);
                } else {
                    List<String> tempMobileList = new ArrayList<>(1);
                    tempMobileList.add(interMobile);
                    mobileMap.put(areaCode, tempMobileList);
                }
            }

            // 最后对map进行组装，将同个区号的手机当做一个批次，k为区号，v为此次批次的手机列表
            mobileMap.forEach((k, v) -> {
                MtDto mtDto = BeanConverter.copy(tempMtDto, MtDto.class);
                mtDto.setExactAreaCode(k);
                mtDto.setMobiles(Joiner.on(",").join(v));
                mtDtoList.add(mtDto);
            });
        });

        return mtDtoList;
    }

    /**
     * desc:拆分200个手机号-->100个推送入队
     *
     * @param firstMtDto
     * @return
     */
    public static List<MtDto> breakingMtDto(MtDto firstMtDto) {
        int phoneCount = 100;
        List<String> phoneList = Splitter.on(",").splitToList(firstMtDto.getMobiles());
        int size = phoneList.size();
        List<MtDto> result = new ArrayList<>(3);
        if (size > phoneCount) {
            MtDto tailMtDto = BeanConverter.copy(firstMtDto, MtDto.class);
            List<String> firstList = phoneList.subList(0, 100);
            List<String> tailList = phoneList.subList(100, phoneList.size());
            firstMtDto.setMobiles(Joiner.on(",").join(firstList));
            tailMtDto.setMobiles(Joiner.on(",").join(tailList));
            result.add(firstMtDto);
            result.add(tailMtDto);
        } else {
            result.add(firstMtDto);
        }
        return result;
    }

    /**
     * 根据批量的手机号筛选过滤重复的手机
     *
     * @param mobiles 批量手机号，多个英文逗号分割
     * @return list
     */
    public List<String> getMobileList(String mobiles) {
        List<String> mobileList = StringUtil.asList(mobiles);
        if (mobiles.contains(",")) {
            mobileList = mobileList.stream().distinct().collect(Collectors.toList());
        }

        if (mobileList.size() > Constants.MAX_MOBILES_SIZE) {
            throw new StatusServiceCnException(Status.PARAMS_OUT_OF_RANGE_ERROR, "一次最多推送的手机个数为200");
        }

        return mobileList;
    }

    /**
     * 通过批量的手机号码构造对接业务方的下行短信返回信息.
     * <p>
     * 由于业务方请求短信直接入队，因此接口一直返回每条短信的成功入队状态
     *
     * @param mobileList the mobile list
     * @return the mt resp
     */
    public MtResp buildMtRespByMobiles(List<String> mobileList) {
        Map<String, MtResp.MobileStatus> mobilesMap = new HashMap<>();
        mobileList.forEach(item -> {
            MtResp.MobileStatus mobileStatus = MtResp.MobileStatus.builder()
                    .mobile(item)
                    .sendStatus("success")
                    .msg("入队成功")
                    .build();
            mobilesMap.put(item, mobileStatus);
        });

        return MtResp.builder().sendRes(mobilesMap).build();
    }

    /**
     * 刷新业务下行短信配置
     *
     * @param req the req
     */
    public List<RefreshConfigDto> refreshMtConfig(RefreshSmsMtConfigReq req) {
        //判空
        if (StringUtil.isBlank(req.getConfigName())) {
            throw new StatusServiceCnException(Status.PARAMS_IS_BLANK, "配置名称参数不能为空");
        }
        ConfigNameTypes config = BaseEnum.parse(ConfigNameTypes.class, req.getConfigName());
        if (config == null) {
            throw new StatusServiceCnException(Status.OBJECT_NOT_EXIST, "配置项不存在");
        }
        //调用
        return refreshConfigService.triggerNodeRefresh(config.getConfigName());
    }


    /**
     * 载入短信下发流程所需要的所有配置到缓存.
     * <p>
     * 1. 黑白名单配置
     * 2. 拦截监控规则配置
     * 3. 短信签名配置
     * 4. 短信模板配置
     * 5. 供应商配置
     * 6. 短信供应商匹配规则配置
     */
    public void loadAllMtConfig() {
        try {
            blackWiteMobileCache.loadAll();
            safeMonitorRuleCache.load();
            smsSignCache.load();
            smsTemplateCache.setAllIdTemplates();
            smsTemplateCache.setAllUidTemplates();
            supplierConfigCache.load();
            supplierMatchRuleCache.loadCommonRule();
            supplierMatchRuleCache.loadExtraRule();
        } catch (Exception e) {
            throw new StatusServiceCnException(Status.BUSY, "载入配置失败:" + e.getMessage());
        }
    }

    /**
     * 截取国际手机的区号，国际手机格式必须为如887-2323232
     *
     * @param mobile the mobile
     * @return String
     */
    private String fetchInterMobAreaCode(String mobile) {
        String pattern = Constants.INTER_AREA_CODE_PREG;
        Pattern r = Pattern.compile(pattern);
        Matcher m = r.matcher(mobile);
        if (m.find()) {
            String areaCode = m.group();
            // 去除下前缀0，再入库
            if (areaCode != null) {
                areaCode = areaCode.trim().replaceFirst(Constants.MOBILE_PREFIX_PREG, "");
            }
            return areaCode;
        } else {
            return Constants.INNER_MOBILE_AREA_CODE;
        }
    }

    /**
     * 截取国际手机号码，国际手机格式必须为如887-2323232
     *
     * @param mobile the mobile
     * @return String
     */
    private String fetchInterMobile(String mobile) {
        String pattern = Constants.INTER_PHONE_PREG;
        Pattern r = Pattern.compile(pattern);
        Matcher m = r.matcher(mobile);
        if (m.find()) {
            return m.group();
        } else {
            return "";
        }
    }

    /**
     * 推送到供应商短信队列
     *
     * @param smsDto the sms dto
     */
    public void pushSmsIntoSupplierQueue(SmsDto smsDto) {
        ProviderAccountInfo accountInfo = ProviderAccountCache.getAccountById(smsDto.getAccountId());
        if (accountInfo == null) {
            log.error("账户id不存在, 短信数据为:" + smsDto.toString());
            return;
        }

        SmsClassConfig config = SmsClassConfigCache.getByProviderId(accountInfo.getProviderId());
        if (config == null) {
            log.error("未配置该供应商的topic:" + accountInfo.getProviderId() + ", 短信数据为:" + smsDto.toString());
            return;
        }

        String topicName = config.getOutBoundTopic();

        // 送进kafka 根据mobile选择分区
        ListenableFuture<SendResult<String, BaseMessage>> future = kafkaTemplate.send(topicName, smsDto.getMobile(), smsDto);

        try {
            future.get(5, TimeUnit.SECONDS);
            /// log.info("[synsend推送结果]:"+sendResult.toString());
        } catch (Exception e) {
            log.error("[retry推送供应商kafka队列异常]短信数据为:" + smsDto.toString(), e.getMessage(), e);
        }
    }

    /**
     * 将mtDto格式的短信转化为SmsDto，并推送入队
     *
     * @param mtDto the mt dto
     */
    public void dispatch(MtDto mtDto) {

        //获取额外参数
        ExtraParamDto extraParamDto = mtDto.getExtraParamDto();
        // 注意以下转换过程中,需要将手机字符串中带有-的去除
        SmsDto smsDto = SmsDto.builder()
                .accountId(mtDto.getAccountId())
                .signType(mtDto.getSignType())
                .content(mtDto.getSendContent())
                .extraParamDto(mtDto.getExtraParamDto())
                .type(mtDto.getType())
                .senderId(extraParamDto == null ? null : extraParamDto.getSenderId())
                .backup(mtDto.getBackup())
                .supplier(mtDto.getSupplier())
                .regionType(mtDto.getRegionType())
                .retryContent(mtDto.getRetryContent())
                .mobile(
                        mtDto.getMobiles().contains(Constants.INTER_MOBILE_JOIN_MARK) ?
                                mtDto.getMobiles().replace(Constants.INTER_MOBILE_JOIN_MARK, "") :
                                mtDto.getMobiles()
                ).mock(mtDto.isMock())
                .mockTimeOutUntilRetryNo(mtDto.getMockTimeOutUntilRetryNo())
                .taskId(mtDto.getTaskId())
                .build();

        pushSmsIntoSupplierQueue(smsDto);
    }

    /**
     * 转换成营销短信实体
     *
     * @param sms         对接业务方的下行短信信息
     * @param mobile      手机号码
     * @param currentTime 当前时间戳，精确秒
     * @return SmsMtMarket
     */
    private SmsMtMarket formSmsMtMarket(MtDto sms, String mobile, int currentTime) {
        return SmsMtMarket.builder()
                .areaCode(sms.getRegionType() == SmsRegionType.国际.code() ? fetchInterMobAreaCode(mobile) : Constants.INNER_MOBILE_AREA_CODE)
                .mobile(mobile.replace(Constants.INTER_MOBILE_JOIN_MARK, ""))
                .type((byte) sms.getType())
                .regionType((byte) sms.getRegionType())
                .signType((byte) sms.getSignType())
                .supplier(sms.getSupplier())
                .admin(StringUtil.isNotBlank(sms.getAdmin()) ? sms.getAdmin() : "system")
                .batch(sms.getBatch())
                .fromType(StringUtil.isNotBlank(sms.getFrom()) ? sms.getFrom() : "")
                .fromUniqueId(StringUtil.isNotBlank(sms.getUniqueId()) ? sms.getUniqueId() : "")
                .taskId(Integer.parseInt(sms.getTaskId()))
                .pushStatus("pushed")
                .requestStatus((byte) 0)
                .status((byte) 0)
                .sendCount((byte) sms.getSendCount())
                .content(sms.getContent())
                .extraParam(StringUtil.isNotBlank(sms.getExtraParam()) ? sms.getExtraParam() : "")
                .sendTime(currentTime)
                .addTime(currentTime)
                .sign(sms.getSign())
                .ext("")
                .updateTime(0)
                .build();
    }

    /**
     * 转换成普通通知短信实体
     *
     * @param sms         对接业务方的下行短信信息SmsType smsType = BaseEnum.parse(SmsType.class, mtDto.getType());
     * @param mobile      手机号码
     * @param currentTime 当前时间戳，精确秒
     * @return SmsMt
     */
    private SmsMt formSmsMt(MtDto sms, String mobile, int currentTime) {
        return SmsMt.builder()
                .areaCode(sms.getRegionType() == SmsRegionType.国际.code() ? fetchInterMobAreaCode(mobile) : Constants.INNER_MOBILE_AREA_CODE)
                .mobile(mobile.replace(Constants.INTER_MOBILE_JOIN_MARK, ""))
                .type((byte) sms.getType())
                .regionType((byte) sms.getRegionType())
                .signType((byte) sms.getSignType())
                .supplier(sms.getSupplier())
                .admin(sms.getAdmin())
                .batch(sms.getBatch())
                .fromType(StringUtil.isNotBlank(sms.getFrom()) ? sms.getFrom() : "")
                .fromUniqueId(StringUtil.isNotBlank(sms.getUniqueId()) ? sms.getUniqueId() : "")
                .taskId(Integer.parseInt(sms.getTaskId()))
                .pushStatus("pushed")
                .requestStatus((byte) 0)
                .status((byte) 0)
                .sendCount((byte) sms.getSendCount())
                .content(sms.getContent())
                .extraParam(StringUtil.isNotBlank(sms.getExtraParam()) ? sms.getExtraParam() : "")
                .sendTime(currentTime)
                .addTime(currentTime)
                .sign(sms.getSign())
                .ext("")
                .updateTime(0)
                .build();
    }

    /**
     * 将业务短信入库
     *
     * @param sms the mt dto
     */
    public void saveToMtDb(MtDto sms) {
        rateLimiter.acquire();

        String mobiles = sms.getMobiles();
        List<String> mobileList = Splitter.on(",").splitToList(mobiles);
        int currentTime = (int) (System.currentTimeMillis() / 1000);

        sms.setSendTime(currentTime);

        if (sms.getType() == SmsType.营销.getCode()) {
            List<SmsMtMarket> marketList = mobileList.parallelStream()
                    .map(mobile -> formSmsMtMarket(sms, mobile, currentTime))
                    .collect(Collectors.toList());
            smsMtMarketMapper.insertList(marketList);
        } else {
            List<SmsMt> normalList = mobileList.parallelStream()
                    .map(mobile -> formSmsMt(sms, mobile, currentTime))
                    .collect(Collectors.toList());
            smsMtMapper.insertList(normalList);
        }

    }

    /**
     * 将拦截业务短信入库
     *
     * @param dto the filter mt dto
     */
    public void saveToFilterDb(FilterMtDto dto) {
        if (CollectionUtil.isNotEmpty(dto.getMobileList())) {
            long currentTime = Instant.now().toEpochMilli() / 1000;
            FilterTypes filterType = BaseEnum.parse(FilterTypes.class, dto.getErrorCode());
            List<SmsSendErrorLog> errList = dto.getMobileList().parallelStream()
                    .map(mobile -> SmsSendErrorLog.builder()
                            .mobile(mobile)
                            .type(dto.getErrorCode())
                            .content(dto.getContent())
                            .msg(filterType.msg())
                            .addTime(currentTime)
                            .build()
                    )
                    .collect(Collectors.toList());

            sendErrorLogMapper.insertList(errList);
        }
    }

    /**
     * 构造获取短信推送到交互记录或总备注的唯一标识
     *
     * @param taskId the task id
     * @param mobile the mobile
     * @return String
     */
    private String genSmsBusinessId(String taskId, String mobile) {
        return "smsMt_" + taskId + "_" + mobile;
    }

    /**
     * 将业务短信推进交互记录队列，通知交互记录
     *
     * @param sms the mt dto
     */
    public void noticeIntersection(MtDto sms) {
        int currentTime = (int) (System.currentTimeMillis() / 1000);
        List<String> mobileList = Splitter.on(",").splitToList(sms.getMobiles());
        mobileList.parallelStream().forEach(mobile -> {
            String phone = mobile.replace(Constants.INTER_MOBILE_JOIN_MARK, "");
            IntersectionDto dto = IntersectionDto.builder()
                    .businessId(genSmsBusinessId(sms.getTaskId(), phone))
                    .adminId(sms.getAdmin())
                    .phone(phone)
                    .startTime(currentTime)
                    .content(sms.getContent())
                    .build();
            kafkaService.sendToIntersectionTopic(dto);
        });
    }

    /**
     * 将业务短信推进总备注队列，通知总备注
     *
     * @param sms the mt dto
     */
    public void noticeRemark(MtDto sms) {
        kafkaService.sendToRemarkTopic(sms);
    }

    /**
     * 将业务短信推进主站的订单短信日志队列.
     *
     * @param sms the sms
     */
    public void noticeOrderSmsLog(MtDto sms) {
        if (
                StringUtil.isNotBlank(sms.getFrom())
                        && (CAR_RENT_FROM_NAME.equals(sms.getFrom()) || POI_FROM_NAME.equals(sms.getFrom()))
                        && StringUtil.isNotBlank(sms.getUniqueId())
        ) {
            List<String> mobileList = Splitter.on(",").splitToList(sms.getMobiles());
            mobileList.parallelStream().forEach(mobile -> {
                String phone = mobile.replace(Constants.INTER_MOBILE_JOIN_MARK, "");
                OrderSmsLogDto dto = OrderSmsLogDto.builder()
                        .mobile(phone)
                        .content(sms.getContent())
                        .uniqueId(sms.getUniqueId())
                        .admin(sms.getAdmin())
                        .build();
                kafkaService.sendToOrderSmsLogTopic(dto);
            });
        }
    }

    /**
     * 构造推送的短信备注
     *
     * @param sms the mt dto
     * @return map
     */
    public Map<String, SendRemarkParam.SendRemarkItem> genSmsRemark(MtDto sms) {
        List<String> mobileList = Splitter.on(",").splitToList(sms.getMobiles());
        Map<String, SendRemarkParam.SendRemarkItem> remarkMaps = new HashMap<>();
        mobileList.forEach(mobile -> {
            //转换extraParam-->ticketIdStr、associateOrder
            String extraParamStr = sms.getExtraParam();
            ExtraParamDto extraParamDto = ExtraParamService.jsonTransfer(extraParamStr);

            String phone = mobile.replace(Constants.INTER_MOBILE_JOIN_MARK, "");
            SendRemarkParam.SendRemarkItem item = SendRemarkParam.SendRemarkItem.builder()
                    .businessId(genSmsBusinessId(sms.getTaskId(), phone))
                    .adminId(sms.getAdmin())
                    .phone(sms.getRegionType() == SmsRegionType.国际.code() ? fetchInterMobile(mobile) : mobile)
                    .phoneCode(sms.getRegionType() == SmsRegionType.国际.code() ? fetchInterMobAreaCode(mobile) : Constants.INNER_MOBILE_AREA_CODE)
                    .content(sms.getContent())
                    .sortTime(sms.getSendTime())
                    .build();
            if (extraParamDto != null) {
                if (StringUtil.isNotBlank(extraParamDto.getTicketIdStr())) {
                    item.setTicketIdStr(extraParamDto.getTicketIdStr());
                }
                if (CollectionUtils.isNotEmpty(extraParamDto.getAssociateOrder())) {
                    item.setAssociateOrder(extraParamDto.getAssociateOrder());
                }
            }
            remarkMaps.put(genSmsBusinessId(sms.getTaskId(), phone), item);
        });
        return remarkMaps;
    }

    /**
     * 使用新的手机列表覆盖下行的手机字符串.
     * <p>
     * 覆盖成功则返回true，手机列表为空则表示没有需要提交的手机返回false
     *
     * @param mtDto         the mt dto
     * @param newMobileList the new mobile list
     * @return boolean
     */
    public boolean resetMtMobiles(MtDto mtDto, List<String> newMobileList) {
        if (CollectionUtils.isNotEmpty(newMobileList)) {
            String newMobiles;

            try {
                newMobiles = Joiner.on(",").join(newMobileList);
            } catch (NullPointerException e) {
                log.error("黑白名单重新设置手机号出错, 短信数据如下: " + mtDto.toString(), e, e.getMessage());
                mtDto.setMobiles("");
                return false;
            }

            mtDto.setMobiles(newMobiles);
            return true;
        } else {
            mtDto.setMobiles("");
            return false;
        }
    }

    /**
     * 清空短信的所有手机号码，包括发送的和白名单
     *
     * @param mtDto the mt dto
     */
    public void trashMtAllMobiles(MtDto mtDto) {
        mtDto.setMobiles("");
        mtDto.setWhiteMobiles("");
    }

    /**
     * 将绕过拦截的白名单手机添加到此次指定下发的手机列表中.
     * <p>
     * 添加成功表示存在白名单手机，添加失败表示不存在白名单手机
     *
     * @param mtDto the mt dto
     */
    public boolean joinWhiteMobsToTotalMobs(MtDto mtDto) {
        if (StringUtil.isNotBlank(mtDto.getWhiteMobiles())) {
            if (StringUtil.isNotBlank(mtDto.getMobiles())) {
                mtDto.setMobiles(mtDto.getMobiles() + "," + mtDto.getWhiteMobiles());
            } else {
                mtDto.setMobiles(mtDto.getWhiteMobiles());
            }
            return true;
        } else {
            return false;
        }
    }

    /**
     * 对该批短信的所有手机号码的请求次数进行增量+1
     *
     * @param sms the mt dto
     */
    public void addMobileFreq(MtDto sms) {
        List<String> mobileList = Splitter.on(",").splitToList(sms.getMobiles());
        if (CollectionUtils.isNotEmpty(mobileList)) {
            mobileList.forEach(mobile ->
                    freqExecutor.submit(() -> {
                        highFreqMobileCache.setMobileIncre(mobile, sms.getType(),sms.getFrom());
                    })
            );
        }
    }

    /**
     * 更新短信下行的数据表Db
     *
     * @param taskId        the task id
     * @param requestStatus the request status
     * @param supplier      the supplier
     * @param mobileList    the mobile list
     */
    public int updateMtRequestStatus(int taskId, int requestStatus, String supplier, List<String> mobileList) {
        int upMtState = smsMtMapper.updateRequestStatusByTaskId(taskId, requestStatus, supplier, mobileList);
        if (upMtState <= 0) {
            upMtState=smsMtMarketMapper.updateRequestStatusByTaskId(taskId, requestStatus, supplier, mobileList);
        }
        return upMtState;
    }

    /**
     * 更新短信下行的状态为重复短信.
     *
     * @param taskId     the task id
     * @param mobileList the mobile list
     */
    public void updateRepeatMobilesStatus(int taskId, Set<String> mobileList) {
        int upMtState = smsMtMapper.updateRepeatMobilesStatus(taskId, mobileList);
        if (upMtState <= 0) {
            smsMtMarketMapper.updateRepeatMobilesStatus(taskId, mobileList);
        }
    }

}
