package com.zuzuche.sms.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Table;
import java.time.LocalDateTime;

/**
 * desc:短信批量手机文件实体
 *
 * @author bingyi
 * @date 2019/10/30
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
@Table(name = "zuzuche_sms_db.sms_file_phone_list")
public class SmsFilePhoneList {
    private Integer id;

    private String fileId;

    private String phone;

    private LocalDateTime createTime;

    /**
     * 额外的参数，包括变量替换
     */
    private String extraParam;

}