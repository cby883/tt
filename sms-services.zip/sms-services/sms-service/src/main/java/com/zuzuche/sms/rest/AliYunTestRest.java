package com.zuzuche.sms.rest;

import com.zuzuche.commons.base.resp.RespResult;
import com.zuzuche.commons.base.util.BeanConverter;
import com.zuzuche.sms.cache.TaskIdGenCache;
import com.zuzuche.sms.dto.MtDto;
import com.zuzuche.sms.dto.SmsDto;
import com.zuzuche.sms.executors.NormalMtExecutor;
import com.zuzuche.sms.job.TokenUtil;
import com.zuzuche.sms.job.runner.AliYunSmsRunner;
import com.zuzuche.sms.rest.request.AliYunMtDtoReq;
import com.zuzuche.sms.rest.request.AliYunSmsReq;
import com.zuzuche.sms.service.SmsMtService;
import io.swagger.annotations.Api;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * desc:阿里云短信接口测试类
 *
 * @author bingyi
 * @date 2019/08/20
 */
@RestController
@RequestMapping(value = "/aliyun/api")
@Api(value = "阿里云接口调试",description = "阿里云接口调试",tags = {"aliYunApi"})
public class AliYunTestRest {
    @Autowired
    TaskIdGenCache taskIdGenCache;
    @Autowired
    NormalMtExecutor normalMtExecutor;
    @Autowired
    SmsMtService smsMtService;
    @PostMapping(value = "/sendSmsToTopic")
    public RespResult<SmsDto> sendSmsToTopic(AliYunSmsReq aliYunSmsReq){
        aliYunSmsReq.setTaskId(taskIdGenCache.increGetStr());
        //封装成smsDto
        SmsDto smsDto= BeanConverter.copy(aliYunSmsReq,SmsDto.class);
        //推送到kafka
        smsMtService.pushSmsIntoSupplierQueue(smsDto);
        return RespResult.success(smsDto);
    }

    @PostMapping(value = "/sendMtDto")
    public RespResult<MtDto> sendMtDto(AliYunMtDtoReq aliYunMtDtoReq){
        MtDto mtDto=BeanConverter.copy(aliYunMtDtoReq,MtDto.class);
        normalMtExecutor.handle(mtDto);
        return RespResult.success(mtDto);
    }
}
