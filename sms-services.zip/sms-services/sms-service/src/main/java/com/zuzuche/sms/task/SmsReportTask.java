package com.zuzuche.sms.task;

import com.zuzuche.commons.base.resp.Status;
import com.zuzuche.commons.base.resp.StatusServiceCnException;
import com.zuzuche.commons.base.util.StringUtil;
import com.zuzuche.kafka.sentry.MessageDto;
import com.zuzuche.kafka.sentry.SentryReport;
import com.zuzuche.sms.common.utils.TimeUtil;
import com.zuzuche.sms.dto.StatusReportDto;
import com.zuzuche.sms.entity.SmsMt;
import com.zuzuche.sms.entity.SmsMtMarket;
import com.zuzuche.sms.entity.SmsOutbound;
import com.zuzuche.sms.listener.inner.StatusReportListener;
import com.zuzuche.sms.mapper.SmsMtMapper;
import com.zuzuche.sms.mapper.SmsMtMarketMapper;
import com.zuzuche.sms.mapper.SmsOutboundMapper;
import com.zuzuche.sms.service.KafkaService;
import com.zuzuche.sms.service.StatusReportService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * 功能：短信状态报告处理
 * 详细：
 *
 * @author Created on 2019.09.29 bingyi
 */
@Component
@Slf4j
@Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class SmsReportTask implements Runnable {


    @Autowired
    SmsOutboundMapper smsOutboundMapper;
    @Autowired
    SmsMtMapper smsMtMapper;
    @Autowired
    SmsMtMarketMapper smsMtMarketMapper;
    @Autowired
    KafkaService kafkaService;
    @Autowired
    StringRedisTemplate stringRedisTemplate;

    @Autowired
    StatusReportService statusReportService;

    @Autowired
    SentryReport sentryReport;
    /**
     * 状态报告连续睡眠最大值
     */
    private static final int MAX_COUNT = 200;

    private static final int MAX_EN_QUEUE_COUNT = 3;

    StatusReportDto statusReport;


    public SmsReportTask(StatusReportDto statusReport) {
        this.statusReport = statusReport;
    }

    /**
     * 执行更新操作
     */
    private void execute() {
        try {
            int num = 0;
            if (!statusReportService.upStatusReport(statusReport)) {
                //保证性能，可以不使用线程安全的计数器
                StatusReportListener.count.incrementAndGet();
                //状态报告告警，人工干预
                sentry(StatusReportListener.count.get());
                //加入队列
                if (needToEnQueue(statusReport)) {
                    kafkaService.sendToStatusReportKafka(statusReport);
                }else{
                    log.error("[SmsReportTask]加入状态报告循环队列超过阈值：{}",statusReport.toString());
                }
                //返回
                return;
            }
            //重置
            StatusReportListener.count.set(0);

        } catch (Exception e) {
            //报错，直接抛出
            log.error(e.getMessage(), e);
        }
    }

    /**
     * @param dto
     * @return
     */
    private boolean needToEnQueue(StatusReportDto dto) {
        try {
            if (dto == null || dto.getEnQueueCount() <= 0 || StringUtil.isBlank(dto.getEnQueueTime())) {
                //数据不完整，直接丢弃
                return false;
            }
            int enCount=dto.getEnQueueCount();
            //大于入队最大次数，直接丢弃
            if (enCount > MAX_EN_QUEUE_COUNT) {
                return false;
            }
            dto.setEnQueueCount(++enCount);
            DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern(TimeUtil.DEFAULT_PATTERN);
            LocalDateTime enQueueTime = LocalDateTime.parse(dto.getEnQueueTime(), dateTimeFormatter);
            if (enQueueTime.plusHours(3).isBefore(LocalDateTime.now())) {
                //打印日志
                log.warn("[消息在sms_report队列生命周期超过一天,直接丢弃]:{}", dto.toString());
                //如果消息在队列生命周期超过一天，则不入队，直接丢弃
                return false;
            }
        } catch (Exception e) {
            log.error("[StatusReporDto]转换失败", e.getMessage(), e);
            return false;
        }
        return true;
    }

    /**
     * 判断是否告警
     */
    private void sentry(int count) {
        if (count > MAX_COUNT) {
            //触发告警，人工干预
            MessageDto messageDto = MessageDto.builder()
                    .wechat(4)
                    .content("[短信状态报告循环队列数据监控]状态报告持续推送循环队列次数达到" + count + ",触发阈值:" + MAX_COUNT + "(状态报告回调更新速率已自动调成1qps/s,持续时间5分钟)")
                    .build();
            //持续5分钟，消费速度为1qps
            StatusReportListener.timeSize.set(300);
            StatusReportListener.count.set(0);
            sentryReport.message(messageDto);
        }
    }

    @Override
    public void run() {
        execute();
    }
}
