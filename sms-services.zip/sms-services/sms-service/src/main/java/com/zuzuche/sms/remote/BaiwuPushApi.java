package com.zuzuche.sms.remote;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.zuzuche.sms.remote.dto.PostReportDto;
import com.zuzuche.sms.remote.dto.PostSmsDto;
import com.zuzuche.sms.remote.param.HSmsSendParam;
import com.zuzuche.sms.remote.param.PostSmsParam;
import com.zuzuche.sms.remote.param.SmsSendParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.client.ResourceAccessException;

import java.nio.charset.Charset;
import java.util.Arrays;

/**
 * @desc: 百唔的推送和拉取api
 * @author: panqiong
 * @date: 2018/11/5
 */
@Component
@Slf4j
public class BaiwuPushApi extends AbstractHttpInvoke {

    @Value("${provider.baiwu.pushurl}")
    private String pushUrl ;


    /**
     * 额外的header设置 比如编码
     *
     * @param header
     */
    @Override
    protected void setHeader(HttpHeaders header) {
        header.setAcceptCharset(Arrays.asList(Charset.forName("GBK")));
    }



    /**
     * 1)发送速度：接口访问没有时间间隔限制。建议用户等到接口返回值后，再进行下一次调用，可多线程并发调用。
     * 2)Ip白名单：如果用户开账户时指定IP，则此接口只接收指定IP的发送请求，提高安全性。
     * IP支持单IP，多IP，IP号段及无IP。
     * 3)内容长度：本接口支持每条短信内容的最大长度不超过1000个汉字（包括1000字）。
     * 4)编码格式：utf-8。
     * 1.2下发返回参数说明
     * 返回代码	代码说明
     * 0#数字	提交成功。数字：提交成功的手机数量
     * 100	余额不足
     * 101	账号关闭
     * 102	短信内容超过1000字（包括1000字）或为空
     * 103	手机号码超过200个或合法手机号码为空或者与通道类型不匹配
     * 104	corp_msg_id超过50个字符或没有传corp_msg_id字段
     * 106	用户名不存在
     * 107	密码错误
     * 108	指定访问ip错误
     * 109	业务代码不存在或者通道关闭
     * 110	扩展号不合法
     * 9	访问地址不存在
     * 注意：
     * 1)长短信：对于长短信，“#”后面的数字代表用户提交的条数，而不是实际扣费的条数。例如用户发送了190字的短信三条，返回的是0#3,后台根据拆分后的结果，计费为9条。
     * 2)0#数字：此返回值数字代表成功提交到我方平台的数据。失败条数不会显示，失败号码也不会显示。
     * @param smsSendParam
     * @return
     */

    @HystrixCommand(groupKey = "baiwuApiGroup", commandKey="smsSend")
    public String smsSend(SmsSendParam smsSendParam){
        String api = "/sms_send2.do";
        String url = pushUrl+api;
        String result = null;
        try {
            result = super.postForm(url,smsSendParam);
        } catch (Exception e) {
            // 接口失败 在这里处理
            log.error("[BaiwuPullApi-smsSend]接口调用异常 ",e.getMessage(),e);
        }
        return result;
    }


    /**
     * 0#数字   提交成功的手机数
     * -10       余额不足
     * -11       账号关闭
     * -12       短信内容超过1000字（包括1000字）或为空
     * -13       手机号码超过200个或合法的手机号码为空，或者手机号码与通道代码正则不匹配
     * -14       msg_id超过50个字符或没有传msg_id字段
     * -16       用户名不存在
     * -18       访问ip错误
     * -19       密码错误 或者业务代码错误 或者通道关闭 或者业务关闭
     * -20       小号错误
     * 9       访问地址不存在
     *
     * 注意：
     * 3)MD5_td_code：由密码+业务代码进行MD5加密后得到，例：密码为123，业务代码为955，则MD5_td_code是将123955放在MD5加密工具中用MD5加密后得到的值。
     * 4)长短信：对于长短信，返回的是用户提交的条数，而不是实际扣费的条数，例如用户发送了190字的短信三条，返回的是ok：3，后台根据拆分后的结果，计费为9条。
     * 5)-12错误：确认接口编码格式是否正确，测试标准是发送带有“%”的短信看是否能成功发送。
     * 6)内容长度：本接口支持每条短信内容的最大长度不超过1000个汉字（包括1000字）。
     * 7)IP访问：如果用户开账户时指定IP，则此接口只接收指定IP的发送请求。
     * 8)可支持多ip或号段绑定。
     * 9)发送速度：接口访问没有时间间隔限制。建议收到接口返回值后，再进行下一次调用。
     * @param postSmsParam
     * @return
     */
    @HystrixCommand(groupKey = "baiwuApiGroup", commandKey="postSms")
    public PostSmsDto postSms(PostSmsParam postSmsParam) throws ResourceAccessException{
        String api = "/post_sms.do";
        String url = pushUrl+api;

        String result = super.postForm(url,postSmsParam);

        String splitter = "#";
        String code ;
        String count ;

        if(result.contains(splitter)){
            // 发送成功
            code = result.split(splitter)[0];
            count = result.split(splitter)[1];
        }else{
            // 业务失败
            code = result;
            count = "";
        }
        PostSmsDto dto = PostSmsDto.builder()
                .code(code)
                .count(count)
                .build();
        return dto;
    }

    /**
     * 1)send_param格式：手机号码&split&短消息序号&split&主叫扩展号码&split&短消息内容。
     *
     * 2)每条短信之间&group&以分隔。以&group&拆分后的短信条数必须等于
     * 3)total_count，如有差别，则全部失败。
     * 4)主叫扩展号码不限制长度，但是需保证通道接入号+主叫扩展号≤20，总长度超过20位则发送失败
     * 5)样例：
     * send_param=13601025412&split&20110608122535001&split&256&split&尊敬的会员张三您好，您的账户余额为20元&group&13821056854&split&2011060812255425003&split&257&split&尊敬的会员李四您好，您的账户余额为30.2元
     * 3.3发送返回说明
     * 参数	说明	备注
     * 0#数字	提交成功#提交成功的短信数量	1、通道支持长短信整条提交则返回长短信数；若不支持整条提交则返回拆分后短信总数；
     * 2、0#0：表示此次个性化短信全部提交失败。
     * 100	余额不足
     * 101	账号关闭
     * 106	用户名不存在
     * 107	密码错误
     * 108	指定访问的IP错误	接口支持绑定单IP，多IP，IP号段及无IP
     * 109	业务不存在
     * 114	接口提交应为POST，不支持GET
     * 115	total_count 与实际短信条数无法匹配，即，实际短信条数与total_count不一致。
     * 如果要返回此参数，则本次提交的所有短信作废，不入库
     * 116	个性化短信提交个数超过200条
     * 9	访问地址不存在
     * 3.4提交方式说明
     * 考虑到短信内容长度拼接后较长，接口支持HTTP协议中的POST方法，不支持GET方法。并且由于个性化参数中本身带有&符号，所以不能使用curl命令测试。具体请您参考此文档最后附录（java发送个性化短信demo）进行测试。
     * @param hSmsSendParam
     * @return
     */
    @HystrixCommand(groupKey = "baiwuApiGroup", commandKey="hSmsSend")
    public String hSmsSend(HSmsSendParam hSmsSendParam){
        String api = "/hSmsSend.do";
        String url = pushUrl+api;
        String result = null;
        try {
            result = super.postForm(url,hSmsSendParam);
        } catch (Exception e) {
            // 接口失败 在这里处理
            log.error("[BaiwuPullApi-hSmsSend]接口调用异常 ",e.getMessage(),e);
            //return new PostSmsDto("-98","post_report接口调用异常");
        }
        return result;
    }



}
