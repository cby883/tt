package com.zuzuche.sms.common.enums;

import com.zuzuche.commons.base.constants.BaseEnum;

/**
 * 功能：短信供应商匹配规则特殊项.
 * 详细：
 *
 * @author Created on 2019.03.11 by chaodian
 */
public enum SupplierMatchExtraRules implements BaseEnum<String> {

    /**
     * Instantiates a new 租车催款.
     */
    租车催款("carExtraPayPressInnerMatch");

    private String code;

    /**
     * Instantiates a new Supplier match extra rules.
     *
     * @param code the code
     */
    SupplierMatchExtraRules(String code) {
        this.code = code;
    }

    @Override
    public String code() {
        return code;
    }
}
