package com.zuzuche.sms.filter.dispatch;


import com.google.common.base.Joiner;
import com.google.common.base.Splitter;
import com.zuzuche.sms.cache.BlackWiteMobileCache;
import com.zuzuche.sms.dto.MtDto;
import com.zuzuche.sms.filter.MtFilter;
import com.zuzuche.sms.service.SmsMtService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * 功能：下行白名单手机过滤器.
 * 详细：
 *
 * @author Created on 2019.03.16 by chaodian
 */
@Component
@Slf4j
@Order(3)
public class MtWhiteMobileFilter implements MtFilter {

    /**
     * The Cache.
     */
    @Autowired
    BlackWiteMobileCache cache;

    /**
     * The Sms mt service.
     */
    @Autowired
    SmsMtService smsMtService;

    @Override
    public boolean doFilter(MtDto mtDto) {
        List<String> mobileList = Splitter.on(",").splitToList(mtDto.getMobiles());

        // 初始化白名单手机和需要进一步过滤校验的手机列表
        List<String> whiteMobileList = new ArrayList<>();
        List<String> needCheckMobileList = new ArrayList<>();
        mobileList.forEach(mobile->{
            if (cache.containsWhiteMob(mobile)) {
                whiteMobileList.add(mobile);
            } else {
                needCheckMobileList.add(mobile);
            }
        });

        if (CollectionUtils.isNotEmpty(whiteMobileList)) {
            String whiteMobiles = Joiner.on(",").join(whiteMobileList);
            mtDto.setWhiteMobiles(whiteMobiles);
        }

        smsMtService.resetMtMobiles(mtDto, needCheckMobileList);
        return true;
    }

}
