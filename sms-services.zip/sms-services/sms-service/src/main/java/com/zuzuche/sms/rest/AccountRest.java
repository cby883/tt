package com.zuzuche.sms.rest;

import com.zuzuche.commons.base.resp.RespResult;
import com.zuzuche.sms.cache.ProviderAccountCache;
import com.zuzuche.sms.cache.SmsSpecialPhoneCache;
import com.zuzuche.sms.rest.request.PushStatusReq;
import com.zuzuche.sms.rest.response.PushStatusRsp;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.List;

/**
 * @desc: 账户信息管理
 * @author: panqiong
 * @date: 2018/10/31
 */
@RestController
@RequestMapping("/account")
@Slf4j
@Api(value = "account", description = "供应商账户信息", tags = {"account"})
public class AccountRest {

    @Autowired
    ProviderAccountCache providerAccountCache;


    @Autowired
    SmsSpecialPhoneCache smsSpecialPhoneCache;

    /**
     * 重新载入缓存
     * @param
     * @return
     */
    @GetMapping("/reload")
    @ApiOperation(value = "重新加载本地缓存", notes = "刷新本地缓存")
    public RespResult<PushStatusRsp> refreshCache() {

        boolean providerAccount = providerAccountCache.reload();
        boolean smsSpecialPhone =  smsSpecialPhoneCache.reload();

        HashMap map = new HashMap();
        map.put("providerAccount",providerAccount);
        map.put("smsSpecialPhone",smsSpecialPhone);
        return RespResult.success(map);
    }




}
