package com.zuzuche.sms.rest.response;

import com.zuzuche.sms.common.enums.RateLimiterKeyTypes;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @desc:
 * @author: bingyi
 * @date: 2019/11/14
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ApiModel(value = "短信限流器请求体")
public class SmsLimiterResp {
    int code;
    String msg;
    /**
     * 配置
     */
      private RateLimiterKeyTypes limiterKeyTypes;
    /**
     * 原来的速率值
     */
    private String originVal;

    /**
     * 更新后的速率值
     */
    private int currentVal;


}
