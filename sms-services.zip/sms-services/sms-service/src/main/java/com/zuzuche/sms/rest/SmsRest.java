package com.zuzuche.sms.rest;

import com.zuzuche.commons.base.annotation.Check;
import com.zuzuche.commons.base.constants.BaseEnum;
import com.zuzuche.commons.base.resp.RespResult;
import com.zuzuche.commons.base.resp.Status;
import com.zuzuche.commons.base.resp.StatusServiceCnException;
import com.zuzuche.kafka.message.BaseMessage;
import com.zuzuche.sms.cache.ProviderAccountCache;
import com.zuzuche.sms.cache.SmsClassConfigCache;
import com.zuzuche.sms.cache.SmsSignCache;
import com.zuzuche.sms.cache.TaskIdGenCache;
import com.zuzuche.sms.cache.co.SmsSignCo;
import com.zuzuche.sms.common.enums.SmsType;
import com.zuzuche.sms.dto.MtDto;
import com.zuzuche.sms.dto.SmsDto;
import com.zuzuche.sms.entity.ProviderAccountInfo;
import com.zuzuche.sms.entity.SmsClassConfig;
import com.zuzuche.sms.rest.request.MtReq;
import com.zuzuche.sms.rest.request.MtTemplateReq;
import com.zuzuche.sms.rest.request.PushStatusReq;
import com.zuzuche.sms.rest.request.SmsReq;
import com.zuzuche.sms.rest.response.MtResp;
import com.zuzuche.sms.rest.response.PushStatusRsp;
import com.zuzuche.sms.rest.response.RetriveInboundSmsRsp;
import com.zuzuche.sms.rest.response.SmsResp;
import com.zuzuche.sms.service.InboundService;
import com.zuzuche.sms.service.RetriveOffsetService;
import com.zuzuche.sms.service.SmsMtService;
import com.zuzuche.sms.service.StatusReportService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

/**
 * @desc: 短信发送rest接口
 * @author: panqiong
 * @date: 2018/9/26
 */
@RestController
@RequestMapping("/sms")
@Slf4j
@Api(value = "sms", description = "短信发送", tags = {"sms"})
public class SmsRest {

    @Autowired
    KafkaTemplate<String, BaseMessage> kafkaTemplate;


    @Autowired
    StatusReportService statusReportService;

    @Autowired
    InboundService inboundService;

    @Autowired
    RetriveOffsetService retriveOffsetService;


    @Autowired
    TaskIdGenCache taskIdGenCache;

    @Autowired
    SmsMtService smsMtService;

    @Autowired
    SmsSignCache smsSignCache;

    /**
     * 根据内容下发业务短信.
     *
     * @param req the req
     * @return resp result
     * @author chaodian
     * @date 2019-01-30
     */
    @PostMapping("/mt/send")
    @ApiOperation(value = "根据内容下发业务短信", notes = "根据内容下发业务短信")
    @Check
    public RespResult<MtResp> sendMt(MtReq req) {
        List<String> mobiles = smsMtService.getMobileList(req.getMobiles());
        MtDto mtDto = smsMtService.formMtDto(req, mobiles);
        smsMtService.pushMtIntoQueue(mtDto,null);
        return RespResult.success(smsMtService.buildMtRespByMobiles(mobiles));
    }

    /**
     * 根据内容下发业务短信.
     *
     * @param req the req
     * @return resp result
     * @author chaodian
     * @date 2019-01-30
     */
    @PostMapping("/mt/sendByTemplate")
    @ApiOperation(value = "根据模板下发业务短信", notes = "根据模板下发业务短信")
    @Check
    public RespResult<MtResp> sendByTemplate(MtTemplateReq req) {
        MtResp mtResp = smsMtService.sendWithTemplate(req);
        return RespResult.success(mtResp);
    }


    /**
     * 同步推送,入队成功才会返回
     * 提供给上游服务调用
     *
     * @param req
     * @return
     */
    @PostMapping("/syn/send")
    @ApiOperation(value = "同步推送短信", notes = "同步推送短信,短信入队(kafka)成功后才会返回")
    public RespResult<SmsResp> send(SmsReq req) {
        String taskId = taskIdGenCache.increGetStr();
        SmsDto smsDto = SmsDto.builder()
                .accountId(req.getAccountId())
                .content(req.getContent())
                .mobile(req.getMobile())
                .mock(req.isMock())
                .mockTimeOutUntilRetryNo(req.getMockTimeOutUntilRetryNo())
                .taskId(taskId)
                .authKey(req.getAuthKey())
                .time(req.getTime())
                .build();
        ProviderAccountInfo accountInfo = ProviderAccountCache.getAccountById(req.getAccountId());
        if (accountInfo == null) {
            throw new StatusServiceCnException(Status.OBJECT_NOT_EXIST, "账户id不存在:" + req.getAccountId());
        }

        SmsClassConfig config = SmsClassConfigCache.getByProviderId(accountInfo.getProviderId());
        if (config == null) {
            throw new StatusServiceCnException(Status.OBJECT_NOT_EXIST, "未配置该供应商的topic:" + accountInfo.getProviderId());
        }

        String topicName = config.getOutBoundTopic();

        // 送进kafka 根据mobile选择分区
        ListenableFuture<SendResult<String, BaseMessage>> future = kafkaTemplate.send(topicName, smsDto.getMobile(), smsDto);

        try {
            future.get(5, TimeUnit.SECONDS);
            /// log.info("[synsend推送结果]:"+sendResult.toString());
        } catch (InterruptedException e) {
            log.error("[synsend推送kafka异常]:", e.getMessage(), e);
            Thread.currentThread().interrupt();
            throw new StatusServiceCnException(Status.BUSY, "推送入队发生异常 InterruptedException");
        } catch (ExecutionException e) {
            log.error("[synsend推送kafka异常]:", e.getMessage(), e);
            throw new StatusServiceCnException(Status.BUSY, "推送入队发生异常 ExecutionException");
        } catch (TimeoutException e) {
            log.error("[synsend推送kafka异常]:", e.getMessage(), e);
            throw new StatusServiceCnException(Status.BUSY, "推送入队发生异常 TimeoutException");
        } catch (Exception e) {
            log.error("[synsend推送kafka异常]:", e.getMessage(), e);
            throw new StatusServiceCnException(Status.BUSY, "推送入队发生异常 Exception");
        }
        // 同步入队 并返回taskId
        return RespResult.success(new SmsResp(taskId));
    }


    /**
     * 获取用户状态报告
     * 提供给上游服务调用
     *
     * @param req
     * @return
     */
    @GetMapping("/syn/pushStatus")
    @ApiOperation(value = "获取用户状态报告", notes = "根据taskId获取")
    public RespResult<PushStatusRsp> retrievePushStatus(PushStatusReq req) {

        List<PushStatusRsp> list = statusReportService.queryPushStatus(req.getTaskId());

        return RespResult.success(list);
    }

    /**
     * 获取用户状态报告
     * 并自动保存offset
     *
     * @param
     * @return
     */
    @GetMapping("/syn/pushStatusAuto")
    @ApiOperation(value = "获取用户状态报告", notes = "获取用户状态报告并自动保存offset")
    public RespResult<SmsResp> retrievePushStatus() {

        List<PushStatusRsp> list = statusReportService.queryPushStatusByOffset();
        // 同步入队 并返回taskId
        return RespResult.success(list);
    }


    /**
     * 获取用户状态报告 拉取位置 偏移量手动设置
     *
     * @param
     * @return
     */
    @GetMapping("/syn/inboundAuto")
    @ApiOperation(value = "拉取上行短信列表", notes = "拉取上行短信列表 会直接根据id做为offset")
    public RespResult<RetriveInboundSmsRsp> retriveInboundSms() {

        List<RetriveInboundSmsRsp> list = inboundService.queryInboundSmsList();

        return RespResult.success(list);
    }

    /**
     * 获取签名
     *
     * @param
     * @return
     */
    @GetMapping("/sms/getSign")
    @ApiOperation(value = "短信签名获取", notes = "短信签名获取")
    public RespResult<Map<String, SmsSignCo>> getSignType() {
        return RespResult.success(smsSignCache.getUsableConfigMap());
    }


    /**
     * 获取短信类型
     *
     * @param
     * @return
     */
    @GetMapping("/sms/getSmsType")
    @ApiOperation(value = "短信类型获取", notes = "短信类型获取")
    public RespResult<RetriveInboundSmsRsp> getSmsType() {
        return RespResult.success(BaseEnum.getItemList(SmsType.class));
    }


}
