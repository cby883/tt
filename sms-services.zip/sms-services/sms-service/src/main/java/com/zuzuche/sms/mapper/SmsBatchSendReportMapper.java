package com.zuzuche.sms.mapper;

import com.zuzuche.commons.mybatis.BaseMapper;
import com.zuzuche.sms.entity.SmsBatchSendReport;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

/**
 * desc:批量提交状态报告mapper
 *
 * @author bingyi
 * @date 2019/10/30
 */
@Repository
public interface SmsBatchSendReportMapper extends BaseMapper<SmsBatchSendReport> {
    /**
     * 根据任务号查询详情
     * @param batchNo
     * @return
     */
     SmsBatchSendReport selectByBatchNo(@Param(value = "batchNo") String batchNo);

    /**
     * 根据batchNo更新记录
     * @param smsBatchSendReport
     * @return
     */
     int updateByBatchNo(SmsBatchSendReport smsBatchSendReport);
}