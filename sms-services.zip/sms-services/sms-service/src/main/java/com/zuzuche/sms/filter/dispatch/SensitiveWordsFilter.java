package com.zuzuche.sms.filter.dispatch;

import com.google.common.base.Splitter;
import com.zuzuche.commons.base.util.StringUtil;
import com.zuzuche.sms.cache.SafeMonitorRuleCache;
import com.zuzuche.sms.common.enums.FilterTypes;
import com.zuzuche.sms.dto.FilterMtDto;
import com.zuzuche.sms.dto.MtDto;
import com.zuzuche.sms.filter.MtFilter;
import com.zuzuche.sms.service.KafkaService;
import com.zuzuche.sms.service.SmsMtService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * 功能：敏感词过滤
 * 详细：
 *
 * @author Created on 2019.11.08 by bingyi
 */
@Component
@Slf4j
@Order(7)
public class SensitiveWordsFilter implements MtFilter {

    /**
     * The Safe monitor rule cache.
     */
    @Autowired
    SafeMonitorRuleCache safeMonitorRuleCache;
    /**
     * The Kafka service.
     */
    @Autowired
    KafkaService kafkaService;


    /**
     * 执行过滤器.
     * 1. 先执行单个号码总频率过高过滤器
     * 2. 再根据短信性质类型执行 验证码过快过滤器 或 营销短信过快过滤器
     *
     * @param sms the mt dto
     * @return boolean
     */
    @Override
    public boolean doFilter(MtDto sms) {
        // 没有需要发送的手机号码， 但是有白名单，白名单需要绕过频率拦截检测
        if (StringUtil.isBlank(sms.getMobiles())) {
            return StringUtil.isNotBlank(sms.getWhiteMobiles());
        }
        //校验匹配
        List<String> sensitive = safeMonitorRuleCache.getSensitive();
        //如果没有配置敏感词。则绕过
        if(CollectionUtils.isEmpty(sensitive)){
            return true;
        }
        for (String content : sensitive) {
            //全匹配
            if (sms.getContent().equalsIgnoreCase(content.trim())) {
                List<String> mobileList = Splitter.on(",").splitToList(sms.getMobiles());
                // 触发敏感词的手机则丢入专门处理kafka的队列
                FilterMtDto filterMtDto = FilterMtDto.builder().mobileList(mobileList)
                        .content(sms.getContent())
                        .errorCode(FilterTypes.短信敏感词过滤器.code())
                        .build();
                kafkaService.sendToFilterTopic(filterMtDto);
                return false;
            }
        }
        return true;
    }
}
