package com.zuzuche.sms.job.runner;

import com.zuzuche.sms.cache.ProviderAccountCache;
import com.zuzuche.sms.common.utils.SpringBeanFactory;
import com.zuzuche.sms.report.mq.listener.AliYunReportListener;
import com.zuzuche.sms.report.mq.listener.AliYunSmsUpListener;
import com.zuzuche.sms.report.mq.puller.AliYunMessagePuller;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

/**
 * desc:阿里云短信接收服务自启动类
 *
 * @author bingyi
 * @date 2019/08/20
 */
@Slf4j
@Service
public class AliYunSmsRunner implements InitializingBean {
    @Value("${aliyun.listener.open}")
    private boolean open;
    private final String SMSUP_MESSAGE_TYPE="SmsUp";
    private final String REPORT_MESSAGE_TYPE="SmsReport";

    /**
     * 阿里供应商id
     */
    private final int ALI_PROVIDE_ID = 5;

    /**
     * 启用监听
     */
    private void startListener() {
        ProviderAccountCache.getAllAccountList().stream().forEach(e -> {
            if (e.getProviderId() == ALI_PROVIDE_ID) {
                //开启短信上行监听
                AliYunMessagePuller.startListener(e.getAccountName(), e.getAccountPwd(), SMSUP_MESSAGE_TYPE,
                        e.getInboundQueueName(), SpringBeanFactory.getBean(AliYunSmsUpListener.class, e.getAccountId()));
                //开启短信下行的监听
                AliYunMessagePuller.startListener(e.getAccountName(), e.getAccountPwd(), REPORT_MESSAGE_TYPE,
                        e.getOutboundQueueName(), SpringBeanFactory.getBean(AliYunReportListener.class, e.getAccountId()));
            }
        });

    }

    @Override
    public void afterPropertiesSet() throws Exception {
        //开启监听
        if(open){
            startListener();
        }

    }
}
