package com.zuzuche.sms.job;

import com.zuzuche.commons.redis.CacheExpires;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.data.redis.connection.RedisConnection;
import org.springframework.data.redis.connection.StringRedisConnection;
import org.springframework.data.redis.core.RedisCallback;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;

/**
 * @desc:
 * @author: panqiong
 * @date: 2018/10/24
 */
@Component
public class TokenUtil {

    @Autowired
    StringRedisTemplate redisTemplate;
    /**
     *   获取任务执行token
     *   拿不到就不执行
     * @param key
     * @return
     */
    public Boolean getJobExecuteToken(String key) {
        return redisTemplate.opsForValue().setIfAbsent(key, "1");
        // 设置成功返回true

///        Boolean ok = redisTemplate.execute(new RedisCallback<Boolean>() {
//            @Override
//            public Boolean doInRedis(RedisConnection connection) throws DataAccessException {
//                // Can cast to StringRedisConnection if using a StringRedisTemplate
//                boolean ok = ((StringRedisConnection) connection).setNX(key, "1");
//                if(ok){
//                    ((StringRedisConnection) connection).expire(key,CacheExpires.IN_1DAY);
//                }
//                return ok;
//            }
//        });
    }
}
