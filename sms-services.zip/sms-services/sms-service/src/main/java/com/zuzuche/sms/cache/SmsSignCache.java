package com.zuzuche.sms.cache;

import com.zuzuche.sms.cache.co.SmsSignCo;
import com.zuzuche.sms.entity.SmsConfig;
import com.zuzuche.sms.entity.SmsSign;
import com.zuzuche.sms.mapper.SmsSignMapper;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 功能：The type Sms sign cache.
 * 详细：
 *
 * @author Created on 2019.03.01 by chaodian
 */
@Component("SmsSignCache")
@Slf4j
@Data
public class SmsSignCache implements InitializingBean,ConfigCache {

    @Autowired
    SmsSignMapper mapper;

    private static Map<String, SmsSignCo> configMap = new HashMap<>(20);

    private static Map<String,SmsSignCo> usableConfigMap=new HashMap<>(20);

    public boolean containsKey(String key){
        return configMap.containsKey(key);
    }

    public SmsSignCo get(String key){
        return configMap.get(key);
    }


    @Override
    public void afterPropertiesSet() throws Exception {
        load();
    }

    public Map<String,SmsSignCo> getConfigMap(){
        return configMap;
    }

    /**
     * 返回可用的签名
     * @return
     */
    public Map<String,SmsSignCo> getUsableConfigMap(){
        return usableConfigMap;
    }
    /**
     * 载入配置到内存
     */
    public synchronized void load() {
        Map<String, SmsSignCo> configMapTemp = new HashMap<>(20);
        Map<String,SmsSignCo> usableConfigMapTemp=new HashMap<>(20);
        List<SmsSign> list = mapper.selectAll();
        if(CollectionUtils.isNotEmpty(list)){
            list.forEach(e->{
                SmsSignCo co = SmsSignCo.builder()
                        .signCode(e.getVal())
                        .name(e.getName())
                        .allFormatNames(e.getAllFormatNames())
                        .build();
                if(e.getDeleted()==0){
                    //可用
                    usableConfigMapTemp.put(e.getVal().toString(),co);
                }

                configMapTemp.put(e.getVal().toString(), co);
            });
        }
        usableConfigMap=usableConfigMapTemp;
        configMap = configMapTemp;
    }

    @Override
    public boolean refresh() {
        try {
            load();
            return true;
        } catch (Exception e) {
            log.error("【SmsSignCache】配置刷新失败",e.getMessage(),e);
            return false;
        }
    }
}

