package com.zuzuche.sms.rest.response;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @desc:
 * @author: panqiong
 * @date: 2018/9/26
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ApiModel(value = "短信下行响应")
public class SmsResp {

    /**
     * 任务id
     */
    @ApiModelProperty(value = "任务id,如果上游不传,则会默认生成一个 ,规则为uuid",required = false)
    private String taskId;
    /**
     * 入队成功数量
     */
    @ApiModelProperty(value = "只是暂时保留 未启用",required = false)
    private int successNum;
    /**
     * 白名单号码数量
     */
    @ApiModelProperty(value = "只是暂时保留 未启用",required = false)
    private int whiteNum;
    /**
     * 黑名单号码数量
     */
    @ApiModelProperty(value = "只是暂时保留 未启用",required = false)
    private int blackNum;

    /**
     * 重复号码数量
     */
    @ApiModelProperty(value = "只是暂时保留 未启用",required = false)
    private int repeatNum;

    public SmsResp(String taskId){
        this.taskId = taskId;
    }


}
