package com.zuzuche.sms.common.utils;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.TimeZone;

/**
 *
 *
 * @desc:
 * @author: panqiong
 * @date: 2018/8/29
 */
public class DateUtil {
    public static final String PATTERN_1 ="yyyy-MM-dd HH:mm:ss";

    public static final String PATTERN_2 ="yyyyMMddHHmmss";

    public static final String PATTERN_3 ="yyMMddHHmmss";

    public static final String PATTERN_UTC ="yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";

    static SimpleDateFormat[] CUSTOM_DATE_FORMATS ;
    static {

                 final String[] possibleDateFormats = {
                                 /* RFC 1123 with 2-digit Year */"EEE, dd MMM yy HH:mm:ss z",
                                 /* RFC 1123 with 4-digit Year */"EEE, dd MMM yyyy HH:mm:ss z",
                                 /* RFC 1123 with no Timezone */"EEE, dd MMM yy HH:mm:ss",
                                 /* Variant of RFC 1123 */"EEE, MMM dd yy HH:mm:ss",
                                 /* RFC 1123 with no Seconds */"EEE, dd MMM yy HH:mm z",
                                 /* Variant of RFC 1123 */"EEE dd MMM yyyy HH:mm:ss",
                                 /* RFC 1123 with no Day */"dd MMM yy HH:mm:ss z",
                                 /* RFC 1123 with no Day or Seconds */"dd MMM yy HH:mm z",
                                 /* ISO 8601 slightly modified */"yyyy-MM-dd'T'HH:mm:ssZ",
                                 /* ISO 8601 slightly modified */"yyyy-MM-dd'T'HH:mm:ss'Z'",
                                 /* ISO 8601 slightly modified */"yyyy-MM-dd'T'HH:mm:sszzzz",
                                 /* ISO 8601 slightly modified */"yyyy-MM-dd'T'HH:mm:ss z",
                                 /* ISO 8601 */"yyyy-MM-dd'T'HH:mm:ssz",
                                 /* ISO 8601 slightly modified */"yyyy-MM-dd'T'HH:mm:ss.SSSz",
                                 /* ISO 8601 slightly modified */"yyyy-MM-dd'T'HHmmss.SSSz",
                                 /* ISO 8601 slightly modified */"yyyy-MM-dd'T'HH:mm:ss",
                                 /* ISO 8601 w/o seconds */"yyyy-MM-dd'T'HH:mmZ",
                                 /* ISO 8601 w/o seconds */"yyyy-MM-dd'T'HH:mm'Z'",
                                 /* RFC 1123 without Day Name */"dd MMM yyyy HH:mm:ss z",
                                 /* RFC 1123 without Day Name and Seconds */"dd MMM yyyy HH:mm z",
                                 /* Simple Date Format */"yyyy-MM-dd",
                                 /* Simple Date Format */"MMM dd, yyyy"};

                 CUSTOM_DATE_FORMATS = new SimpleDateFormat[possibleDateFormats.length];

                 for (int i = 0; i < possibleDateFormats.length; i++) {
                         CUSTOM_DATE_FORMATS[i] = new SimpleDateFormat(possibleDateFormats[i], Locale.getDefault());
                         CUSTOM_DATE_FORMATS[i].setTimeZone(TimeZone.getDefault());
                 }
    }


    public static String getCurrentTime(String pattern){
        return LocalDateTime.now().format(DateTimeFormatter.ofPattern(pattern));
    }


    public static void main(String[] args) {
        String utcTime ="2019-07-24T06:28:00.000Z";
        //String utcTime = "2018-01-31T14:32:19Z";
        long xxxx = LocalDateTime.parse(utcTime, DateTimeFormatter.ofPattern(DateUtil.PATTERN_UTC))
                .toInstant(ZoneOffset.of("+8")).toEpochMilli();
        System.out.println("xxxx = " + xxxx);


        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");


    }

}
