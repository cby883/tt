package com.zuzuche.sms.remote;

import com.aliyuncs.DefaultAcsClient;
import com.aliyuncs.IAcsClient;
import com.aliyuncs.dysmsapi.model.v20170525.SendBatchSmsRequest;
import com.aliyuncs.dysmsapi.model.v20170525.SendBatchSmsResponse;
import com.aliyuncs.http.MethodType;
import com.aliyuncs.profile.DefaultProfile;
import com.aliyuncs.profile.IClientProfile;
import com.google.common.base.Splitter;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.zuzuche.commons.base.util.JsonUtil;
import com.zuzuche.sms.cache.ProviderAccountCache;
import com.zuzuche.sms.cache.SmsSignCache;
import com.zuzuche.sms.cache.co.SmsSignCo;
import com.zuzuche.sms.common.constant.ErrorMessage;
import com.zuzuche.sms.dto.SmsDto;
import com.zuzuche.sms.entity.ProviderAccountInfo;
import com.zuzuche.sms.remote.dto.AliYunSmsSendDto;
import com.zuzuche.sms.remote.dto.SmsContentDto;
import com.zuzuche.sms.remote.param.AliYunPushParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;
import org.springframework.web.client.ResourceAccessException;

import java.nio.charset.Charset;
import java.util.*;

/**
 * @desc: 文件批量发送短信api类
 * @author: chenbingyi
 * @date: 2019/8/12
 */
@Service
@Slf4j
public class BatchSendApi extends AbstractHttpInvoke {


    @Override
    public String postJson(String url,Object param){
        return super.postJson(url,param);
    }
    @Override
    public String postForm(String url, Object param){
        return super.postForm(url,param);
    }

    @Override
    public String get(String url) {
        return super.get(url);
    }
    @Override
    protected void setHeader(HttpHeaders header) {

    }
}
