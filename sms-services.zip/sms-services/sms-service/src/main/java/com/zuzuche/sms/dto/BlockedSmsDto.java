package com.zuzuche.sms.dto;

import com.zuzuche.kafka.message.BaseMessage;
import com.zuzuche.sms.common.constant.Constants;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Set;

/**
 * @desc: 重复短信
 * @author: panqiong
 * @date: 2018/10/29
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class BlockedSmsDto extends BaseMessage {

    private String taskId;

    private Constants.FilterTypes filterType;

    private Set<String> mobileList;



}
