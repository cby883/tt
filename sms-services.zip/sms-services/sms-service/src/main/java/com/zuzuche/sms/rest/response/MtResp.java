package com.zuzuche.sms.rest.response;


import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;

/**
 * 功能：对接业务方的下行短信返回信息.
 * 详细：
 *
 * @author Created on 2019.01.30 by chaodian
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ApiModel(value = "对接业务方的下行短信返回信息")
public class MtResp {
    @ApiModelProperty(value = "手机入队状态返回信息",required = true)
    private Map<String, MobileStatus> sendRes;

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    @ApiModel(value = "单个手机入队状态")
    public static class MobileStatus {
        @ApiModelProperty(value = "单个手机号",required = true)
        private String mobile;

        @ApiModelProperty(value = "入队状态, success表示该号码发送成功，failed表示发送失败",required = true)
        private String sendStatus;

        @ApiModelProperty(value = "提交结果提示信息",required = true)
        private String msg;
    }
}
