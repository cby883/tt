package com.zuzuche.sms.remote.param;


import com.zuzuche.commons.feign.annotation.PhpRequest;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 功能：添加主站订单短信日志的请求信息.
 * 详细：
 *
 * @author Created on 2019.03.26 by chaodian
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@PhpRequest
public class AddOrderSmsLogParam {
    /**
     * 手机号码
     */
    private String mobile;

    /**
     * 短信内容
     */
    private String content;

    /**
     * 订单号
     */
    private String uniqueId;

    /**
     * 操作人
     */
    private String admin;
}
