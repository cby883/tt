package com.zuzuche.sms.listener.provider;

import com.google.common.util.concurrent.RateLimiter;
import com.zuzuche.sms.cache.SmsConfigCache;
import com.zuzuche.sms.dto.SmsDto;
import com.zuzuche.sms.executors.JuchnExecutor;
import com.zuzuche.sms.report.syn.JuchnSynService;
import com.zuzuche.sms.service.KafkaService;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

/**
 * @desc: 通用下行队列,从这个队列下发的短信将自动选择供应商
 * 暂时无确认需求实现
 * @author: panqiong
 * @date: 2018/10/18
 */
@Component
@Slf4j
public class OutboundListener implements InitializingBean {

    private static String RATE_KEY = "sms_outbound_topic_rate";


    private static RateLimiter rateLimiter;

    @Autowired
    JuchnSynService juchnService;


    @Autowired
    KafkaService kafkaService;

    @Autowired
    SmsConfigCache configCache;


    @Autowired
    JuchnExecutor outboundExecutor;

    /**
     * 注意:
     *  - 如果消息处理超时,spring默认最多会重新处理三次
     *  - 如果对消息保障性要求高,发生异常要预警,可以把处理失败的消息转发到dlq队列
     *  - 优雅退出应用,不然会可能丢失已消费未处理的消息
     * 短信下发队列
     * @param consumer
     */
    @KafkaListener(topics = KafkaService.SMS_OUTBOUND_TOPIC)
    public void consume(ConsumerRecord<String, SmsDto> consumer) {
        log.info("[receive sms_outbound_topic]:" +consumer.value());
        rateLimiter.acquire();
//        try{
//            // 1个短信实体
//            SmsDto sms = consumer.value();
//            // 下行业务处理
//            outboundExecutor.handle(sms);
//
//        }catch (RejectedExecutionException e){
//            log.error("[线程池拒绝策略触发-sms_outbound_topic]message:"+consumer.value(),e.getMessage(),e);
//            // 发送到dlq队列 并预警人工接入
//            //kafkaService.sendToDlq(consumer.value());
//        }catch (Exception e){
//            // 发送到dlq队列 并预警人工接入
//            log.error("[消息处理出现异常-sms_outbound_topic]message:"+consumer.value(),e.getMessage(),e);
//            //kafkaService.sendToDlq(consumer.value());
//        }

    }



    @Override
    public void afterPropertiesSet() throws Exception {
        if(configCache.containsKey(RATE_KEY)){
            int rate = Integer.parseInt(configCache.get(RATE_KEY));
            rateLimiter = RateLimiter.create(rate);
        }else{
            // 默认速度
            rateLimiter = RateLimiter.create(50);
        }
    }
}
