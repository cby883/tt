package com.zuzuche.sms.dto;


import com.alibaba.fastjson.annotation.JSONField;
import com.zuzuche.kafka.message.BaseMessage;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 功能：回调推送给总备注接口的信息.
 * 详细：
 *
 * @author Created on 2019.03.15 by chaodian
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class RemarkDto extends BaseMessage {
    /**
     * 总备注的唯一id
     */
    private String businessId;

    /**
     * 来源网站
     */
    @Builder.Default
    private String website = "zzc";

    /**
     * 项目渠道
     */
    @Builder.Default
    private String project = "sms";

    /**
     * 客服账号
     */
    private String adminId;

    /**
     * 手机号码
     */
    private String phone;

    /**
     * 区号
     */
    private String phoneCode;

    /**
     * 短信内容
     */
    private String content;

    /**
     * 时间
     */
    private String sortTime;
}
