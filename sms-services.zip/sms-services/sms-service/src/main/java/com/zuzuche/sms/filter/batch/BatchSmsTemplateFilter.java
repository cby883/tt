package com.zuzuche.sms.filter.batch;


import com.alibaba.fastjson.JSONException;
import com.zuzuche.commons.base.util.JsonUtil;
import com.zuzuche.commons.base.util.StringUtil;
import com.zuzuche.sms.cache.SmsTemplateCache;
import com.zuzuche.sms.common.enums.FilterTypes;
import com.zuzuche.sms.common.enums.SmsFileType;
import com.zuzuche.sms.dto.MtDto;
import com.zuzuche.sms.entity.SmsBatchTask;
import com.zuzuche.sms.filter.BatchFilter;
import com.zuzuche.sms.filter.MtFilter;
import com.zuzuche.sms.service.KafkaService;
import com.zuzuche.sms.service.SmsMtService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * 功能：批量短信模板替换过滤器.
 * 详细：
 *
 * @author bingyi
 */
@Component
@Slf4j
@Order(0)
public class BatchSmsTemplateFilter implements BatchFilter {
    @Autowired
    SmsTemplateCache smsTemplateCache;

    @Autowired
    KafkaService kafkaService;

    @Autowired
    SmsMtService smsMtService;

    /**
     * 短信模板替换.
     *
     * 1. 判断是否需要模板替换,通过file_type字段判断
     * 2. 从phone_list表中取出extra_param字段的json串，进行变量替换
     *
     * @param sms the sms
     */
    @Override
    public boolean doFilter(MtDto sms, SmsBatchTask smsBatchTask) {
       //变量替换
        String variables = sms.getVariables();
        if (StringUtil.isNotEmpty(variables)&&smsBatchTask.getFileType()==SmsFileType.SMS_FILE_TYPE_NORMAL.code()) {
            try {
                Map<String, Object> variMap = JsonUtil.stringToMap(variables);
                for (String varikey : variMap.keySet()) {
                    String variVal = variMap.get(varikey).toString();
                    sms.setContent(sms.getContent().replace(varikey, variVal));
                }
            } catch (JSONException e) {
                log.info("批量工具短信模板变量格式有误，数据如:" + sms.toString());
                return false;
            } catch (Exception e) {
                log.error("批量短信工具短信模板变量解析异常，不允许替换模板, 数据如:" + sms.toString(), e, e.getMessage());
                return false;
            }
        }
        return true;
    }

}
