package com.zuzuche.sms.dto;

import com.alibaba.fastjson.annotation.JSONField;
import com.zuzuche.kafka.message.BaseMessage;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 功能：回调推送给交互记录接口的信息.
 * 详细：
 *
 * @author Created on 2019.03.15 by chaodian
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class IntersectionDto extends BaseMessage {
    /**
     * 交互记录的唯一id
     */
    private String businessId;

    /**
     * 客服账号
     */
    private String adminId;

    /**
     * 手机号码
     */
    private String phone;

    /**
     * 提交时间
     */
    private int startTime;

    /**
     * 短信下行/上行类型，1为下行，2为上行
     */
    @Builder.Default
    private int smsType = 1;

    /**
     * 短信内容
     */
    private String content;

    /**
     * 来源网站
     */
    @Builder.Default
    private String website = "zuzuche";

    /**
     * 项目渠道
     */
    @Builder.Default
    private String project = "sms";
}
