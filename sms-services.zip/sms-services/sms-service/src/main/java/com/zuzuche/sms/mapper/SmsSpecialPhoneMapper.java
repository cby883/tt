package com.zuzuche.sms.mapper;

import com.zuzuche.commons.mybatis.BaseMapper;
import com.zuzuche.sms.entity.SmsSpecialPhone;

import java.util.List;

/**
 * @desc:
 * @author: panqiong
 * @date: 2018/11/9
 */
public interface SmsSpecialPhoneMapper extends BaseMapper<SmsSpecialPhone> {

    /**
     * 黑白名单一般不会很多吧?
     * 现在简单实现只支持2000个,如果后续有需求记得修改
     * @return
     */
    List<SmsSpecialPhone> queryAllList();


}
