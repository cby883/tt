package com.zuzuche.sms.mapper;

import com.zuzuche.commons.mybatis.BaseMapper;
import com.zuzuche.sms.entity.SmsBatchTask;
import com.zuzuche.sms.entity.SmsFilePhoneList;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * desc:
 *
 * @author bingyi
 * @date 2019/10/30
 */
@Repository
public interface SmsFilePhoneListMapper extends BaseMapper<SmsFilePhoneList> {
    /**
     * 通过fileId 和 offset，每次查出100条记录
     * @param smsBatchTask
     * @return
     */
    public List<SmsFilePhoneList> searchWithOffset(SmsBatchTask smsBatchTask);
}