package com.zuzuche.sms.listener.inner;

import com.google.common.util.concurrent.RateLimiter;
import com.zuzuche.logback.util.MDCUtil;
import com.zuzuche.sms.cache.SmsConfigCache;
import com.zuzuche.sms.common.enums.RateLimiterKeyTypes;
import com.zuzuche.sms.dto.InvokeResultDto;
import com.zuzuche.sms.service.KafkaService;
import com.zuzuche.sms.service.SendResultService;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

/**
 * @desc: 发送结果topic监听
 * @author: panqiong
 * @date: 2018/11/1
 */
@Component
@Slf4j
public class SendResultListener  {
    private static String RATE_KEY = "send_result_topic_rate";
    /**
     * 消费限速,每秒5个
     */
    private static RateLimiter rateLimiter ;

    @Autowired
    SmsConfigCache configCache;

    @Autowired
    SendResultService sendResultService;

    /**
     * 发送供应商后的结果
     * @param consumer
     */
    @KafkaListener(topics = KafkaService.SEND_RESULT_TOPIC)
    public void consume(ConsumerRecord<String, InvokeResultDto> consumer) {
        rateLimiter=configCache.getLimiter(RateLimiterKeyTypes.SEND_RESULT_TOPIC_RATE);
        rateLimiter.acquire();
        log.info("[receive send_result_topic]:" +consumer.value());
        InvokeResultDto result = consumer.value();

        sendResultService.process(result);
    }
}
