package com.zuzuche.sms.common.enums;

import com.zuzuche.commons.base.constants.BaseEnum;
import lombok.Getter;

/**
 * 短信文件类型
 *
 * @author bingyi
 * @date 2019/11-06
 */
@Getter
public enum SmsFileType implements BaseEnum<Integer> {
    /**
     * 小批量且可能带变量替换
     */
    SMS_FILE_TYPE_NORMAL(2,"小批量且可能带变量替换"),
    /**
     * 大批量文件且不带变量替换
     */
    SMS_FILE_TYPE_LARGE(1,"大批量文件且不带变量替换");

    /**
     * 状态code
     */
    private Integer code;

    /**
     * 描述
     */
    private String desc;


    SmsFileType(Integer code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    @Override
    public Integer code() {
        return code;
    }
}