package com.zuzuche.sms.rest;

import com.zuzuche.commons.base.annotation.Check;
import com.zuzuche.commons.base.resp.RespResult;
import com.zuzuche.commons.base.util.ConcurrentSafeSet;
import com.zuzuche.sms.common.utils.Md5Util;
import com.zuzuche.sms.common.utils.Sha1Util;
import com.zuzuche.sms.dto.SmsDto;
import com.zuzuche.sms.remote.AliYunPushApi;
import com.zuzuche.sms.remote.BaiwuPushApi;
import com.zuzuche.sms.remote.MockApi;
import com.zuzuche.sms.remote.dto.AliYunSmsSendDto;
import com.zuzuche.sms.remote.param.*;
import com.zuzuche.sms.rest.response.MtResp;
import com.zuzuche.sms.rest.response.SmsResp;
import com.zuzuche.threadpool.ThreadPoolExecutorFactory;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import com.zuzuche.sms.common.utils.PerformUtil;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.net.URLEncoder;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.ThreadPoolExecutor;


/**
 * @desc:
 * @author: panqiong
 * @date: 2018/11/5
 */
@RestController
@RequestMapping("/test")
@Api(value = "test", description = "test", tags = {"test"})
@Slf4j
public class TestRest {
    @Autowired
    AliYunPushApi aliYunPushApi;

    @Autowired
    MockApi testRemote;



    @Autowired
    BaiwuPushApi baiwuPushApi;

    @Autowired
    Sha1Util sha1Util;


    /**
     * 纯转发
     * @return
     */
    @PostMapping("/threadPoolStats")
    @ApiOperation(value = "根据模板下发业务短信", notes = "根据模板下发业务短信")
    @Check
    public RespResult<List<ThreadPoolExecutorFactory.PoolMetrics>> threadPoolStats() {
        List<ThreadPoolExecutorFactory.PoolMetrics> list = ThreadPoolExecutorFactory.printStats();
        return RespResult.success(list);
    }



    /**
     * 获取用户状态报告
     * 并自动保存offset
     * @param
     * @return
     */
    @GetMapping("/send1")
    @ApiOperation(value = "testsend", notes = "testsend")
    public RespResult<SmsResp> send1() {

        SmsSendParam param = SmsSendParam.builder()
                .corpId("2e5f001")
                .corpPwd("wlkj51")
                .corpService("10690226yd")
                .mobile("18122720701")
                .msgContent("【租租车】hello world! 验证码是1245")
                .build();

        baiwuPushApi.smsSend(param);
        // 同步入队 并返回taskId
        return RespResult.success();
    }


    /**
     * 获取用户状态报告
     * 并自动保存offset
     * @param
     * @return
     */
    @GetMapping("/send2")
    @ApiOperation(value = "send2", notes = "send2")
    public RespResult<SmsResp> send2() {

        PostSmsParam param = PostSmsParam.builder()
                .id("2e5f001")
                .md5TdCode(Md5Util.string2MD5("wlkj5110690226yd"))
                .mobile("18122720701")
                .msgContent("【租租车】send2")
                .msgId("zlsldfjasdfj123")
                .build();

        baiwuPushApi.postSms(param);
        // 同步入队 并返回taskId
        return RespResult.success();
    }



    /**
     * @param
     * @return
     */
    @GetMapping("/hystest")
    public String hystest() {
        long start = Instant.now().toEpochMilli();
        try{
            SmsSendParam param = SmsSendParam.builder()
                    .msgContent("1111")
                    .mobile("181111111")
                    .corpId("12313")
                    .corpPwd("123sadf")
                    .corpMsgId("1111")
                    .build();
            testRemote.smsSend(param);
        }catch (Exception e){
            log.error("[TestRest::hystest]",e.getMessage(), e);
        }
        long end = Instant.now().toEpochMilli();
        PerformUtil.logTime("hystest",start,end);

        return "OK";
    }

    /**
     * @param
     * @return
     */
    @GetMapping("/juchnhello")
    public String hello() {
        long start = Instant.now().toEpochMilli();
        try{
            MockSendParam param = MockSendParam.builder()
                  .mobiles("18122720701")
                    .content("你好哦")
                    .build();
            testRemote.mockSend(param);
        }catch (Exception e){
            log.error("[TestRest::hello]", e.getMessage(), e);
        }
        long end = Instant.now().toEpochMilli();
        PerformUtil.logTime("hystest",start,end);

        return "OK";
    }

    /**
     * @param
     * @return
     */
    @GetMapping("/increaseTopicJson")
    public Map increaseTopicJson() {
        List<String> topicList = new ArrayList();
        topicList.add("send_result_topic");
        topicList.add("intersection_topic");
        topicList.add("order_sms_log_topic");
        topicList.add("filter_topic");
        topicList.add("sms_normal_topic");
        topicList.add("remark_topic");
        topicList.add("baiwu_sms_outbound_topic");
        topicList.add("sms_outbound_topic");
        topicList.add("blocked_sms_topic");
        topicList.add("springCloudBus");
        topicList.add("sms_market_topic");
        topicList.add("sms_verify_topic");
        topicList.add("chlan_sms_outbound_topic");
        topicList.add("juchn_sms_outbound_topic");

        topicList.add("state_switch_event");

        topicList.add("email_virtual_send");
        topicList.add("email_rec_result");
        topicList.add("email_send_result");

        topicList.add("CS_USER_INFO_CHANGE");

        topicList.add("http_task_common_topic");
        topicList.add("task_retry_prepare_topic");
        topicList.add("task_execute_result_topic");
        topicList.add("http_task_high_topic");



        topicList.add("source_export_topic");
        topicList.add("source_event_topic");

        List<Partition> partitionList = new ArrayList<>(100);
        topicList.stream().forEach(topic->{
            for(int i = 0; i<6 ; i++){

                Partition partition =  Partition.builder()
                        .topic(topic)
                        .partition(i)
                        .replicas(Arrays.asList(1,2,3))
                        .build();

                partitionList.add(partition);

            }
        });

        Map map = new HashMap<>();
        map.put("version",1);
        map.put("partitions",partitionList);

        return map;


    }



    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class Partition{
        private String topic;
        private int partition;
        private List<Integer> replicas ;
    }

}
