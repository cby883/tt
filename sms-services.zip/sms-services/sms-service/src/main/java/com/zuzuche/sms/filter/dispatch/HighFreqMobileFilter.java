package com.zuzuche.sms.filter.dispatch;

import com.google.common.base.Joiner;
import com.google.common.base.Splitter;
import com.zuzuche.commons.base.util.JsonUtil;
import com.zuzuche.commons.base.util.StringUtil;
import com.zuzuche.sms.cache.HighFreqMobileCache;
import com.zuzuche.sms.cache.SafeMonitorRuleCache;
import com.zuzuche.sms.common.enums.FilterTypes;
import com.zuzuche.sms.common.enums.HighFreqFilterTypes;
import com.zuzuche.sms.common.enums.SmsType;
import com.zuzuche.sms.common.utils.PerformUtil;
import com.zuzuche.sms.dto.FilterMtDto;
import com.zuzuche.sms.dto.MtDto;
import com.zuzuche.sms.filter.MtFilter;
import com.zuzuche.sms.service.KafkaService;
import com.zuzuche.sms.service.SmsMtService;
import com.zuzuche.threadpool.ThreadPoolExecutorFactory;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.lang.reflect.Array;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.*;
import java.util.stream.Collectors;

/**
 * 功能：短信发送过快拦截器(包括全部、验证码、营销).
 * 详细：
 *
 * @author Created on 2019.03.08 by chaodian
 */
@Component
@Slf4j
@Order(5)
public class HighFreqMobileFilter implements MtFilter {

    private static String SPLIT = ",";

    /**
     * The High freq mobile cache.
     */
    @Autowired
    HighFreqMobileCache highFreqMobileCache;

    /**
     * The Safe monitor rule cache.
     */
    @Autowired
    SafeMonitorRuleCache safeMonitorRuleCache;

    /**
     * The Kafka service.
     */
    @Autowired
    KafkaService kafkaService;

    /**
     * The Sms mt service.
     */
    @Autowired
    SmsMtService smsMtService;

    /**
     * 能绕过营销短信频率限制的黑卡业务方标识名
     */
    private static final String BLACK_UNIQUE_FROM_SIGN = "black_unique";

    /**
     * 能绕过营销短信频率限制的TIDL业务方参数标识的key
     */
    private static final String TIDL_PASS_MARKET_FILTER_SIGN = "tidl_business_type";

    /**
     * 能绕过营销短信频率限制的TIDL业务方参数标识key对应的val。
     *
     * tidl_activate表示TIDL激活提醒
     * tidl_unpaid_tip表示TIDL挽回待支付用户
     *
     */
    private static Set<String> tidlPassMarketFilterSignVals;
    static {
        tidlPassMarketFilterSignVals = new HashSet<>(2);
        tidlPassMarketFilterSignVals.add("tidl_activate");
        tidlPassMarketFilterSignVals.add("tidl_unpaid_tip");
    }

    private static ExecutorService executor = ThreadPoolExecutorFactory
            .create(ThreadPoolExecutorFactory.Config.builder()
                    .corePoolSize(300)
                    .maximumPoolSize(300)
                    .keepAliveTime(5)
                    .workQueue(new ArrayBlockingQueue<>(1000))
                    .unit(TimeUnit.MINUTES)
                    .handler(new ThreadPoolExecutor.CallerRunsPolicy())
                    .threadPoolName("HighFreqMobFilterRedisGetExecutor")
                    .build());

    /**
     * 执行过滤器.
     * 1. 先执行单个号码总频率过高过滤器
     * 2. 再根据短信性质类型执行 验证码过快过滤器 或 营销短信过快过滤器
     * @param sms the mt dto
     * @return boolean
     */
    @Override
    public boolean doFilter(MtDto sms) {
        // 没有需要发送的手机号码， 但是有白名单，白名单需要绕过频率拦截检测
        if (StringUtil.isBlank(sms.getMobiles())) {
            return StringUtil.isNotBlank(sms.getWhiteMobiles());
        }

        if (safeMonitorRuleCache.checkIsSafeMonitorOpen(HighFreqFilterTypes.短信发送频率过高.getSafeMonitorRuleNm())
                && !executeFilter(sms, FilterTypes.短信发送频繁过滤器, HighFreqFilterTypes.短信发送频率过高)) {
            return false;
        } else {
            if (sms.getType() == SmsType.验证码.code()
                    && safeMonitorRuleCache.checkIsSafeMonitorOpen(HighFreqFilterTypes.验证码发送频率过高.getSafeMonitorRuleNm()) ) {
                return executeFilter(sms, FilterTypes.验证码发送频繁过滤器, HighFreqFilterTypes.验证码发送频率过高);
            } else if (sms.getType() == SmsType.营销.code()
                    && safeMonitorRuleCache.checkIsSafeMonitorOpen(HighFreqFilterTypes.营销短信发送频率过高.getSafeMonitorRuleNm())
                    && !checkIsNoMarketFreqFilter(sms)
            ) {
                return executeFilter(sms, FilterTypes.营销发送频繁过滤器, HighFreqFilterTypes.营销短信发送频率过高);
            }
        }

        return true;
    }

    /**
     * 检查是否可以绕过营销短信拦截.
     *
     * 1. 全球购骑士卡，绕过拦截
     * 2. TIDL激活提醒、TIDL挽回待支付用户 短信，绕过营销短信
     *
     * @param sms the mt dto
     * @return boolean
     */
    private boolean checkIsNoMarketFreqFilter(MtDto sms) {
        if (StringUtil.isNotBlank(sms.getExtraParam())) {
            try {
                Map<String, String> extraParamMap = JsonUtil.stringToMap(sms.getExtraParam());
                if (extraParamMap.containsKey(TIDL_PASS_MARKET_FILTER_SIGN) &&
                        StringUtil.isNotBlank(extraParamMap.get(TIDL_PASS_MARKET_FILTER_SIGN)) &&
                        tidlPassMarketFilterSignVals.contains(extraParamMap.get(TIDL_PASS_MARKET_FILTER_SIGN))
                ) {
                    return true;
                }
            } catch (Exception e) {
                log.error("业务短信extraParam的Json解析出错，短信数据如下:" + sms.toString());
            }
        }

        return StringUtil.isNotBlank(sms.getFrom()) && BLACK_UNIQUE_FROM_SIGN.equals(sms.getFrom());
    }

    /**
     * 过滤主流程
     * @param sms the mt dto
     * @param freqType 短信发送频率过快类型
     * @return boolean
     */
    private boolean executeFilter(MtDto sms, FilterTypes filter, HighFreqFilterTypes freqType) {
        // 手机号码为空，直接返回false
        if (StringUtil.isBlank(sms.getMobiles())) {
            return false;
        }

        // 发送频率没有超过限制的手机列表
        List<String> noHighFreqList = null;

        // 批量发送多个手机
        if (sms.getMobiles().contains(SPLIT)) {
            List<String> mobileList = Splitter.on(",").splitToList(sms.getMobiles());

            // 从redis获取发送频率超过限制的手机列表
            List<String> highFreqList = getHighFreqList(mobileList, freqType,sms.getFrom());

            // 存在超过限制的手机列表
            if (CollectionUtils.isNotEmpty(highFreqList)) {
                // 过滤一下超过限制的手机， 筛选出没有超过限制的手机
                noHighFreqList = mobileList.parallelStream().filter(m->!highFreqList.contains(m)).collect(Collectors.toList());
                // 超过限制的手机则丢入专门处理kafka的队列
                FilterMtDto filterMtDto  = FilterMtDto.builder().mobileList(highFreqList)
                        .content(sms.getContent())
                        .errorCode(filter.code())
                        .build();
                kafkaService.sendToFilterTopic(filterMtDto);
            } else {
                noHighFreqList = mobileList;
            }

            boolean resetState = smsMtService.resetMtMobiles(sms, noHighFreqList);
            // 识别到有白名单，还是会返回true
            return  StringUtil.isNotBlank(sms.getWhiteMobiles()) || resetState;

        } else {
            if (highFreqMobileCache.checkIsMobileOverLimit(sms.getMobiles(), freqType,sms.getFrom())) {
                FilterMtDto filterMtDto  = FilterMtDto.builder().mobileList(Arrays.asList(sms.getMobiles()))
                        .content(sms.getContent())
                        .errorCode(filter.code())
                        .build();
                kafkaService.sendToFilterTopic(filterMtDto);
                // 单个手机被拦截，因此最后发送的手机列表需要设置为空
                sms.setMobiles("");
                // 识别到有白名单，还是会返回true
                return StringUtil.isNotBlank(sms.getWhiteMobiles());
            } else {
                return true;
            }
        }
    }

    /**
     * 从redis获取发送频率超过限制的手机列表
     * @param mobileList the mobile list
     * @param freqType 短信发送频率过快类型
     * @return list
     */
    private List<String> getHighFreqList(List<String> mobileList, HighFreqFilterTypes freqType,String customerSign) {
        // 结果集
        List<String> list = new ArrayList<>(200);
        long start = Instant.now().toEpochMilli();
        // 封装后无返回值，必须自己whenComplete()获取
        CompletableFuture[] cfs = mobileList.stream()
                .map(mobile ->
                        CompletableFuture.supplyAsync(() -> highFreqMobileCache.checkIsMobileOverLimit(mobile, freqType,customerSign), executor)
                                .whenComplete((status, exception) -> {
                                    if (status) {
                                        list.add(mobile);
                                    }
                                })
                ).toArray(CompletableFuture[]::new);
        // 上面异步执行的多个子线程在这里主线程进行阻塞同步返回
        CompletableFuture.allOf(cfs).join();
        long end = Instant.now().toEpochMilli();
        PerformUtil.logTime("getHighMobileFreq", start, end);

        return list;
    }
}
