package com.zuzuche.sms.job;
import com.google.common.util.concurrent.RateLimiter;
import com.zuzuche.commons.redis.RedisLock;
import com.zuzuche.logback.util.MDCUtil;
import com.zuzuche.sms.common.enums.SmsBatchSendTaskType;
import com.zuzuche.sms.common.utils.SpringBeanFactory;
import com.zuzuche.sms.entity.SmsBatchTask;
import com.zuzuche.sms.mapper.SmsBatchTaskMapper;
import com.zuzuche.sms.service.BatchTaskContainerService;
import com.zuzuche.sms.service.StatusReportService;
import com.zuzuche.sms.task.SmsBatchSendTask;
import com.zuzuche.threadpool.ThreadPoolExecutorFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * @desc: 文件批量状态报告定时器
 * @author: bingyi
 * @date: 2019/11/07
 */
@Component
@Slf4j
public class SmsBatchReportJob {
    @Autowired
    StatusReportService statusReportService;
    private static final String SMS_BATCH_SEND_REPORT_KEY="SMS_BATCH_SEND_REPORT_KEY_2_";
    /**
     *  每天凌晨两点更新
     */
    @Scheduled(cron = "0 0 2 * * ?")
    public void execute(){
        MDCUtil.set();
        RedisLock redisLock=new RedisLock(SMS_BATCH_SEND_REPORT_KEY);
        try {
            if (redisLock.lock()) {
                try {
                    statusReportService.updateSmsBatchReport();
                } finally {
                    //释放锁
                    redisLock.unlock();
                }
            }
        } catch (Exception e) {
            log.error("【SmsBatchReportJob】营销小工具状态报告定时器出错",e.getMessage(),e);
        }
        MDCUtil.clear();
    }
}
