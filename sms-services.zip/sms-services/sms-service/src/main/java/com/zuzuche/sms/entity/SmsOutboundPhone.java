package com.zuzuche.sms.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Table;
import java.time.LocalDateTime;
import java.util.Date;


/**
 * @desc 下行短信手机号码
 * @author panqiong
 * @date 20181019
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "sms_outbound_phone")
public class SmsOutboundPhone {

    private int id;

    private String taskId;

    private String phone;

    private LocalDateTime createTime;


}