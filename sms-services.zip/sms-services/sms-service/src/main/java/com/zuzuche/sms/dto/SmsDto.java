package com.zuzuche.sms.dto;

import com.zuzuche.kafka.message.BaseMessage;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Queue;
import java.util.Set;

/**
 * @desc:
 * @author: panqiong
 * @date: 2018/10/29
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SmsDto extends BaseMessage {
    /**
     * 任务id 自己需要保存这个 跟踪这个批次需要
     * 上游没有传的话会自动生成一个
     */
    private String taskId ;
    /**
     * 签名类型
     */
    private int signType ;

    /**
     * 手机号码
     */
    private String mobile;

    /**
     * 短信内容
     */
    private String content;

    /**
     * md5后的content
     */
    private String md5Content;


    /**
     * 短信供应商id
     */
    private Integer accountId;

    /**
     * 权限认证签名 md5(secret+time)
     */
    private String authKey;

    /**
     * 时间 秒 ,用于权限认证签名
     */
    private long time;

    /**
     * 是否模拟 true的话将不会真实发送
     */
    @Builder.Default
    private boolean mock = false;

    /**
     * 模拟超时，该值表示重试到第n次才不会超时，0表示不会出现超时
     */
    @Builder.Default
    private int mockTimeOutUntilRetryNo = 0;

    /**
     * 重试前的短信供应商id，用于短信下发供应商失败重试用
     */
    private Integer parentAccountId;

    /**
     * 当前重试第n次，0表示没有重试过
     */
    @Builder.Default
    private int retryNo = 0;

    /**
     * 提交供应商的返回响应码
     */
    private String respCode;

    /**
     * 提交供应商的批次号
     */
    private String batchNo;

    /**
     * 额外参数dto
     */
    private ExtraParamDto extraParamDto;

    /**
     * 提交给供应商的下发来源，比如ERC，也即用户终端手机的短信显示的来源号码串
     */
    private String senderId;

    /**
     * 短信类型
     */
    @Builder.Default
    private int type = 1;
    /**
     * 备份accountId 队列
     */
    private Queue<Integer> backup;

    /**
     * 供应商名称
     */
    private String supplier;

    /**
     * 国家类型
     */
    @Builder.Default
    private int regionType = 1;

    /**
     * 重发短信内容
     */
    private String retryContent;
}
