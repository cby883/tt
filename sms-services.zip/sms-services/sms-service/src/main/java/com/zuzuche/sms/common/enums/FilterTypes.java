package com.zuzuche.sms.common.enums;

import com.zuzuche.commons.base.constants.BaseEnum;
import io.swagger.models.auth.In;


/**
 * The enum Filter types.
 *
 * @author Chaodian
 * @date 2019 -02-28
 */
public enum FilterTypes implements BaseEnum<Integer> {

    /**
     * 重复短信过滤器 filter types.
     */
    重复短信过滤器(1,"duplicated", "短信重复发送"),

    /**
     * 黑名单过滤器 filter types.
     */
    黑名单过滤器(2,"blackMobile", "号码处在黑名单当中"),

    /**
     * 权限检查过滤器 filter types.
     */
    权限检查过滤器(3,"authorize", "短信权限检查错误"),

    /**
     * 白名单过滤器 filter types.
     */
    白名单过滤器(4,"whiteMobile", "号码处在白名单"),

    /**
     * 错误格式国际号码过滤器 filter types.
     */
    错误格式国际号码过滤器(5, "errInterMobile", "国际短信号码不符合规范"),

    /**
     * 错误格式国内号码过滤器 filter types.
     */
    错误格式国内号码过滤器(6, "errInnerMobile", "国内短信号码不符合规范"),

    /**
     * 短信发送频繁过滤器 filter types.
     */
    短信发送频繁过滤器(7, "highFreqMobile", "同一号码发送短信频繁"),

    /**
     * 验证码发送频繁过滤器 filter types.
     */
    验证码发送频繁过滤器(8,"highFreqVerify", "同一号码触发验证码频繁"),

    /**
     * 营销发送频繁过滤器 filter types.
     */
    营销发送频繁过滤器(9, "highFreqMarket", "同一号码营销短信发送次数过多"),

    /**
     * 匹配供应商出错过滤器 filter types.
     */
    匹配供应商出错过滤器(10,"matchSupplierErr", "没有找到匹配的供应商"),



    /**
     * 模板替换出错过滤器 filter types.
     */
    模板替换出错过滤器(11, "templateMatchErr", "没有找到指定的短信模板"),


    /**
     * 短信内容为空过滤器 filter types.
     */
    短信内容为空过滤器(13, "emptyContent", "短信文案为空"),

    /**
     * 签名不存在过滤器 filter types.
     */
    签名不存在过滤器(14, "notExistSign", "短信签名不存在"),


    /**
     * 匹配供应商账户出错过滤器 filter types.
     */
    匹配供应商账户出错过滤器(15, "matchAccountIdErr", "没有找到对应的供应商账户id"),

    /**
     *
     */
    短信敏感词过滤器(16, "sensitiveWordsErr", "短信含有敏感词内容");

    private Integer code;

    private String sign;

    private String msg;

    FilterTypes(Integer code, String sign, String msg) {
        this.code = code;
        this.sign = sign;
        this.msg = msg;
    }

    @Override
    public Integer code() {
        return code;
    }

    /**
     * Sign string.
     *
     * @return the string
     */
    public String sign() {
        return sign;
    }

    /**
     * Msg string.
     *
     * @return the string
     */
    public String msg() {
        return msg;
    }

}