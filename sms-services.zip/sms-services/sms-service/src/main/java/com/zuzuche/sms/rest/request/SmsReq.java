package com.zuzuche.sms.rest.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;

/**
 * @desc: 常规短信
 * @author: panqiong
 * @date: 2018/9/26
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ApiModel(value = "短信下行")
public class SmsReq {
    /**
     * 任务id 自己需要保存这个 跟踪这个批次需要
     * 上游没有传的话会自动生成一个
     */
    @ApiModelProperty(value = "任务id,如果上游不传,则会默认生成一个 目前规则是2亿起步累加",required = false)
    private String taskId ;

    /**
     * 手机号码
     */
    @ApiModelProperty(value = "手机号码,多个,隔开, 目前规定单次上限200个",required = true)
    private String mobile;

    /**
     * 短信内容
     */
    @ApiModelProperty(value = "短信内容",required = true)
    private String content;


    /**
     * 短信供应商id
     */
    @ApiModelProperty(value = "供应商账户id",required = true)
    private int accountId;

    /**
     * 权限认证签名  md5()
     */
    @ApiModelProperty(value = "权限认证签名  md5(secret+time(秒))",required = false)
    private String authKey;

    /**
     * 时间 秒 ,用于权限认证签名
     */
    @ApiModelProperty(value = "时间 秒 ,用于权限认证签名",required = false)
    private long time;

    /**
     * 是否模拟 true的话将不会真实发送
     */
    @Builder.Default
    @ApiModelProperty(value = "是否只是模拟,不真实发送",required = true)
    private boolean mock = false;


    /**
     * 模拟超时，该值表示重试到第n次才不会超时，0表示不会出现超时
     */
    @Builder.Default
    @ApiModelProperty(value = "当mock为true，该参数才有效，表示是否需要进一步模拟超时")
    private int mockTimeOutUntilRetryNo = 0;

//    /**
//     * 签名id
//     */
//    private String signId;
//
//    /**
//     * 1:普通短信  2:营销短信
//     */
//    private int smsType;
//
//    /**
//     * 1:国内短信  2:国际短信
//     */
//    private int areaType;


}
