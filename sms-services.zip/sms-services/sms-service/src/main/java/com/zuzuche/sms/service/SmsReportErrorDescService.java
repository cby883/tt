package com.zuzuche.sms.service;

import com.zuzuche.commons.base.util.JsonUtil;
import com.zuzuche.commons.base.util.StringUtil;
import com.zuzuche.sms.cache.ConfigCache;
import com.zuzuche.sms.cache.ProviderAccountCache;
import com.zuzuche.sms.cache.SmsReportErrorDescCache;
import com.zuzuche.sms.common.utils.SpringBeanFactory;
import com.zuzuche.sms.dto.RefreshConfigDto;
import com.zuzuche.sms.entity.ProviderAccountInfo;
import com.zuzuche.sms.entity.SmsReportErrorDesc;
import com.zuzuche.sms.mapper.SmsReportErrorDescMapper;
import com.zuzuche.sms.remote.AbstractHttpInvoke;
import com.zuzuche.sms.rest.request.SmsReportErrorReq;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author chenbingyi
 * @desc: 状态报告详情
 * @date 2019/11/27
 */
@Service
@Slf4j
public class SmsReportErrorDescService {
    @Autowired
    SmsReportErrorDescCache cache;

    @Autowired
    SmsReportErrorDescMapper mapper;
    /**
     * desc：根据错误状态码和providerId获取 错误详情
     * @param errorCode
     * @param accountId
     * @return
     */
    public String getErrorDesc(String errorCode, int accountId) {
        //简单验参
        if (StringUtil.isBlank(errorCode) || accountId <= 0) {
            return errorCode;
        }
        //获取providerId
        ProviderAccountInfo info=ProviderAccountCache.getAccountById(accountId);
        if(info==null){
            return errorCode;
        }
        return cache.getErrorDesc(errorCode,info.getProviderId());
    }

    /**
     * 导入json数据
     * @param req
     */
    public void importErrorDesc(SmsReportErrorReq req){
        List<SmsReportErrorDesc> list=JsonUtil.stringToObjList(req.getJsonList(),SmsReportErrorDesc.class);
        //设置创建时间
        list.forEach(e->{
            e.setCreateTime(LocalDateTime.now());
        });
        //导入数据
        mapper.insertList(list);
        return ;
    }

    public List<SmsReportErrorDesc> exportData(){
        return mapper.selectAll();
    }
}
