package com.zuzuche.sms.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Table;
import java.time.LocalDateTime;

/**
 * @desc:
 * @author: panqiong
 * @date: 2018/11/8
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "sms_class_config")
public class SmsClassConfig {
    private int id;

    private int providerId;

    private String synServiceClass;

    private String outBoundTopic;

    private LocalDateTime createTime;

    private int validState;
}
