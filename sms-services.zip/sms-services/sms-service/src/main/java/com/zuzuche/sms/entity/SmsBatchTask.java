package com.zuzuche.sms.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Id;
import javax.persistence.Table;
import java.time.LocalDateTime;

/**
 * desc:批次短信任务实体类
 *
 * @author bingyi
 * @date 2019/10/30
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
@Table(name = "zuzuche_sms_db.sms_batch_task")
public class SmsBatchTask {
    @Id
    private Integer id;

    private Integer batchMtId;
    private String fileId;

    private Integer status;

    private Integer offset;

    private LocalDateTime planSendTime;

    private LocalDateTime createTime;

    private LocalDateTime updateTime;

    private Integer deleted;
    /**
     * 短信类型
     */
    private int smsType;

    /**
     * 短信文件类型
     */
    private int fileType;
}