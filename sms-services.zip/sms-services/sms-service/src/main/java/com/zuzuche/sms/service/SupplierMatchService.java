package com.zuzuche.sms.service;

import com.zuzuche.commons.base.util.StringUtil;
import com.zuzuche.sms.cache.SupplierMatchRuleCache;
import com.zuzuche.sms.cache.co.CommonMatchRuleCo;
import com.zuzuche.sms.common.enums.SmsRegionType;
import com.zuzuche.sms.common.enums.SmsType;
import com.zuzuche.sms.common.utils.Md5Util;
import com.zuzuche.sms.dto.MtDto;
import com.zuzuche.sms.vo.SupplierRuleMatchInfo;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.lang.reflect.Method;
import java.util.*;
import java.util.stream.Collectors;

/**
 * 功能：短信供应商匹配服务层.
 * 详细：
 *
 * @author Created on 2019.03.11 by chaodian
 */
@Service
@Slf4j
public class SupplierMatchService {
    /**
     * 根据权重随机选取供应商的阈值.
     *
     * 比如根据短信签名【租租车】找到两个匹配的供应商为BW2和CL2，那么根据BW2和CL2的优先级LEVEL进行权重随机选取供应商
     */
    private static final int RANDOM_SELECT_LIMIT = 2;

    /**
     * 租车催款短信的批次标识
     */
    private static final String CAR_PAY_BATCH_SIGN = "car_extra_pay_press_2018-08-02";

    /**
     * 供应商常规匹配规则标识
     */
    private static final String SUPPLIER_MATCH_COMMON_RULE = "commonRule";


    @Autowired
    SupplierMatchRuleCache ruleCache;

    /**
     * 获取短信匹配到的供应商的acountId
     *
     * 1. 先从特殊的匹配规则中挑选获取供应商
     * 2. 获取不到供应商则从常规的匹配规则中寻找
     *
     * @param mtDto the mt dto
     * @return Integer
     */
    public int getAccountIdFromRules(MtDto mtDto) {
        int accountId = chooseAcountIdFromAllExtraRules(mtDto);
        //额外规则匹配不到
        if (accountId <= 0) {
            accountId = chooseSupplierFromCommonRule(mtDto);
            if (accountId > 0) {
                mtDto.setSign(SUPPLIER_MATCH_COMMON_RULE);
            }

        }

        return accountId;
    }


    /**
     * 从各个供应商权重优先级中随机获取某个供应商的AcountId
     *
     * 获取方法:
     * 1. 调用方需要先对匹配到的所有供应商和对应的权重，封装成一个map对象，如 {"BW2" : 50, "CL2" : 50}
     * 2. 方法主体会根据map的供应商的权重值生成一个list，如此BW2会在list占有50个元素，CL2会在list占有50个元素
     * 3. 打乱list的排序
     * 4. 获取list的头元素
     *
     * @param supplierLevelMap 供应商权重map
     * @return Integer
     */
    private int getAccountIdRandomly(Map<Integer, Integer> supplierLevelMap) {
        List<Integer> accountList = new ArrayList<>();
        supplierLevelMap.forEach((k, v) -> {
            for (int i = 1; i <= v; i++) {
                accountList.add(k);
            }
        });
        if(CollectionUtils.isEmpty(accountList)){
            return 0;
        }
        Collections.shuffle(accountList);
        return accountList.get(0);

    }

    /**
     * 获取可以发送的具有不同权重的供应商规则列表.
     *
     * 1. 先从国际规则中获取，如果获取得到，以国际规则的为准，签名、类型、国内/国际、国家区号四个维度
     * 2. 如果获取不到，则直接以常规的签名、类型、国内/国际三个维度为准
     *
     * @param mtDto the mt dto
     * @return common match rule list
     */
    private List<CommonMatchRuleCo> getCommonMatchRuleList(MtDto mtDto) {
        List<CommonMatchRuleCo> ruleCoList = new ArrayList<>(16);
        if (StringUtil.isNotBlank(mtDto.getExactAreaCode())) {
            ruleCoList = ruleCache.getInterCommonRules(mtDto.getSignType(), mtDto.getType(),
                    mtDto.getRegionType(), mtDto.getExactAreaCode());
        }

        if (CollectionUtils.isEmpty(ruleCoList)) {
            ruleCoList = ruleCache.getCommonRules(mtDto.getSignType())
                    .stream()
                    .filter(e->e.getSmsType() == mtDto.getType() &&
                            e.getRegionType()==mtDto.getRegionType() && e.getAccountId()!=0)
                    .collect(Collectors.toList());
        }

        return ruleCoList;
    }

    /**
     * 从普通规则中挑选获取可以发送的一个供应商名称
     * @param mtDto the mt dto
     * @return int
     */
    private int chooseSupplierFromCommonRule(MtDto mtDto) {

        if (!ruleCache.containsCommonRuleKey(mtDto.getSignType())) {
            log.error("通过短信签名"+mtDto.getSignType()+"值找不到相关的供应商匹配规则配置");
            return 0;
        }

        // 获取可以发送的具有不同权重的供应商规则列表
        List<CommonMatchRuleCo> commonRules = getCommonMatchRuleList(mtDto);
        if (CollectionUtils.isEmpty(commonRules)) {
            log.error("找不到供应商,短信数据如:"+mtDto.toString());
            return 0;
        }

        // 如果最后筛选的供应商仅有一个，则直接返回这个供应商acountId
        if (commonRules.size() < RANDOM_SELECT_LIMIT) {
            int accountId=commonRules.get(0).getAccountId();
            //设置backup队列
            Queue<Integer> backup = chooseCommonBackup(commonRules,accountId);
            mtDto.setBackup(backup);
            return accountId;
        }

        // 供应商有多个的话，则根据权重随机获取
        Map<Integer, Integer> acountIdLevelMap = new HashMap<>(5);
        commonRules.forEach(e->{
            acountIdLevelMap.put(e.getAccountId(), e.getLevel());
        });

        //设置backup队列
        int accountId=getAccountIdRandomly(acountIdLevelMap);
        Queue<Integer> backup = chooseCommonBackup(commonRules,accountId);
        mtDto.setBackup(backup);
        return accountId;
    }

    /**
     * desc:选择 common backup队列
     * @param commonMatchRuleCos
     * @param usedAccountId
     * @return
     */
    public  Queue<Integer> chooseCommonBackup(List<CommonMatchRuleCo> commonMatchRuleCos, int usedAccountId){
        //初始化back队列
        List<Integer> backupList=commonMatchRuleCos.stream().filter(e->e.getAccountId()!=usedAccountId)
                .map(e->e.getAccountId())
                .collect(Collectors.toList());
        return new ArrayDeque<>(backupList);
    }

    /**
     * desc:选择extra backup队列
     * @param supplierRuleMatchInfos
     * @param usedAccountId
     * @return
     */
    public  Queue<Integer> chooseExtraBackup(List<SupplierRuleMatchInfo> supplierRuleMatchInfos, int usedAccountId){
        //初始化back队列
        List<Integer> backupList=supplierRuleMatchInfos.stream().filter(e->e.getAccountId()!=usedAccountId)
                .map(e->e.getAccountId())
                .collect(Collectors.toList());
        return new ArrayDeque<>(backupList);
    }

    /**
     * 通过额外的规则名称获取选择供应商账号
     * @param extraRuleName 匹配规则名称
     * @return int
     */
    private int chooseAccountIdFromExtraRule(String extraRuleName,MtDto mtDto) {
        if (!ruleCache.containsExtraRuleKey(extraRuleName)) {
            //匹配不到供应商
            return 0;
        }

        List<SupplierRuleMatchInfo> extraRules = ruleCache.getExtraRules(extraRuleName);
        // 如果最后筛选的供应商仅有一个，则直接返回这个供应商名称
        if (CollectionUtils.isEmpty(extraRules)) {
            return 0;
        }
        if (extraRules.size() < RANDOM_SELECT_LIMIT) {
            //设置backup
            int accountId=extraRules.get(0).getAccountId();
            Queue<Integer> backup=chooseExtraBackup(extraRules,accountId);
            mtDto.setBackup(backup);
            return accountId;
        }

        // 供应商有多个的话，则根据权重随机获取
        Map<Integer, Integer> supplierLevelMap = new HashMap<>(4);
        extraRules.forEach(e->{
            supplierLevelMap.put(e.getAccountId(), e.getLevel());
        });

        //设置backup
        int accountId = getAccountIdRandomly(supplierLevelMap);
        Queue<Integer> backup=chooseExtraBackup(extraRules,accountId);
        mtDto.setBackup(backup);
        return accountId;
    }



    /**
     * 通过反射方法获取选择供应商账号.
     * 遍历所有的特殊的匹配规则名称，规则名称的list按优先级高到低排列，
     * 如果由于短信的特性匹配到了某个特殊的规则，找该对应的特殊规则的映射的供应商，供应商按照权重进行随机获取
     * @param mtDto the mt dto
     * @return int
     */
    private int chooseAcountIdFromAllExtraRules(MtDto mtDto) {
        int accountId = 0;
        if (CollectionUtils.isNotEmpty(ruleCache.getAllExtraSignNames())) {
            for (String ruleName : ruleCache.getAllExtraSignNames()) {
                try {
                    // 调用
                    Method func = this.getClass().getDeclaredMethod(ruleName, MtDto.class);
                    if ((Boolean) func.invoke(this, mtDto)) {
                        accountId = chooseAccountIdFromExtraRule(ruleName,mtDto);
                        // 匹配到规则的话，则更新下mtDto的字段
                        if (accountId>0) {
                            mtDto.setSign(ruleName);
                        }
                        break;
                    }
                } catch (Exception exception) {
                    log.error("反射方法调用失败" + ruleName, exception);
                }
            }
        }

        return accountId;
    }

    /**
     * 租车催款短信规则匹配.
     *
     * 规则背景：下面短信文案原先走百唔供应商，不给发，需要上层传特殊标识，底层识别到走别的可以发的供应商渠道
     * 对接方: 产品郑美琦
     * 隐患：可能发送延迟慢甚至发不出去
     * 文案：
     * 1.【租租车】您的新西兰租车订单79807914有一笔额外费用账单需支付￥1（含儿童座椅），请点击 http://l.zuzuche.com/72IVt4 查看详细内容并支付，最迟支付日为2018年08月07日，过期将会影响您的芝麻信用积累，感谢您的支持
     *
     */
     private boolean carExtraPayPressInnerMatch(MtDto mtDto) {
        return mtDto.getSignType() == 1
                && mtDto.getRegionType() == SmsRegionType.国内.code()
                && (mtDto.getType() == SmsType.普通通知.getCode() || mtDto.getType() == SmsType.验证码.getCode())
                && StringUtil.isNotEmpty(mtDto.getBatch())
                && mtDto.getBatch().equals(Md5Util.string2MD5(CAR_PAY_BATCH_SIGN));

    }

}
