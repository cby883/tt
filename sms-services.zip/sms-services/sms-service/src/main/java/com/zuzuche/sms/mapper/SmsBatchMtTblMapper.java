package com.zuzuche.sms.mapper;

import com.zuzuche.commons.mybatis.BaseMapper;
import com.zuzuche.sms.entity.SmsBatchMtTbl;
import org.springframework.stereotype.Repository;

@Repository
public interface SmsBatchMtTblMapper extends BaseMapper<SmsBatchMtTbl> {
}