package com.zuzuche.sms.report.syn;

import com.zuzuche.commons.base.util.BeanConverter;
import com.zuzuche.commons.base.util.StringUtil;
import com.zuzuche.kafka.sentry.EventDto;
import com.zuzuche.kafka.sentry.SentryReport;
import com.zuzuche.sms.cache.ProviderAccountCache;
import com.zuzuche.sms.common.utils.DateUtil;
import com.zuzuche.sms.common.utils.TimeUtil;
import com.zuzuche.sms.dto.StatusReportDto;
import com.zuzuche.sms.entity.ProviderAccountInfo;
import com.zuzuche.sms.entity.SmsInbound;
import com.zuzuche.sms.entity.StatusReport;
import com.zuzuche.sms.mapper.SmsInboundMapper;
import com.zuzuche.sms.mapper.StatusReportMapper;
import com.zuzuche.sms.service.KafkaService;
import com.zuzuche.sms.service.StatusReportService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * @desc: 抽象同步服务类 从供应商同步数据
 * @author: panqiong
 * @date: 2018/11/7
 */
@Slf4j
public abstract class AbstractSynService implements SynService{

    @Autowired
    StatusReportMapper statusReportMapper;

    @Autowired
    StatusReportService statusReportService;

    @Autowired
    SmsInboundMapper smsInboundMapper;

    @Autowired
    SentryReport sentryReport;

    @Autowired
    KafkaService kafkaService;

    @Override
    public void synStatusReport(int providerId){
        // 查询有效账号列表
        List<ProviderAccountInfo> accountList = ProviderAccountCache.getListByProviderId(providerId);

        if(CollectionUtils.isEmpty(accountList)){
            log.warn("[AbstractSynService] providerId:"+providerId+" 没有任何有效账户,本次job执行终止");
            return;
        }

        accountList.stream().forEach(account->{
            try{

                List<StatusReport> list = doInvokeStatusReportApi(account);

                // 埋点预警系统
                toSentry(providerId, list);

                statusReportService.pushToReportKafka(list);

            }catch (Exception e){
                log.error("[synStatusReport]拉取状态报告处理异常:accountName:"+account.getAccountName(),e.getMessage(),e);
            }


        });
    }

    private void toSentry(int providerId, List<StatusReport> list) {
        try{
            if(list==null){
                return;
            }
            list.stream().forEach(e->{
                long reciveTime = Instant.now().toEpochMilli();
                if(StringUtil.isNotEmpty(e.getRecvTime())&&!"null".equals(e.getRecvTime())){
                    if(e.getRecvTime().contains("T")&&e.getRecvTime().contains("Z")){
                        reciveTime = LocalDateTime.parse(e.getRecvTime(), DateTimeFormatter.ofPattern(DateUtil.PATTERN_UTC))
                                .toInstant(ZoneOffset.of("+8")).toEpochMilli();
                    }else{
                        reciveTime = LocalDateTime.parse(e.getRecvTime(), DateTimeFormatter.ofPattern(DateUtil.PATTERN_1))
                                .toInstant(ZoneOffset.of("+8")).toEpochMilli();
                    }

                }else{
                    log.error("[状态报告返回的接收时间为空:]"+e.toString());
                }
                EventDto eventDto = EventDto.builder()
                        .metric("sms_status_report_total")
                        .time(reciveTime)
                        .addLabel("status", e.getStatus())
                        .addLabel("providerId", String.valueOf(providerId))
                        .value(1)
                        .build();
                sentryReport.incrCounter(eventDto);
            });
        }catch (Exception e){
            log.error("[状态报告预警埋点异常]",e.getMessage(),e);
        }

    }

    /**
     * 调用状态报告接口
     * @param account
     * @return
     */
    protected abstract List<StatusReport> doInvokeStatusReportApi(ProviderAccountInfo account);

    @Override
    public void synInboundSms(int providerId){
        // 查询有效账号列表
        List<ProviderAccountInfo> accountList = ProviderAccountCache.getListByProviderId(providerId);

        if(CollectionUtils.isEmpty(accountList)){
            log.warn("[JuchnInboundJob] providerId:"+providerId+" 没有任何有效账户,本次job执行终止");
            return;
        }
        accountList.stream().forEach(account->{
            try{
                List<SmsInbound> list = doInvokeInboundApi(account);

                if(CollectionUtils.isNotEmpty(list)){
                    smsInboundMapper.insertList(list);
                }

            }catch (Exception e){
                log.error("[synInboundSms]拉取上行短信异常:accountName:"+account.getAccountName(),e.getMessage(),e);
            }
        });
    }

    /**
     * 调用上行短信接口
     * @param account
     * @return
     */
    protected abstract List<SmsInbound>  doInvokeInboundApi(ProviderAccountInfo account);


}
