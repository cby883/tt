package com.zuzuche.sms.filter.dispatch;

import com.google.common.base.Joiner;
import com.google.common.base.Splitter;
import com.zuzuche.commons.base.util.StringUtil;
import com.zuzuche.sms.common.constant.Constants;
import com.zuzuche.sms.common.enums.FilterTypes;
import com.zuzuche.sms.common.enums.SmsRegionType;
import com.zuzuche.sms.dto.FilterMtDto;
import com.zuzuche.sms.dto.MtDto;
import com.zuzuche.sms.filter.MtFilter;
import com.zuzuche.sms.service.KafkaService;
import com.zuzuche.sms.service.SmsMtService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * 功能：过滤格式不正确的手机.
 * 详细：
 *
 * @author Created on 2019.02.29 by chaodian
 */
@Component
@Slf4j
@Order(2)
public class ErrFormatMobileFilter implements MtFilter {
    /**
     * The Kafka service.
     */
    @Autowired
    KafkaService kafkaService;

    /**
     * The Sms mt service.
     */
    @Autowired
    SmsMtService smsMtService;

    @Override
    public boolean doFilter(MtDto mtDto) {
        List<String> mobileList = Splitter.on(",").splitToList(mtDto.getMobiles());

        // 格式校验
        String mobileFormatPreg = mtDto.getRegionType() == SmsRegionType.国内.code() ?
                Constants.INNER_MOBILE_FORMAT_PREG : Constants.INTER_MOBILE_FORMAT_PREG;

        // 获取正则匹配正确的手机和错误的手机
        List<String> rightMobileList = new LinkedList<>();
        List<String> wrongMobileList = new LinkedList<>();
        mobileList.forEach(e->{
            if (e.matches(mobileFormatPreg)) {
                rightMobileList.add(formatMobile(e, mtDto.getRegionType()));
            } else {
                wrongMobileList.add(e);
            }
        });


        // 错误的手机则丢入过滤器队列，由监听器消费录入错误log
        if (CollectionUtils.isNotEmpty(wrongMobileList)) {
            int errorCode = mtDto.getRegionType() == SmsRegionType.国内.code() ?
                    FilterTypes.错误格式国内号码过滤器.code() : FilterTypes.错误格式国际号码过滤器.code();
            FilterMtDto filterMtDto = FilterMtDto.builder()
                    .content(mtDto.getContent())
                    .errorCode(errorCode)
                    .mobileList(wrongMobileList)
                    .build();
            kafkaService.sendToFilterTopic(filterMtDto);
        }

        return smsMtService.resetMtMobiles(mtDto, rightMobileList);
    }

    /**
     * 格式化手机.
     *
     * 1. 国内手机去除前缀0、00和86
     * 2. 国际手机去除前缀0和00
     *
     * @param mobile 手机号
     * @param regionType 国内/国际类型
     * @return
     */
    private String formatMobile(String mobile, int regionType) {
        if (regionType == SmsRegionType.国内.code()) {
            return removeInnerMobAreaCode(removeMobilePrefix(mobile));
        } else {
            return removeMobilePrefix(mobile);
        }
    }

    /**
     * 去除国内手机号区号前缀86
     *
     * @param mobile the mobile
     * @return string
     */
    private String removeInnerMobAreaCode(String mobile) {
        return mobile.replaceFirst(Constants.INNER_MOBILE_AREA_CODE_PREG, "");
    }

    /**
     * 去除手机前缀0
     * @param mobile the mobile
     * @return string
     */
    private String removeMobilePrefix(String mobile) {
        return mobile.replaceFirst(Constants.MOBILE_PREFIX_PREG, "");
    }

}
