package com.zuzuche.sms.listener.inner;

import com.google.common.util.concurrent.RateLimiter;
import com.zuzuche.commons.base.util.StringUtil;
import com.zuzuche.sms.cache.SmsConfigCache;
import com.zuzuche.sms.common.enums.RateLimiterKeyTypes;
import com.zuzuche.sms.dto.SmsDto;
import com.zuzuche.sms.service.KafkaService;
import com.zuzuche.sms.service.RetryingSmsService;
import com.zuzuche.sms.service.SmsMtService;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

/**
 * 功能：供应商重试短信处理.
 * 详细：
 *
 * @author Created on 2019.07.30 by chaodian
 */
@Component
@Slf4j
public class RetryingSmsListener {

    private static String RATE_KEY = "retrying_sms_topic_rate";
    /**
     * 消费限速
     */
    private static RateLimiter rateLimiter;

    @Value("${retrying.strategy}")
    private String retryingStrategy;

    private static final String RETRYING_SIGN = "retrying_sign";
    private static final String RETRYING_CONFIG = "retrying_config";
    @Autowired
    SmsConfigCache configCache;

    @Autowired
    RetryingSmsService retryingSmsService;

    @Autowired
    SmsMtService smsMtService;

    @Autowired
    SmsConfigCache smsConfigCache;

    /**
     * 注意:
     * - 如果消息处理超时,spring默认最多会重新处理三次
     * - 发生异常要预警,把处理失败的消息转发到dlq队列
     * - 优雅退出应用,不然会可能丢失消息未处理
     * 重复短信处理,这些消息是由 filters 送进去的
     *
     * @param consumer
     */
    @KafkaListener(topics = KafkaService.RETRYING_SMS_TOPIC)
    public void consume(ConsumerRecord<String, SmsDto> consumer) {
        //限速
        RateLimiter rateLimiter = smsConfigCache.getLimiter(RateLimiterKeyTypes.RETRYING_SMS_TOPIC_RATE);
        rateLimiter.acquire();

        log.info("[receive retrying_sms_topic]:" + consumer.value());
        SmsDto smsDto = consumer.value();

        // 先获取没被改变前的供应商账户id，即重试前的供应商账户id，以便入库做日志记录
        int accountId = smsDto.getAccountId();
        // 先将retryNo+1，表示当前准备第几次重试
        int retryNo = smsDto.getRetryNo() + 1;
        smsDto.setRetryNo(retryNo);
        // 第1次重试，则设置下这条短信的最初的accountId
        if (retryNo == 1) {
            smsDto.setParentAccountId(smsDto.getAccountId());
        }
        // 获取重试挑选到的供应商账户id
        int nextAccountId = accountId;

        //选择重试策略 和重试得accountId
        if (StringUtil.isNotBlank(retryingStrategy)) {
            if (retryingStrategy.equalsIgnoreCase(RETRYING_SIGN)) {
                nextAccountId = retryingSmsService.getNextAccountId(smsDto);
            } else if (retryingStrategy.equalsIgnoreCase(RETRYING_CONFIG)) {
                nextAccountId = retryingSmsService.getNextAccountIdStrategy2(accountId, retryNo);
            }
        }


        smsDto.setAccountId(nextAccountId);
        smsMtService.pushSmsIntoSupplierQueue(smsDto);
        retryingSmsService.saveToRetryLogDb(accountId, nextAccountId, smsDto);
    }

}
