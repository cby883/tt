package com.zuzuche.sms.service;


import com.zuzuche.sms.cache.AccountIdBakPolicyCache;
import com.zuzuche.sms.cache.ProviderAccountCache;
import com.zuzuche.sms.dto.SmsDto;
import com.zuzuche.sms.entity.ProviderAccountInfo;
import com.zuzuche.sms.entity.SmsOutboundRetryLog;
import com.zuzuche.sms.mapper.SmsOutboundRetryLogMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;


/**
 * 功能：短信重试服务层.
 * 详细：
 *
 * @author Created on 2019.07.30 by chaodian
 */
@Slf4j
@Service
public class RetryingSmsService {
    /**
     * The Account id bak relate cache.
     */
    @Autowired
    AccountIdBakPolicyCache accountIdBakPolicyCache;

    /**
     * The Provider account cache.
     */
    @Autowired
    ProviderAccountCache providerAccountCache;

    /**
     * The Sms outbound retry log mapper.
     */
    @Autowired
    SmsOutboundRetryLogMapper smsOutboundRetryLogMapper;

    @Autowired
    SmsMtService smsMtService;

    /**
     * 最大的重试次数为2
     */
    public static final int MAX_RETRY_NO = 2;


    /**
     * 根据某个供应商id获取下一次重试所选中的供应商id..
     *
     * @param smsDto     当前要进行第几次重试
     * @return int
     */
    public int getNextAccountId(SmsDto smsDto) {
        //初始化
        Queue<Integer> backup = smsDto.getBackup();
        if(backup==null){
            return smsDto.getParentAccountId();
        }
        // 极端情况，如果是第0次重试，那么下一个供应商账户id还是原来accountId
        if (smsDto.getRetryNo() <= 0) {
            return smsDto.getParentAccountId();
        }

        //从backup中抽取任意一个备份accountId
        Integer nextAccountId=backup.poll();
        //如果重试中没有备份accountId，则直接返回本身
        if(nextAccountId!=null&&nextAccountId>0){
            return nextAccountId;
        }

        return smsDto.getParentAccountId();
    }

    /**
     * 根据某个供应商id获取下一次重试所选中的供应商id..
     *
     * @param parentAccountId 最开始的父accountId，如果为0，表示accountId即为首次发送的id
     * @param retryNo         当前要进行第几次重试
     * @return the next account id
     */
    public int getNextAccountIdStrategy2(int parentAccountId, int retryNo) {
        // 极端情况，如果是第0次重试，那么下一个供应商账户id还是原来accountId
        if (retryNo <= 0) {
            return parentAccountId;
        }

        // 转换一下需要去匹配的这个供应商id，找出这个供应商id的备份供应商信息
        List<Integer> bakAccountIdList = accountIdBakPolicyCache.getBakByAccountId(parentAccountId);

        // 供应商账户的备份供应商信息为空，则仍然返回传入的accountId
        if (bakAccountIdList == null || CollectionUtils.isEmpty(bakAccountIdList)) {
            return parentAccountId;
        }

        // 初始化返回的下一个账户id
        int nextAccountId;

        // 获取这个供应商支持的最大重试次数
        // 当前重试次数大于最大重试次数，则取parentAccountId
        int maxRetryNo = bakAccountIdList.size();
        if (retryNo > maxRetryNo) {
            nextAccountId = parentAccountId;
        } else {
            try {
                nextAccountId = bakAccountIdList.get(retryNo - 1);
            } catch (IndexOutOfBoundsException e) {
                log.error("[重试模块查找备份供应商]parentAccountId"+parentAccountId+", bakList"+bakAccountIdList.toString(), e.getMessage(), e);
                nextAccountId = parentAccountId;
            }
        }

        // 判断一下如果匹配到的下一次供应商账户id不存在，则取检索匹配的parentAccountId
        if (nextAccountId <= 0) {
            nextAccountId = parentAccountId;
        }

        // 再次从供应商账户信息里匹配下，如果匹配的下一个accountId找不到配置信息，则还是返回原来的accountId
        if (!ProviderAccountCache.contains(nextAccountId)) {
            nextAccountId = parentAccountId;
        }

        return nextAccountId;
    }

    /**
     * 将重试到供应商队列的入库作为日志
     *
     * @param accountId     the account id
     * @param nextAccountId the next account id
     * @param smsDto        the sms dto
     */
    public void saveToRetryLogDb(int accountId, int nextAccountId, SmsDto smsDto) {
        SmsOutboundRetryLog log = SmsOutboundRetryLog.builder()
                .accountId((short) accountId)
                .nextAccountId((short) nextAccountId)
                .retryNo((byte) (smsDto.getRetryNo()-1))
                .respCode(smsDto.getRespCode() != null ? smsDto.getRespCode() : "")
                .batchNo(smsDto.getBatchNo() != null ? smsDto.getBatchNo() : "")
                .taskId(smsDto.getTaskId())
                .build();
        smsOutboundRetryLogMapper.insertSelective(log);
    }
}
