package com.zuzuche.sms.remote.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * respcode
 * 代码	说明
 * 0	提交成功
 * 100	缺少必填参数
 * 101	用户名错误
 * 102	密码错误
 * 103	手机号码超限（非审核短信单批小于5000，审核短信单批小于50000）
 * 104	内容长度超限（单条内容最多支持536）
 * 105	余额不足
 * 107	IP地址校验错误（提交短信IP地址与绑定IP地址不一致）
 * 109	签名错误
 * 110	关键字错误
 * 113	合批ID长度超过限制或含有非数字
 * 114	扩展码错误（非数字或超过限制）
 * 115	发送时间格式错误
 * 116	无效的手机号
 * 117	账号被禁用
 * 118	没有检测到有效条数
 * 119	无效的一对一JSON格式
 * 120	获取CRM客户信息错误
 * 121	内容包含乱码字符
 * 200	系统其他错误
 * 注：若响应状态码为 120、200请联系技术支持；
 *
 * @desc:
 * @author: panqiong
 * @date: 2018/10/17
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ShortMessageDto {
    /**
     * 短信提交成功后返回的批次号
     */
    private String batchno;

    /**
     * 短信提交响应状态码
     *
     */
    private String respcode;

    /**
     * 短信提交响应状态码说明
     */
    private String respdesc;

    /**
     * 日志id
     */
    private String logid;


}
