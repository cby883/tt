package com.zuzuche.sms.vo;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 功能：供应商与规则匹配信息.
 * 详细：
 *
 * @author Created on 2019.03.11 by chaodian
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SupplierRuleMatchInfo {
    /**
     * 规则标识英文名
     */
    private String sign;

    /**
     * 供应商
     */
    private String supplier;

    /**
     * 供应商账户
     */
    private int accountId;

    /**
     * 权重/优先级
     */
    private int level;
}
