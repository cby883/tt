package com.zuzuche.sms.task;

import com.zuzuche.sms.cache.ProviderAccountCache;
import com.zuzuche.sms.dto.InvokeResultDto;
import com.zuzuche.sms.dto.SmsDto;
import com.zuzuche.sms.entity.ProviderAccountInfo;
import com.zuzuche.sms.remote.AliYunPushApi;
import com.zuzuche.sms.remote.dto.AliYunSmsSendDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.time.Instant;


/**
 * @desc: 阿里云发送短信任务
 *        原型模式
 * @author: bingyi
 * @date: 2019/08/09
 */
@Slf4j
@Component
@Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class AliYunSendTask extends AbstractSendTask{

    @Autowired
    AliYunPushApi aliYunPushApi;

    AliYunSendTask(SmsDto sms) {
        super(sms);
    }


    /**
     * 过滤器链
     */
    @Override
    public boolean beforeSend(SmsDto sms) {
        return super.beforeSend( sms);
    }

    /**
     * 发送给供应商
     */
    @Override
    public InvokeResultDto invokeApi(SmsDto sms) {

        ProviderAccountInfo account = ProviderAccountCache.getAccountById(sms.getAccountId());

         // 调用推送接口
        AliYunSmsSendDto result = aliYunPushApi.aLiYunSend(sms);

         // 封装返回对象
        InvokeResultDto resultDto = InvokeResultDto.builder()
                 // 用bizId记录批次号
                .bachNo(result.getBizId())
                .extra(result.getBizId())
                .respCode(result.getCode())
                .taskId(sms.getTaskId())
                .mobiles(sms.getMobile())
                .md5Content(sms.getMd5Content())
                .timestamp(Instant.now().toEpochMilli())
                .providerId(account.getProviderId())
                .build();

         return resultDto;

    }

}
