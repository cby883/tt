package com.zuzuche.sms.service;

import com.google.common.base.Joiner;
import com.zuzuche.sms.common.constant.Constants;
import com.zuzuche.sms.common.utils.Md5Util;
import com.zuzuche.sms.dto.BlockedSmsDto;
import com.zuzuche.sms.entity.SmsBlockedLog;
import com.zuzuche.sms.mapper.SmsBlockedLogMapper;
import com.zuzuche.sms.mapper.SmsOutboundMapper;
import com.zuzuche.sms.remote.CallBackBusiApi;
import com.zuzuche.sms.remote.param.NotifyBlockMobilesParam;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * @desc: 被拦截掉的短信处理
 * @author: panqiong
 * @date: 2018/10/29
 */
@Service
@Slf4j
public class BlockSmsService {

    @Autowired
    SmsBlockedLogMapper smsBlockedLogMapper;


    @Autowired
    CallBackBusiApi smsbusiRemote;

    @Autowired
    SmsOutboundMapper smsOutboundMapper;

    @Autowired
    SmsMtService smsMtService;


    /**
     * 被拦截短信的处理
     * 1.插入短信拦截日志表 sms_blocked_log
     * 2.更新下行短信表 发送状态 sms_outbound
     * 3.回调上游短信业务服务 告知拦截的号码详细情况
     * @param blockSms
     */
    public void process(BlockedSmsDto blockSms){
        Set<String> mobileList = blockSms.getMobileList();
        try{
            String taskId = blockSms.getTaskId();
            String filterCode = blockSms.getFilterType().code();
            // 存库
            List<SmsBlockedLog> logList = mobileList.parallelStream().map(mobile->
                    SmsBlockedLog.builder()
                            .blockFilter(filterCode)
                            .createTime(LocalDateTime.now())
                            .phone(mobile)
                            .taskId(taskId)
                            .build()
            ).collect(Collectors.toList());

            // 短信拦截日志
            smsBlockedLogMapper.insertList(logList);

            // 下行表也更新一下 会产生覆盖问题  所以不再更新
//            mobileList.parallelStream().forEach(mobile->{
//
//                smsOutboundMapper.updateResultByTaskId( "", "-2", filterCode, taskId,LocalDateTime.now());
//
//            });


        }catch (Exception e){
            log.error("[BlockedSmsListener]:入库出现异常 ",e.getMessage(),e);
        }

        // 手机号不为空，并且过滤的类型为重复短信过滤，则同时更新mt表的推送状态为重复推送
        if (CollectionUtils.isNotEmpty(mobileList) &&
                blockSms.getFilterType().equals(Constants.FilterTypes.重复短信过滤器)
        ) {
            smsMtService.updateRepeatMobilesStatus(Integer.parseInt(blockSms.getTaskId()), mobileList);
        }
    }
}
