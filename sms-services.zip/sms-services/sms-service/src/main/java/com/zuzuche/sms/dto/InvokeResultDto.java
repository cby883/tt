package com.zuzuche.sms.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

/**
 * @desc: 调用供应商推送接口 结果
 * @author: panqiong
 * @date: 2018/10/27
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class InvokeResultDto {

    private String taskId;
    private String respCode;
    private String bachNo;
    private String extra;
    private String mobiles;
    private String md5Content;
    private long timestamp;
    private int providerId;

    /**
     * 新的被更新到的供应商账户id，为0表示不用更新
     */
    private int updatedAccountId = 0;

}
