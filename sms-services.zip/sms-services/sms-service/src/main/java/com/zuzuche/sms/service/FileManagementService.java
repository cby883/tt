package com.zuzuche.sms.service;

import com.google.common.base.Joiner;
import com.google.common.util.concurrent.RateLimiter;
import com.zuzuche.commons.base.resp.RespResult;
import com.zuzuche.commons.base.resp.Status;
import com.zuzuche.commons.base.resp.StatusServiceCnException;
import com.zuzuche.commons.base.util.JsonUtil;
import com.zuzuche.commons.base.util.StringUtil;
import com.zuzuche.sms.cache.SmsConfigCache;
import com.zuzuche.sms.common.enums.RateLimiterKeyTypes;
import com.zuzuche.sms.common.enums.SmsFileRecordType;
import com.zuzuche.sms.common.utils.FileDecodingUtils;
import com.zuzuche.sms.entity.SmsFilePhoneList;
import com.zuzuche.sms.entity.SmsUploadFileLog;
import com.zuzuche.sms.mapper.SmsFilePhoneListMapper;
import com.zuzuche.sms.mapper.SmsUploadFileLogMapper;
import com.zuzuche.sms.rest.request.FileUploadReq;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.apache.http.util.EncodingUtils;
import org.aspectj.util.FileUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.*;
import java.nio.charset.Charset;
import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * desc:文件上传、导数据模块
 *
 * @author bingyi
 * @date 2016/10/31
 */
@Slf4j
@Service
public class FileManagementService {

    private static final String contentType = "text/csv";

    @Autowired
    SmsUploadFileLogMapper smsUploadFileLogMapper;

    @Autowired
    SmsFilePhoneListMapper smsFilePhoneListMapper;

    private static final String PHONE_HEADER = "mobile";

    private static final int TOTAL = 200;

    @Autowired
    SmsConfigCache smsConfigCache;
    /**
     * 国际号码、国内号码
     */
    private static final String REGEX = "(\\d+)|(\\d+-\\d+)";

    @Value("${file.saveUrl}")
    String fileUrl;

    /**
     * 默认一次读入64k数据到内存
     */
    private final static Integer BUFF_BYTES = 64 * 1024;

    /**
     * 上传文件
     *
     * @param req
     * @return
     */
    public SmsUploadFileLog upload(FileUploadReq req) {
        try {
            //转存文件
            MultipartFile multipartFile = req.getFile();

            boolean isCsv = (multipartFile != null
                    && !multipartFile.isEmpty()
                    && multipartFile.getContentType().equalsIgnoreCase(contentType));
            if (isCsv) {
                //解析文件属性
                String originName = multipartFile.getOriginalFilename();
                //后缀名
                String suffix = originName.substring(originName.lastIndexOf("."));

                //文件名
                String fileName = originName.substring(0, originName.lastIndexOf(".")).trim();
                //文件大小
                long fileSize = multipartFile.getSize();
                //存储的文件名
                String saveName = fileName + UUID.randomUUID().toString() + suffix;
                //存储的路径
                String saveUrl = fileUrl;
                //创建文件目录
                File file = new File(saveUrl);
                if (!file.exists()) {
                    file.mkdirs();
                }
                //创建保存文件
                File saveFile = new File(saveUrl + saveName);
                try (BufferedInputStream in = new BufferedInputStream(multipartFile.getInputStream());
                     FileOutputStream out = new FileOutputStream(saveFile)) {
                    //导入数据，每次导入64k
                    byte[] buffTem = new byte[BUFF_BYTES];
                    int len = 0;
                    //循环读取文件流
                    while ((len = in.read(buffTem)) != -1) {
                        out.write(buffTem, 0, len);
                    }
                }

                //构造文件记录实体
                SmsUploadFileLog smsUploadFileLog = SmsUploadFileLog.builder()
                        .fileName(fileName)
                        .fileSize(fileSize)
                        .remark(req.getRemark())
                        .saveFileName(saveName)
                        .saveUrl(saveUrl + saveName)
                        .suffix(suffix)
                        .deleted(0)
                        .tab("短信csv文件")
                        .recorded(SmsFileRecordType.SMS_FILE_RECORD_TYPE_FIRST.code())
                        .importPhoneBatch("")
                        .creator(req.getCreator())
                        .fileType(req.getFileType())
                        .uploadTime(LocalDateTime.now())
                        .updatePeople(req.getCreator())
                        .updateTime(LocalDateTime.now())
                        .build();
                //插入文件记录
                SmsUploadFileLog fileLog = insert(smsUploadFileLog);
                if (fileLog == null) {
                    throw new StatusServiceCnException(Status.BUSY, "文件记录保存失败");
                }
                return fileLog;

            }

        } catch (IOException e) {
            log.error("文件上传失败", e.getMessage(), e);
            throw new StatusServiceCnException(Status.BUSY, "上传文件失败");
        }
        throw new StatusServiceCnException(Status.OPERATION_NOT_SUPPORT, "文件不符合格式");
    }

    /**
     * 插入文件记录
     *
     * @param fileLog
     * @return
     */
    private SmsUploadFileLog insert(SmsUploadFileLog fileLog) {
        int count = smsUploadFileLogMapper.insertUseGeneratedKeys(fileLog);
        if (count <= 0) {
            //插入失败，返回null
            return null;
        }
        return fileLog;
    }

    /**
     * desc:根据文件id删除文件
     *
     * @param fileId
     * @return
     */
    public RespResult delFile(String fileId) {
        //验参
        if (StringUtil.isBlank(fileId)) {
            throw new StatusServiceCnException(Status.PARAMS_IS_BLANK);
        }
        //查出文件记录
        SmsUploadFileLog fileLog = smsUploadFileLogMapper.findById(fileId);

        if (fileLog == null || fileLog.getDeleted() == 1) {
            return RespResult.success("文件不存在");
        }

        //删除文件
        try {
            File file = new File(fileLog.getSaveUrl());
            if (file.delete()) {
                //删除文件记录
                smsUploadFileLogMapper.deleteByPrimaryKey(fileLog.getId());
                return RespResult.success("文件删除成功");
            } else {
                //找不到文件
                return RespResult.error("文件不存在");
            }
        } catch (Exception e) {
            log.error("【FileUploadService】文件删除出错", e.getMessage(), e);
        }
        return RespResult.error("文件删除失败");
    }

    /**
     * 查询所有文件
     *
     * @return
     */
    public List<SmsUploadFileLog> search() {
        return smsUploadFileLogMapper.selectAll();
    }

    /**
     * 更新文件记录
     *
     * @param fileLog
     * @return
     */
    public int updateById(SmsUploadFileLog fileLog) {
        return smsUploadFileLogMapper.updateByPrimaryKeySelective(fileLog);
    }

    /**
     * 开始导入文件数据到数据库中
     * ①读取每行文件（包括简单的纯数字正则验证）
     * ②执行200个手机号的整合
     * ③插入记录到数据库
     *
     * @param fileLog
     * @return
     */
    public SmsUploadFileLog importData(SmsUploadFileLog fileLog) {
        try {
            //创建手机缓冲区
            Set<String> phoneList = new HashSet<>(255);
            //创建任务batch
            String batch = UUID.randomUUID().toString();

            //判断文件字符编码
            String fileEncoding = null;
            try (InputStream in =new FileInputStream(fileLog.getSaveUrl());){
                //判断文件字符编码
                fileEncoding = FileDecodingUtils.getFilecharset(in);
            } catch (FileNotFoundException e) {
                log.error("【importDataWithNormal】文件读取编码出错");
                return null;
            } catch (IOException e) {
                log.error("【importDataWithNormal】文件读取编码出错");
                return null;
            }

            //执行行数
            AtomicInteger count = new AtomicInteger(0);
            CSVParser csvParser = null;
            File file = new File(fileLog.getSaveUrl());
            try (InputStreamReader fileReader = new InputStreamReader(new FileInputStream(fileLog.getSaveUrl()), fileEncoding);) {
                csvParser = CSVFormat.DEFAULT.parse(fileReader);
                //迭代，如果文件不存在，则退出
                for (CSVRecord e : csvParser) {
                    //文件存在时，才导入
                    if (file.exists()) {
                        RateLimiter  rateLimiter = smsConfigCache.getLimiter(RateLimiterKeyTypes.SMS_BATCH_IMPORT_FILE_DB_RATE);
                        rateLimiter.acquire();
                        //简单验证是否为纯数字
                        if (e.get(0).matches(REGEX)) {
                            count.incrementAndGet();
                            phoneList.add(e.get(0));
                        }
                        if (phoneList.size() == TOTAL) {
                            String phoneStr = Joiner.on(",").join(phoneList);
                            insertToPhoneLog(String.valueOf(fileLog.getId()), phoneStr, batch);
                            //清空set容器
                            phoneList.clear();
                        }
                    } else {
                        break;
                    }
                }
                //判断数据是否为0
                if (count.get() <= 0) {
                    throw new StatusServiceCnException(Status.BUSY, "文件手机数据读取出错，请重新检查！！！");
                }
                if (phoneList.size() > 0) {
                    //执行完剩余的
                    String phoneStr = Joiner.on(",").join(phoneList);
                    insertToPhoneLog(String.valueOf(fileLog.getId()), phoneStr, batch);
                }
                fileLog.setImportPhoneBatch(batch);
                fileLog.setRecorded(SmsFileRecordType.SMS_FILE_RECORD_TYPE_IS_IMPORT.code());
                fileLog.setSendCount(count.get());
                //如果文件不存在，则返回null
                if (!file.exists()) {
                    return null;
                }
                return fileLog;
            }
        } catch (IOException e) {
            log.error("【文件导入失败】", e.getMessage(), e);
        } catch (Exception ex) {
            log.error("【文件导入失败】", ex.getMessage(), ex);
        }
        return null;
    }

    /**
     * 解析普通短信且带变量文件导入数据库
     *
     * @param fileLog
     * @return
     */
    public SmsUploadFileLog importDataWithNormal(SmsUploadFileLog fileLog) {
        //获取文件
        File file = new File(fileLog.getSaveUrl());
        //创建任务batch
        String batch = UUID.randomUUID().toString();
        //记录执行次数
        AtomicInteger count = new AtomicInteger(0);
        boolean firstRow = true;
        //判断文件字符编码
        String fileEncoding = null;
        try (InputStream in =new FileInputStream(fileLog.getSaveUrl());){
            //判断文件字符编码
            fileEncoding = FileDecodingUtils.getFilecharset(in);
        } catch (FileNotFoundException e) {
            log.error("【importDataWithNormal】文件读取编码出错");
            return null;
        } catch (IOException e) {
            log.error("【importDataWithNormal】文件读取编码出错");
            return null;
        }

        //解析文件
        try (InputStreamReader fileReader = new InputStreamReader(new FileInputStream(fileLog.getSaveUrl()), fileEncoding);) {
            //设置CSV解析器
            CSVParser csvParser = CSVFormat.DEFAULT.parse(fileReader);
            List<String> header = new ArrayList<>(16);
            //记录表头大小
            //迭代行，如果文件不存在，则退出
            for (CSVRecord row : csvParser) {
                //文件存在时，才导入
                if (file.exists()) {
                    //控速
                    RateLimiter rateLimiter = smsConfigCache.getLimiter(RateLimiterKeyTypes.SMS_BATCH_IMPORT_FILE_DB_RATE);
                    rateLimiter.acquire();
                    if (firstRow) {
                        //判断表头是否为空
                        if (row == null) {
                            throw new StatusServiceCnException(Status.PARAMS_FORMAT_ERROR, "表头不存在，请检查数据");
                        }
                        //第一行，设置表头
                        Iterator<String> it = row.iterator();
                        while (it.hasNext()) {
                            header.add(it.next());
                        }
                        firstRow = false;
                    } else {
                        //迭代列
                        Iterator<String> column = row.iterator();
                        //构造变量
                        SmsFilePhoneList smsFilePhoneList = createPhoneLog(batch, column, header);
                        if (smsFilePhoneList != null) {
                            //插入记录
                            int oper = smsFilePhoneListMapper.insert(smsFilePhoneList);
                            if (oper == 1) {
                                count.incrementAndGet();
                            }
                        }
                    }
                }
            }
            //构造文件记录返回
            fileLog.setImportPhoneBatch(batch);
            fileLog.setRecorded(SmsFileRecordType.SMS_FILE_RECORD_TYPE_IS_IMPORT.code());
            fileLog.setSendCount(count.get());
            //如果文件不存在，则返回null
            if (!file.exists()) {
                return null;
            }
            return fileLog;

        } catch (IOException e) {
            log.error("【文件导入失败】", e.getMessage(), e);
        } catch (Exception ex) {
            log.error("【文件导入失败】", ex.getMessage(), ex);
        }
        return null;
    }

    /**
     * 构造变量替换map json
     *
     * @param column
     * @param header
     * @return
     */
    private SmsFilePhoneList createPhoneLog(String batchNo, Iterator<String> column, List<String> header) {
        //简单验证
        if (CollectionUtils.isEmpty(header)) {
            return null;
        }
        Map<String, String> map = new HashMap<>(16);
        SmsFilePhoneList.SmsFilePhoneListBuilder builder = SmsFilePhoneList
                .builder()
                .fileId(batchNo);
        int i = 0;
        String phone = null;
        while (column.hasNext()) {
            //获取表头
            String headerName = null;
            try {
                headerName = header.get(i++);
            } catch (Exception e) {
                log.error("营销短信工具数据导入出错", e.getMessage(), e);
            }
            String content = column.next();
            if (StringUtil.isEmpty(headerName)) {
                break;
            }
            if (headerName.equals(PHONE_HEADER) && content.matches(REGEX)) {
                phone = content;
            } else {
                map.put(headerName, content);
            }
        }
        if (CollectionUtils.isNotEmpty(map.keySet())) {
            try {
                String extraParam = JsonUtil.mapToString(map);
                builder.extraParam(extraParam);
            } catch (Exception e) {
                log.error("批量发送工具变量替换失败", e.getMessage(), e);
                return null;
            }
        }
        //手机号不为空
        if (StringUtil.isNotEmpty(phone)) {
            return builder
                    .phone(phone)
                    .createTime(LocalDateTime.now())
                    .build();
        }
        return null;
    }

    private int insertToPhoneLog(String fileId, String phoneStr, String batch) {
        SmsFilePhoneList smsFilePhoneList = SmsFilePhoneList.builder()
                .fileId(batch)
                .phone(phoneStr)
                .createTime(LocalDateTime.now())
                .build();
        return smsFilePhoneListMapper.insert(smsFilePhoneList);
    }

}
