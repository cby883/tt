package com.zuzuche.sms.remote;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.zuzuche.commons.base.util.JsonUtil;
import com.zuzuche.sms.cache.SmsSignCache;
import com.zuzuche.sms.remote.dto.MiaoxinPushDto;
import com.zuzuche.sms.remote.param.MiaoxinSendParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;

import java.nio.charset.Charset;
import java.util.Arrays;

/**
 * @desc: 阿里云的推送api
 * @author: chenbingyi
 * @date: 2019/8/12
 */
@Service
@Slf4j
public class MiaoXinPushApi extends AbstractHttpInvoke {

    @Value(value = "${provider.miaoxin.pushurl}")
    private String pushurl;
    @Autowired
    SmsSignCache smsSignCache;


    /**
     * 额外的header设置 比如编码
     *
     * @param header
     */
    @Override
    protected void setHeader(HttpHeaders header) {
        header.setAcceptCharset(Arrays.asList(Charset.forName("UTF-8")));
    }


    /**
     * 1、获取签名值
     * 2、调用供应商短信接口
     * 3、封装返回体
     *
     * @param param
     * @return
     */
    @HystrixCommand(groupKey = "miaoXinApiGroup", commandKey = "miaoXinSend")
    public MiaoxinPushDto miaoXinSend(MiaoxinSendParam param) {
        //发送短信
        String result = super.postForm(pushurl, param);
        //转换DTO
        MiaoxinPushDto miaoxinPushDto = JsonUtil.stringToObj(result, MiaoxinPushDto.class);

        return miaoxinPushDto;
    }
}
