package com.zuzuche.sms.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Table;
import java.time.LocalDateTime;


/**
 * @desc 巨辰的上行短信
 * @author panqiong
 * @date 20181019
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "sms_inbound")
public class SmsInbound {

    private int id;

    private String port;

    private String phone;

    private String msg;

    private LocalDateTime createTime;

    private int accountId;


}