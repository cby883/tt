package com.zuzuche.sms.report.callback;

import com.zuzuche.commons.base.util.DateUtils;
import com.zuzuche.commons.base.util.StringUtil;
import com.zuzuche.sms.common.enums.CmStatusReportType;
import com.zuzuche.sms.entity.ProviderAccountInfo;
import com.zuzuche.sms.entity.StatusReport;
import com.zuzuche.sms.rest.request.CmStatusCallbackReq;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * 功能：CM供应商的数据回调服务层.
 * 详细：
 *
 * @author Created on 2019.09.08 by chaodian
 */
@Service("cmCallbackService")
@Slf4j
public class CmCallbackService extends AbstractCallbackService {
    /**
     * 切割CM供应商回馈的短信状态报告的分隔符.
     * 1. 短信发送提交给供应桑接口的批次号格式为自定义的如 126_10064955，即账户Id + _ + taskid
     * 2. 第1步这样做的好处是便于状态报告回调，使用_切割，获取到accountId，能具体定位到是哪个账户id发送的短信
     */
    private static final String STATUS_REPORT_TEXT_SPLIT_SIGN = "_";

    @Override
    protected List<StatusReport> doAnalyzeCallbackStatusReport(ProviderAccountInfo account, Object callbackData) {
        // 先强制转换下类型
        CmStatusCallbackReq req = (CmStatusCallbackReq) callbackData;

        String statusText = buildStatusText(req);
        StatusReport report = StatusReport.builder()
                .batchNo(req.getREFERENCE())
                .createTime(LocalDateTime.now())
                .phone(req.getGSM())
                .recvTime(DateUtils.formatDateStr(req.getDATETIME_S()))
                .status(statusText)
                .accountId(account.getAccountId())
                .build();

        List<StatusReport> statusReportList = new ArrayList<>(2);
        statusReportList.add(report);
        return statusReportList;
    }

    /**
     * 从回调的状态报告再进一步构造信息明确的状态.
     *
     * 1. 如果短信状态报告标识成功，转为DELIVRD
     * 2. 如果短信失败，将状态返回的失败描述尽可能带上入库
     * 3. CM供应商返回短信状态报告比较特殊，一条短信最终发送给用户失败，但是提交给到CM成功，会返回两条状态报告，一条为status为0，切另一条为status为3
     *
     * @param req the req
     * @return string
     */
    private String buildStatusText(CmStatusCallbackReq req) {
        String statusStr;
        if (CmStatusReportType.SEND_SUCCESS.getCode().equals(req.getSTATUS())) {
            statusStr = "DELIVRD";
        } else {
            // 格式可能如:
            // 3_5_Message failed
            statusStr = req.getSTATUS();

            if (StringUtil.isNotBlank(req.getSTATUSDESCRIPTION())) {
                statusStr += "_" + req.getSTATUSDESCRIPTION();
            }

            if (StringUtil.isNotBlank(req.getSTANDARDERRORTEXT())) {
                statusStr += "_" + req.getSTANDARDERRORTEXT();
            }
            log.warn("【CM状态报告发送失败详细信息】发件人消息:{},发送失败详细信息:{}",req.getGSM(),statusStr);
        }


        //大于29个字符，进行截取
        int len = statusStr.length();
        if(len > 29) {
            return statusStr.substring(4,25);
        }

        return statusStr;
    }


    /**
     * 从CM回馈的状态报告的批次号解析获取accountId.
     *
     * @param batchNo the batch no
     * @return the account id by batch no
     */
    public int getAccountIdByBatchNo(String batchNo) {
        int accountId = 0;

        if (batchNo != null) {
            String[] strArr = batchNo.split(STATUS_REPORT_TEXT_SPLIT_SIGN);
            if (strArr.length > 0) {
                try {
                    accountId = Integer.parseInt(strArr[0]);
                } catch (IndexOutOfBoundsException e) {
                    log.error("CM状态报告batchNo解析获取不到accountId");
                } catch (Exception e) {
                    log.error("CM状态报告batchNo解析获取accountId异常", e, e.getMessage());
                }
            }
        }

        return accountId;
    }
}
