package com.zuzuche.sms.common.config;

import com.google.common.base.Splitter;
import com.zuzuche.commons.base.util.StringUtil;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import java.io.IOException;
import java.net.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * desc:代理支持配置类
 *
 * @author bingyi
 * @date 2019/09/04
 */
@Configuration
@Slf4j
public class ProxySelectorConfig extends ProxySelector implements InitializingBean {

    @Value(value = "${okhttp.proxy}")
    private String proxyConfig;
    private String localProxyConfig;
    Map<String, List<Proxy>> proxyMapList;
    /**
     * 系统默认的代理选择器
     */
    private static ProxySelector defaultProxySelector;

    static {
        try {
            Class<?> c = Class.forName("sun.net.spi.DefaultProxySelector");
            if (c != null && ProxySelector.class.isAssignableFrom(c)) {
                @SuppressWarnings("deprecation")
                ProxySelector tmp = (ProxySelector) c.newInstance();
                defaultProxySelector = tmp;
            }
        } catch (Exception e) {
            defaultProxySelector = null;
        }
    }

    @Override
    public List<Proxy> select(URI uri) {
        Map<String, List<Proxy>> tem = convert();
        if (tem != null && !tem.isEmpty()) {
            if (tem.containsKey(uri.toString().trim())) {
                return tem.get(uri.toString().trim());
            }
        }
        //如果匹配不上代理服务器，使用系统默认的方法
        return defaultProxySelector.select(uri);
    }


    @Override
    public void connectFailed(URI uri, SocketAddress sa, IOException ioe) {
        //使用系统默认的处理方法
        defaultProxySelector.connectFailed(uri, sa, ioe);
    }

    public Map<String, List<Proxy>> convert() {
        if (StringUtil.isNotBlank(proxyConfig)) {
            if (isNeedConvert()) {
                List<ProxyJson> arr = formData(proxyConfig);
                Map<String, List<Proxy>> proxyListMaptem = new HashMap<>();
                if (CollectionUtils.isNotEmpty(arr)) {
                    //配置不为空
                    arr.forEach(e -> {
                        if (StringUtil.isNotBlank(e.url.trim()) || StringUtil.isNotBlank(e.proxyIp.trim()) || e.proxyPort > 0) {
                            //判断不为空
                            e.url = e.url.trim();
                            e.proxyIp = e.proxyIp.trim();
                            if (proxyListMaptem.containsKey(e.url)) {
                                proxyListMaptem.get(e.url).add(new Proxy(Proxy.Type.HTTP, new InetSocketAddress(e.proxyIp, e.proxyPort)));
                            } else {
                                //初始化proxyListMap
                                List<Proxy> temProxy = new ArrayList<>();
                                temProxy.add(new Proxy(Proxy.Type.HTTP, new InetSocketAddress(e.proxyIp, e.proxyPort)));
                                proxyListMaptem.put(e.url, temProxy);
                            }
                        }
                    });
                    //为每个map加上直连代理
                    proxyListMaptem.keySet().forEach(e -> {
                        proxyListMaptem.get(e).add(Proxy.NO_PROXY);
                    });
                    proxyMapList = proxyListMaptem;
                }

            }
            return proxyMapList;
        }
        return null;
    }

    private boolean isNeedConvert() {
        if (StringUtil.isBlank(localProxyConfig)) {
            //第一次加载，需要转化
            localProxyConfig = proxyConfig;
            return true;
        }
        if (localProxyConfig.equalsIgnoreCase(proxyConfig)) {
            //如果配置没修改过，则不需要转化
            return false;
        } else {
            localProxyConfig = proxyConfig;
            return true;
        }
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        ProxySelector.setDefault(this);
    }

    @AllArgsConstructor
    @NoArgsConstructor
    @Data
    @Builder
    public static class ProxyJson {
        String url;
        String proxyIp;
        int proxyPort;
    }

    public List<ProxyJson> formData(String json) {
        List<ProxyJson> arr = new ArrayList<>();
        if (StringUtil.isNotBlank(json)) {
            List<String> configList = Splitter.on(",").splitToList(json);
            configList.forEach(e -> {
                e = e.trim();
                List<String> temp = Splitter.on("$$").splitToList(e);
                try {
                    arr.add(ProxyJson.builder().url(temp.get(0)).proxyIp(temp.get(1)).proxyPort(Integer.parseInt(temp.get(2))).build());
                } catch (Exception ex) {
                    log.error("【ProxySelectorConfig】代理配置转换错误：{}", e, ex.getMessage(), e);
                }
            });
        }
        return arr;
    }
}