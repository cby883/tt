package com.zuzuche.sms.service;

import com.google.common.util.concurrent.RateLimiter;
import com.zuzuche.commons.base.constants.BaseEnum;
import com.zuzuche.commons.base.util.JsonUtil;
import com.zuzuche.commons.base.util.StringUtil;
import com.zuzuche.sms.cache.ConfigCache;
import com.zuzuche.sms.cache.SmsConfigCache;
import com.zuzuche.sms.common.enums.RateLimiterKeyTypes;
import com.zuzuche.sms.common.utils.SpringBeanFactory;
import com.zuzuche.sms.dto.RefreshConfigDto;
import com.zuzuche.sms.entity.SmsConfig;
import com.zuzuche.sms.mapper.SmsConfigMapper;
import com.zuzuche.sms.remote.AbstractHttpInvoke;
import com.zuzuche.sms.rest.response.SmsLimiterResp;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @author chenbingyi
 * @desc: 配置刷新
 * @date 2019/09/23
 */
@Service
@Slf4j
public class RefreshConfigService extends AbstractHttpInvoke {

    @Autowired
    SmsConfigMapper smsConfigMapper;

    @Autowired
    SmsConfigCache smsConfigCache;
    /**
     * 刷新配置的接口uri
     */
    private static final String REFRESH_URL = "/smsConfig/refresh/";

    @Autowired
    DiscoveryClient discoveryClient;

    public RefreshConfigDto refresh(String configClassName) {
        //获取主机实例
        String instance = instanceIp();
        //封装返回体
        RefreshConfigDto.RefreshConfigDtoBuilder builder = RefreshConfigDto.builder()
                .configName(configClassName)
                .instanceHostAddress(instance);
        //判空
        if (StringUtil.isBlank(configClassName)) {
            return builder.code(-1).message("配置名称不存在").build();
        }
        ConfigCache configCache;
        //根据配置类，转换成bean
        try {
            configCache = (ConfigCache) SpringBeanFactory.getBean(configClassName);
        } catch (Exception e) {
            log.error("【RefreshConfigService】配置转换出错,配置类名为：{}", configClassName, e.getMessage(), e);
            return builder.code(-1).message("配置转换错误").build();
        }
        //更新配置
        boolean result = false;
        if (configCache != null) {
            result = configCache.refresh();
        }

        if (result) {
            builder.code(0).message("集群实例:" + instance + "  " + configClassName + "刷新成功");
        } else {
            builder.code(-1).message("集群实例:" + instance + "  " + configClassName + "刷新失败");
        }
        //返回
        return builder.build();
    }

    public String instanceIp() {
        try {
            InetAddress inetAddress = InetAddress.getLocalHost();
            return inetAddress.getHostAddress();
        } catch (UnknownHostException e) {
            log.error("【RefreshConfigService】获取节点ip出错", e.getMessage(), e);
            return "未知实例";
        }
    }

    /**
     * desc:多节点刷新配置
     *
     * @param configName the config name
     * @return list
     */
    public synchronized List<RefreshConfigDto> triggerNodeRefresh(String configName) {
        if (StringUtil.isBlank(configName)) {
            return null;
        }
        //获取eureka得节点信息
        List<ServiceInstance> serviceInstances = discoveryClient.getInstances("SMS-SERVICE");
        //拼接get请求路径，发送请求
        List<RefreshConfigDto> resultList = serviceInstances.stream().map(item -> {
            //拼接get请求路径
            String getUrl = item.getUri().toString() + REFRESH_URL + configName;
            // 发起请求 --兼容网络超时错误
            String result;
            try {
                result = super.get(getUrl);
            } catch (Exception e) {
                log.error("{}配置刷新错误", configName, e.getMessage(), e);
                //返回错误信息
                return RefreshConfigDto.builder()
                        .message(e.getMessage())
                        .code(-2)
                        .instanceHostAddress(item.getHost())
                        .configName(configName).build();
            }
            //封装返回体
            return transfer(result,item.getHost());

        }).collect(Collectors.toList());
        return resultList;
    }

    /**
     * desc:转化
     *
     * @param json
     * @return
     */
    public RefreshConfigDto transfer(String json,String host) {
        if (StringUtil.isBlank(json)) {
            return null;
        }
        //初始化
        RefreshConfigDto refreshConfigDto = null;
        try {
            refreshConfigDto = JsonUtil.stringToObj(json, RefreshConfigDto.class);
            refreshConfigDto.setInstanceHostAddress(host);
        } catch (Exception e) {
            log.error("【RefreshConfigService】配置刷新json转化错误", e.getMessage(), e);
        }
        return refreshConfigDto;
    }

    @Override
    protected void setHeader(HttpHeaders header) {

    }

    /**
     * 更新限流器速率值
     *
     * @param rateConfigName
     * @param val
     * @return
     */
    public SmsLimiterResp updateRate(String rateConfigName, int val) {
        //先判断配置名是否存在
        RateLimiterKeyTypes rateLimiterKeyTypes = BaseEnum.parse(RateLimiterKeyTypes.class, rateConfigName);
        if (rateLimiterKeyTypes == null) {
            return SmsLimiterResp.builder()
                    .code(-1)
                    .msg("找不到限流器配置名，请重新输入")
                    .build();
        }
        SmsConfig smsConfig = smsConfigMapper.queryOffset(rateConfigName);
        //先更新数据库
        int count = smsConfigMapper.updateOffset(rateConfigName, val + "", LocalDateTime.now());

        if (count <= 0) {
            return SmsLimiterResp.builder()
                    .code(-2)
                    .msg("配置更新库出错，请重试！！！")
                    .build();
        }
        //更新缓存
        List<RefreshConfigDto> result = triggerNodeRefresh("SmsConfigCache");

        //构造返回体
        SmsLimiterResp.SmsLimiterRespBuilder builder = SmsLimiterResp.builder()
                .code(0)
                .msg("更新成功")
                .currentVal(val)
                .originVal(smsConfig.getConfigValue());

        result.forEach(e -> {
            if (e.getCode() != 0) {
                builder.code(-3);
                builder.msg("当前节点更新成功，集群更新失败,请重试");
            }
        });
        return builder.build();
    }

    /**
     * 获取所有的限流器
     *
     * @return
     */
    public List<SmsConfig> getAllRate() {
        List<SmsConfig> list = new ArrayList<>(16);
        Map<String, RateLimiter> limiterMap = smsConfigCache.getLimiterMap();
        limiterMap.keySet().forEach(e -> {
            RateLimiterKeyTypes rateLimiterKeyTypes = BaseEnum.parse(RateLimiterKeyTypes.class, e);
            if (rateLimiterKeyTypes != null) {
                SmsConfig smsConfig = SmsConfig.builder()
                        .configKey(e)
                        .configValue(limiterMap.get(e).getRate() + "")
                        .remark(rateLimiterKeyTypes.desc())
                        .build();
                list.add(smsConfig);
            }
        });
        return list;
    }
}
