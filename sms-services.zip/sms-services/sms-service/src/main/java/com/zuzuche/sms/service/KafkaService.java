package com.zuzuche.sms.service;

import com.google.common.base.Splitter;
import com.zuzuche.kafka.message.BaseMessage;
import com.zuzuche.kafka.sentry.SentryReport;
import com.zuzuche.sms.common.enums.FilterTypes;
import com.zuzuche.sms.dto.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Service;
import org.springframework.util.concurrent.ListenableFuture;

import java.time.Instant;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * @desc: kafka相关处理
 * @author: panqiong
 * @date: 2018/10/25
 */
@Service
@Slf4j
public class KafkaService {

    /**
     * 状态报告更新队列
     */
    public static final String STATUS_REPORT_TOPIC_NAME="sms_status_report_cycle_topic";
    /**
     * 通用下行队列,保留,暂未启用
     */
    public static final String SMS_OUTBOUND_TOPIC = "sms_outbound_topic";

    /**
     * 百唔短信队列
     */
    public static final String BAIWU_SMS_OUTBOUND_TOPIC = "baiwu_sms_outbound_topic";

    /**
     * 巨辰短信队列
     */
    public static final String JUCHN_SMS_OUTBOUND_TOPIC = "juchn_sms_outbound_topic";

    /**
     * 秒信短信队列
     */
    public static final String MIAOXIN_SMS_OUTBOUND_TOPIC = "miaoxin_sms_outbound_topic";

    /**
     * 卓越恒信短信队列
     */
    public static final String HENGXIN_SMS_OUTBOUND_TOPIC = "hengxin_sms_outbound_topic";

    /**
     * CM供应商短信队列
     */
    public static final String CM_SMS_OUTBOUND_TOPIC = "cm_sms_outbound_topic";

    /**
     * 创蓝短信队列
     */
    public static final String CHLAN_SMS_OUTBOUND_TOPIC = "chlan_sms_outbound_topic";

    /**
     * 阿里云短信队列
     */
    public static final String ALIYUN_SMS_OUTBOUND_TOPIC = "aliyun_sms_outbound_topic";

    public static final String TELESIGN_SMS_OUTBOUND_TOPIC="teleSign_outbound_topic_rate";
    /**
     * 死信队列 保存发送失败的消息
     */
    public static final String DLQ_TOPIC = "sms_outbound_dlq";
    /**
     * 告警收集队列
     */
    public static final String SOURCE_EVENT_TOPIC= "source_event_topic";
    /**
     * 重复短信队列
     */
    public static final String BLOCKED_SMS_TOPIC= "blocked_sms_topic";
    /**
     * 发送供应商结果回送队列
     */
    public static final String SEND_RESULT_TOPIC= "send_result_topic";

    /**
     * 普通通知下行短信队列
     */
    public static final String NORMAL_MT_TOPIC = "sms_normal_topic";

    /**
     * 营销通知下行短信队列
     */
    public static final String MARKET_MT_TOPIC = "sms_market_topic";

    public static final String BATCH_MARKET_MT_TOPIC="sms_batch_market_topic";

    /**
     * 验证码通知下行短信队列
     */
    public static final String VERIFY_MT_TOPIC = "sms_verify_topic";

    /**
     * 短信发送拦截过滤队列
     */
    public static final String FILTER_TOPIC = "filter_topic";

    /**
     * 回调推送给交互记录的队列
     */
    public static final String INTERSECTION_TOPIC = "intersection_topic";

    /**
     * 回调推送给总备注的队列
     */
    public static final String REMARK_TOPIC = "remark_topic";

    /**
     * 主站的订单短信日志数据回调
     */
    public static final String ORDER_SMS_LOG_TOPIC = "order_sms_log_topic";


    /**
     * 供应商下发短信重试
     */
    public static final String RETRYING_SMS_TOPIC = "retrying_sms_topic";

    @Autowired
    KafkaTemplate kafkaTemplate;

    @Autowired
    SentryReport sentryReport;



    /**
     * 发送消息到死信队列
     * @param sms
     */
    public void sendToDlq(String sms){
        kafkaTemplate.send(DLQ_TOPIC,sms);
    }

    /**
     * 发送消息到死信队列
     * @param sms
     */
    public void sendToDlq(SmsDto sms){
        kafkaTemplate.send(DLQ_TOPIC,sms);
    }


    /**
     * 发送到重复短信队列
     * 供上游订阅
     */
    public void sendToBlockedTopic(BlockedSmsDto smsDto){

        kafkaTemplate.send(BLOCKED_SMS_TOPIC,smsDto);
    }

    /**
     * 发送到重复短信队列
     * 供上游订阅
     */
    public void sendToResultTopic(InvokeResultDto resultDto){

        kafkaTemplate.send(SEND_RESULT_TOPIC,resultDto);
    }

    /**
     * 发送到拦截过滤队列
     *
     * @param filterMtDto the filter mt dto
     */
    public void sendToFilterTopic(FilterMtDto filterMtDto) {
        kafkaTemplate.send(FILTER_TOPIC, filterMtDto);
    }

    /**
     * 将此次mt的请求都推入到过滤器队列
     * @param mobiles 手机号，多个英文逗号分割
     * @param content 短信内容
     * @param filter 过滤器枚举
     */
    public void sendToFilterTopic(String mobiles, String content, FilterTypes filter) {
        List<String> mobileList = Splitter.on(",").splitToList(mobiles);
        int errorCode = filter.code();
        FilterMtDto filterMtDto = FilterMtDto.builder()
                .content(content)
                .errorCode(errorCode)
                .mobileList(mobileList)
                .build();
        sendToFilterTopic(filterMtDto);
    }

    /**
     * desc:状态报告推送队列
     * @param statusReport
     */
    public void sendToStatusReportKafka(StatusReportDto statusReport) {
        ListenableFuture<SendResult<String, BaseMessage>> future= kafkaTemplate.send(KafkaService.STATUS_REPORT_TOPIC_NAME,statusReport);
        try {
            future.get(5, TimeUnit.SECONDS);
            //log.warn("[synsend推送结果]:"+statusReport.toString());
        } catch (Exception e) {
            log.error("【状态报告推送延时kafka队列异常】状态报告数据为:" + statusReport.toString(), e.getMessage(), e);
        }
    }

    /**
     * 发送到交互记录队里
     *
     * @param intersectionDto the intersection dto
     */
    public void sendToIntersectionTopic(IntersectionDto intersectionDto) {
        kafkaTemplate.send(INTERSECTION_TOPIC, intersectionDto);
    }

    /**
     * 发送到总备注队列.
     *
     * @param mtDto the mt dto
     */
    public void sendToRemarkTopic(MtDto mtDto) {
        kafkaTemplate.send(REMARK_TOPIC, mtDto);
    }

    /**
     * 发送到供应商下发重试队列
     *
     * @param smsDto the sms dto
     */
    public void sendToRetryingSmsTopic(SmsDto smsDto) {
        kafkaTemplate.send(RETRYING_SMS_TOPIC, smsDto);
    }

    /**
     * 发送到订单的短信日志队列
     * @param dto the dto
     */
    public void sendToOrderSmsLogTopic(OrderSmsLogDto dto) {
        kafkaTemplate.send(ORDER_SMS_LOG_TOPIC, dto);
    }

    /**
     * 上报统计
     * @param groupId
     * @param metric
     */
    public void reportToSentry(String groupId,String metric){
        SourceEventDto event = SourceEventDto.builder()
                .groupId(groupId)
                .metric(metric)
                .time(Instant.now().toEpochMilli())
                .value(1)
                .build();
        kafkaTemplate.send(SOURCE_EVENT_TOPIC,event.getGroupId(),event);
    }





}
