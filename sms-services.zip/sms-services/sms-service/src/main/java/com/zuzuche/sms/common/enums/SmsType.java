package com.zuzuche.sms.common.enums;

import com.zuzuche.commons.base.constants.BaseEnum;
import lombok.Getter;

/**
 * 短信类型.
 */
@Getter
public enum SmsType implements BaseEnum<Integer> {
    /**
     * 普通通知 sms type.
     */
    普通通知(1, "sms_normal_topic", 1),
    /**
     * 营销 sms type.
     */
    营销(2, "sms_market_topic", 2),
    /**
     * 验证码 sms type.
     */
    验证码(3, "sms_verify_topic", 1),
    /**
     * 批量营销小工具单独topic
     */
    营销小工具(4,"sms_batch_market_topic",2);

    /**
     * 短信类型值
     */
    private Integer code;

    /**
     * 所属的队列名称
     */
    private String topic;

    /**
     * 对应的供应商短信性质
     */
    private Integer supplierSmsType;

    SmsType(Integer code, String topic, Integer supplierSmsType) {
        this.code = code;
        this.topic = topic;
        this.supplierSmsType = supplierSmsType;
    }

    @Override
    public Integer code() {
        return code;
    }
}