package com.zuzuche.sms.rest.request;


import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;

/**
 * 功能：刷新短信配置的请求信息.
 * 详细：
 *
 * @author Created on 2019.03.18 by chaodian
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ApiModel(value = "刷新短信配置的信息")
public class RefreshSmsMtConfigReq {
    @ApiModelProperty(value = "刷新短信下行配置的名称, blackWhite为黑白名单，safeMonitorRule为安全拦截规则，smsSign为短信签名配置，smsTemplate为短信模板配置，supplierConfig供应商配置, supplierMatchRule为短信供应商匹配规则配置，accountIdBakPolicy为供应商账户备份策略配置",required = true)
    @NotBlank(message = "配置名称不能为空")
    private String configName;
}
