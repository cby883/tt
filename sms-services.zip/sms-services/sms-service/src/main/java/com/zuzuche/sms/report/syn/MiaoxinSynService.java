package com.zuzuche.sms.report.syn;

import com.zuzuche.sms.common.utils.DateUtil;
import com.zuzuche.sms.common.utils.Md5Util;
import com.zuzuche.sms.common.utils.PerformUtil;
import com.zuzuche.sms.common.utils.Sha1Util;
import com.zuzuche.sms.dto.InvokeResultDto;
import com.zuzuche.sms.dto.SmsDto;
import com.zuzuche.sms.entity.ProviderAccountInfo;
import com.zuzuche.sms.entity.SmsInbound;
import com.zuzuche.sms.entity.StatusReport;
import com.zuzuche.sms.remote.JuchnPullApi;
import com.zuzuche.sms.remote.MiaoXinPullApi;
import com.zuzuche.sms.remote.dto.MiaoxinPullReportDto;
import com.zuzuche.sms.remote.dto.MiaoxinPushDto;
import com.zuzuche.sms.remote.dto.PullSmsReportDto;
import com.zuzuche.sms.remote.dto.PullSmsUplinkDto;
import com.zuzuche.sms.remote.param.MiaoxinPullParam;
import com.zuzuche.sms.remote.param.MiaoxinSendParam;
import com.zuzuche.sms.remote.param.PullSmsReportParam;
import com.zuzuche.sms.remote.param.PullSmsUplinkParam;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpServerErrorException;

import java.net.URLEncoder;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @desc: 秒信的短信发送服务类
 * @author: bingyi
 * @date: 2019/12/14
 */
@Service("miaoxinSysService")
@Slf4j
public class MiaoxinSynService extends AbstractSynService {

    @Autowired
    MiaoXinPullApi miaoXinPullApi;

    private static final int SUCCESS = 1;


    @Override
    protected List<StatusReport> doInvokeStatusReportApi(ProviderAccountInfo account) {
        //构造请求参数
        MiaoxinPullParam pullParam = formData(account);
        long start = Instant.now().toEpochMilli();
        MiaoxinPullReportDto dto = miaoXinPullApi.pullSmsReport(pullParam);
        if (log.isDebugEnabled()) {
            log.debug("[response]" + dto.toString());
        }
        long end = Instant.now().toEpochMilli();
        PerformUtil.logTime("miaoXinPullApi.pullSmsReport", start, end);
        if (dto != null && dto.getCode() == 0) {
            if (CollectionUtils.isEmpty(dto.getReports())&&CollectionUtils.isEmpty(dto.getMos())) {
                log.warn("[MiaoxinStatusReportJob]:accountName:" + account.getAccountName() + " 本次拉取List为空");
                return null;
            }
            log.info("[MiaoxinStatusReportJob]:accountName:" + account.getAccountName() + " 拉取到状态记录 " + dto.getReports().size() + " 条");

            List<StatusReport> list = dto.getReports().stream()
                    .map(report ->
                            StatusReport.builder()
                                    .batchNo(report.getRef())
                                    .createTime(LocalDateTime.now())
                                    .phone(report.getMobile())
                                    .recvTime(report.getReceivedTime())
                                    .status(report.getStatus() == SUCCESS ? "DELIVRD" : report.getMsg() + "")
                                    .accountId(account.getAccountId())
                                    .build()
                    ).collect(Collectors.toList());

            //处理上行内容
            doInvokeInbound(dto.getMos(),account.getAccountId());
            return list;
        }
        return null;

    }

    @Override
    protected List<SmsInbound> doInvokeInboundApi(ProviderAccountInfo account) {
        return null;
    }

    /**
     * 处理上行内容
     */
    public void doInvokeInbound(List<MiaoxinPullReportDto.Mos> mosList, int accountId) {
        try {
            if (CollectionUtils.isNotEmpty(mosList)) {
                List<SmsInbound> smsInbounds = mosList.stream().map(e -> {
                    return SmsInbound.builder()
                            .accountId(accountId)
                            .phone(e.getUserMobile())
                            .msg(e.getUserContent())
                            .port(e.getChannelNum())
                            .createTime(LocalDateTime.now())
                            .build();
                }).collect(Collectors.toList());
                if (CollectionUtils.isNotEmpty(smsInbounds)) {
                    smsInboundMapper.insertList(smsInbounds);
                }
            }
        } catch (Exception e) {
            log.error("[synInboundSms]拉取上行短信异常:accountName:" + accountId, e.getMessage(), e);
        }
    }

    /**
     * 封装请求参数
     *
     * @param account
     * @return
     */
    private MiaoxinPullParam formData(ProviderAccountInfo account) {
        try {
            //构造时间
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
            String ts = LocalDateTime.now().format(formatter);
            //构造token 明文
            String tokenStr = new String("account=" + account.getAccountName() + "&ts=" + ts + "&secret=" + account.getAccountPwd());
            //sha1加密token 明文
            String token = Sha1Util.shaEncode(tokenStr);
            MiaoxinPullParam miaoxinPullParam = MiaoxinPullParam.builder()
                    .account(account.getAccountName())
                    .token(token)
                    .ts(ts)
                    .build();
            return miaoxinPullParam;
        } catch (Exception e) {
            log.error("秒信状态报告构造请求参数出错", e.getMessage(), e);
            //统一抛出重试错误
        }
        return null;
    }
}
