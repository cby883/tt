package com.zuzuche.sms.mapper;

import com.zuzuche.commons.mybatis.BaseMapper;
import com.zuzuche.sms.entity.SmsConfig;
import org.apache.ibatis.annotations.Param;

import java.time.LocalDateTime;

/**
 * @desc:
 * @author: panqiong
 * @date: 2018/10/31
 */
public interface SmsConfigMapper extends BaseMapper<SmsConfig> {

    /**
     * 查询
     * @param configKey
     * @return
     */
    SmsConfig queryOffset(@Param("configKey") String configKey);
    /**
     * desc
     * @param configKey
     * @param configValue
     * @param updateTime
     */
    int updateOffset(@Param("configKey") String configKey, @Param("configValue") String configValue, @Param("updateTime") LocalDateTime updateTime);
}
