package com.zuzuche.sms.common.enums;

import com.zuzuche.commons.base.constants.BaseEnum;
import lombok.Getter;

/**
 * 大批量短信发送任务状态枚举类
 */
@Getter
public enum SmsBatchSendTaskType implements BaseEnum<Integer> {
    /**
     * 导入数据中
     */
    SMS_BATCH_SEND_TASK_TYPE_IMPORT_DATA(1,"导入数据中"),
    /**
     * 可以被执行
     */
    SMS_BATCH_SEND_TASK_TYPE_READY(2,"就绪"),
    /**
     * running
     */
    SMS_BATCH_SEND_TASK_TYPE_RUNNING(3,"运行中"),
    /**
     * pause
     */
    SMS_BATCH_SEND_TASK_TYPE_PAUSE(4,"暂停中"),
    /**
     * finished
     */
    SMS_BATCH_SEND_TASK_TYPE_FINISHED(5,"已完成"),
    /**
     * error
     */
    SMS_BATCH_SEND_TASK_TYPE_ERROR(-1,"失败");

    /**
     * 状态code
     */
    private Integer code;

    /**
     * 描述
     */
    private String desc;


    SmsBatchSendTaskType(Integer code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    @Override
    public Integer code() {
        return code;
    }
}