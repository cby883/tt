package com.zuzuche.sms.task;

import com.zuzuche.sms.cache.ProviderAccountCache;
import com.zuzuche.sms.common.utils.Sha1Util;
import com.zuzuche.sms.dto.InvokeResultDto;
import com.zuzuche.sms.dto.SmsDto;
import com.zuzuche.sms.entity.ProviderAccountInfo;
import com.zuzuche.sms.remote.MiaoXinPushApi;
import com.zuzuche.sms.remote.dto.MiaoxinPushDto;
import com.zuzuche.sms.remote.param.MiaoxinSendParam;
import com.zuzuche.sms.service.KafkaService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;


/**
 * @desc: 秒信的发送任务实现类
 * 原型模式
 * @author: bingyi
 * @date: 2019/12/14
 */
@Slf4j
@Component
@Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class MiaoXinSendTask extends AbstractSendTask {

    @Autowired
    MiaoXinPushApi pushApi;


    @Autowired
    KafkaService kafkaService;

    MiaoXinSendTask(SmsDto sms) {
        super(sms);
    }

    /**
     * 过滤器链
     */
    @Override
    public boolean beforeSend(SmsDto sms) {
        return super.beforeSend(sms);
    }

    /**
     * 发送给供应商
     */
    @Override
    public InvokeResultDto invokeApi(SmsDto sms) {
        //取得账号密码
        ProviderAccountInfo account = ProviderAccountCache.getAccountById(sms.getAccountId());
        // 调用推送接口 这个接口方法用hystrix包装
        MiaoxinSendParam param = formData(sms, account);
        if (param == null) {
            //告警
            InvokeResultDto errorDto = InvokeResultDto.builder()
                    .bachNo(sms.getTaskId())
                    .extra("秒信请求参数构造出错")
                    .respCode("-99")
                    .taskId(sms.getTaskId())
                    .mobiles(sms.getMobile())
                    .md5Content(sms.getMd5Content())
                    .timestamp(Instant.now().toEpochMilli())
                    .providerId(account.getProviderId())
                    .build();
            return errorDto;
        }
        //请求接口
        MiaoxinPushDto result = pushApi.miaoXinSend(param);
        //封装返回体
        InvokeResultDto resultDto = transferResultDto(result, sms, account);
        return resultDto;

    }

    /**
     * 封装请求参数
     *
     * @param smsDto
     * @return
     */
    private MiaoxinSendParam formData(SmsDto smsDto, ProviderAccountInfo account) {
        //构造短信内容
        try {
            String sendContent = null;
            sendContent = URLEncoder.encode(smsDto.getContent(), "UTF-8");
            //构造时间
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
            String ts = LocalDateTime.now().format(formatter);
            //构造token 明文
            String tokenStr = new String("account=" + account.getAccountName() + "&ts=" + ts + "&secret=" + account.getAccountPwd());
            //sha1加密token 明文
            String token = null;
            token = Sha1Util.shaEncode(tokenStr);
            //构造请求体
            MiaoxinSendParam param = MiaoxinSendParam.builder()
                    .account(account.getAccountName())
                    .mobiles(smsDto.getMobile())
                    .content(sendContent)
                    .token(token)
                    .ts(ts)
                    .ref(smsDto.getTaskId())
                    .build();
            return param;
        } catch (Exception e) {
            log.error("[秒信发送短信请求参数出错]:{}", smsDto.toString(), e.getMessage(), e);
            return null;
        }
    }

    private InvokeResultDto transferResultDto(MiaoxinPushDto result, SmsDto smsdto, ProviderAccountInfo accountInfo) {
        // 封装返回对象
        InvokeResultDto resultDto = InvokeResultDto.builder()
                .bachNo(smsdto.getTaskId())
                .extra("")
                .respCode(result.getCode() + "")
                .taskId(sms.getTaskId())
                .mobiles(sms.getMobile())
                .md5Content(sms.getMd5Content())
                .timestamp(Instant.now().toEpochMilli())
                .providerId(accountInfo.getProviderId())
                .build();
        return resultDto;
    }


}
