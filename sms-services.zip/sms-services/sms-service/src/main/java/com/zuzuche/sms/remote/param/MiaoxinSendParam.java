package com.zuzuche.sms.remote.param;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * desc:秒信发送参数
 *
 * @author bingyi
 * @date 2019/12/13
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class MiaoxinSendParam {

    /**
     * 账号
     */
    String account;
    /**
     * token
     */
    String token;
    /**
     * 时间戳
     */
    String ts;
    /**
     * 手机号，多个手机号以逗号分隔
     */
    String mobiles;
    /**
     * 短信内容
     */
    String content;
    /**
     * batchNo，目前用taskId作为批次号
     */
    String ref;
}
