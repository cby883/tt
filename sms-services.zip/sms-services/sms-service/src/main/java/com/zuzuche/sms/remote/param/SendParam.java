package com.zuzuche.sms.remote.param;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @desc:
 * @author: panqiong
 * @date: 2018/11/12
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SendParam {
    /**
     * 用户在253云通讯平台上申请的API账号
     */
    private String account;

    /**
     * 用户在253云通讯平台上申请的API账号对应的API密钥
     */
    private String password;

    /**
     * 短信内容。长度不能超过536个字符
     */
    private String msg;

    /**
     * 手机号码。多个手机号码使用英文逗号分隔
     */
    private String phone;

    /**
     * 定时发送短信时间。格式为yyyyMMddHHmm，值小于或等于当前时间则立即发送，不填则默认为立即发送（选填参数）
     */
    private String sendtime;

    /**
     * 是否需要状态报告（默认为false）（选填参数）
     */
    private String report;

    /**
     * 用户自定义扩展码，纯数字，建议1-3位（选填参数）
     */
    private String extend;

    /**
     * 该条短信在客户业务系统内的ID，客户自定义（选填参数）
     */
    private String uid;


    @Override
    public String toString() {
        return "SendParam{" +
                "account='" + account + '\'' +
                ", msg='" + msg + '\'' +
                ", phone='" + phone + '\'' +
                ", sendtime='" + sendtime + '\'' +
                ", report='" + report + '\'' +
                ", extend='" + extend + '\'' +
                ", uid='" + uid + '\'' +
                '}';
    }
}
