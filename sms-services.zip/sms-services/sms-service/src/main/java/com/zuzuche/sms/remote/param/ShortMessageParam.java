package com.zuzuche.sms.remote.param;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @desc:
 * @author: panqiong
 * @date: 2018/10/17
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ShortMessageParam {
    /**
     * 必填参数，用户账号
     */
    private String username;

    /**
     * 必填参数，用户密码
     */
    private String passwd;

    /**
     * 必填参数，合法的手机号码，号码间用英文逗号分隔
     */
    private String phone;

    /**
     * 必填参数，短信内容(包含签名)
     */
    private String msg;
    /**
     * 必填参数。是否需要状态报告，取值true或false
     */
    private String needstatus;

    /**
     * 可选参数，扩展码，用户定义扩展码(不能超过三位)
     */
    private String port;
    /**
     * 可选参数，发送时间( 格式1900-01-01 00:00:00)
     * 即时发送：参数不传或此时间小于等于平台服务器时间
     * 定时发送：需填写此参数并且大于平台服务器时间
     */
    private String sendtime;

    /**
     * 可选参数，合批ID（用途：将短时间内提交的内容相同的短信合批显示，精简发送记录显示列表。
     * 适应范围：使用企业宝客户平台查看发送记录并且觉得发送记录太多的营销客户，不使用企业宝客户平台查看发送记录的客户直接忽略此参数。
     * 生成规则：月日时分秒+三位毫秒+随机数（随机数范围1~999999999），整串ID最长不能超过22位）
     * 例：0819140230485123或0819140230485123456789其中0819140230对应08月19日14时02分30秒，485对应毫秒，剩下部分为随机数；
     * 随机数不一定要9位但需要保证mergerid不重复，如果不同内容使用同一个mergerid那么这两批短信将会合到同一批，造成数据显示混乱。
     */
    private String mergerid;


    @Override
    public String toString() {
        return "ShortMessageParam{" +
                "username='" + username + '\'' +
                ", phone='" + phone + '\'' +
                ", msg='" + msg + '\'' +
                ", needstatus='" + needstatus + '\'' +
                ", port='" + port + '\'' +
                ", sendtime='" + sendtime + '\'' +
                ", mergerid='" + mergerid + '\'' +
                '}';
    }
}
