package com.zuzuche.sms.remote;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.zuzuche.commons.base.util.JsonUtil;
import com.zuzuche.sms.remote.dto.CommonSmsBusiDto;
import com.zuzuche.sms.remote.param.NotifyBlockMobilesParam;
import com.zuzuche.sms.remote.param.NotifySendStatusParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;

import java.nio.charset.Charset;
import java.util.Arrays;

/**
 * @desc: 短信业务系统接口 php的服务 需要回调
 * @author: panqiong
 * @date: 2018/10/24
 */
@Component
@Slf4j
public class CallBackBusiApi extends AbstractHttpInvoke{

    @Value("${smsbusi.url}")
    private String url ;


    public static final String SECRETE = "94fc916cffc2b627dd729986ebd6f613";

    /**
     *
     * 回调上游系统 告知发送供应商结果
     * @param param
     * @return
     */
    @HystrixCommand(groupKey = "callBackBusiGroup", commandKey="notifySendStatus")
    public CommonSmsBusiDto notifySendStatus(NotifySendStatusParam param){
        String result = null;
        try {
            result = super.postForm(url,param);

            CommonSmsBusiDto dto = JsonUtil.stringToObj(result,CommonSmsBusiDto.class);
            return dto;
        } catch (Exception e) {
            log.error("[回调上游发送结果接口]调用发生异常,接口响应内容result:"+result);
            CommonSmsBusiDto dto = CommonSmsBusiDto.builder()
                    .code("-98")
                    .msg("接口调用异常")
                    .build();
            return dto;
        }
    }


    /**
     *
     * 回送通知被拦截的短信
     * @param param
     * @return
     */
    @HystrixCommand(groupKey = "callBackBusiGroup", commandKey="notifyBlockMobiles")
    public CommonSmsBusiDto notifyBlockMobiles(NotifyBlockMobilesParam param){
        String result = null;
        try {
            result = super.postForm(url,param);
            CommonSmsBusiDto dto = JsonUtil.stringToObj(result,CommonSmsBusiDto.class);
            return dto;
        } catch (Exception e) {
            log.error("[回调上游拦截号码接口]调用发生异常,接口响应内容result:"+result);
            CommonSmsBusiDto dto = CommonSmsBusiDto.builder()
                    .code("-98")
                    .msg("接口调用异常")
                    .build();
            return dto;
        }
    }


    /**
     * 额外的header设置 比如编码
     *
     * @param header
     */
    @Override
    protected void setHeader(HttpHeaders header) {
        header.setAcceptCharset(Arrays.asList(Charset.forName("UTF-8")));
    }
}
