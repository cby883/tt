package com.zuzuche.sms.remote.param;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @desc:
 * @author: panqiong
 * @date: 2018/11/12
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BalanceParam {

    private String account;

    private String password;


    @Override
    public String toString() {
        return "BalanceParam{" +
                "account='" + account + '\'' +
                '}';
    }
}
