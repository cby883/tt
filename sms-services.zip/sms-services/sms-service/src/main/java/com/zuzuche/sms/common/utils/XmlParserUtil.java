package com.zuzuche.sms.common.utils;

import com.zuzuche.sms.remote.dto.PostDeliverMsgDto;
import com.zuzuche.sms.remote.dto.PostReportDto;
import lombok.extern.slf4j.Slf4j;
import org.dom4j.Attribute;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * @desc: xml解析 借助dom4j
 * 解析百唔的xml响应
 * @author: panqiong
 * @date: 2018/11/7
 */
@Slf4j
public class XmlParserUtil {

    /**
     * <?xml version="1.0" encoding="GBK" ?>
     * <reports>
     * <report>
     * <corp_id>test</corp_id>
     * <mobile>13810000001</mobile>
     * <sub_seq>0</sub_seq>(0表示整条，其余数字表示一条长短信被拆分的第几条)
     * <msg_id>12345asd</msg_id>
     * <err>2</err>（表示具体的错误码，其中err为0或000均表示为成功）
     * <fail_desc>undeliver</fail_desc>（表示具体的错误描述）
     * <report_time>2010-07-02 00:00:00</report_time>
     * </report>
     * <report>
     * <corp_id>test</corp_id>
     * <mobile>13810000002</mobile>
     * <sub_seq>0</sub_seq>
     * <msg_id>12345asd</msg_id>
     * <err>2</err>（表示具体的错误码，其中err为0或000均表示为成功）
     * <fail_desc>undeliver</fail_desc>
     * <report_time>2010-07-02 00:00:00</report_time>
     * </report>
     * </reports>
     * @param xml
     * @return
     */
    public static PostReportDto parseReport(String xml) throws Exception{
        Document document = DocumentHelper.parseText(xml);
        Element root = document.getRootElement();

        // 获取根节点下的子节点head
        Iterator iter = root.elementIterator("report");

        List<PostReportDto.Report> reportList = new ArrayList<>();
        // 遍历head节点
        while (iter.hasNext()) {

            Element recordEle = (Element) iter.next();
            String corpId = recordEle.elementTextTrim("corp_id");
            String mobile = recordEle.elementTextTrim("mobile");
            String subSeq = recordEle.elementTextTrim("sub_seq");
            String msgId = recordEle.elementTextTrim("msg_id");
            String err = recordEle.elementTextTrim("err");
            String failDesc = recordEle.elementTextTrim("fail_desc");
            String reportTime = recordEle.elementTextTrim("report_time");
            PostReportDto.Report report = PostReportDto.Report.builder()
                    .corpId(corpId)
                    .mobile(mobile)
                    .subSeq(subSeq)
                    .msgId(msgId)
                    .err(err)
                    .failDesc(failDesc)
                    .reportTime(reportTime)
                    .build();
            reportList.add(report);
        }

        PostReportDto dto = PostReportDto.builder()
                .reportList(reportList)
                .code("0")
                .build();

        return dto;
    }


    /**
     * <?xml version="1.0" encoding="GBK" ?>
     * <delivers>
     * <deliver>
     * <corp_id>test</corp_id>
     * <mobile>13810000000</mobile>
     * <ext>8888</ext> (对应下发时的ext参数，根据手机用户回复短信（即上行信息）的ext的值， 匹配客户或者客户下发的信息)
     * <time>2010-07-02 00:00:00</time>\
     * <content>收到</content>
     * </deliver>
     * </delivers>
     * @param xml
     * @return
     */
    public static PostDeliverMsgDto parseInbound(String xml) throws Exception{
        Document document = DocumentHelper.parseText(xml);
        Element root = document.getRootElement();

        // 获取根节点下的子节点head
        Iterator iter = root.elementIterator("deliver");

        List<PostDeliverMsgDto.Deliver> smsList = new ArrayList<>();
        // 遍历head节点
        while (iter.hasNext()) {

            Element recordEle = (Element) iter.next();
            String corpId = recordEle.elementTextTrim("corp_id");
            String mobile = recordEle.elementTextTrim("mobile");
            String ext = recordEle.elementTextTrim("ext");
            String time = recordEle.elementTextTrim("time");
            String content = recordEle.elementTextTrim("content");
            PostDeliverMsgDto.Deliver sms = PostDeliverMsgDto.Deliver.builder()
                    .corpId(corpId)
                    .mobile(mobile)
                    .ext(ext)
                    .time(time)
                    .content(content)
                    .build();
            smsList.add(sms);
        }

        PostDeliverMsgDto dto = PostDeliverMsgDto.builder()
                .deliverList(smsList)
                .code("0")
                .build();
        return dto;
    }



    public static void main(String[] args) throws Exception {
        String text = "<?xml version=\"1.0\" encoding=\"GBK\" ?>\n" +
                "<reports>\n" +
                "<report>\n" +
                "<corp_id>test</corp_id>\n" +
                "<mobile>13810000001</mobile>\n" +
                "<sub_seq>0</sub_seq>(0表示整条，其余数字表示一条长短信被拆分的第几条)\n" +
                "<msg_id>12345asd</msg_id>\n" +
                "<err>2</err>（表示具体的错误码，其中err为0或000均表示为成功）\n" +
                "<fail_desc>undeliver</fail_desc>（表示具体的错误描述）\n" +
                "<report_time>2010-07-02 00:00:00</report_time>\n" +
                "</report>\n" +
                "<report>\n" +
                "<corp_id>test</corp_id>\n" +
                "<mobile>13810000002</mobile>\n" +
                "<sub_seq>0</sub_seq>\n" +
                "<msg_id>12345asd</msg_id>\n" +
                "<err>2</err>（表示具体的错误码，其中err为0或000均表示为成功）\n" +
                "<fail_desc>undeliver</fail_desc>\n" +
                "<report_time>2010-07-02 00:00:00</report_time>\n" +
                "</report>\n" +
                "</reports>";
        PostReportDto dto = XmlParserUtil.parseReport(text);
        log.info(dto.toString());


        String insmsXml = "<?xml version=\"1.0\" encoding=\"GBK\" ?> \n" +
                "<delivers>\n" +
                "<deliver>\n" +
                "<corp_id>test</corp_id>\n" +
                "<mobile>13810000000</mobile>\n" +
                "<ext>8888</ext> (对应下发时的ext参数，根据手机用户回复短信（即上行信息）的ext的值， 匹配客户或者客户下发的信息)\n" +
                "<time>2010-07-02 00:00:00</time>\\\n" +
                "<content>收到</content>\n" +
                "</deliver>\n" +
                "</delivers>";

        PostDeliverMsgDto dto2 = XmlParserUtil.parseInbound(insmsXml);
        log.info(dto2.toString());

    }
}
