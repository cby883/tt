package com.zuzuche.sms.filter;

import com.zuzuche.sms.common.utils.SpringBeanFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @desc:
 * @author: panqiong
 * @date: 2018/10/26
 */
@Component
public class FilterManager {

    @Autowired
    List<Filter> filters;

    @Autowired
    List<MtFilter> mtFilters;

    /**
     * 获取所有过滤器
     * @return
     */
    public List<Filter> getFilters(){
//        Map<String,Filter> map = SpringBeanFactory.getBeansOfType(Filter.class);
//        List<Filter> filters = map.values().stream().collect(Collectors.toList());
        return filters;
    }

    /**
     * 获取所有业务短信下发过滤器
     *
     * @return mt filters
     */
    public List<MtFilter> getMtFilters() {
        return mtFilters;
    }
}
