package com.zuzuche.sms.mapper;

import com.zuzuche.commons.mybatis.BaseMapper;
import com.zuzuche.sms.entity.PhoneMember;

/**
 * The interface Phone member mapper.
 */
public interface PhoneMemberMapper extends BaseMapper<PhoneMember> {
}