package com.zuzuche.sms.cache;

import com.google.common.collect.Maps;
import com.zuzuche.commons.base.resp.Status;
import com.zuzuche.commons.base.resp.StatusServiceCnException;
import com.zuzuche.sms.entity.SmsClassConfig;
import com.zuzuche.sms.mapper.SmsClassConfigMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.locks.ReentrantLock;

/**
 * @desc: 短信同步服务类缓存
 * @author: panqiong
 * @date: 2018/11/8
 */
@Component("SmsClassConfigCache")
@Slf4j
public class SmsClassConfigCache implements InitializingBean,ConfigCache {


    @Autowired
    SmsClassConfigMapper mapper;

    /***
     * key:accountId
     * value:账户信息
     */
    private static Map<Integer,SmsClassConfig> accountInfoMap = new HashMap<>(16);


    public static SmsClassConfig getByProviderId(Integer providerId){
        return accountInfoMap.get(providerId);
    }
    /**
     * 载入配置到内存
     */
    private synchronized void load() {
        List<SmsClassConfig> list = mapper.queryAllClassConfigList();
        if(CollectionUtils.isEmpty(list)){
            log.error("[重要] 没有配置供应商数据同步处理类!!!");
            throw new StatusServiceCnException(Status.OBJECT_NOT_EXIST,"[重要] 没有配置供应商数据同步处理类!!!");
        }
        accountInfoMap = Maps.uniqueIndex(list, e->e.getProviderId());
    }



    @Override
    public void afterPropertiesSet() throws Exception {
        load();
    }

    @Override
    public boolean refresh() {
        try {
            load();
            return true;
        } catch (Exception e) {
            log.error("【SmsClassConfigCache】配置刷新失败",e.getMessage(),e);
            return false;
        }
    }
}
