package com.zuzuche.sms.cache;

import com.zuzuche.sms.entity.AccountIdBakPolicy;
import com.zuzuche.sms.mapper.AccountIdBakPolicyMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.concurrent.ThreadSafe;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;

/**
 * 功能： 供应商账户备份关联数据缓存.
 * 详细：
 *
 * @author Created on 2019.07.30 by chaodian
 */
@Slf4j
@Component("AccountIdBakPolicyCache")
@ThreadSafe
public class AccountIdBakPolicyCache implements ConfigCache, InitializingBean {

    private ReentrantLock lock = new ReentrantLock();

    /**
     * 某个供应商id的某个备份id为0，表示没有这个备份，需要忽略绕过
     */
    private final static int BACKUP_ACCOUNT_ID_MISS_VAL = 0;

    /**
     * The Mapper.
     */
    @Autowired
    AccountIdBakPolicyMapper mapper;

    /***
     * key:accountId
     * value:账户信息
     */
    private static Map<Integer, List<Integer>> bakMap = new HashMap<>(16);


    /**
     * 根据某个账户id获取它的所有备份账户id的列表.
     *
     * @param accountId the account id
     * @return the relate list by account id
     */
    public List<Integer> getBakByAccountId(int accountId) {
        return bakMap.get(accountId);
    }

    /**
     * 载入配置到内存
     */
    private void load() {
        List<AccountIdBakPolicy> list = mapper.selectAll();

        if (CollectionUtils.isNotEmpty(list)) {
            Map<Integer, List<Integer>> policyMap = new HashMap<>(16);
            list.forEach(e -> {
                if (e.getAccountId() != null) {
                    List<Integer> bakAccountIdList = new ArrayList<>(16);
                    if (e.getBackUp1() != null && e.getBackUp1() != BACKUP_ACCOUNT_ID_MISS_VAL) {
                        bakAccountIdList.add(e.getBackUp1());
                    }
                    if (e.getBackUp2() != null && e.getBackUp2() != BACKUP_ACCOUNT_ID_MISS_VAL) {
                        bakAccountIdList.add(e.getBackUp2());
                    }
                    policyMap.put(e.getAccountId(), bakAccountIdList);
                }
            });
            bakMap = policyMap;
        }
    }

    /**
     * 重新载入配置
     * 线程安全
     *
     * @return the boolean
     */
    public synchronized boolean reload() {
        try {
            load();
            return true;
        }  catch (Exception e) {
            log.error("【AccountIdBakPolicyCache】配置刷新失败", e.getMessage(), e);
            return false;
        }
    }

    /**
     * 初始化配置信息
     *
     * @throws Exception
     */
    @Override
    public void afterPropertiesSet() throws Exception {
        load();
    }

    @Override
    public boolean refresh() {
        return reload();
    }
}
