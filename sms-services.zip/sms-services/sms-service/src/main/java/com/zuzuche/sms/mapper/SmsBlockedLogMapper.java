package com.zuzuche.sms.mapper;

import com.zuzuche.commons.mybatis.BaseMapper;
import com.zuzuche.sms.entity.ProviderInfo;
import com.zuzuche.sms.entity.SmsBlockedLog;
import org.springframework.stereotype.Repository;

/**
 * @desc: 拦截
 * @author: panqiong
 * @date: 2018/10/29
 */
@Repository
public interface SmsBlockedLogMapper extends BaseMapper<SmsBlockedLog> {
}
