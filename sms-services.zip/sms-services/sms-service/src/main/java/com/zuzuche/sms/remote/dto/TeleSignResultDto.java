package com.zuzuche.sms.remote.dto;

import com.alibaba.fastjson.annotation.JSONField;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;
import java.util.List;

/**
 * @desc: teleSign短信dto
 * @author: bingyi
 * @date: 2019/08/30
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class TeleSignResultDto {
    /**
     * 关联Id
     */
    @JSONField(name = "reference_id")
    private String referenceId;
    /**
     * 返回信息体
     */
    private Status status;

    /**
     * 调用方法
     */
    @JSONField(name = "sub_resource")
    private String subResource;

    private List<Error> errors;
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    @Data
    public static class Status{
        /**
         * 状态码 290表示成功接收
         */
        private int code;
        /**
         * 状态码描述信息
         */
        private String description;
    }

    @AllArgsConstructor
    @NoArgsConstructor
    @Data
    @Builder
    public static class Error {
        /**
         * 错误码
         */
        private int code;
        /**
         * 描述
         */
        private String description;
    }

}
