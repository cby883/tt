package com.zuzuche.sms.remote;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.zuzuche.commons.base.util.JsonUtil;
import com.zuzuche.sms.remote.dto.*;
import com.zuzuche.sms.remote.param.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;
import org.springframework.web.client.ResourceAccessException;

import java.nio.charset.Charset;
import java.util.Arrays;

/**
 * 状态码	状态值	处理策略
 * 0	提交成功
 * 101	API账号错误	账号是否正确（不能使用登录的用户名密码发送短信，应使用登陆之后的API账号密码发送短信）；接口地址调用错误，参数错误（账号）；账号的状态是否被暂停；是否使用以前平台的demo测试云通讯平台的账号（账号应该与接口文档相对应）
 * 102	API密码错误	密码填写错误（是否有空格或者大小写）；参数错误（pw）；特殊符号是否有使用urlencode转码（+,空格,/,?,%,#,&,=）
 * 103	提交过快	提交速度超过流速限制
 * 104	系统忙碌	因平台侧原因，暂时无法处理提交的短信
 * 105	敏感短信	短信内容包含敏感词，请把短信内容给到售后客服查询是否有敏感词
 * 106	短信内容长度错误	长度>536或<=0，消息内容超过长度；参数错误（msg 消息内容）；内容中有特殊符号（？、&、%…）
 * 107	手机号码格式错误	手机号的位数以及手机号号段是否正确；参数错误（phone）
 * 108	手机号码个数错误	个数>50000或<=0；对手机号码进行了转码；手机号码是否用英文的逗号分开；phone参数中的手机号没有传值成功为空导致；
 * 109	无发送额度	账号没有余额，请充值
 * 110	不在发送时间内
 * 113	扩展码格式错	非数字或者长度不对， extno传的值是否为数字（注：Extno传的数字会在短信的接入号后面显示，传的数字以及前面固定的接入号位数不得超过20位）
 * 114	可用参数组个数错误	小于最小设定值或者大于1000 ; 变量参数组大于20个
 * 116	msg签名不合法或未带签名	用户必须带签名的前提下，需要在短信平台申请短信签名，并申请通过的签名才是有效的签名；是否有在短信内容前或者后加上申请并审核通过的签名
 * 117	IP地址认证错	绑定的服务器ip和提交短信的ip不一致（绑定了只能在绑定的这台服务器上发送短信）
 * 118	用户没有相应的发送权限	账号被禁止发送，联系售后客服查询短信账号的发送状态是否正常
 * 119	用户已过期
 * 120	超过日发送条数限制	账号设置了日发送上限，是否超过设置的额度 可联系客服解除
 * 123	发送类型错误	查看是否账号设置cmpp协议，而使用http协议发送短信，反之亦然。
 * 124	白模板匹配错误
 * 125	匹配到驳回模板，提交失败	联系售后客服查询提交的短信内容是否有驳回模板
 * 126	审核通过模板匹配错误
 * 127	定时发送时间格式错误	定时发送短信时间。检查时间格式是否为yyyyMMddHHmm
 * 128	内容解码失败，	内容要保证utf-8格式的编码,
 * 例如%#+之类的特殊字符用urlencode编码
 * 129	JSON格式错误	请以JSON格式提交数据，注意设置
 * Content-Type 为 application/json
 * 130	请求参数错误	缺少必填参数，没有使用查询余额接口地址
 * @desc: 创蓝推送api
 * @author: panqiong
 * @date: 2018/11/12
 */
@Component
@Slf4j
public class ChuangLanInterApi extends AbstractHttpInvoke{

    @Value("${provider.clan.international_url}")
    private String base ;

    /**
     * 额外的header设置 比如编码
     *
     * @param header
     */
    @Override
    protected void setHeader(HttpHeaders header) {
        header.setAcceptCharset(Arrays.asList(Charset.forName("UTF-8")));
    }




    /**
     * 客户发送短信的账号不是253平台登录账号，是短信接口API账号 。
     * 发送的短信内容一定要加上签名，账号有报备过签名的可不用带上签名， 但如果您有多个短信签名，请将需要的短信签名放在短信内容前面 。
     * 例如您有”【253云通讯】”，”【通讯云】”两个签名，但是想以”【通讯云】”签名发送短信，则”msg”字段可赋值为：”【通讯云】你的验证码是xxxx”，不填默认第一个签名。
     * 用户自定义扩展码，发送短信显示号码，规则为：10690+xxx（通道号）+xxx(系统扩展码) +xxx（用户自定义扩展码）；扩展码的长度将直接影响短信上行接收的接收。如需要传扩展码参数时，请咨询客服相关设置问题 。
     * @param param
     * @return
     */
    @HystrixCommand(groupKey = "chLanApiGroup", commandKey="send")
    public SendInterDto send(SendInterParam param) throws ResourceAccessException{
        String api = "/send/json";
        String url = base+api;
        String result = super.postJson(url,param);
        // 结果解析
        try {
            SendInterDto dto = JsonUtil.stringToObj(result,SendInterDto.class);
            return dto;
        } catch (Exception e) {
            log.error("[创蓝发送短信国际接口]解析返回的响应json报错 接口相应内容result:"+result);
            return SendInterDto.builder()
                    .code("-99")
                    .error("json解析异常")
                    .msgId("")
                    .build();
        }
    }


    /**
     * 国际批量短信
     * @param param
     * @return
     */
    @HystrixCommand(groupKey = "chLanApiGroup", commandKey="send")
    public SendInterBatchDto sendBatch(SendInterBatchParam param) throws ResourceAccessException{
        String api = "/send";
        String url = base+api;
        String result = super.postJson(url,param);
        try {
            SendInterBatchDto dto = JsonUtil.stringToObj(result,SendInterBatchDto.class);
            return dto;
        } catch (Exception e) {
            log.error("[创蓝群发送短信国际接口]解析返回的响应json报错 接口相应内容result:"+result);
            return SendInterBatchDto.builder()
                    .code("-99")
                    .message("json解析异常")
                    .build();
        }
    }

    /**
     * 余额查询
     * @param param
     * @return
     */
    @HystrixCommand(groupKey = "chLanApiGroup", commandKey="balance")
    public BalanceInterDto balance(BalanceParam param){
        String api = "/balance/json";
        String url = base+api;
        String result;
        try {
            result = super.postJson(url,param);
        }catch (ResourceAccessException e){
            log.error("[ChuangLanInterApi-balance]接口resource异常",e.getMessage(),e);
            return BalanceInterDto.builder()
                    .code("-90")
                    .error("接口resource异常")
                    .build();
        }catch (Exception e) {
            log.error("[ChuangLanInterApi-balance]接口调用异常 ",e.getMessage(),e);
            return BalanceInterDto.builder()
                    .code("-98")
                    .error("接口调用异常")
                    .build();
        }
        try {
            BalanceInterDto dto = JsonUtil.stringToObj(result,BalanceInterDto.class);
            return dto;
        } catch (Exception e) {
            log.error("[创蓝余额国际查询接口]解析返回的响应json报错 接口相应内容result:"+result);
            return BalanceInterDto.builder()
                    .code("-99")
                    .error("json解析异常")
                    .build();
        }
    }

    /**
     * 拉取状态报告
     * @param param
     * @return
     */
    @HystrixCommand(groupKey = "chLanApiGroup", commandKey="pullReport")
    public PullReportInterDto pullReport(PullReportParam param){
        String api = "/pull/report";
        String url = base+api;
        String result;
        try {
            result = super.postJson(url,param);
        }catch (ResourceAccessException e){
            log.error("[ChuangLanInterApi-pullReport]接口resource异常",e.getMessage(),e);
            return PullReportInterDto.builder()
                    .code("-90")
                    .error("接口resource异常")
                    .build();
        }catch (Exception e) {
            log.error("[ChuangLanInterApi-pullReport]接口调用异常 ",e.getMessage(),e);
            return PullReportInterDto.builder()
                    .code("-98")
                    .error("接口调用异常")
                    .build();
        }

        try {
            PullReportInterDto dto = JsonUtil.stringToObj(result,PullReportInterDto.class);
            return dto;
        } catch (Exception e) {
            log.error("[创蓝状态报告国际查询接口]解析返回的响应json报错 接口相应内容result:"+result);
            return PullReportInterDto.builder()
                    .code("-99")
                    .error("json解析异常")
                    .build();
        }
    }


    /**
     * 拉取上行短信
     * @param param
     * @return
     */
    @HystrixCommand(groupKey = "chLanApiGroup", commandKey="pullMo")
    public PullMoInterDto pullMo(PullMoParam param){
        String api = "/pull/mo";
        String url = base+api;
        String result;
        try {
            result = super.postJson(url,param);
        }catch (ResourceAccessException e){
            log.error("[ChuangLanInterApi-pullMo]接口resource异常",e.getMessage(),e);
            return PullMoInterDto.builder()
                    .code("-90")
                    .error("接口resource异常")
                    .build();
        } catch (Exception e) {
            log.error("[ChuangLanInterApi-pullMo]接口调用异常 ",e.getMessage(),e);
            return PullMoInterDto.builder()
                    .code("-98")
                    .error("接口调用异常")
                    .build();
        }

        try {
            PullMoInterDto dto = JsonUtil.stringToObj(result,PullMoInterDto.class);
            return dto;
        } catch (Exception e) {
            log.error("[创蓝状态报告国际查询接口]解析返回的响应json报错 接口相应内容result:"+result);
            return PullMoInterDto.builder()
                    .code("-99")
                    .error("json解析异常")
                    .build();
        }
    }





}
