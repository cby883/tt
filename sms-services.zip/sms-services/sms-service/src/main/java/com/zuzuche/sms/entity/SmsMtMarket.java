package com.zuzuche.sms.entity;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Table;

/**
 * 功能：The type Sms mt market.
 * 详细：
 *
 * @author Created on 2019.01.31 by chaodian
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "zuzuche_sms_db.sms_mt_market_tbl")
public class SmsMtMarket {
    private Long id;

    private String mobile;

    private String areaCode;

    private Byte type;

    private Byte regionType;

    private Byte signType;

    private String supplier;

    private String admin;

    private String batch;

    private String fromType;

    private String fromUniqueId;

    private Integer taskId;

    private String pushStatus;

    private Byte requestStatus;

    private Byte status;

    private String sign;

    private String ext;

    private Byte sendCount;

    private Integer updateTime;

    private Integer sendTime;

    private Integer addTime;

    private String content;

    private String extraParam;
}