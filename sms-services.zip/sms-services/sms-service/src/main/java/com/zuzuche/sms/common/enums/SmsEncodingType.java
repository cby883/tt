package com.zuzuche.sms.common.enums;

import com.zuzuche.commons.base.constants.BaseEnum;
import lombok.Getter;

/**
 * desc:短信编码类型
 *
 * @author bingyi
 * @date 2019/09/19
 */
@Getter
public enum SmsEncodingType implements BaseEnum<Integer> {
    /**
     * unicode编码
     */
    SMS_UNICODE(1,"UNICODE",70,67),
    /**
     * GSM编码
     */
    SMS_GSM(2,"GSM",160,153),
    /**
     * ASCII编码
     */
    SMS_ASCII(3,"ASCII",140,133);

    /**
     * 编码code
     */
    private Integer code;
    /**
     * 编码类型
     */
    private String codingType;
    /**
     * 一条短信的最大字符
     */
    private int unixMaxCount;
    /**
     * 一条短信的切割字符
     */
    private int unixCutCount;

    SmsEncodingType(Integer code,String name,int unixMaxCount,int unixCutCount) {
        this.code = code;
        this.codingType =name;
        this.unixMaxCount=unixMaxCount;
        this.unixCutCount=unixCutCount;
    }

    @Override
    public Integer code() {
        return code;
    }

    public String codingType(){
        return this.codingType;
    }

    public int unixCutCount(){
        return this.unixCutCount;
    }

    public int unixMaxCount(){
        return this.unixMaxCount;
    }
}