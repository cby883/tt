package com.zuzuche.sms.rest;

import com.zuzuche.commons.base.resp.RespResult;
import com.zuzuche.sms.entity.SmsReportErrorDesc;
import com.zuzuche.sms.rest.request.SmsReportErrorReq;
import com.zuzuche.sms.service.SmsReportErrorDescService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @desc: 短信状态报告错误码详情rest
 * @author: bingyi
 * @date: 2019/11/27
 */
@RestController
@RequestMapping("/smsErrorDesc")
@Slf4j
@Api(value = "smsErrorDesc", description = "短信状态报告错误码详情", tags = {"smsErrorDesc"})
public class SmsReportErrorRest {
    @Autowired
    SmsReportErrorDescService reportErrorDescService;

    /**
     * 获取短信类型
     *
     * @param
     * @return
     */
    @GetMapping("/getErrorDesc")
    @ApiOperation(value = "短信错误码详情", notes = "短信错误码详情")
    public RespResult<String> getErrorDesc(@RequestParam("errorCode") @ApiParam(value = "错误码", required = true) String errorCode
            , @RequestParam(value = "accountId") @ApiParam(value = "供应商id,必须大于0", required = true) int accountId) {
        String errorDesc = reportErrorDescService.getErrorDesc(errorCode, accountId);
        return RespResult.success(errorDesc);
    }

    @PostMapping("/importErrorDesc")
    public RespResult importErrorDesc(SmsReportErrorReq smsReportErrorReq){
        reportErrorDescService.importErrorDesc(smsReportErrorReq);
        return RespResult.success();
    }

    @GetMapping("/exportData")
    public RespResult exportData(){
        List<SmsReportErrorDesc> list= reportErrorDescService.exportData();
        return RespResult.success(list);
    }


}
