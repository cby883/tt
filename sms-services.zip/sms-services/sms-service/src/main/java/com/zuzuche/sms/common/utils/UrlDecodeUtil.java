package com.zuzuche.sms.common.utils;

import com.google.common.collect.Lists;
import com.zuzuche.commons.base.util.BeanConverter;
import com.zuzuche.commons.base.util.JsonUtil;
import com.zuzuche.commons.base.util.StringUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.HttpServletRequest;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * url Decode工具类
 *
 * @author bingyi
 */
@Slf4j
public class UrlDecodeUtil<T> {

    private String objToUrl(T obj, String charset) throws UnsupportedEncodingException {
        if (obj == null) {
            return "";
        }
        Map<String, Object> map = BeanConverter.beanToMap(obj);
        StringBuilder result = new StringBuilder(128);
        Iterator var4 = map.entrySet().iterator();

        while (var4.hasNext()) {
            Map.Entry<String, ?> entry = (Map.Entry) var4.next();
            result.append((String) entry.getKey()).append("=").append(URLEncoder.encode(String.valueOf(entry.getValue()), charset)).append("&");
        }

        result.setLength(result.length() - 1);
        return result.toString();


    }
}
