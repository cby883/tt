package com.zuzuche.sms.remote.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @desc: 1.7上行短信拉取返回参数
 * @author: panqiong
 * @date: 2018/10/17
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PullSmsUplinkDto {

    private int respcode;
    private String respdesc;
    private List<Uplink> uplinks;

    public PullSmsUplinkDto(int respcode,String respdesc){
        this.respcode = respcode;
        this.respdesc = respdesc;
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class Uplink {
        /**
         * 上行端口
         */
        private String port;

        /**
         * 手机号码
         */
        private String phone;

        /**
         *
         */
        private String accesscode;

        /**
         * 短信内容
         */
        private String msg;
    }



}
