package com.zuzuche.sms.common.constant;

import com.zuzuche.commons.base.constants.BaseEnum;
import io.swagger.models.auth.In;
import lombok.Getter;

/**
 * @desc:
 * @author: panqiong
 * @date: 2018/10/24
 */
public class Constants {


    public final static int JUCHN_PROVIDER_ID = 1;

    public final static int BAIWU_PROVIDER_ID = 2;

    public final static int HENGXIN_PROVIDER_ID = 4;

    /**
     * 一次最多推送的手机个数
     */
    public final static int MAX_MOBILES_SIZE = 200;

    /**
     * 国内手机号码正则匹配格式
     */
    public static final String INNER_MOBILE_FORMAT_PREG = "^[0-9]+[0-9]+$";

    /**
     * 国际手机号码正则匹配格式
     */
    public static final String INTER_MOBILE_FORMAT_PREG = "^[0-9]+-[0-9]+$";

    /**
     * 手机号码0前缀正则匹配格式
     */
    public static final String MOBILE_PREFIX_PREG = "^0+";

    /**
     * 国内手机号码86前缀正则匹配格式
     */
    public static final String INNER_MOBILE_AREA_CODE_PREG = "^86";

    /**
     * 国内手机号码的默认国际号前缀86
     */
    public static final String INNER_MOBILE_AREA_CODE = "86";

    /**
     * 国际手机区号与具体号码连接标识符-
     */
    public static final String INTER_MOBILE_JOIN_MARK = "-";

    /**
     * 截取国际号码区号的正则表达式，如886-2434334， 将截取886
     */
    public static final String INTER_AREA_CODE_PREG = "^\\d{0,}[^-]";

    /**
     * 截取国际号码的正则表达式，如886-23232，将截取23232
     */
    public static final String INTER_PHONE_PREG = "\\d+$";

    /**
     * 过滤器类型
     */
    public enum FilterTypes implements BaseEnum<String> {
        /**
         * 与zcs前端对应
         */
        重复短信过滤器("duplicated"),

        黑名单过滤器("blackMobile"),

        权限检查过滤器("authorize"),

        白名单过滤器("whiteMobile"),
        ;

        private String code;

        FilterTypes(String code) {
            this.code = code;
        }

        @Override
        public String code() {
            return code;
        }

    }


    /**
     * 发送供应商编码
     */
    public enum OutboundState implements BaseEnum<String> {
        成功("0"),

        异常("-1"),

        被过滤器拦截("-2");

        private String code;

        OutboundState(String code) {
            this.code = code;
        }

        @Override
        public String code() {
            return code;
        }

    }


    /**
     * 发送供应商编码
     */
    public enum EnvEnum implements BaseEnum<String> {
        开发("dev"),

        测试("test"),

        生产("prd");

        private String code;

        EnvEnum(String code) {
            this.code = code;
        }

        @Override
        public String code() {
            return code;
        }

    }
    /**
     * 发送供应商编码
     */
    public enum CharsetEnums implements BaseEnum<String> {
        utf8("UTF-8"),

        gbk("GBK");

        private String code;

        CharsetEnums(String code) {
            this.code = code;
        }

        @Override
        public String code() {
            return code;
        }

    }


    /**
     * 国际化枚举.
     */
    public enum LocaleLanguage implements BaseEnum<String> {
        /**
         * 与zcs前端对应
         */
        英语("en"),

        中文("zh-cn");

        private String code;

        LocaleLanguage(String code) {
            this.code = code;
        }

        @Override
        public String code() {
            return code;
        }

    }
}
