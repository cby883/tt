package com.zuzuche.sms.cache;

import com.zuzuche.commons.base.constants.BaseEnum;
import com.zuzuche.commons.base.util.StringUtil;
import com.zuzuche.sms.cache.co.SupplierConfigCo;
import com.zuzuche.sms.common.enums.SmsType;
import com.zuzuche.sms.entity.SupplierConfig;
import com.zuzuche.sms.mapper.SupplierConfigMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 功能：供应商配置缓存操作.
 * 详细：
 *
 * @author Created on 2019.03.12 by chaodian
 */
@Component("SupplierConfigCache")
@Slf4j
public class SupplierConfigCache implements InitializingBean ,ConfigCache{

    /**
     * The Mapper.
     */
    @Autowired
    SupplierConfigMapper mapper;

    /**
     * 供应商特殊匹配规则配置信息
     */
    private static Map<String, SupplierConfigCo> configMap = new HashMap<>();

    /**
     * accountId与supplier映射的信息
     */
    private static Map<Integer, String> supplierMap = new HashMap<>(16);

    /**
     * 是否存在某个key
     * @param key the key
     * @return boolean
     */
    private boolean containsConfig(String key){
        return configMap.containsKey(key);
    }

    /**
     * Get config supplier config co.
     *
     * @param supplier   the supplier 供应商名称
     * @param regionType the region type 1国内，2国际
     * @param smsType    the sms type 业务短信类型，1普通，2营销，3验证码
     * @return the supplier config co
     */
    public SupplierConfigCo getConfig(String supplier, int regionType, int smsType){
        String key = getMapKey(supplier, regionType, smsType);
        if (StringUtil.isEmpty(key)) {
            return null;
        }
        if (!containsConfig(key)) {
            return null;
        }
        return configMap.get(key);
    }


    /**
     * 根据供应商账户id获取对应的供应商标识.
     *
     * 如112获取到的是JC
     *
     * @param accountId the account id
     * @return the supplier by account id
     */
    public String getSupplierByAccountId(int accountId) {
        return supplierMap.get(accountId);
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        load();
    }

    /**
     * Load.
     */
    public void load() {
        List<SupplierConfig> list = mapper.selectAll();
        if (CollectionUtils.isNotEmpty(list)) {
            Map<String, SupplierConfigCo> configMapTemp = new HashMap<>();
            Map<Integer, String> tempSupplierMap = new HashMap<>(16);
            list.forEach(e->{
                String key = genMapKey(e.getSupplier(), e.getRegionType(), e.getSmsType());
                SupplierConfigCo co = SupplierConfigCo.builder()
                        .preFix(e.getPrefix())
                        .postFix(e.getSuffix())
                        .supplierSmsType(e.getSmsType())
                        .regionType(e.getRegionType())
                        .unixMaxCount(e.getUnitMaxCount())
                        .unixCutCount(e.getUnitCutCount())
                        .accountId(e.getAccountId())
                        .cleanSignType(e.getCleanSignType())
                        .build();
                configMapTemp.put(key, co);


                if (e.getAccountId() != null &&
                        e.getAccountId() > 0 &&
                        StringUtil.isNotBlank(e.getSupplier())
                ) {
                    tempSupplierMap.put(e.getAccountId(), e.getSupplier());
                }
            });

            configMap=configMapTemp;
            supplierMap = tempSupplierMap;
        }
    }

    /**
     * 通过供应商、国家性质和业务短信性质获取key
     * @param supplier   the supplier 供应商名称
     * @param regionType the region type 1国内，2国际
     * @param smsType    the sms type 业务短信类型，1普通，2营销，3验证码
     * @return string
     */
    private String getMapKey(String supplier, int regionType, int smsType) {
        // 由于map每个key存的是供应商的行业短信性质，这里业务短信性质先转换一下
        SmsType smsTypeEnum = BaseEnum.parse(SmsType.class, smsType);
        if (smsTypeEnum == null) {
            return "";
        }
        int supplierSmsType = smsTypeEnum.getSupplierSmsType();

        return genMapKey(supplier, regionType, supplierSmsType);
    }

    /**
     * 通过供应商、国家性质和供应商短信性质构造生成key
     * @param supplier   the supplier 供应商名称
     * @param regionType the region type 1国内，2国际
     * @param supplierSmsType    the supplier sms type 供应商短信类型，1行业通知，2营销通知
     * @return string
     */
    private String genMapKey(String supplier, int regionType, int supplierSmsType) {
        return supplier + "_" + supplierSmsType + "_" + regionType;
    }

    @Override
    public boolean refresh() {
        try {
            load();
            return true;
        } catch (Exception e) {
            log.error("【SupplierConfigCache】配置刷新失败",e.getMessage(),e);
            return false;
        }
    }
}
