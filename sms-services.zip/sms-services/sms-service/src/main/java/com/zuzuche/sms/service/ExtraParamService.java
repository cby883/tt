package com.zuzuche.sms.service;

import com.zuzuche.commons.base.util.JsonUtil;
import com.zuzuche.commons.base.util.StringUtil;
import com.zuzuche.sms.dto.ExtraParamDto;
import com.zuzuche.sms.dto.MtDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

/**
 * desc:ExtraParam 参数转化
 *
 * @author bingyi
 * @date 2019/09/09
 */
@Service
@Slf4j
public class ExtraParamService {
    public static ExtraParamDto jsonTransfer(String json) {
        //如果为空，直接返回
        if (StringUtils.isEmpty(json)) {
            return null;
        }
        ExtraParamDto extraParamDto = null;
        try {
            extraParamDto = JsonUtil.stringToObj(json, ExtraParamDto.class);
        } catch (Exception e) {
            log.warn("短信额外参数解析异常，数据如:" + json, e.getMessage(), e);
        }
        return extraParamDto;
    }

    /**
     * 转换模板id
     * @param extraParamDto
     * @return
     */
    public  void transferTempId(MtDto mtDto, ExtraParamDto extraParamDto){
        //判断是否存在模板id
        if(mtDto.getUseTemplate()==1){
            //判断extraParamDto是否为空
            if(extraParamDto==null){
                extraParamDto=ExtraParamDto.builder().build();
            }
            //填充模板id
            if(StringUtil.isNotEmpty(mtDto.getTempId())){
                extraParamDto.setTempId(mtDto.getTempId());
            }else{
                extraParamDto.setTempUid(mtDto.getTempUid());
            }
            //转换成json字符串
            String extraParam=mtDto.getExtraParam();
            try {
                extraParam=JsonUtil.objToStr(extraParamDto);
            } catch (Exception e) {
                log.error("【ExtraParamService】模板id填充json转换失败",e.getMessage(),e);
            }
            mtDto.setExtraParam(extraParam);
        }
        mtDto.setExtraParamDto(extraParamDto);
    }

}
