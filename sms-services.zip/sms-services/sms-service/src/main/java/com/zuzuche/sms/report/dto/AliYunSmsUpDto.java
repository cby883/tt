package com.zuzuche.sms.report.dto;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonFilter;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @desc:上行短信dto
 *
 * @author bingyi
 * @date 2019/08/19
 */
@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AliYunSmsUpDto {
    @JSONField(name = "phone_number")
    private String phoneNumber;
    /**
     * 短信内容
     */
    private String content;
    /**
     * 短信签名
     */
    @JSONField(name = "sign_name")
    private String signName;
    /**
     * 时间
     */
    @JSONField(name = "send_time")
    private String sendTime;
    /**
     * 扩展码
     */
    @JSONField(name = "dest_code")
    private String destCode;
    /**
     * 消息序列ID
     */
    @JSONField(name = "sequence_id")
    private double sequenceId;
}
