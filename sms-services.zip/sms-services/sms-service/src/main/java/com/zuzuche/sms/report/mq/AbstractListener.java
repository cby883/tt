package com.zuzuche.sms.report.mq;

import com.zuzuche.commons.base.util.BeanConverter;
import com.zuzuche.commons.base.util.StringUtil;
import com.zuzuche.kafka.sentry.EventDto;
import com.zuzuche.kafka.sentry.SentryReport;
import com.zuzuche.sms.cache.ProviderAccountCache;
import com.zuzuche.sms.common.utils.DateUtil;
import com.zuzuche.sms.common.utils.TimeUtil;
import com.zuzuche.sms.dto.StatusReportDto;
import com.zuzuche.sms.entity.ProviderAccountInfo;
import com.zuzuche.sms.entity.SmsInbound;
import com.zuzuche.sms.entity.StatusReport;
import com.zuzuche.sms.mapper.SmsInboundMapper;
import com.zuzuche.sms.mapper.StatusReportMapper;
import com.zuzuche.sms.service.KafkaService;
import com.zuzuche.sms.service.StatusReportService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * @desc:监听器的模板父类
 *
 * @author bingyi
 * @date 2019/08/20
 */
@Slf4j
public abstract class AbstractListener {

       @Autowired
       StatusReportMapper statusReportMapper;

       @Autowired
       StatusReportService statusReportService;


       @Autowired
       SmsInboundMapper smsInboundMapper;
       @Autowired
       KafkaService kafkaService;

       @Autowired
       SentryReport sentryReport;
       public void mqStatusReport(int providerId,List<StatusReport> list){
              try{
                     // 埋点预警系统
                     toSentry(providerId, list);
                     statusReportService.pushToReportKafka(list);

              }catch (Exception e){
                     log.error("[mqStatusReport]拉取状态报告处理异常:provideId:"+providerId,e.getMessage(),e);
              }
       }

       private void toSentry(int providerId, List<StatusReport> list) {
              try{
                     if(list==null){
                            return;
                     }
                     list.stream().forEach(e->{
                            long reciveTime = Instant.now().toEpochMilli();
                            if(StringUtil.isNotEmpty(e.getRecvTime())&&!"null".equals(e.getRecvTime())){
                                   if(e.getRecvTime().contains("T")&&e.getRecvTime().contains("Z")){
                                          reciveTime = LocalDateTime.parse(e.getRecvTime(), DateTimeFormatter.ofPattern(DateUtil.PATTERN_UTC))
                                                  .toInstant(ZoneOffset.of("+8")).toEpochMilli();
                                   }else{
                                          reciveTime = LocalDateTime.parse(e.getRecvTime(), DateTimeFormatter.ofPattern(DateUtil.PATTERN_1))
                                                  .toInstant(ZoneOffset.of("+8")).toEpochMilli();
                                   }

                            }else{
                                   log.error("[状态报告返回的接收时间为空:]"+e.toString());
                            }
                            EventDto eventDto = EventDto.builder()
                                    .metric("sms_status_report_total")
                                    .time(reciveTime)
                                    .addLabel("status", e.getStatus())
                                    .addLabel("providerId", String.valueOf(providerId))
                                    .value(1)
                                    .build();
                            sentryReport.incrCounter(eventDto);
                     });
              }catch (Exception e){
                     log.error("[状态报告预警埋点异常]",e.getMessage(),e);
              }

       }

       /**
        * desc:上行短信的监听父类
        * @param
        */
       public void mqInboundSms(List<SmsInbound> list) {
              try {
                   if (CollectionUtils.isNotEmpty(list)) {
                          smsInboundMapper.insertList(list);
                     }

              } catch (Exception e) {
                     log.error("[mqInboundSms]拉取上行短信异常" ,e.getMessage(), e);
              }
       }

}
