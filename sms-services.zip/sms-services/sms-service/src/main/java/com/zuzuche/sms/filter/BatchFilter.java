package com.zuzuche.sms.filter;


import com.zuzuche.sms.dto.MtDto;
import com.zuzuche.sms.entity.SmsBatchTask;

/**
 * 大批量发送功能过滤器
 * @author bingyi
 * @date  2019-02-28
 */
public interface BatchFilter {

    /**
     * 过滤器统一入口方法
     *
     * @param mtDto the mt dto
     * @return boolean
     */
    boolean doFilter(MtDto mtDto, SmsBatchTask smsBatchTask);
}
