package com.zuzuche.sms.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Table;
import java.time.LocalDateTime;
import java.util.Date;


/**
 * @desc 下行短信记录
 * @author panqiong
 * @date 20181019
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "sms_outbound")
public class SmsOutbound {
    private int id;

    private String taskId;

    private String content;

    private int accountId;

    private LocalDateTime createTime;

    private String batchNo;

    private String respCode;

    private String logId;

    private LocalDateTime updateTime;


}