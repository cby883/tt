package com.zuzuche.sms.executors;

import com.google.common.base.Splitter;
import com.google.common.util.concurrent.RateLimiter;
import com.zuzuche.logback.util.MDCUtil;
import com.zuzuche.sms.dto.SmsDto;
import com.zuzuche.sms.entity.SmsOutbound;
import com.zuzuche.sms.entity.SmsOutboundPhone;
import com.zuzuche.sms.mapper.SmsOutboundMapper;
import com.zuzuche.sms.mapper.SmsOutboundPhoneMapper;
import com.zuzuche.sms.task.AbstractSendTask;
import com.zuzuche.threadpool.ThreadPoolExecutorFactory;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.LocalDateTime;
import java.util.List;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

/**
 * @desc: 短信下行服务 模板模式抽象类
 * @author: panqiong
 * @date: 2018/10/25
 */
@Slf4j
public abstract class AbstractOutboundExecutor {


    /**
     * 线程池
     * 溢出策略 最长阻塞主线程60秒后抛出异常
     */
    private ExecutorService executorService ;


    @Autowired
    SmsOutboundMapper smsOutboundMapper;

    @Autowired
    SmsOutboundPhoneMapper outboundPhoneMapper;

    /**
     * @param confg
     */
    public AbstractOutboundExecutor(ThreadPoolExecutorFactory.Config confg){
        //初始化线程池
        executorService = ThreadPoolExecutorFactory.create(confg);

    }


    /**
     * 下行逻辑处理
     * 1.持久化数据,统一实现. 持久化数据放在主流程 .数据消费后尽快入库,增强可靠性 ,吞吐率不是重点,先保证可靠性.如果要提高吞吐能力,入库放在异步流程
     * 2.将短信包装成task
     * 3.提交task到线程池
     * @param sms
     */
    public void handle(SmsDto sms) throws RejectedExecutionException{
        // 如果没有重试过，才进行入库，因为重试前已经入过库
        if (sms.getRetryNo() <= 0) {
            // 同步保存db 没有做异步
            saveToDb(sms);
        }
        // 将短信包装成任务 task
        AbstractSendTask task = packingSendTask(sms);

        executorService.submit(task);
    }



    /**
     * 保存至数据库
     * @param sms
     */
    private void saveToDb(SmsDto sms) {
        String mobiles = sms.getMobile();
        String taskId = sms.getTaskId();
        Integer accountId = sms.getAccountId();

        List<String> mobileList = Splitter.on(",").splitToList(mobiles);

        String content = sms.getContent();
        // 截断短信内容
        int lengthThrehold = 300;
        if(content.length()>=lengthThrehold){
            content = content.substring(0,290)+"[...]";
        }
        // 入库
        // content 注入换为空 @CHaodian 2019-03-21
        SmsOutbound outbound = SmsOutbound.builder()
                .taskId(taskId)
                .accountId(accountId)
                .content("")
                .createTime(LocalDateTime.now())
                .build();
        smsOutboundMapper.insertSelective(outbound);

        // 表冗余，暂时不插入，减小db压力 @Chaodian 2019-03-21
        // List<SmsOutboundPhone> phoneList =  mobileList.parallelStream().map(mobile->
        //         SmsOutboundPhone.builder()
        //                 .phone(mobile)
        //                 .taskId(taskId)
        //                 .createTime(LocalDateTime.now())
        //                 .build()
        // ).collect(Collectors.toList());
        //
        // outboundPhoneMapper.insertList(phoneList);
    }


    /**
     * 打包发送任务  将sms包装成task
     * @param sms
     * @return 任务
     */
    public abstract AbstractSendTask packingSendTask(SmsDto sms);




    protected void printException(Runnable r, Throwable t) {
        if (t == null && r instanceof Future<?>) {
            try {
                Future<?> future = (Future<?>) r;
                if (future.isDone()){
                    future.get();
                }
            } catch (CancellationException ce) {
                t = ce;
            } catch (ExecutionException ee) {
                t = ee.getCause();
            } catch (InterruptedException ie) {
                Thread.currentThread().interrupt(); // ignore/reset
            }
        }
        if (t != null){
            log.error(t.getMessage(), t);
        }

    }


}
