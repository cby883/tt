package com.zuzuche.sms.rest;

import com.zuzuche.commons.base.resp.RespResult;
import com.zuzuche.commons.mybatis.PageData;
import com.zuzuche.sms.entity.SmsBatchSendReport;
import com.zuzuche.sms.entity.SmsUploadFileLog;
import com.zuzuche.sms.entity.StatusReport;
import com.zuzuche.sms.rest.request.FileUploadReq;
import com.zuzuche.sms.service.FileManagementService;
import com.zuzuche.sms.service.StatusReportService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;


/**
 * @desc: 文件管理状态报告
 * @author: bingyi
 * @date: 2019-10-31
 */
@RestController
@RequestMapping("/batchReport")
@Slf4j
@Api(value = "batchReport", description = "批量状态报告", tags = {"batchReport"})
public class BatchReportRest {
    @Autowired
    StatusReportService statusReportService;
    @ApiOperation(value = "批量状态报告")
    @PostMapping(value = "/batchReport")
    public RespResult<SmsBatchSendReport> batchReport(@RequestParam(value = "batchNo") String batchNo) {
           SmsBatchSendReport batchSendReport=statusReportService.batchReport(batchNo);
           return RespResult.success(batchSendReport);
    }
}
