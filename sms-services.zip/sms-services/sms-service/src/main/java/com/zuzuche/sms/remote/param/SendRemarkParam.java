package com.zuzuche.sms.remote.param;


import com.alibaba.fastjson.annotation.JSONField;
import com.zuzuche.commons.feign.annotation.PhpRequest;
import com.zuzuche.sms.dto.ExtraParamDto;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;

/**
 * 功能：插入总备注提交参数.
 * 详细：
 *
 * @author Created on 2019.03.15 by chaodian
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@PhpRequest
public class SendRemarkParam {
    @JSONField(name = "request_list_json")
    private Map<String, SendRemarkItem> remarkMaps;

    /**
     * 总备注提交的每个短信备注
     */
    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class SendRemarkItem {
        /**
         * 总备注的唯一id
         */
        @JSONField(name = "bussiness_id")
        private String businessId;

        /**
         * 来源网站
         */
        @Builder.Default
        private String website = "zzc";

        /**
         * 项目渠道
         */
        @Builder.Default
        private String project = "sms";

        /**
         * 客服账号
         */
        @JSONField(name = "admin_id")
        private String adminId;

        /**
         * 手机号码
         */
        private String phone;

        /**
         * 区号
         */
        @JSONField(name = "phone_code")
        private String phoneCode;

        /**
         * 短信内容
         */
        @JSONField(name = "sms_content")
        private String content;

        /**
         * 时间
         */
        @JSONField(name = "sort_time")
        private int sortTime;
        /**
         * 关联的订单数据,目前只有crc
         */
        @JSONField(name = "associate_order_json")
        private List<ExtraParamDto.OrderRelate> associateOrder;
        /**
         * 关联的工单号，多个逗号隔开。
         */
        @JSONField(name = "ticket_id_str")
        private String ticketIdStr;
    }
}
