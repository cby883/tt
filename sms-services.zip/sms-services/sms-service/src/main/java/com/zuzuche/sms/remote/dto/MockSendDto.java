package com.zuzuche.sms.remote.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @desc:
 * @author: panqiong
 * @date: 2018/11/12
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class MockSendDto {

    private String code;
    private String message;

    private Result data;

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class Result{
        /**
         * 短信提交成功后返回的批次号
         */
        private String batchno;

        /**
         * 短信提交响应状态码
         *
         */
        private String respcode;

        /**
         * 短信提交响应状态码说明
         */
        private String respdesc;

        /**
         * 日志id
         */
        private String logid;
    }


}
