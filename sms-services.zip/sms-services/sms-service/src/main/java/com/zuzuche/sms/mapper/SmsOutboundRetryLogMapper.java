package com.zuzuche.sms.mapper;

import com.zuzuche.commons.mybatis.BaseMapper;
import com.zuzuche.sms.entity.SmsOutboundRetryLog;
import org.springframework.stereotype.Repository;

/**
 * The interface Sms outbound retry log mapper.
 * @author Chaodian
 */
@Repository
public interface SmsOutboundRetryLogMapper extends BaseMapper<SmsOutboundRetryLog> {

}