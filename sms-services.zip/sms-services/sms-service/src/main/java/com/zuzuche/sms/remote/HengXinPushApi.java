package com.zuzuche.sms.remote;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.zuzuche.commons.base.util.JsonUtil;
import com.zuzuche.sms.remote.dto.PostHxSmsDto;
import com.zuzuche.sms.remote.dto.SendDto;
import com.zuzuche.sms.remote.param.PostHxSmsParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.client.ResourceAccessException;

import java.nio.charset.Charset;
import java.util.Arrays;

/**
 * 功能：卓越恒信供应商发送请求Api接口.
 * 详细：
 *
 * 返回状态码
 * 0: 成功加入发送个队列
 * 11: account参数错误
 * 12: mobile参数不能为空
 * 13: mobile个数过多
 * 14: 号码包含非数字字符
 * 15: 号码长度错误
 * 16: content参数错误
 * 17: 签名为空，内容必须带有【】格式的签名
 * 18： 无法校验签名(secret)值
 * 22:  签名校验失败(secret值不匹配)
 *
 *
 * @author Created on 2019.06.27 by chaodian
 */
@Component
@Slf4j
public class HengXinPushApi extends AbstractHttpInvoke {
    @Value("${provider.hengxin.pushurl}")
    private String pushurl ;

    /**
     * 额外的header设置 比如编码.
     *
     * charset需要UTF-8
     * content-type需要x-www-form-urlencoded
     *
     * @param header
     */
    @Override
    protected void setHeader(HttpHeaders header) {
        header.setAcceptCharset(Arrays.asList(Charset.forName("UTF-8")));
    }

    /**
     * 发送细节注意:
     * 1. 原先卓越恒信供应商发送短信接口的接口返回没有批次id，后面沟通加上，多了batch_id，因此回执的状态报告需要结合batch_id和手机唯一匹配;
     * 2. 后台登录地址： http://fastsms.happycheer.com， 账号为liangxianjing@zuzuche.com 密码为bee5o6
     * 3. 提交短信可以不用模板，但是最好报备，现在运营商管控的严
     *
     * @param param
     * @return
     */
    @HystrixCommand(groupKey = "hengXinGroup", commandKey = "postHxSms")
    public PostHxSmsDto send(PostHxSmsParam param) throws ResourceAccessException{

        String result = super.postForm(pushurl, param);

        try {
            PostHxSmsDto dto = JsonUtil.stringToObj(result, PostHxSmsDto.class);
            return dto;
        } catch (Exception e) {
            log.error("[卓越恒信发送短信接口]解析返回的响应json报错 接口相应内容result:"+result, e.getMessage(), e);
            PostHxSmsDto dto = PostHxSmsDto.builder()
                    .code("-99")
                    .message("json解析异常")
                    .build();
            return dto;
        }
    }
}
