package com.zuzuche.sms.dto;


import com.zuzuche.kafka.message.BaseMessage;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 功能： 主站订单短信日志信息.
 * 详细：
 *
 * @author Created on 2019.03.26 by chaodian
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class OrderSmsLogDto extends BaseMessage {
    /**
     * 手机号码
     */
    private String mobile;

    /**
     * 短信内容
     */
    private String content;

    /**
     * 订单号
     */
    private String uniqueId;

    /**
     * 操作人
     */
    private String admin;

}
