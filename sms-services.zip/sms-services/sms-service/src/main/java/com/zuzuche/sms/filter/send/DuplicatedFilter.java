package com.zuzuche.sms.filter.send;

import com.google.common.base.Joiner;
import com.google.common.base.Splitter;
import com.zuzuche.commons.base.util.ConcurrentSafeSet;
import com.zuzuche.commons.base.util.StringUtil;
import com.zuzuche.sms.common.constant.Constants;
import com.zuzuche.sms.common.utils.Md5Util;
import com.zuzuche.sms.common.utils.PerformUtil;
import com.zuzuche.sms.dto.BlockedSmsDto;
import com.zuzuche.sms.dto.SmsDto;
import com.zuzuche.sms.filter.Filter;
import com.zuzuche.sms.service.KafkaService;
import com.zuzuche.threadpool.ThreadPoolExecutorFactory;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.SetUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.*;
import java.util.stream.Collectors;

/**
 * @desc: 重复短信处理过滤器
 *       1.如果该条是重复短信,号码列表中每一个号码都是重复的 直接返回false 整个流程中断
 *       2.如果号码列表中有部分重复,那么将把这些重复的号码去掉,并收集起来发送到kafka队列 blocked_sms_topic
 * 20190227 改成多线程存取,适应redis集群
 * @author: panqiong
 * @date: 2018/10/26
 */
@Component
@Order(2)
@Slf4j
public class DuplicatedFilter implements Filter {

    private static final Constants.FilterTypes FILTER = Constants.FilterTypes.重复短信过滤器;

    @Autowired
    KafkaService kafkaService;

    @Autowired
    StringRedisTemplate redisTemplate;

    private static String SPLIT = ",";

    private static ExecutorService executor = ThreadPoolExecutorFactory
            .create(ThreadPoolExecutorFactory.Config.builder()
                    .corePoolSize(250)
                    .maximumPoolSize(300)
                    .keepAliveTime(5)
                    .workQueue(new ArrayBlockingQueue<>(1000))
                    .unit(TimeUnit.MINUTES)
                    .handler(new ThreadPoolExecutor.CallerRunsPolicy())
                    .threadPoolName("DuplicatedFilterRedisGetExecutor")
                    .build());


    /**
     *
     * @param sms
     * @return
     */
    @Override
    public boolean doFilter(SmsDto sms) {
        String taskId = sms.getTaskId();
        // 计算短信的md5
        final String md5Sms = sms.getRetryNo()>0?sms.getMd5Content():Md5Util.string2MD5(sms.getContent());
        // 设置md5值
        sms.setMd5Content(md5Sms);

        // 不重复号码集合
        List<String> noDuplicatedList = null;

        // 批量发送多个手机号码的
        if(sms.getMobile().contains(SPLIT)){
            // 这条短信已经存在,那么要判断每个号码是否发过这条短信
            List<String> mobileList = Splitter.on(",").splitToList(sms.getMobile());

            // 防重复标识位--> 手机号码+md5(短信内容)
            List<String> markKeyList = mobileList.parallelStream().map(mobile->mobile+md5Sms).collect(Collectors.toList());

            // 从缓存获取重复号码集合
            Set<String> dupplicatedList = getDupilcatedMobiles(markKeyList);

            if(CollectionUtils.isNotEmpty(dupplicatedList)){
                // 过滤出不重复的号码
                noDuplicatedList = mobileList.parallelStream().filter(m->!dupplicatedList.contains(m)).collect(Collectors.toList());
                // 将本次重复的号码短信发到kafka
                if(sms.getRetryNo()<=0){
                    BlockedSmsDto duSmsDto = BlockedSmsDto.builder()
                            .mobileList(dupplicatedList)
                            .taskId(taskId)
                            .filterType(FILTER)
                            .build();
                    kafkaService.sendToBlockedTopic(duSmsDto);
                }

            }else{
                noDuplicatedList = mobileList;
            }

            if(CollectionUtils.isNotEmpty(noDuplicatedList)){
                String mobiles = Joiner.on(",").join(noDuplicatedList);
                sms.setMobile(mobiles);
                return true;
            }else{
                // 直接过滤掉了 这个task
                return false;
            }
        }else{
            // 单个手机号码 检查
            String markkey = sms.getMobile()+md5Sms;
            String mobile = getFromRedis(markkey);
            if(StringUtil.isEmpty(mobile)){
                // 不重复
                return true;
            }else{
                Set set = new HashSet<>(1);
                set.add(sms.getMobile());

                // 将本次重复的号码短信发到kafka
                BlockedSmsDto duSmsDto = BlockedSmsDto.builder()
                        .mobileList(set)
                        .taskId(taskId)
                        .filterType(FILTER)
                        .build();
                kafkaService.sendToBlockedTopic(duSmsDto);
                // 直接过滤掉了 这个task
                return false;
            }
        }




    }

    /**
     * 从redis获取重复短信的手机号码
     * @param markKeyList 防重复标识位
     */
    public Set<String> getDupilcatedMobiles(List<String> markKeyList) {
        // 结果集
        ConcurrentSafeSet<String> safeSet = new ConcurrentSafeSet<>(200);

        long start = Instant.now().toEpochMilli();
        // 封装后无返回值，必须自己whenComplete()获取
        CompletableFuture[] cfs = markKeyList.stream()
                .map(markKey ->
                        CompletableFuture.supplyAsync(() -> getFromRedis(markKey), executor)
                                .whenComplete((s, e) -> safeSet.add(s))
                ).toArray(CompletableFuture[]::new);
        CompletableFuture.allOf(cfs).join();
        long end = Instant.now().toEpochMilli();
        PerformUtil.logTime("getDupilcatedMobiles",start,end);
        //list.stream().forEach(System.out::println);
        return safeSet;
    }

    /**
     * 根据防重复标识位 从redis获取关联的手机号码
     * 关系:
     * markkey:mobile
     * @param markKey
     * @return
     */
    private String getFromRedis(String markKey){
        return redisTemplate.opsForValue().get(markKey);
    }



}
