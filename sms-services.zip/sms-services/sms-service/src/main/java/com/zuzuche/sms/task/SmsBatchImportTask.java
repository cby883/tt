package com.zuzuche.sms.task;

import com.google.common.base.Joiner;
import com.zuzuche.commons.base.resp.Status;
import com.zuzuche.commons.base.resp.StatusServiceCnException;
import com.zuzuche.commons.base.util.StringUtil;
import com.zuzuche.commons.redis.RedisLock;
import com.zuzuche.kafka.sentry.MessageDto;
import com.zuzuche.kafka.sentry.SentryReport;
import com.zuzuche.sms.common.enums.SmsBatchSendTaskType;
import com.zuzuche.sms.common.enums.SmsFileRecordType;
import com.zuzuche.sms.dto.StatusReportDto;
import com.zuzuche.sms.entity.*;
import com.zuzuche.sms.listener.inner.StatusReportListener;
import com.zuzuche.sms.mapper.*;
import com.zuzuche.sms.rest.request.BatchSendReq;
import com.zuzuche.sms.service.FileManagementService;
import com.zuzuche.sms.service.KafkaService;
import com.zuzuche.sms.service.SmsBatchTaskService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;

import java.io.FileReader;
import java.io.IOException;
import java.text.MessageFormat;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

/**
 * 功能：大批量发送短信数据导入任务
 * 详细：
 *
 * @author Created on 2019.11.04 bingyi
 */
@Component
@Slf4j
@Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class SmsBatchImportTask implements Runnable {

    /**
     * 导入数据分布式锁key
     */
    private static final String SMS_BATCH_IMPORT_DATA_KEY = "SMS_BATCH_IMPORT_DATA_KEY_{0}_";
    SmsBatchTask smsBatchTask;

    private static final String REGEX = "\\d+";

    private static final int TOTAL = 200;
    @Autowired
    SmsUploadFileLogMapper smsUploadFileLogMapper;

    @Autowired
    SmsBatchTaskService smsBatchTaskService;

    @Autowired
    FileManagementService fileManagementService;

    @Autowired
    SmsFilePhoneListMapper smsFilePhoneListMapper;


    public SmsBatchImportTask(SmsBatchTask smsBatchTask) {
        this.smsBatchTask = smsBatchTask;
    }

    /**
     * ①先判断文件记录是否被录入过
     * ②导入数据
     * ③修改task状态
     */
    private void execute() {
        //查出文件记录
        SmsUploadFileLog fileLog = smsUploadFileLogMapper.findById(smsBatchTask.getFileId());
        //找不到文件，设置此次任务为异常状态
        if (fileLog == null) {
            smsBatchTask.setStatus(SmsBatchSendTaskType.SMS_BATCH_SEND_TASK_TYPE_ERROR.code());
            smsBatchTaskService.updateById(smsBatchTask);
            throw new StatusServiceCnException(Status.BUSY, "找不到文件，请检查");
        }
        //针对同一批文件id,设置分布式锁
        String redisKey = MessageFormat.format(SMS_BATCH_IMPORT_DATA_KEY, fileLog.getId());
        //分布式锁获取锁等待100秒
        RedisLock redisLock = new RedisLock(redisKey, 100000);
        //开始导入数据，导入数据必须设置分布式锁，避免同批数据重复导入，导致数据错乱
        if (redisLock.lock()) {
            try {
                //判断是否为数据不完整状态
//                if (fileLog.getRecorded() == SmsFileRecordType.SMS_FILE_RECORD_TYPE_NOT_COMPLETE.code()) {
//                    smsBatchTask.setStatus(SmsBatchSendTaskType.SMS_BATCH_SEND_TASK_TYPE_ERROR.code());
//                    smsBatchTaskService.updateById(smsBatchTask);
//                    //数据不完整，请重新上传文件
//                    throw new StatusServiceCnException(Status.BUSY, "数据不完成，请重新上传数据文件");
//                }
//                //判断是否为已导入的文件
//                if (fileLog.getRecorded() == SmsFileRecordType.SMS_FILE_RECORD_TYPE_IS_IMPORT.code()) {
//                    smsBatchTask.setStatus(SmsBatchSendTaskType.SMS_BATCH_SEND_TASK_TYPE_START.code());
//                    smsBatchTaskService.updateById(smsBatchTask);
////                    return;
////                }
//                if (importData(fileLog)) {
//                    //设置文件记录为已导入
//                    fileLog.setRecorded(SmsFileRecordType.SMS_FILE_RECORD_TYPE_IS_IMPORT.code());
//                    fileManagementService.updateById(fileLog);
//                    smsBatchTask.setStatus(SmsBatchSendTaskType.SMS_BATCH_SEND_TASK_TYPE_START.code());
//                    smsBatchTaskService.updateById(smsBatchTask);
//                } else {
//                    //导入失败，修改文件记录状态为不完整状态，同时设置任务状态为失败状态
//                    fileLog.setRecorded(SmsFileRecordType.SMS_FILE_RECORD_TYPE_NOT_COMPLETE.code());
//                    fileManagementService.updateById(fileLog);
//                    smsBatchTask.setStatus(SmsBatchSendTaskType.SMS_BATCH_SEND_TASK_TYPE_ERROR.code());
//                    smsBatchTaskService.updateById(smsBatchTask);
//                }
            } finally {
                redisLock.unlock();
            }
        } else {
            //等待100秒后，仍然获取不到锁，直接设置任务失败
            smsBatchTask.setStatus(SmsBatchSendTaskType.SMS_BATCH_SEND_TASK_TYPE_ERROR.code());
            smsBatchTaskService.updateById(smsBatchTask);
        }
    }

    @Override
    public void run() {
        execute();
    }
}
