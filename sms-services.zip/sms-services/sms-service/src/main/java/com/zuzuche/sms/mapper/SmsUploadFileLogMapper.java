package com.zuzuche.sms.mapper;

import com.zuzuche.commons.mybatis.BaseMapper;
import com.zuzuche.sms.entity.SmsBatchTask;
import com.zuzuche.sms.entity.SmsUploadFileLog;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

/**
 * desc:
 *
 * @author bingyi
 * @date 2019/10/30
 */
@Repository
public interface SmsUploadFileLogMapper extends BaseMapper<SmsUploadFileLog> {
    /**
     * desc:根据id查出文件
     * @param id
     * @return
     */
    public SmsUploadFileLog findById(@Param("id")String id);

    /**
     * 查出某一状态的文件记录
     * @param recorded
     * @return
     */
    public List<SmsUploadFileLog> findByRecord(@Param("recorded") int recorded, @Param("beginTime")LocalDateTime localDateTime);

}