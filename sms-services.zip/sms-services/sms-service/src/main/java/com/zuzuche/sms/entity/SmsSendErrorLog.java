package com.zuzuche.sms.entity;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Table;


/**
 * 功能：The type Sms send error log.
 * 详细：
 *
 * @author Created on 2019.02.25 by chaodian
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "zuzuche_sms_db.sms_send_error_log_tbl")
public class SmsSendErrorLog {
    /**
     * 主键id
     */
    private Long id;

    /**
     * 错误日志类型
     */
    private int type;

    /**
     * 手机号码
     */
    private String mobile;

    /**
     * 错误提示
     */
    private String msg;

    /**
     * 添加时间戳
     */
    private Long addTime;

    /**
     * 短信内容
     */
    private String content;
}