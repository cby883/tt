package com.zuzuche.sms.remote.param;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @desc:
 * @author: panqiong
 * @date: 2018/11/12
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class MockSendParam {
    private String mobiles;
    private String content;

    @Override
    public String toString() {
        return "MockSendParam{" +
                "mobiles='" + mobiles + '\'' +
                ", content='" + content + '\'' +
                '}';
    }
}
