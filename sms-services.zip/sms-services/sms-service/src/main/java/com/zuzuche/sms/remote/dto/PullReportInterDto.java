package com.zuzuche.sms.remote.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @desc: 创蓝状态报告拉取
 * @author: panqiong
 * @date: 2018/11/12
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PullReportInterDto {
    /**
     * 请求状态。0成功，其他状态为失败
     */
    private String code;
    private String error;
    private List<Report> result;


    @Data
    @Builder
    @AllArgsConstructor
    @NoArgsConstructor
    public static class Report{
        /**
         * I2170326_1808142031_0000000
         */
        private String batchSeq;
        /**
         *8618037170702
         */
        private String mobile;
        /**
         * 18081509281005782276
         */
        private String msgid;
        /**
         * 1808150928
         */
        private String reportTime;
        /**
         * DELIVRD
         */
        private String status;

    }
}
