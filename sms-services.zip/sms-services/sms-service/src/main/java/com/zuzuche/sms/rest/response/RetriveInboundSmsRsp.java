package com.zuzuche.sms.rest.response;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * @desc:
 * @author: panqiong
 * @date: 2018/10/24
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ApiModel(value = "上行短信对象")
public class RetriveInboundSmsRsp {

    @ApiModelProperty(value = "短信id",required = false)
    private int smsId;

    @ApiModelProperty(value = "手机号码",required = false)
    private String mobile;


    @ApiModelProperty(value = "短信内容",required = false)
    private String content;


    @ApiModelProperty(value = "账户id",required = false)
    private int accountId;


    @ApiModelProperty(value = "账户类型 1：验证码类型  2:营销短信类型",required = false)
    private int accountType;


    @ApiModelProperty(value = "端口",required = false)
    private String port;

    @ApiModelProperty(value = "时间",required = false)
    private LocalDateTime time;
}
