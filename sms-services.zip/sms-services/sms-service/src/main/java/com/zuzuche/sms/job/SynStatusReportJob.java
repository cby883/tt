package com.zuzuche.sms.job;
import com.zuzuche.commons.base.util.StringUtil;
import com.zuzuche.commons.redis.DistributeJobExecutor;
import com.zuzuche.logback.util.MDCUtil;
import com.zuzuche.sms.cache.ProviderAccountCache;
import com.zuzuche.sms.cache.SmsClassConfigCache;
import com.zuzuche.sms.common.utils.SpringBeanFactory;
import com.zuzuche.sms.entity.SmsClassConfig;
import com.zuzuche.sms.report.syn.SynService;
import com.zuzuche.threadpool.ThreadPoolExecutorFactory;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.text.MessageFormat;
import java.util.Set;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * @desc: 从供应商同步上行短信
 * @author: panqiong
 * @date: 2018/11/8
 */
@Component
@Slf4j
public class SynStatusReportJob {
    private static AtomicInteger atomicInteger = new AtomicInteger(0);


    /**
     * 状态报告同步线程池
     * 溢出策略 最长阻塞主线程60秒后抛出异常
     */
    private static ExecutorService executor = ThreadPoolExecutorFactory.create(
            ThreadPoolExecutorFactory.Config.builder()
                    .corePoolSize(4)
                    .maximumPoolSize(4)
                    .keepAliveTime(5)
                    .workQueue(new ArrayBlockingQueue<>(10))
                    .unit(TimeUnit.MINUTES)
                    .handler(new ThreadPoolExecutor.CallerRunsPolicy())
                    .threadPoolName("synStatusReport-pool")
                    .build());

    private static String STATUS_REPORT_SMS_KEY = "SMS:SYN_STATUS_REPORT_KEY_{0}_";

    private static final int MX_PROVIDER=8;


    @Autowired
    StringRedisTemplate redisTemplate;

    @Autowired
    DistributeJobExecutor distributeJobExecutor;

    /**
     *  每30秒
     */
    @Scheduled(cron = "*/30 * * * * ?")
    public void execute(){
        MDCUtil.set();
        Set<Integer> providerList = ProviderAccountCache.getProviderListMap().keySet();
        if(CollectionUtils.isEmpty(providerList)){
            log.error("[SynStatusReportJob] 没有配置供应商信息");
            return ;
        }
        providerList.stream().forEach(providerId->{
            executor.submit(()->{
                try{
                    String jobKey = MessageFormat.format(STATUS_REPORT_SMS_KEY,providerId);
                    distributeJobExecutor.doEveryThirtySecond(jobKey,()->{
                        SmsClassConfig synClazz = SmsClassConfigCache.getByProviderId(providerId);
                        String beanName = synClazz.getSynServiceClass();
                        if (StringUtil.isNotBlank(beanName)) {
                            SynService synService = (SynService)SpringBeanFactory.getBean(beanName);
                            if (providerId!=MX_PROVIDER) {
                                synService.synStatusReport(providerId);
                            }
                        }
                        return true;
                    });
                }catch (Exception e){
                    log.error("[状态报告同步任务执行报错] providerId:"+providerId,e.getMessage(),e);
                }
            });
        });
        MDCUtil.clear();
    }





}
