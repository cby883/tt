package com.zuzuche.sms.remote.param;

import com.alibaba.fastjson.annotation.JSONField;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @desc:
 * @author: panqiong
 * @date: 2018/11/5
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PostSmsParam {

    /**
     * 必填参数，用户id
     */
    @JSONField(name="id")
    private String id;

    /**
     * （密码+业务代码）MD5加密码
     */
    @JSONField(name="MD5_td_code")
    private String md5TdCode;


    /**
     * 下发用户手机号
     * 多个号码之间用英文逗号隔开，且一次群发总号码数不能超过200个
     */
    @JSONField(name="mobile")
    private String mobile;

    /**
     * 短信内容
     * 短信内容长度不超过1000个汉字（包括1000字），每个英文或阿拉伯字符也算1个汉字
     */
    @JSONField(name="msg_content")
    private String msgContent;

    /**
     * 用户发送短信时自己定义的短信id，用于区分状态报告。
     * 参数名必须填写，参数值可为空，为空时，系统自动生成
     * 总长度不能超过50个字符
     */
    @JSONField(name="msg_id")
    private String msgId;

    /**
     * 用户自行分配扩展号。参数名必须填写，参数值可为空。
     * 该参数是显示在接收手机上的主叫尾号，可用于上行信息匹配，
     * 例：我方给合作方主叫号码号为：10657532521924，合作方在发送信息时可随意填写扩展号（需为0-9数字）ext=8888，那么用户收到信息时显示的下发号码就是106575325219248888
     * 通道本身主叫号码加上用户自己分配扩展号的总长度不能超过20位
     */
    @JSONField(name="ext")
    private String ext;
}
