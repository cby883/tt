package com.zuzuche.sms.remote.param;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @desc:
 * @author: panqiong
 * @date: 2018/11/12
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SendInterParam {
    /**
     * 用户在253云通讯平台上申请的API账号
     */
    private String account;

    /**
     * 用户在253云通讯平台上申请的API账号对应的API密钥
     */
    private String password;

    /**
     * 短信内容。长度不能超过536个字符
     */
    private String msg;

    /**
     * 手机号码。多个手机号码使用英文逗号分隔
     */
    private String mobile;

    /**
     * 用户收到短信之后显示的发件人，国内不支持自定义，国外支持，但是需要提前和运营商沟通注册，具体请与TIG对接人员确定。 选填
     */
    private String sendId;


    @Override
    public String toString() {
        return "SendInterParam{" +
                "account='" + account + '\'' +
                ", msg='" + msg + '\'' +
                ", mobile='" + mobile + '\'' +
                ", sendId='" + sendId + '\'' +
                '}';
    }
}
