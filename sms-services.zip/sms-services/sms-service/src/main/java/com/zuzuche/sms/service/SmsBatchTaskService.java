package com.zuzuche.sms.service;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.zuzuche.commons.base.resp.Status;
import com.zuzuche.commons.base.resp.StatusServiceCnException;
import com.zuzuche.commons.base.util.BeanConverter;
import com.zuzuche.commons.mybatis.PageData;
import com.zuzuche.sms.common.enums.SmsBatchSendTaskType;
import com.zuzuche.sms.common.utils.SpringBeanFactory;
import com.zuzuche.sms.entity.SmsBatchMtTbl;
import com.zuzuche.sms.entity.SmsBatchTask;
import com.zuzuche.sms.entity.SmsUploadFileLog;
import com.zuzuche.sms.mapper.SmsBatchMtTblMapper;
import com.zuzuche.sms.mapper.SmsBatchTaskMapper;
import com.zuzuche.sms.mapper.SmsUploadFileLogMapper;
import com.zuzuche.sms.rest.request.BatchSendReq;
import com.zuzuche.sms.rest.request.BatchTaskReq;
import com.zuzuche.sms.rest.response.BatchTaskRsp;
import com.zuzuche.sms.task.SmsBatchImportTask;
import com.zuzuche.threadpool.ThreadPoolExecutorFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * desc:文件上传状态service
 *
 * @author bingyi
 * @date 2016/10/31
 */
@Slf4j
@Service
public class SmsBatchTaskService {


    @Autowired
    SmsBatchMtTblMapper smsBatchMtTblMapper;

    @Autowired
    SmsUploadFileLogMapper smsUploadFileLogMapper;
    ExecutorService executorService = ThreadPoolExecutorFactory.create(
            ThreadPoolExecutorFactory.Config.builder()
                    .corePoolSize(5)
                    .maximumPoolSize(5)
                    .keepAliveTime(5)
                    .workQueue(new ArrayBlockingQueue<>(50))
                    .unit(TimeUnit.MINUTES)
                    .handler(new ThreadPoolExecutor.CallerRunsPolicy())
                    .threadPoolName("SmsBatchTaskExecutor")
                    .build());
    @Autowired
    SmsBatchTaskMapper smsBatchTaskMapper;


    /**
     * 创建任务：
     * ①保存发送短信的相关内容
     * ②创建此次任务的上下文context
     *
     * @param batchSendReq
     * @return
     */
    public SmsBatchTask createBatchTask(BatchSendReq batchSendReq) {
        //保存短信内容信息
        SmsBatchMtTbl smsBatchMtTbl = BeanConverter.copy(batchSendReq, SmsBatchMtTbl.class);
        //设置添加时间
        smsBatchMtTbl.setAddTime(LocalDateTime.now());
        int count = smsBatchMtTblMapper.insertUseGeneratedKeys(smsBatchMtTbl);
        if (count <= 0) {
            //插入不成功，直接报错
            throw new StatusServiceCnException(Status.BUSY, "短信内容插入失败");
        }
        //查出文件log
        SmsUploadFileLog smsUploadFileLog = smsUploadFileLogMapper.findById(batchSendReq.getFileId());
        if (smsUploadFileLog == null) {
            throw new StatusServiceCnException(Status.BUSY, "文件不存在");
        }
        //构造任务实体,偏移量offset=0表示从头开始
        SmsBatchTask smsBatchTask = SmsBatchTask.builder()
                .fileId(smsUploadFileLog.getImportPhoneBatch())
                .status(SmsBatchSendTaskType.SMS_BATCH_SEND_TASK_TYPE_READY.code())
                .offset(0)
                .fileType(smsUploadFileLog.getFileType())
                .batchMtId(smsBatchMtTbl.getId())
                .createTime(LocalDateTime.now())
                .updateTime(LocalDateTime.now())
                .smsType(batchSendReq.getType())
                .deleted(0)
                .planSendTime(batchSendReq.getPlanSendTime() == null ?
                        LocalDateTime.now() : batchSendReq.getPlanSendTime())
                .build();

        //插入任务
        if (smsBatchTaskMapper.insertUseGeneratedKeys(smsBatchTask) > 0) {
            return smsBatchTask;
        } else {
            //插入不成功，直接报错
            throw new StatusServiceCnException(Status.BUSY, "创建任务失败");
        }
    }

    public int updateById(SmsBatchTask smsBatchTask) {
        return smsBatchTaskMapper.updateByPrimaryKeySelective(smsBatchTask);
    }

    /**
     * 创建文件导入数据任务
     *
     * @param smsBatchTask
     * @return
     */
    private SmsBatchImportTask packingTask(SmsBatchTask smsBatchTask) {
        return SpringBeanFactory.getBean(SmsBatchImportTask.class, smsBatchTask);
    }

    /**
     * 批量查询任务
     *
     * @return
     */
    public PageData<BatchTaskRsp> searchBatchTask(BatchTaskReq batchTaskReq) {
        //查询出列表
        PageHelper.startPage(batchTaskReq.getPage(), batchTaskReq.getPageSize());
        Page<SmsBatchTask> smsBatchTasks = (Page<SmsBatchTask>) smsBatchTaskMapper.selectList(batchTaskReq.getId(), batchTaskReq.getStartTime(), batchTaskReq.getEndTime());

        List<BatchTaskRsp> result = BeanConverter.copyList(smsBatchTasks.getResult(), BatchTaskRsp.class);
        //封装返回对象
        result.forEach(e -> {
            int taskId = e.getId();
            SmsBatchMtTbl smsBatchMtTbl = smsBatchMtTblMapper.selectByPrimaryKey(e.getBatchMtId());
            BeanConverter.copy(smsBatchMtTbl, e);
            e.setId(taskId);
        });
        //构造分页对象返回
        PageData<BatchTaskRsp> pageData = PageData.emptyResult();
        pageData.setRows(result);
        pageData.setTotal(smsBatchTasks.getTotal());

        //返回
        return pageData;
    }

    /**
     * 查询时间范围以内的sms_batch_task的记录
     *
     * @return
     */
    public List<SmsBatchTask> selectInDays(LocalDateTime startTime, LocalDateTime endTime) {
        return smsBatchTaskMapper.selectInDays(startTime, endTime);
    }

}
