package com.zuzuche.sms.filter.dispatch;


import com.zuzuche.sms.cache.SupplierConfigCache;
import com.zuzuche.sms.cache.co.SupplierConfigCo;
import com.zuzuche.sms.common.enums.FilterTypes;
import com.zuzuche.sms.dto.MtDto;
import com.zuzuche.sms.filter.MtFilter;
import com.zuzuche.sms.service.KafkaService;
import com.zuzuche.sms.service.SmsMtService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

/**
 * 功能：短信的供应商账户id匹配过滤器.
 * 详细：
 *
 * @author Created on 2019.03.20 by chaodian
 */
@Component
@Slf4j
public class MtAccountIdMatchFilter{
    @Autowired
    SupplierConfigCache supplierConfigCache;

    @Autowired
    KafkaService kafkaService;

    @Autowired
    SmsMtService smsMtService;

    /**
     * 默认的供应商accountId
     */
    private static final int DEFAULT_ACCOUNT_ID = 0;

    /**
     * 设置短信供应商accountId.
     *
     * 返回true则表示匹配供应商accountId成功
     * 返回false则匹配失败，无法进行提交短信
     *
     * @param mtDto the mt dto
     * @return boolean
     */
    public boolean doFilter(MtDto mtDto) {
        // 获取供应商配置项
        SupplierConfigCo co = supplierConfigCache.getConfig(mtDto.getSupplier(), mtDto.getRegionType(), mtDto.getType());

        if (co == null) {
            log.error("找不到匹配供应商账户配置项，短信数据如下:" + mtDto.toString());
            kafkaService.sendToFilterTopic(mtDto.getMobiles(), mtDto.getContent(), FilterTypes.匹配供应商账户出错过滤器);
            smsMtService.trashMtAllMobiles(mtDto);
            return false;
        }

        if (co.getAccountId() > DEFAULT_ACCOUNT_ID) {
            mtDto.setAccountId(co.getAccountId());
            return true;
        }

        log.error("匹配供应商accountId失败，短信数据如下:" + mtDto.toString());
        kafkaService.sendToFilterTopic(mtDto.getMobiles(), mtDto.getContent(), FilterTypes.匹配供应商账户出错过滤器);
        smsMtService.trashMtAllMobiles(mtDto);
        return false;
    }
}
