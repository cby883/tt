package com.zuzuche.sms.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Table;
import java.time.LocalDateTime;
import java.util.Date;
/**
 * desc:批量上传状态报告
 *
 * @author bingyi
 * @date 2019/10/30
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "zuzuche_sms_db.sms_batch_send_report")
public class SmsBatchSendReport {
    private Integer id;

    private String batchNo;

    private Integer pushTotal;

    private Integer pushSuccess;

    private Integer pushFail;

    private Integer arrivalSuccess;

    private Integer arrivalFail;

    private Integer billCount;

    private LocalDateTime createTime;

    private LocalDateTime updateTime;
}