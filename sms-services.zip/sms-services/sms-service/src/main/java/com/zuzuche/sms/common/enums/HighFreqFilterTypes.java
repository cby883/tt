package com.zuzuche.sms.common.enums;

import com.zuzuche.commons.base.constants.BaseEnum;

/**
 * 短信发送频率过快拦截器类型枚举.
 */
public enum HighFreqFilterTypes implements BaseEnum<Integer> {
    /**
     * 短信发送频率过高 high freq filter types.
     */
    短信发送频率过高(1, "SMS::MOBILE_FREQ", "monitorSamePhoneFreq", 60, 12),

    /**
     * 验证码发送频率过高 high freq filter types.
     */
    验证码发送频率过高(2, "SMS::VERIFY_FREQ", "monitorSamePhoneVerify", 120, 5),

    /**
     * 营销短信发送频率过高 high freq filter types.
     */
    营销短信发送频率过高(3, "SMS::MARKET_FREQ", "monitorSamePhoneMarketFreq", 172800, 1);

    private Integer code;

    /**
     * 保存在redis的缓存key
     */
    private String cacheKeyName;

    /**
     * 获取的拦截监控规则配置名
     */
    private String safeMonitorRuleNm;

    /**
     * 默认的拦截时间范围，精确到秒
     */
    private int defaultDuration;

    /**
     * 默认的拦截频率
     */
    private int defaultFreq;

    HighFreqFilterTypes(Integer code, String cacheKeyName, String safeMonitorRuleNm, int defaultDuration, int defaultFreq) {
        this.code = code;
        this.cacheKeyName = cacheKeyName;
        this.safeMonitorRuleNm = safeMonitorRuleNm;
        this.defaultDuration = defaultDuration;
        this.defaultFreq = defaultFreq;
    }

    @Override
    public Integer code() {
        return code;
    }

    /**
     * Gets cache key name.
     *
     * @return the cache key name
     */
    public String getCacheKeyName() {
        return cacheKeyName;
    }

    /**
     * Gets safe monitor rule nm.
     *
     * @return the safe monitor rule nm
     */
    public String getSafeMonitorRuleNm() {
        return safeMonitorRuleNm;
    }

    /**
     * Gets default duration.
     *
     * @return the default duration
     */
    public int getDefaultDuration () {
        return defaultDuration;
    }

    /**
     * Gets default freq.
     *
     * @return the default freq
     */
    public int getDefaultFreq() {
        return defaultFreq;
    }
}
