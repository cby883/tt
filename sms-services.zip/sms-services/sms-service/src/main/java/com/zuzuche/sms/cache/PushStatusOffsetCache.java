package com.zuzuche.sms.cache;

import com.zuzuche.commons.redis.CacheExecutor;
import com.zuzuche.commons.redis.CacheExpires;
import com.zuzuche.sms.entity.SmsConfig;
import com.zuzuche.sms.mapper.SmsConfigMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;

/**
 * @desc: 状态报告拉取位置保存
 * @author: panqiong
 * @date: 2018/10/24
 */
@Slf4j
@Component()
public class PushStatusOffsetCache {

    public final static String PUSH_STATUS_OFFSET_KEY="SMS:RETRIVE_PUSH_STATUS_OFFSET";

    @Autowired
    SmsConfigMapper offsetMapper;

    @Autowired
    StringRedisTemplate redisTemplate;

    CacheExecutor<String> cacheExcutor = CacheExecutor.create(PUSH_STATUS_OFFSET_KEY, String.class, CacheExpires.PERMANENT);


    /**
     * 从缓存获取
     * 弱没有则穿透db查询
     * @return
     */
    public String get(){
        String value = cacheExcutor.get(PUSH_STATUS_OFFSET_KEY,(key)->{
            SmsConfig offset = offsetMapper.queryOffset((String)key);
            if(offset!=null){
                return offset.getConfigValue();
            }
            return null;
        });
        return value;
    }

    /**
     * 更新缓存和db
     * @param value
     */
    public void set(String value){
        redisTemplate.opsForValue().set(PUSH_STATUS_OFFSET_KEY,value);
        offsetMapper.updateOffset(PUSH_STATUS_OFFSET_KEY,value,LocalDateTime.now());

    }




}
