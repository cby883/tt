package com.zuzuche.sms.mapper;

import com.zuzuche.commons.mybatis.BaseMapper;
import com.zuzuche.sms.entity.SmsMt;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Set;

/**
 * The interface Sms mt mapper.
 */
@Repository
public interface SmsMtMapper extends BaseMapper<SmsMt> {

    /**
     * Query by task id sms mt.
     *
     * @param taskId the task id
     * @return the sms mt
     */
    @Select("SELECT * FROM zuzuche_sms_db.sms_mt_tbl WHERE task_id = #{taskId}")
    SmsMt queryByTaskId(@Param("taskId") int taskId);

    /**
     * Update request status by task id int.
     *
     * @param taskId        the task id
     * @param requestStatus the request status
     * @param supplier      the supplier
     * @param mobileList    the mobile list
     * @return the int
     */
    int updateRequestStatusByTaskId(@Param("taskId") int taskId, @Param("requestStatus") int requestStatus, @Param("supplier") String supplier, @Param("mobileList") List<String> mobileList);

    /**
     * Update repeat mobiles status int.
     *
     * @param taskId     the task id
     * @param mobileList the mobile list
     * @return the int
     */
    int updateRepeatMobilesStatus(@Param("taskId") int taskId, @Param("mobileList") Set<String> mobileList);

    /**
     * desc:
     * @param smsMt
     * @return
     */
    int updateStatusByMobileAndTaskId(SmsMt smsMt);

    /**
     * 根据batchNo查询计费条数
     * @param batchNo
     * @return
     */
    Integer searchBillCountByBatchNo(@Param("batchNo")String batchNo);

    /**
     * 查询短信到达成功数量
     * @param batchNo
     * @return
     */
    int arrivalSuccessByBatchNo(@Param("batchNo")String batchNo);

    /**
     * 查询短信到达失败数量
     * @param batchNo
     * @return
     */
    int arrivalFailByBatchNo(@Param("batchNo")String batchNo);

    /**
     * 查询短信推送总数
     * @param batchNo
     * @return
     */
    int pushCountByBatchNo(@Param("batchNo")String batchNo);

    /**
     * 成功推送总数
     * @param batchNo
     * @return
     */
    int pushSuccessByBatchNo(@Param("batchNo")String batchNo);
}