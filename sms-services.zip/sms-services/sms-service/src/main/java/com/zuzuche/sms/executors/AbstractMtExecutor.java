package com.zuzuche.sms.executors;

import com.zuzuche.commons.base.resp.StatusServiceException;
import com.zuzuche.sms.common.utils.SpringBeanFactory;
import com.zuzuche.sms.dto.MtDto;
import com.zuzuche.sms.filter.FilterManager;
import com.zuzuche.sms.task.MtDispatchTask;
import com.zuzuche.threadpool.ThreadPoolExecutorFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.RejectedExecutionException;

/**
 * 功能：业务短信下行服务, 模板模式抽象类.
 * 详细：
 *
 * @author Created on 2019.02.14 by chaodian
 */
@Slf4j
public abstract class AbstractMtExecutor {

    @Autowired
    FilterManager filterManager;

    /**
     * 线程池
     * 溢出策略 最长阻塞主线程60秒后抛出异常
     */
    private ExecutorService executorService;

    /**
     * Instantiates a new Abstract mt executor.
     *
     * @param confg the confg
     */
    public AbstractMtExecutor(ThreadPoolExecutorFactory.Config confg){
        //初始化线程池
        executorService = ThreadPoolExecutorFactory.create(confg);
    }

    /**
     * 下行逻辑处理
     * 1.持久化数据,统一实现. 持久化数据放在主流程 .数据消费后尽快入库,增强可靠性 ,吞吐率不是重点,先保证可靠性.如果要提高吞吐能力,入库放在异步流程
     * 2.将短信包装成task
     * 3.提交task到线程池
     * @param sms
     */
    public void handle(MtDto sms) throws RejectedExecutionException {
        // 将mt业务短信打包封装成task
        MtDispatchTask task = packingSendTask(sms);
        // 提交到对应线程池
        executorService.submit(task);
    }

    /**
     * 将mt业务短信打包封装成task.
     *
     * @param sms the sms
     * @return the mt send task
     */
    public MtDispatchTask packingSendTask(MtDto sms)  {

        MtDispatchTask sendTask = SpringBeanFactory.getBean(MtDispatchTask.class, sms);

        return sendTask;

    }


}
