package com.zuzuche.sms.remote.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
/**
 * Demo class
 *
 * @author bingyi
 * @date 2016/10/31
 */
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class SmsContentDto{
    /**
     * 短信模板code
     */
    @Builder.Default
    String msg="";
}
