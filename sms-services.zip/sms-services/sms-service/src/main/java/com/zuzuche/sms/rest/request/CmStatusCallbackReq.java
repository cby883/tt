package com.zuzuche.sms.rest.request;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

/**
 * 功能：CM供应商状态报告回调接口协议.
 * 详细：
 * 下面的短信回调由于是供应商要求的get参数，不符合驼峰命名规范，比较特殊
 *
 * @author Created on 2019.09.08 by chaodian
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@ApiModel(value = "CM供应商状态报告回调接口")
public class CmStatusCallbackReq {
    /**
     * 报告创建时间
     */
    private String CREATED_S;

    /**
     * 报告发送时间
     */
    private String DATETIME_S;

    /**
     * 收件人号码
     */
    private String GSM;

    /**
     * 自定义的短信 ID
     */
    private String REFERENCE;

    /**
     * 错误名称
     */
    private String STANDARDERRORTEXT;

    /**
     * 短信状态.
     * 0=接收成功,
     * 1=接收被拒绝,
     * 2=发送成功,
     * 3=发送失败
     */
    private String STATUS;

    /**
     * 错误描述
     */
    private String STATUSDESCRIPTION;
}
