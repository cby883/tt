package com.zuzuche.sms.common.enums;

import com.zuzuche.commons.base.constants.BaseEnum;


/**
 * desc:配置刷新配置名称枚举类
 *
 * @author bingyi
 * @date 2019-09-24
 */
public enum ConfigNameTypes implements BaseEnum<String> {
    /**
     *供应商账户备份关联数据缓存
     */
    ACCOUNT_ID_BAK("accountIdBakPolicy","AccountIdBakPolicyCache","供应商账户备份关联数据缓存"),
    /**
     *
     */
    BLACK_WRITE_MOBILE("blackWhite","BlackWiteMobileCache","黑白名单手机配置缓存"),
    /**
     *
     */
    SAFE_MONITOR_RULE("safeMonitorRule","SafeMonitorRuleCache","拦截安全规则配置缓存"),
    /**
     *
     */
    SMS_SIGN("smsSign","SmsSignCache","签名配置缓存"),
    /**
     *
     */
    SUPPLIER_CONFIG("supplierConfig","SupplierConfigCache","供应商配置缓存"),
    /**
     *
     */
    SUPPLIER_MATCH("supplierMatchRule","SupplierMatchRuleCache","短信发送规则与供应商匹配"),
    /**
     *
     */
    SMS_TEMPLATE("smsTemplate","SmsTemplateCache","短信模板配置"),
    /**
     *
     */
    SMS_CUSTOMER_CACHE("smsCustomerCache","SmsCustomerCache","短信业务方配置");


    /**
     * 编码
     */
    private String code;
    /**
     * 配置名称
     */
    private String configName;
    /**
     * 配置名称描述
     */
    private String description;

    ConfigNameTypes(String code,String configName,String description){
        this.code=code;
        this.configName=configName;
        this.description=description;
    }

    @Override
    public String code() {
        return this.code;
    }

    public String getConfigName(){
        return this.configName;
    }

    public String getDescription(){
        return this.description;
    }
}