package com.zuzuche.sms.remote.dto;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @desc: 阿里云提交短信dto
 * @author: bingyi
 * @date: 2019/08/12
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class AliYunSmsSendDto {
    /**
     * 请求id
     */
    @JSONField(name = "RequestId")
    private String requestId;
    /**
     * 返回信息
     */
    @JSONField(name = "Message")
    private String message;
    /**
     * 返回状态码
     */
    @JSONField(name = "Code")
    private String code;

    /**
     * 批次号，用于查询状态报告
     */
    @JSONField(name = "BizId")
    private String bizId;

}
