package com.zuzuche.sms.filter.dispatch;

import com.google.common.base.Joiner;
import com.zuzuche.commons.base.util.StringUtil;
import com.zuzuche.sms.cache.SignLanguageTypeCache;
import com.zuzuche.sms.cache.SupplierMatchRuleCache;
import com.zuzuche.sms.common.enums.FilterTypes;
import com.zuzuche.sms.common.enums.NeedInterPrefixSuppliers;
import com.zuzuche.sms.dto.MtDto;
import com.zuzuche.sms.filter.MtFilter;
import com.zuzuche.sms.service.KafkaService;
import com.zuzuche.sms.service.SmsMtService;
import com.zuzuche.sms.service.SupplierMatchService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * 功能：短信供应商匹配过滤器.
 * 详细：
 *
 * @author Created on 2019.03.20 by chaodian
 */
@Component
@Slf4j
@Order(6)
public class MtSupplierMatchFilter implements MtFilter {
    /**
     * The Supplier match service.
     */
    @Autowired
    SupplierMatchService supplierMatchService;

    /**
     * The Kafka service.
     */
    @Autowired
    KafkaService kafkaService;

    /**
     * The Sms mt service.
     */
    @Autowired
    SmsMtService smsMtService;

    @Autowired
    SignLanguageTypeCache signLanguageTypeCache;

    /**
     * The Rule cache.
     */
    @Autowired
    SupplierMatchRuleCache ruleCache;




    @Override
    public boolean doFilter(MtDto sms) {
        // 所有的白名单必须在该拦截器开始执行
        if (StringUtil.isNotBlank(sms.getWhiteMobiles())) {
            smsMtService.joinWhiteMobsToTotalMobs(sms);
        }

        //根据accountId 权重去选择供应商
        int accountId = getAccountIdFromRulesWithSignLanguage(sms);
        if (accountId > 0) {
            String supplier = ruleCache.getSupplierByAccountId(accountId);
            if(StringUtil.isNotBlank(supplier)){
                sms.setAccountId(accountId);
                sms.setSupplier(supplier);
                addMobilePrefix(sms);
                return true;
            }else{
                log.error("匹配不到供应商, 短信数据为:" + sms.toString());
                kafkaService.sendToFilterTopic(sms.getMobiles(), sms.getContent(), FilterTypes.匹配供应商出错过滤器);
                smsMtService.trashMtAllMobiles(sms);
                return false;
            }
        } else {
            log.error("匹配不到供应商账号, 短信数据为:" + sms.toString());
            kafkaService.sendToFilterTopic(sms.getMobiles(), sms.getContent(), FilterTypes.匹配供应商账户出错过滤器);
            smsMtService.trashMtAllMobiles(sms);
            return false;
        }
    }

    /**
     * 获取规则匹配的供应商账号id
     * @param mtDto
     * @return
     */
    private int getAccountIdFromRulesWithSignLanguage(MtDto mtDto){
        int originalSignType=mtDto.getSignType();
        //根据语言版本转换签名
        int signType=signLanguageTypeCache.getBySign(mtDto.getSignType(),mtDto.getLanguage());
        //设置为转换后的语言版本的签名
        mtDto.setSignType(signType);
        int accountId=supplierMatchService.getAccountIdFromRules(mtDto);
        if(accountId<=0){
            //此处转换后的签名无法匹配到对应的供应商账号id,应该设置为原来的签名类型
            mtDto.setSignType(originalSignType);
            return supplierMatchService.getAccountIdFromRules(mtDto);
        }
        return accountId;
    }

    /**
     * 添加手机前缀.
     *
     * 由于匹配到供应商后，一些供应商如CM发的是海外号码，统一都需要带上00前缀才能发送出去
     *
     * @param sms the sms
     */
    private void addMobilePrefix(MtDto sms) {
        if (StringUtil.isNotBlank(sms.getMobiles())) {
            if (NeedInterPrefixSuppliers.CM.getCode().equals(sms.getSupplier())) {
                List<String> tempMobiles = StringUtil.asList(sms.getMobiles());
                List<String> mobiles = new ArrayList<>();
                tempMobiles.forEach(tempMobile -> {
                    String mobile = NeedInterPrefixSuppliers.CM.getPrefix() + tempMobile;
                    mobiles.add(mobile);
                });

                sms.setMobiles(Joiner.on(",").join(mobiles));
            }
        }
    }
}
