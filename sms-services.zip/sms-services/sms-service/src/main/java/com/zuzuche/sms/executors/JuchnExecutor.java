package com.zuzuche.sms.executors;

import com.zuzuche.sms.common.utils.SpringBeanFactory;
import com.zuzuche.sms.dto.SmsDto;
import com.zuzuche.sms.task.AbstractSendTask;
import com.zuzuche.sms.task.JuchnSendTask;
import com.zuzuche.threadpool.ThreadPoolExecutorFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.integration.util.CallerBlocksPolicy;
import org.springframework.stereotype.Component;

import java.util.concurrent.*;

/**
 * @desc: 巨辰的工作线程池
 * @author: panqiong
 * @date: 2018/10/28
 */
@Component
@Slf4j
public class JuchnExecutor extends AbstractOutboundExecutor{



    public JuchnExecutor(){
        super(
                ThreadPoolExecutorFactory.Config.builder()
                .corePoolSize(20)
                .maximumPoolSize(25)
                .keepAliveTime(2)
                .workQueue(new ArrayBlockingQueue<>(100))
                .unit(TimeUnit.MINUTES)
                .handler(new ThreadPoolExecutor.CallerRunsPolicy())
                .threadPoolName("JuchnExecutor")
                .build()
        );
    }


    /**
     *
     * @param sms
     */
    @Override
    public AbstractSendTask packingSendTask(SmsDto sms) {
        // 获取一个实例化的原型任务对象
        JuchnSendTask juchnSendTask = SpringBeanFactory.getBean(JuchnSendTask.class,sms);

        return juchnSendTask;
    }
}
