package com.zuzuche.sms.listener.inner;

import com.google.common.util.concurrent.RateLimiter;
import com.zuzuche.logback.util.MDCUtil;
import com.zuzuche.sms.cache.SmsConfigCache;
import com.zuzuche.sms.dto.FilterMtDto;
import com.zuzuche.sms.service.KafkaService;
import com.zuzuche.sms.service.SmsMtService;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;


/**
 * 功能：拦截短信消费监听器.
 * 详细：
 *
 * @author Created on 2019.03.16 by chaodian
 */
@Component
@Slf4j
public class MtFilterListener implements InitializingBean {

    private static final String RATE_KEY = "filter_topic_rate";

    private static RateLimiter rateLimiter;

    @Autowired
    KafkaService kafkaService;

    @Autowired
    SmsMtService smsMtService;

    @Autowired
    SmsConfigCache configCache;

    @KafkaListener(topics = KafkaService.FILTER_TOPIC)
    public void consume(ConsumerRecord<String, FilterMtDto> consumer) {
        MDCUtil.set();
        if(log.isDebugEnabled()){
            log.debug("[receive filter_topic]:" +consumer.value());
        }

        rateLimiter.acquire();
        try {
            FilterMtDto dto = consumer.value();
            smsMtService.saveToFilterDb(dto);
        } catch (Exception e){
            // 发送到dlq队列 并预警人工接入
            log.error("[拦截的短信消息处理出现异常-filter_topic]message:"+consumer.value(),e.getMessage(),e);
        } finally {
            MDCUtil.clear();
        }
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        if(configCache.containsKey(RATE_KEY)){
            int rate = Integer.parseInt(configCache.get(RATE_KEY));
            rateLimiter = RateLimiter.create(rate);
        }else{
            // 默认速度
            rateLimiter = RateLimiter.create(50);
        }
    }
}
