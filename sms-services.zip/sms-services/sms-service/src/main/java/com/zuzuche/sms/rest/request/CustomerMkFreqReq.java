package com.zuzuche.sms.rest.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @desc: 业务方营销短信拦截规则req
 * @author: bingyi
 * @date: 2020/2/19
 * @blame Android Team
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ApiModel(value = "业务方营销短信拦截规则配置")
public class CustomerMkFreqReq {
    /**
     * 业务方标签
     */
    @ApiModelProperty(value = "业务方标签",required = true)
    private String customerSign;

    /**
     * 拦截次数
     */
    @ApiModelProperty(value = "拦截次数,默认为1次",required = false)
    @Builder.Default
    private int interceptFreq=1;

    /**
     * 是否打开营销拦截开关，0不打开，1打开
     */
    @ApiModelProperty(value = "是否打开营销拦截开关，0不打开，1打开,默认打开",required = true)
    @Builder.Default
    private int hasOpenMkFreq=1;

    /**
     * 拦截间隔
     */
    @ApiModelProperty(value = "拦截持续时间间隔，默认86400秒（单位/s)",required = false)
    @Builder.Default
    private int mkFreqDuration=86400;

}
