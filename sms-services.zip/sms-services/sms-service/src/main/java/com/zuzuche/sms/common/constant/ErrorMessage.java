package com.zuzuche.sms.common.constant;

/**
 * @desc:
 * @author: panqiong
 * @date: 2019-07-25
 */
public class ErrorMessage {
    public static final String HYSTRIX_SHORT_CIRCUITED_PHRASE = "Hystrix circuit short-circuited and is OPEN";

    public static final String NETWORK_CONNECT_TIME_OUT_PHRASE = "connect timed out";


    public static final String NETWORK_READ_TIME_OUT_PHRASE = "Read timed out";

}
