package com.zuzuche.sms.service;

import com.zuzuche.commons.redis.RedisLock;
import com.zuzuche.sms.cache.InboundOffsetCache;
import com.zuzuche.sms.cache.PushStatusOffsetCache;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

/**
 * @desc: 数据拉取偏移量服务
 * @author: panqiong
 * @date: 2018/10/24
 */
@Service
public class RetriveOffsetService {

    @Autowired
    InboundOffsetCache inboundOffsetCache;

    @Autowired
    PushStatusOffsetCache pushStatusOffsetCache;


    @Autowired
    StringRedisTemplate redisTemplate;


    /**
     * 获取offset信息列表
     * @return
     */
    public Map<String,String> retriveOffsetList(){
        String inbound = inboundOffsetCache.get();
        String pushstatus = pushStatusOffsetCache.get();

        HashMap map = new HashMap();
        map.put("pushstatusOffset",pushstatus);
        map.put("inboundOffset",inbound);
        return map;

    }

    /**
     * 手动设置偏移量
     * @param offset
     */
    public void setPushStatusOffset(String offset) {
        RedisLock lock = new RedisLock(redisTemplate,PushStatusOffsetCache.PUSH_STATUS_OFFSET_KEY);
        if(lock.lock()){
            try{
                pushStatusOffsetCache.set(offset);
            }finally {
                lock.unlock();
            }
        }


    }

    /**
     * 手动设置偏移量
     * @param offset
     */
    public void setInboundOffset(String offset) {
        RedisLock lock = new RedisLock(redisTemplate,InboundOffsetCache.RETRIVE_INBOUND_OFFSET_KEY);

        if(lock.lock()){
            try{
                inboundOffsetCache.set(offset);
            }finally {
                lock.unlock();
            }
        }
    }


}
