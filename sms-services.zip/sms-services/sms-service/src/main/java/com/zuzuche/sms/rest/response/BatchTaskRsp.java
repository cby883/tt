package com.zuzuche.sms.rest.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.Table;
import java.time.LocalDateTime;

/**
 * desc:批次短信任务返回体
 *
 * @author bingyi
 * @date 2019/11/13
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class BatchTaskRsp {
    private int id;

    private Integer batchMtId;

    private String content;

    private String status;

    private LocalDateTime planSendTime;

    private LocalDateTime createTime;

    private int regionType;

    private int signType;

    private String fromUniqueId;

    private String fromType;

    private String admin;

}