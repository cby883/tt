package com.zuzuche.sms.rest.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import java.time.LocalDateTime;

/**
 * desc:文件批量发送状态请求类
 *
 * @author bingyi
 * @date 2019/10/30
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
@ApiModel(value = "文件批量发送状态请求类",description = "文件批量发送状态请求类")
public class BatchTaskStatusReq {
    @ApiModelProperty(value = "任务id",required = true)
    @NotBlank(message = "任务id不能为空")
    private int id;

    @ApiModelProperty(value = "任务状态码")
    private int status;

}