package com.zuzuche.sms.remote;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.zuzuche.commons.base.util.JsonUtil;
import com.zuzuche.sms.remote.dto.PostHxSmsDto;
import com.zuzuche.sms.remote.dto.PullSmsUplinkDto;
import com.zuzuche.sms.remote.dto.ShortMessageDto;
import com.zuzuche.sms.remote.param.ShortMessageParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;
import org.springframework.web.client.ResourceAccessException;

import java.nio.charset.Charset;
import java.util.Arrays;

/**
 * @desc: 巨辰api接口
 * @author: panqiong
 * @date: 2018/10/17
 */
@Component
@Slf4j
public class JuchnPushApi extends AbstractHttpInvoke{

    @Value("${provider.juchn.pushurl}")
    private String pushurl ;

    /**
     * 额外的header设置 比如编码
     *
     * @param header
     */
    @Override
    protected void setHeader(HttpHeaders header) {
        header.setAcceptCharset(Arrays.asList(Charset.forName("UTF-8")));
    }



    /**
     * 通用短信群发接口是指多号码，
     * 内容相同的短信的发送(参数值以UTF-8格式请求)。
     * 包括普通短信、长短信。该接口的使用无需模板报备，针对营销、行业客户提供使用
     *
     * 把异常抛出去,以便熔断器能检测到异常并按配置触发熔断
     * @param param
     * @return
     */
    @HystrixCommand(groupKey = "juchnApiGroup", commandKey="shortMessage")
    public ShortMessageDto shortMessage(ShortMessageParam param) throws ResourceAccessException{
        String api = "/shortMessage";
        String url = pushurl+api;

        String result = super.postForm(url,param);

        try {
            ShortMessageDto dto = JsonUtil.stringToObj(result,ShortMessageDto.class);
            return dto;
        } catch (Exception e) {
            log.error("[巨辰发送短信接口]解析返回的响应json报错 接口相应内容result:"+result);
            return ShortMessageDto.builder()
                    .respcode("-99")
                    .respdesc("json解析异常")
                    .build();
        }
    }


}
