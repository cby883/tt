package com.zuzuche.sms.common.constant;

import com.zuzuche.commons.base.constants.BaseEnum;

/**
 * @desc:
 * @author: panqiong
 * @date: 2019-07-25
 */
public enum ErrorStatusEnum implements BaseEnum<String> {
    /**
     * 熔断器被打开
     */
    HYSTRIX_SHORT_CIRCUITED("-81"),

    /**
     * hystrix相关未知异常
     */
    HYSTRIX_EXCEPTION("-80"),


    /**
     * 网络连接超时异常
     */
    NETWORK_CONNETCT_TIME_OUT("-91"),

    /**
     * 网络连接未知异常
     */
    NETWORK_EXCEPTION("-90"),



    /**
     * 未知异常
     */
    UNKOWN_EXCEPTION("-98"),


    HTTP_ERROR("-70"),
    /**
     * HTTP50X
     */
    HTTP_50X("-71");




    private String code;

    ErrorStatusEnum(String code) {
        this.code = code;
    }

    @Override
    public String code() {
        return code;
    }

}

