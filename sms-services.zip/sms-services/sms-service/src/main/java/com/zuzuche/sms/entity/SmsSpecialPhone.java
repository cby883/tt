package com.zuzuche.sms.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Table;
import java.time.LocalDateTime;

/**
 * @desc:
 * @author: panqiong
 * @date: 2018/11/9
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "sms_special_phone")
public class SmsSpecialPhone {


    private int id;

    /**
     * 号码
     */
    private String phone;

    /**
     * 1:黑名单 2:白名单
     */
    private int phoneType;

    /**
     * 1:有效 2:无效
     */
    private String validState;

    private LocalDateTime createTime;
}
