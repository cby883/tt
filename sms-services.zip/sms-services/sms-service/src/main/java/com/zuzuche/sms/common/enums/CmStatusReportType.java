package com.zuzuche.sms.common.enums;

import com.zuzuche.commons.base.constants.BaseEnum;
import lombok.Getter;

/**
 * CM供应商短信的状态报告回馈的状态枚举.
 * @author Chaodian
 */
@Getter
public enum CmStatusReportType implements BaseEnum<String> {
    /**
     * 提交成功 cm status report type.
     */
    SUBMIT_SUCCESS("0"),

    /**
     * 提交被拒绝 cm status report type.
     */
    SUBMIT_REJECTED("1"),

    /**
     * 发送成功 cm status report type.
     */
    SEND_SUCCESS("2"),

    /**
     * 发送失败 cm status report type.
     */
    SEND_FAILED("3");

    /**
     * 回馈的状态码
     */
    private String code;

    CmStatusReportType(String code) {
        this.code = code;
    }

    @Override
    public String code() {
        return null;
    }
}
