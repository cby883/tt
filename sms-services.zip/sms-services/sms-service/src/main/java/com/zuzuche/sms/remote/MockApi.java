package com.zuzuche.sms.remote;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.zuzuche.commons.base.util.JsonUtil;
import com.zuzuche.sms.remote.dto.MockSendDto;
import com.zuzuche.sms.remote.param.MockSendParam;
import com.zuzuche.sms.remote.param.SmsSendParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;

import java.nio.charset.Charset;
import java.util.Arrays;

/**
 * @desc:
 * @author: panqiong
 * @date: 2018/11/9
 */
@Component
@Slf4j
public class MockApi extends AbstractHttpInvoke {

    /**
     * 额外的header设置 比如编码
     *
     * @param header
     */
    @Override
    protected void setHeader(HttpHeaders header) {
        header.setAcceptCharset(Arrays.asList(Charset.forName("UTF-8")));
    }


    @HystrixCommand(groupKey = "baiwuApiGroup", commandKey="smsSend")
    public String smsSend(SmsSendParam smsSendParam){
        String api = "http://www.baidu.com:8080/sms_send2.do";
        String result = null;
        try {
            result = super.postForm(api,smsSendParam);
        } catch (Exception e) {
            log.error("[模拟百唔短信提交sms_send2]", e.getMessage(), e);
        }
        return result;
    }


    @HystrixCommand(groupKey = "baiwuApiGroup", commandKey="check")
    public String check(SmsSendParam smsSendParam){
        String api = "http://www.baidu.com:8080/check.do";
        String result = null;
        try {
            result = super.postForm(api,smsSendParam);
        } catch (Exception e) {
            log.error("[模拟百唔短信提交check]", e.getMessage(), e);
        }
        return result;
    }

    @HystrixCommand(groupKey = "mockApiGroup", commandKey="mockSend")
    public MockSendDto.Result mockSend(MockSendParam sms){
        String api = "http://192.168.100.96:9000/mock/sendSms";
        String result = null;
        try {
            result = super.postForm(api,sms);
        } catch (Exception e) {
            log.error("[模拟短信提交sendSms]", e.getMessage(), e);
        }
        MockSendDto dto = JsonUtil.stringToObj(result,MockSendDto.class);
        return dto.getData();

    }

    /**
     * 封装http header
     *
     * @return
     */
    @Override
    protected HttpHeaders getHttpHeaders() {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        headers.setAcceptCharset(Arrays.asList(Charset.forName("GBK")));
        return headers;
    }
}
