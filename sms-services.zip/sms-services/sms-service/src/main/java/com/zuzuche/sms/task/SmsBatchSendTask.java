package com.zuzuche.sms.task;

import com.google.common.util.concurrent.RateLimiter;
import com.zuzuche.sms.cache.SmsConfigCache;
import com.zuzuche.sms.common.enums.RateLimiterKeyTypes;
import com.zuzuche.sms.common.enums.SmsBatchSendTaskType;
import com.zuzuche.sms.common.enums.SmsType;
import com.zuzuche.sms.dto.MtDto;
import com.zuzuche.sms.entity.SmsBatchMtTbl;
import com.zuzuche.sms.entity.SmsBatchTask;
import com.zuzuche.sms.entity.SmsFilePhoneList;
import com.zuzuche.sms.filter.BatchFilter;
import com.zuzuche.sms.mapper.SmsBatchMtTblMapper;
import com.zuzuche.sms.mapper.SmsBatchTaskMapper;
import com.zuzuche.sms.mapper.SmsFilePhoneListMapper;
import com.zuzuche.sms.mapper.SmsUploadFileLogMapper;
import com.zuzuche.sms.service.BatchTaskContainerService;
import com.zuzuche.sms.service.SmsMtService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * 功能：大批量发送短信发送处理类
 * 详细：
 *
 * @author Created on 2019.11.04 bingyi
 */
@Component
@Slf4j
@Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class SmsBatchSendTask implements Runnable {
    /**
     * 任务id
     */
    int taskId;
    @Autowired
    SmsMtService smsMtService;

    @Autowired
    SmsBatchTaskMapper smsBatchTaskMapper;

    @Autowired
    SmsFilePhoneListMapper smsFilePhoneListMapper;

    @Autowired
    SmsUploadFileLogMapper smsUploadFileLogMapper;

    @Autowired
    SmsBatchMtTblMapper smsBatchMtTblMapper;

    @Autowired
    BatchTaskContainerService batchTaskContainerService;

    @Autowired
    SmsConfigCache smsConfigCache;

    @Value("${sms.batchSend.open}")
    private boolean isSendOpen = true;

    @Value("${envi}")
    String smsEnv;

    private static final String BATCH_SEND_SMS_RATE = "batch_send_sms_rate";
    /**
     * 短信生产环境的配置标识
     */
    private static final String SMS_ENV_PRD = "prd";

    @Autowired
    List<BatchFilter> filters;


    public SmsBatchSendTask(int taskId) {
        this.taskId = taskId;
    }

    /**
     * ①判断状态
     */
    private void execute() {
        //前置操作

        SmsBatchTask task = batchTaskContainerService.get(taskId);
        //拿出短信内容
        SmsBatchMtTbl smsBatchMtTbl = smsBatchMtTblMapper.selectByPrimaryKey(task.getBatchMtId());
        while (batchTaskContainerService.get(taskId) != null) {
            int maxId = -1;
            try {
                RateLimiter rateLimiter = smsConfigCache.getLimiter(RateLimiterKeyTypes.SMS_BATCH_QUERY_DB_RATE);
                rateLimiter.acquire();
                //拿10次请求
                List<SmsFilePhoneList> lists = smsFilePhoneListMapper.searchWithOffset(task);

                //任务跑完了
                if (CollectionUtils.isEmpty(lists)) {
                    //更新状态
                    task.setStatus(SmsBatchSendTaskType.SMS_BATCH_SEND_TASK_TYPE_FINISHED.code());
                    batchTaskContainerService.remove(task);
                    break;
                }
                //推送入队
                maxId = lists.get(lists.size() - 1).getId();
                for (SmsFilePhoneList e : lists) {
                    if (maxId < e.getId()) {
                        maxId = e.getId();
                    }
                    MtDto mtDto = transfer(smsBatchMtTbl, e, taskId);
                    if (isSendOpen) {
                        if (beforeAction(mtDto,task)) {
                            smsMtService.pushMtIntoQueue(mtDto, SmsType.营销小工具.getTopic());
                        }
                    }
                }
                //设置偏移量
                task.setOffset(maxId);
                smsBatchTaskMapper.updateOffset(task);
            } catch (Exception e) {
                log.error("【SmsBatchSendTask】批量短信推送出错", e.getMessage(), e);
                task = smsBatchTaskMapper.selectByPrimaryKey(taskId);
                task.setOffset(task.getOffset() < maxId ? maxId : task.getOffset());
            }
        }
    }

    /**
     * 入队前置方法
     *
     * @param mtDto
     * @return
     */
    private boolean beforeAction(MtDto mtDto,SmsBatchTask smsBatchTask) {
        for (BatchFilter filter : filters) {
            if (!filter.doFilter(mtDto,smsBatchTask)) {
                log.info("批量短信发送工具-拦截短信日志：" + mtDto.toString());
                return false;
            }
        }
        return true;
    }

    private MtDto transfer(SmsBatchMtTbl smsBatchMtTbl, SmsFilePhoneList phoneList, int taskId) {
        //此处手机号脱敏
        MtDto mtDto = MtDto.builder()
                .mobiles(phoneList.getPhone())
                .content(smsBatchMtTbl.getContent())
                .type(smsBatchMtTbl.getType())
                .variables(phoneList.getExtraParam())
                .regionType(smsBatchMtTbl.getRegionType())
                .signType(smsBatchMtTbl.getSignType())
                .batch(String.valueOf(taskId))
                .admin(smsBatchMtTbl.getAdmin())
                .extraParam(smsBatchMtTbl.getExtraParam())
                .from(smsBatchMtTbl.getFromType())
                .mock(checkIsSmsMock())
                .uniqueId(smsBatchMtTbl.getFromUniqueId())
                .build();
        return mtDto;
    }

    /**
     * 判断短信是否模拟提交，不真是发送
     *
     * @return boolean
     */
    private boolean checkIsSmsMock() {
        return !SMS_ENV_PRD.equals(smsEnv);
    }

    @Override
    public void run() {
        execute();
    }
}
