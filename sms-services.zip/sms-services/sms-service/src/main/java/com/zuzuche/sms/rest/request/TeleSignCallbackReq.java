package com.zuzuche.sms.rest.request;

import com.alibaba.fastjson.annotation.JSONField;
import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * 功能：teleSign供应商状态报告回调接口协议.
 * 详细：
 * 下面的短信回调由于是供应商要求的get参数，不符合驼峰命名规范，比较特殊
 *
 * @author Created on 2019.09.10 by bingyi
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@ApiModel(value = "TeleSign供应商状态报告回调接口")
public class TeleSignCallbackReq {
    /**
     * 每个手机号对应的session_id,此处格式为：accountId_taskId
     */
    @JSONField(name = "session_id")
    private String sessionId;
    /**
     * 短信发送批次的唯一批次号
     */
    @JSONField(name = "reference_id")
    private String referenceId;
    /**
     * 发送短信的api名称
     */
    @JSONField(name = "sub_resource")
    private String subResource;
    /**
     * 错误列表
     */
    private List<Error> errors;

    /**
     * 存sessionId转化后的手机信息
     */
    private String number;
    /**
     * 存sessionId转化后的batchNo
     */
    private String batchNo;
    /**
     * 存sessionId转化后的accoundId
     */
    @Builder.Default
    private int accoundId=0;
    /**
     * 状态实体
     */
    private Status status;

    @AllArgsConstructor
    @NoArgsConstructor
    @Data
    @Builder
    public static class Status {
        /**
         * 更新时间
         */
        @JSONField(name = "updated_on")
        private String updatedOn;
        /**
         * 状态码
         */
        int code;
        /**
         * 描述
         */
        private String description;

    }

    @AllArgsConstructor
    @NoArgsConstructor
    @Data
    @Builder
    public static class Error {
        /**
         * 错误码
         */
        private int code;
        /**
         * 描述
         */
        private String description;
    }
}
