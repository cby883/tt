package com.zuzuche.sms.report.callback;

import com.zuzuche.sms.entity.ProviderAccountInfo;

/**
 * 回调接口.
 */
public interface CallbackService {
    /**
     * 回调状态报告
     *
     * @param account      the account
     * @param callbackData the callback data 回调数据
     */
    void callbackStatusReport(ProviderAccountInfo account, Object callbackData);

    /**
     * 回调上行短信
     *
     * @param account      the account
     * @param callbackData the callback data 回调数据
     */
    void callbackInboundSms(ProviderAccountInfo account, Object callbackData);
}
