package com.zuzuche.sms.remote;

import com.zuzuche.commons.base.resp.Status;
import com.zuzuche.commons.base.resp.StatusServiceCnException;
import com.zuzuche.commons.base.util.BeanConverter;
import com.zuzuche.commons.base.util.JsonUtil;
import com.zuzuche.commons.base.util.StringUtil;
import com.zuzuche.sms.common.constant.ErrorMessage;
import lombok.extern.slf4j.Slf4j;
import okhttp3.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.Assert;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * @desc: 抽象http调用父类, feign解析不方便, 直接采用resttamplate
 * @author: panqiong
 * @date: 2018/11/5
 */
@Slf4j
public abstract class AbstractHttpInvoke implements Ser{


    @Autowired
    private RestTemplate restTemplate;

    private static final OkHttpClient httpClient;

    private static final Map<String, String> DEFAULT_HEADERS = new HashMap(4);

    static {
        httpClient = (new okhttp3.OkHttpClient.Builder())
                .connectTimeout(5L, TimeUnit.SECONDS)
                .readTimeout(8L, TimeUnit.SECONDS)
                .writeTimeout(8L, TimeUnit.SECONDS)
                .followRedirects(true)
                .followSslRedirects(true)
                .connectionPool(new ConnectionPool())
                .build();
        DEFAULT_HEADERS.put("User-agent", "Mozilla/5.0 (Windows; U; Windows NT 5.1; zh-CN; rv:1.9.2) Gecko/20100115 Firefox/3.6");
        DEFAULT_HEADERS.put("Connection", "close");
    }

    public static void main(String[] args) {
        String s1=new String("abc");
        String s2=new String("abc");
        String s3="abc";
        String s6="c";
        String s4="ab"+"c";
        String s5="ab"+s6;
        Integer a1=1;
        Integer a2=new Integer(1);
        Integer a3=new Integer(1);
        Integer a4=1;
        Integer a7=400;
        Integer a8=400;
        Integer a9=1;
        int a5=1;
        Short a6=1;
        System.out.println();
    }


    /**
     * 默认UTF-8
     * 如果需要用json方式提交
     * 封装http header
     *
     * @return
     */
    protected HttpHeaders getHttpHeaders() {
        HttpHeaders headers = new HttpHeaders();
        headers.setAcceptCharset(Arrays.asList(StandardCharsets.UTF_8));
        return headers;
    }

    /**
     * 转换参数
     *
     * @param postSmsParam
     */
    protected MultiValueMap<String, String> paramTransform(Object postSmsParam) {
        MultiValueMap<String, String> bodyParam = new LinkedMultiValueMap<>();
        String origin = JsonUtil.objToStr(postSmsParam);
        Map<String, String> raw = JsonUtil.stringToMap(origin);
        raw.forEach((k, v) -> {
            bodyParam.add(k, v);
        });
        return bodyParam;
    }


    protected String postForm(String url, Object param) {
        String result;
        if (!log.isDebugEnabled()) {
            log.info("[request]url:" + url + " param:" + param.toString());
        }

        MultiValueMap<String, String> bodyParam = paramTransform(param);

        HttpHeaders headers = getHttpHeaders();
        //给接口给子类留填充headers
        setHeader(headers);
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<>(bodyParam, headers);
        ResponseEntity<String> response = restTemplate.postForEntity(url, request, String.class);
        result = response.getBody();
        if (log.isDebugEnabled()) {
            log.debug("[response] \n->[url]:" + url + "\n->[param]" + param.toString() + "\n->[result]:" + result);
        }
        if (StringUtil.isEmpty(result)) {
            throw new StatusServiceCnException(Status.OBJECT_NOT_EXIST, "接口返回result为空");
        }


        return result == null ? "" : result;
    }

    /**
     * get方法调用
     *
     * @param url
     * @return
     */
    protected String get(String url) {
        String result;
        if (log.isDebugEnabled()) {
            log.debug("[request]url:" + url);
        }
        //对请求参数设置不编码
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url);
        result = restTemplate.getForObject(builder.build(true).toUri(), String.class);
        if (log.isDebugEnabled()) {
            log.debug("[url]:{}\n[response]:{}", url, result);
        }
        return result;
    }


    /**
     * json原文发送
     *
     * @param url
     * @param param
     * @return
     */
    protected String postJson(String url, Object param) {
        String result;
        if (!log.isDebugEnabled()) {
            log.info("[request]url:" + url + " param:" + param.toString());
        }
        HttpHeaders headers = getHttpHeaders();
        //给接口给子类留填充headers
        setHeader(headers);
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<String> request = new HttpEntity<>(JsonUtil.objToStr(param), headers);
        ResponseEntity<String> response = restTemplate.postForEntity(url, request, String.class);
        result = response.getBody();
        if (log.isDebugEnabled()) {
            log.debug("[response] \n->[url]:" + url + "\n->[param]" + param.toString() + "\n->[result]:" + result);
        }
        if (StringUtil.isEmpty(result)) {
            throw new StatusServiceCnException(Status.OBJECT_NOT_EXIST, "接口返回result为空");
        }
        return result == null ? "" : result;
    }

    /**
     * json原文发送
     *
     * @param url
     * @param param
     * @return
     */
    protected String postJson(String url, Map param) {
        String result;
        if (!log.isDebugEnabled()) {
            log.info("[request]url:" + url + " param:" + param.toString());
        }
        HttpHeaders headers = getHttpHeaders();
        //给接口给子类留填充headers
        setHeader(headers);
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<String> request = new HttpEntity<>(JsonUtil.mapToString(param), headers);
        ResponseEntity<String> response = restTemplate.postForEntity(url, request, String.class);
        result = response.getBody();
        if (log.isDebugEnabled()) {
            log.debug("[response] \n->[url]:" + url + "\n->[param]" + param.toString() + "\n->[result]:" + result);
        }
        if (StringUtil.isEmpty(result)) {
            throw new StatusServiceCnException(Status.OBJECT_NOT_EXIST, "接口返回result为空");
        }
        return result == null ? "" : result;
    }

    /**
     * desc:post请求带上header
     * @param url
     * @param params
     * @param headers
     * @return
     * @throws IOException
     */

    protected static Response postWithHeader(String url, Object params, Map<String, String> headers)  {
        Assert.notNull(url, "url不能为空");
        RequestBody body = null;
        try {
            body = RequestBody.create(okhttp3.MediaType.parse("application/x-www-form-urlencoded"),objToUrl(params, "utf-8"));
        } catch (UnsupportedEncodingException e) {
            log.error("[AbstractHttpInvoke-postWithHeader]请求参数转化错误",e.getMessage(),e);
            //请求还未发送，理应重发
            throw new ResourceAccessException(ErrorMessage.NETWORK_CONNECT_TIME_OUT_PHRASE);
        }
        Request.Builder builder = new Request.Builder();
        if (headers != null && headers.size() > 0) {
            Iterator iterator = headers.entrySet().iterator();

            while (iterator.hasNext()) {
                Map.Entry<String, String> entry = (Map.Entry) iterator.next();
                builder.addHeader((String) entry.getKey(), (String) entry.getValue());
            }
        }
        Request request = builder.url(url).post(body).build();
        Response response = null;
        try {
            response = httpClient.newCall(request).execute();
        } catch (IOException e) {
            log.error(e.getMessage(),e);
            //返回一个不受检查性的网络异常
            throw new ResourceAccessException(e.getMessage());
        }
        return response;
    }
    private static String objToUrl(Object obj, String charset) throws UnsupportedEncodingException {
        if (obj == null) {
            return "";
        }
        Map<String, Object> map = BeanConverter.beanToMap(obj);
        StringBuilder result = new StringBuilder(128);
        Iterator iterator = map.entrySet().iterator();

        while (iterator.hasNext()) {
            Map.Entry<String, ?> entry = (Map.Entry) iterator.next();
            result.append((String) entry.getKey()).append("=").append(URLEncoder.encode(String.valueOf(entry.getValue()), charset)).append("&");
        }

        result.setLength(result.length() - 1);
        return result.toString();


    }

    /**
     * 额外的header设置 比如编码
     *
     * @param header
     */
    protected abstract void setHeader(HttpHeaders header);


}
