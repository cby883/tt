package com.zuzuche.sms.common.enums;

import com.zuzuche.commons.base.constants.BaseEnum;


/**
 * desc:限流器枚举类
 *
 * @author bingyi
 * @date 2019/09/02
 */
public enum RateLimiterKeyTypes implements BaseEnum<String> {
    /**
     *
     */
    SEND_RESULT_TOPIC_RATE("send_result_topic_rate","回调上游结果通知接口速度"),
    BLOCKED_SMS_TOPIC_RATE("blocked_sms_topic_rate","回调上游短信拦截通知速度"),
    JUCHN_SMS_OUTBOUND_TOPIC_RATE("juchn_sms_outbound_topic_rate","巨辰短信下行速度"),
    BAIWU_SMS_OUNTBOUND_TOPIC_RATE("baiwu_sms_outbound_topic_rate","百唔短信下行速度"),
    CHLAN_SMS_OUTBOUND_TOPIC_RATE("chlan_sms_outbound_topic_rate","创蓝短信下行速度"),
    MIAOXIN_SMS_OUTBOUND_TOPIC_RATE("miaoxin_outbound_topic_rate","秒信短信下行速度"),
    SMS_NORMAL_TOPIC_RATE("sms_normal_topic_rate","普通通知队列下行速度"),
    SMS_VERIFY_TOPIC_RATE("sms_verify_topic_rate","验证码通知队列下行速度"),
    SMS_MARKEY_TOPIC_RATE("sms_market_topic_rate","营销短信队列下行速度"),
    SMS_BATCH_MARKEY_TOPIC_RATE("sms_batch_market_topic_rate","批量营销小工具短信队列下行速度"),
    ALIYUN_SMS_OUTBOUND_TOPIC_RATE("aliyun_sms_outbound_topic_rate","阿里云短信下行速度"),
    CM_SMS_OUTBOUND_TOPIC_RATE("cm_sms_outbound_topic_rate","CM短信下发速度"),
    SMS_BATCH_IMPORT_FILE_DB_RATE("sms_batch_import_file_db_rate","营销批量短信文件导入速度"),
    SMS_BATCH_QUERY_DB_RATE("sms_batch_query_db_rate","营销批量短信推送短信速度"),
    STATUS_REPORT_DB_RATE("status_report_db_rate","短信状态报告入库速度"),
    STATUS_REPORT_CYCLE_TOPIC_RATE("status_report_cycle_topic_rate","短信状态报告循环队列消费速度"),
    RETRYING_SMS_TOPIC_RATE("retrying_sms_topic_rate","短信重试队列下行速度");
    /**
     * 限流器map得唯一Key
     */
    private String code;
    /**
     * 限流器key描述
     */
    private String desc;
    private RateLimiterKeyTypes(String code,String desc){
        this.code=code;
        this.desc=desc;
    }

    public String desc(){
        return this.desc;
    }
    @Override
    public String code() {
        return this.code;
    }
}
