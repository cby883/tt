package com.zuzuche.sms.entity;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Table;

/**
 * 功能：常规短信供应商匹配规则表.
 * 详细：
 *
 * @author on 2019.01.31 by chaodian
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "zuzuche_sms_db.common_match_rule_tbl")
public class CommonMatchRule {
    private Integer id;

    private Short sign;

    private Byte type;

    private Byte regionType;

    private String areaCodes;

    private String supplier;

    private Short level;

    private int accountId;

    private Integer addTime;

    private Integer updateTime;
}