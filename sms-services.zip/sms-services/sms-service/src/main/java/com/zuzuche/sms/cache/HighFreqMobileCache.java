package com.zuzuche.sms.cache;


import com.zuzuche.commons.base.util.StringUtil;
import com.zuzuche.sms.cache.co.SafeMonitorRuleCo;
import com.zuzuche.sms.common.enums.HighFreqFilterTypes;
import com.zuzuche.sms.common.enums.SmsType;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;

import java.util.concurrent.TimeUnit;

/**
 * 功能： 手机号码频率缓存操作.
 * 详细：
 *
 * @author Created on 2019.03.07 by chaodian
 */
@Component
@Slf4j
public class HighFreqMobileCache {
    @Autowired
    private StringRedisTemplate redisTemplate;

    @Autowired
    private SafeMonitorRuleCache safeMonitorRuleCache;

    @Autowired
    private SmsCustomerCache smsCustomerCache;


    /**
     * 通过手机号码获取完整的缓存key
     * @param mobile
     * @param type 短信发送频率过快拦截器类型枚举
     * @return string
     */
    private String getCacheKey(String mobile, HighFreqFilterTypes type) {
        return type.getCacheKeyName()+"::"+mobile;
    }

    /**
     * 业务方营销规则手机号缓存key
     * @param mobile
     * @param types
     * @param customer
     * @return
     */
    private String getCustomerMkCacheKey(String mobile,HighFreqFilterTypes types,String customer){
        return types.getCacheKeyName()+"::"+mobile+"::"+customer;
    }

    /**
     * 获取拦截配置的时长, 获取不到则取默认时长
     * @param type 短信发送频率过快拦截器类型枚举
     * @return int
     */
    private int getDuration(HighFreqFilterTypes type) {
        SafeMonitorRuleCo co = safeMonitorRuleCache.get(type.getSafeMonitorRuleNm());

        if (co != null &&
                co.getRuleFrequency() != null &&
                StringUtil.isNotEmpty(co.getRuleFrequency().getDuration())) {
            return Integer.parseInt(co.getRuleFrequency().getDuration());
        } else {
            return type.getDefaultDuration();
        }
    }

    /**
     * 获取拦截规则配置的频数， 获取不到则取默认频数
     * @param type 短信发送频率过快拦截器类型枚举
     * @return int
     */
    private int getFreq(HighFreqFilterTypes type) {
        SafeMonitorRuleCo co = safeMonitorRuleCache.get(type.getSafeMonitorRuleNm());
        if (co != null &&
                co.getRuleFrequency() != null &&
                StringUtil.isNotEmpty(co.getRuleFrequency().getFreqNum())) {
            return Integer.parseInt(co.getRuleFrequency().getFreqNum());
        } else {
            return type.getDefaultFreq();
        }
    }

    /**
     * 删除某个key
     *
     * @param type 短信发送频率过快拦截器类型枚举
     * @param mobile the mobile
     */
    public void deleteMobileKey(String mobile, HighFreqFilterTypes type) {
        redisTemplate.delete(getCacheKey(mobile, type));
    }


    /**
     * 原子增加一个手机的请求数.
     *
     * 如果是第一次增量+1，则设置缓存时间，缓存时间n和频数构成了一个手机的请求频率限制
     *
     * @param mobile the mobile
     * @param type 短信发送频率过快拦截器类型枚举
     */
    public void setMobileIncre(String mobile, HighFreqFilterTypes type){
        Long count = redisTemplate.opsForValue().increment(getCacheKey(mobile, type), 1);
        // 首次添加则需要设置时间
        if (count != null && count == 1) {
            redisTemplate.expire(getCacheKey(mobile, type), getDuration(type), TimeUnit.SECONDS);
        }
    }

    /**
     *
     * @param mobile
     * @param type
     * @param customerSign
     */
    public void setCustomerMkMobileIncr(String mobile, HighFreqFilterTypes type,String customerSign){
        Long count = redisTemplate.opsForValue().increment(getCustomerMkCacheKey(mobile,type,customerSign), 1);
        // 首次添加则需要设置时间
        if (count != null && count == 1) {
            redisTemplate.expire(getCustomerMkCacheKey(mobile,type,customerSign), smsCustomerCache.getMkDuration(customerSign), TimeUnit.SECONDS);
        }
    }

    /**
     * 原子增加一个手机的请求数.
     *
     * @param mobile the mobile
     * @param smsType 1普通、2营销、3验证码
     * @param customerSign 业务方标识
     */
    public void setMobileIncre(String mobile, int smsType,String customerSign) {
        if (safeMonitorRuleCache.checkIsSafeMonitorOpen(HighFreqFilterTypes.短信发送频率过高.getSafeMonitorRuleNm())) {
            setMobileIncre(mobile, HighFreqFilterTypes.短信发送频率过高);
        }
        // @todo: 后期可能需要加入普通通知的频率
        if (smsType == SmsType.验证码.getCode()) {
            if (safeMonitorRuleCache.checkIsSafeMonitorOpen(HighFreqFilterTypes.验证码发送频率过高.getSafeMonitorRuleNm())) {
                setMobileIncre(mobile, HighFreqFilterTypes.验证码发送频率过高);
            }
        } else if (smsType == SmsType.营销.getCode()) {
            if (safeMonitorRuleCache.checkIsSafeMonitorOpen(HighFreqFilterTypes.营销短信发送频率过高.getSafeMonitorRuleNm())) {
                setMobileIncre(mobile, HighFreqFilterTypes.营销短信发送频率过高);
            }
            //是否针对业务方设置缓存
            if (checkIsOpenCustomerMkFreq(HighFreqFilterTypes.营销短信发送频率过高,customerSign)){
                setCustomerMkMobileIncr(mobile,HighFreqFilterTypes.营销短信发送频率过高,customerSign);
            }
        }
    }

    /**
     * 获取一个手机在监控时间内的请求频数.
     *
     * @param mobile the mobile
     * @param type 短信发送频率过快拦截器类型枚举
     * @return the mobile req
     */
    private int getMobileFreq(String mobile, HighFreqFilterTypes type) {
        String freq = redisTemplate.opsForValue().get(getCacheKey(mobile, type));
        if (StringUtil.isNotEmpty(freq)) {
            return Integer.parseInt(freq);
        } else {
            return 0;
        }
    }

    /**
     * 获取一个手机在监控时间内的请求频数.
     *
     * @param mobile the mobile
     * @param type 短信发送频率过快拦截器类型枚举
     * @return the mobile req
     */
    private int getMobileCustomerMkFreq(String mobile, HighFreqFilterTypes type,String customerSign) {
        String freq = redisTemplate.opsForValue().get(getCustomerMkCacheKey(mobile,type,customerSign));
        if (StringUtil.isNotEmpty(freq)) {
            return Integer.parseInt(freq);
        } else {
            return 0;
        }
    }

    /**
     * 检查一个手机是否超过了频率限制.
     *
     * @param mobile the mobile
     * @param type 短信发送频率过快拦截器类型枚举
     * @param customerSign 业务方标识
     * @return the boolean
     */
    public boolean checkIsMobileOverLimit(String mobile, HighFreqFilterTypes type,String customerSign) {
        //判断是否使用针对业务方的营销规则发送拦截机制
        if(checkIsOpenCustomerMkFreq(type,customerSign)){
           return getMobileCustomerMkFreq(mobile,type,customerSign) >= smsCustomerCache.getMkFreqBySign(customerSign);
        }
        //原来规则
        return getMobileFreq(mobile, type) >= getFreq(type);
    }

    /**
     * 判断是否启用针对业务方的营销拦截机制
     * @param types
     * @param customerSign
     * @return
     */
    public boolean checkIsOpenCustomerMkFreq(HighFreqFilterTypes types,String customerSign){
        //判断参数
        if(StringUtil.isEmpty(customerSign)||types==null){
            return false;
        }
        //查询缓存是否开启
        boolean result=types.equals(HighFreqFilterTypes.营销短信发送频率过高)&&smsCustomerCache.hasOpenMkFreq(customerSign);
        return result;
    }
}
