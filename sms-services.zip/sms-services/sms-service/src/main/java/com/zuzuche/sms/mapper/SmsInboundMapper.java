package com.zuzuche.sms.mapper;

import com.zuzuche.commons.mybatis.BaseMapper;
import com.zuzuche.sms.entity.SmsInbound;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @desc ~
 * @author panqiong
 * @date 20181019
 */
@Repository
public interface SmsInboundMapper extends BaseMapper<SmsInbound> {

    /**
     * 查询下行短信
     * @param id
     * @param count
     * @return
     */
    List<SmsInbound> queryListByIdLimit(@Param("id") String id, @Param("count") int count);

}