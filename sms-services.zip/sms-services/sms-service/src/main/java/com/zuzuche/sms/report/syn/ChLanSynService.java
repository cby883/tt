package com.zuzuche.sms.report.syn;

import com.zuzuche.sms.entity.ProviderAccountInfo;
import com.zuzuche.sms.entity.SmsInbound;
import com.zuzuche.sms.entity.StatusReport;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @desc: 创蓝的同步数据服务
 * 创蓝比较变态,作为一个供应商,国内和国际短信居然提供两套不同协议的api,真是活久见. 而且协议只是字段名不一样,意义确是一样的!
 * 所以这里做一个代理做一层转发,这个service类似一个proxy
 * @author: panqiong
 * @date: 2018/11/12
 */
@Service("chLanSynService")
@Slf4j
public class ChLanSynService extends AbstractSynService{

    /**
     * 国内
     */
    @Autowired
    ChLanDomesticSynService domesticSynService;

    /**
     * 国际
     */
    @Autowired
    ChLanInterSynService interSynService;


    @Override
    protected List<StatusReport> doInvokeStatusReportApi(ProviderAccountInfo account) {
        int areaType = account.getAreaType();
        int international = 2;
        // 国际
        if(areaType==international){
            return interSynService.doInvokeStatusReportApi(account);
        }else{
            return domesticSynService.doInvokeStatusReportApi(account);
        }

    }


    @Override
    protected List<SmsInbound> doInvokeInboundApi(ProviderAccountInfo account) {
        int areaType = account.getAreaType();
        int international = 2;
        // 国际
        if(areaType==international){
            return interSynService.doInvokeInboundApi(account);
        }else{
            return domesticSynService.doInvokeInboundApi(account);
        }
    }

}
