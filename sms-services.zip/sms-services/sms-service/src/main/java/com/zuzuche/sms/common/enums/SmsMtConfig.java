package com.zuzuche.sms.common.enums;

import com.zuzuche.commons.base.constants.BaseEnum;
import lombok.Getter;

/**
 * 业务下行短信需要加载的配置项.
 */
@Getter
public enum SmsMtConfig implements BaseEnum<String> {
    /**
     * 黑白名单配置 sms mt config.
     */
    黑白名单配置("blackWhite"),

    /**
     * 拦截监控规则配置 sms mt config.
     */
    拦截监控规则配置("safeMonitorRule"),

    /**
     * 短信签名配置 sms mt config.
     */
    短信签名配置("smsSign"),

    /**
     * 短信模板配置 sms mt config.
     */
    短信模板配置("smsTemplate"),

    /**
     * 供应商配置 sms mt config.
     */
    供应商配置("supplierConfig"),

    /**
     * 短信供应商匹配规则配置 sms mt config.
     */
    短信供应商匹配规则配置("supplierMatchRule"),

    /**
     * 供应商账户备份策略配置 sms mt config.
     */
    供应商账户备份策略配置("accountIdBakPolicy");

    private String code;

    SmsMtConfig(String code) {
        this.code = code;
    }

    @Override
    public String code() {
        return code;
    }
}
