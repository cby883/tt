package com.zuzuche.sms.remote;

import com.zuzuche.commons.base.resp.PhpResult;
import com.zuzuche.sms.remote.param.SendIntersectionParam;
import feign.Headers;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;

/**
 * 交互记录请求api.
 *
 * @author Created on 2019-03-15 by chaodian
 */
@FeignClient(name="intersection",url="${zcs.url}")
@Headers({"Content-Type: application/x-www-form-urlencoded","Cookie:allow_test_ip=1,header_code=1"})
public interface IntersectionRemote {


    /**
     * 添加交互记录.
     *
     * @param param the param
     * @return the php result
     */
    @PostMapping(value = "/crm/addIntersection",consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
    PhpResult addIntersection(SendIntersectionParam param);
}
