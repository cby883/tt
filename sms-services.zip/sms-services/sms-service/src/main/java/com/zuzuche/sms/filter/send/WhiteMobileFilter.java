package com.zuzuche.sms.filter.send;

import com.google.common.base.Splitter;
import com.zuzuche.sms.cache.SmsSpecialPhoneCache;
import com.zuzuche.sms.common.constant.Constants;
import com.zuzuche.sms.dto.BlockedSmsDto;
import com.zuzuche.sms.dto.SmsDto;
import com.zuzuche.sms.filter.Filter;
import com.zuzuche.sms.service.KafkaService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * @desc: 白名单
 * 非生产环境下,只有白名单号码能真实下发
 * @author: panqiong
 * @date: 2018/11/9
 */
// @Component
// @Slf4j
// @Order(4)
public class WhiteMobileFilter implements Filter {

    private static final Constants.FilterTypes FILTER = Constants.FilterTypes.白名单过滤器;

    @Value("${envi}")
    private String env;


    @Autowired
    KafkaService kafkaService;


    /**
     * 返回false将导致整个下发流程中断
     *
     * @param sms
     * @return
     */
    @Override
    public boolean doFilter(SmsDto sms) {
        // 生产环境下全部放行
        if(Constants.EnvEnum.生产.code().equals(env)){
            return true;
        }
        // 测试和开发环境只有白名单能放行
        boolean isWhite = SmsSpecialPhoneCache.isWhiteUser(sms.getMobile());

        // 非白名单被拒绝  给与通知
        if(!isWhite){
            reportKafka(sms);
        }
        return isWhite;

    }

    private void reportKafka(SmsDto sms){
        List<String> list = Splitter.on(",").splitToList(sms.getMobile());
        if(list!=null&&list.size()>0){
            Set set = list.stream().collect(Collectors.toSet());
            BlockedSmsDto duSmsDto = BlockedSmsDto.builder()
                    .mobileList(set)
                    .taskId(sms.getTaskId())
                    .filterType(FILTER)
                    .build();
            kafkaService.sendToBlockedTopic(duSmsDto);
        }

    }
}
