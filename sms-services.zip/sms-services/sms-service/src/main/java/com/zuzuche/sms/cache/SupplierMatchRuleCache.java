package com.zuzuche.sms.cache;

import com.zuzuche.commons.base.constants.BaseEnum;
import com.zuzuche.commons.base.util.StringUtil;
import com.zuzuche.sms.cache.co.CommonMatchRuleCo;
import com.zuzuche.sms.common.enums.SupplierMatchExtraRules;
import com.zuzuche.sms.entity.CommonMatchRule;
import com.zuzuche.sms.mapper.CommonMatchRuleMapper;
import com.zuzuche.sms.mapper.RulesSupplierRelatedMapper;
import com.zuzuche.sms.vo.SupplierRuleMatchInfo;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

/**
 * 功能：短信发送规则与供应商匹配缓存层.
 * 详细：
 *
 * @author Created on 2019.03.11 by chaodian
 */
@Component("SupplierMatchRuleCache")
@Slf4j
public class SupplierMatchRuleCache implements InitializingBean,ConfigCache {
    /**
     * The Extra rule mapper.
     */
    @Autowired
    RulesSupplierRelatedMapper extraRuleMapper;

    /**
     * The Common rule mapper.
     */
    @Autowired
    CommonMatchRuleMapper commonRuleMapper;

    /**
     * 供应商特殊匹配规则配置信息
     */
    private static Map<String, List<SupplierRuleMatchInfo>> extraRuleMap = new HashMap<>();

    /**
     * 供应商普通规则匹配配置信息
     */
    private static Map<Integer, List<CommonMatchRuleCo>> commonRuleMap = new HashMap<>();

    /**
     * 国际短信供应商规则匹配配置信息
     */
    private static Map<String, List<CommonMatchRuleCo>> interCommonRuleMap = new HashMap<>();

    /**
     * 供应商和账号的配置信息
     */
    private static Map<Integer,String> accountSupplierMap =new ConcurrentHashMap<>();

    /**
     * 供应商特殊匹配规则名称列表
     */
    private static List<String> extraSignNameList = new ArrayList<>();

    /**
     * Contains extra rule key boolean.
     *
     * @param key the key
     * @return the boolean
     */
    public boolean containsExtraRuleKey(String key){
        return extraRuleMap.containsKey(key);
    }

    /**
     * Get extra rules list.
     *
     * @param key the key
     * @return the list
     */
    public List<SupplierRuleMatchInfo> getExtraRules(String key){
        return extraRuleMap.get(key);
    }

    /**
     * Contains common rule key boolean.
     *
     * @param key the key
     * @return the boolean
     */
    public boolean containsCommonRuleKey(Integer key){
        return commonRuleMap.containsKey(key);
    }

    public String getSupplierByAccountId(int account){
        if(account<=0){
            return "";
        }
        if(accountSupplierMap.containsKey(account)){
            return accountSupplierMap.get(account);
        }
        return "";
    }
    /**
     * Get common rules list.
     *
     * @param key the key
     * @return the list
     */
    public List<CommonMatchRuleCo> getCommonRules(Integer key){
        return commonRuleMap.get(key);
    }

    /**
     * 构建国际短信规则的key.
     * 国际短信区号的规则格式为： <签名>_<类型>_<国家类型>_<国家区号>;，如14_1_2_886
     *
     * @param sign       the sign
     * @param type       the type
     * @param regionType the region type
     * @param areaCode   the area code
     * @return the string
     */
    private String buildInterCommonRuleKey(int sign, int type, int regionType, String areaCode) {
        return sign + "_" + type + "_" + regionType + "_" + areaCode;
    }

    /**
     * Contains inter common rule key boolean.
     *
     * @param sign       the sign
     * @param type       the type
     * @param regionType the region type
     * @param areaCode   the area code
     * @return the boolean
     */
    public boolean containsInterCommonRuleKey(int sign, int type, int regionType, String areaCode){
        String key = buildInterCommonRuleKey(sign, type, regionType, areaCode);
        return interCommonRuleMap.containsKey(key);
    }

    /**
     * Gets inter common rules.
     *
     * @param sign       the sign
     * @param type       the type
     * @param regionType the region type
     * @param areaCode   the area code
     * @return the inter common rules
     */
    public List<CommonMatchRuleCo> getInterCommonRules(int sign, int type, int regionType, String areaCode) {
        String key = buildInterCommonRuleKey(sign, type, regionType, areaCode);
        return interCommonRuleMap.get(key);
    }

    /**
     * Gets all extra sign names.
     *
     * @return all extra sign names
     */
    public List<String> getAllExtraSignNames() {
        return extraSignNameList;
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        loadExtraRule();
        loadCommonRule();
    }

    /**
     * 加载所有额外的匹配规则
     */
    public synchronized void loadExtraRule() {
        List<SupplierRuleMatchInfo> list = extraRuleMapper.queryAllRulesList();
        Map<String, List<SupplierRuleMatchInfo>> extraRuleMapTemp = new HashMap<>();
        List<SupplierRuleMatchInfo> tempList = new ArrayList<>(list);
        List<String> extraSignNameListTemp = new ArrayList<>();
        if(CollectionUtils.isNotEmpty(list)){
            list.forEach(e->{
                List<SupplierRuleMatchInfo> eachList = tempList.stream()
                        .filter(item->item.getSign().equals(e.getSign()))
                        .collect(Collectors.toList());
                if (CollectionUtils.isNotEmpty(eachList)) {
                    extraRuleMapTemp.put(e.getSign(), eachList);
                }

                if(e.getAccountId()>0){
                    accountSupplierMap.put(e.getAccountId(),e.getSupplier());
                }
            });

            extraSignNameListTemp = list.stream()
                    .filter(e-> BaseEnum.parse(SupplierMatchExtraRules.class, e.getSign()) != null )
                    .map(SupplierRuleMatchInfo::getSign)
                    .collect(Collectors.toList());
        }

        extraRuleMap=extraRuleMapTemp;
        extraSignNameList=extraSignNameListTemp;
    }

    /**
     * 加载所有的普通短信匹配规则
     */
    public synchronized void loadCommonRule() {
        List<CommonMatchRule> list = commonRuleMapper.selectAll();
        List<CommonMatchRule> tempList = new ArrayList<>(list);
        Map<Integer, List<CommonMatchRuleCo>> commonRuleMapTemp = new HashMap<>();
        Map<String, List<CommonMatchRuleCo>> tempInterCommonRuleMap = new HashMap<>(128);
        if(CollectionUtils.isNotEmpty(list)) {
            list.forEach(e->{
                List<CommonMatchRuleCo> eachList = tempList.stream()
                        .filter(item->item.getSign().equals(e.getSign()))
                        .map(item->{
                            return CommonMatchRuleCo.builder()
                                    .sign(item.getSign())
                                    .smsType(item.getType())
                                    .regionType(item.getRegionType())
                                    .supplier(item.getSupplier())
                                    .accountId(item.getAccountId())
                                    .level(item.getLevel())
                                    .build();
                        }).collect(Collectors.toList());

                if (CollectionUtils.isNotEmpty(eachList)) {
                    commonRuleMapTemp.put(Short.toUnsignedInt(e.getSign()), eachList);
                }
                //设置账号_供应商对应配置信息
                accountSupplierMap.put(e.getAccountId(),e.getSupplier());

                // 下面为国际的规则进行配置，如果权重为0，表示不需要发送，也不设置
                if (StringUtil.isNotBlank(e.getAreaCodes()) && e.getLevel() > 0) {
                    List<String> areaCodes = StringUtil.asList(e.getAreaCodes());
                    CommonMatchRuleCo interCommonRule = CommonMatchRuleCo.builder()
                            .sign(e.getSign())
                            .smsType(e.getType())
                            .regionType(e.getRegionType())
                            .supplier(e.getSupplier())
                            .accountId(e.getAccountId())
                            .level(e.getLevel())
                            .build();
                    for (String areaCode : areaCodes) {
                        // 国际短信区号的规则格式为： <签名>_<类型>_<国家类型>_<国家区号>;，如14_1_2_886
                        String interRuleKey = buildInterCommonRuleKey(e.getSign(), e.getType(), e.getRegionType(), areaCode);
                        if (tempInterCommonRuleMap.containsKey(interRuleKey)) {
                            List<CommonMatchRuleCo> existRuleList = tempInterCommonRuleMap.get(interRuleKey);
                            existRuleList.add(interCommonRule);
                            tempInterCommonRuleMap.put(interRuleKey, existRuleList);
                        } else {
                            List<CommonMatchRuleCo> newRuleList = new ArrayList<>();
                            newRuleList.add(interCommonRule);
                            tempInterCommonRuleMap.put(interRuleKey, newRuleList);
                        }
                    }
                }
            });
        }

        commonRuleMap=commonRuleMapTemp;
        interCommonRuleMap = tempInterCommonRuleMap;
    }

    @Override
    public boolean refresh() {
        try {
            loadExtraRule();
            loadCommonRule();
            return true;
        } catch (Exception e) {
            log.error("【SupplierMatchRuleCache】配置刷新失败",e.getMessage(),e);
            return false;
        }

    }
}
