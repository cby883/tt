package com.zuzuche.sms.mapper;

import com.zuzuche.commons.mybatis.BaseMapper;
import com.zuzuche.sms.entity.RulesSupplierRelated;
import com.zuzuche.sms.vo.SupplierRuleMatchInfo;

import java.util.List;


/**
 * The interface Rules supplier related mapper.
 */
public interface RulesSupplierRelatedMapper extends BaseMapper<RulesSupplierRelated> {

    /**
     * Query all rules list list.
     *
     * @return the list
     */
    List<SupplierRuleMatchInfo> queryAllRulesList();
}