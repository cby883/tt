package com.zuzuche.sms.cache;

import com.zuzuche.commons.base.util.StringUtil;
import com.zuzuche.sms.entity.SmsCustomer;
import com.zuzuche.sms.mapper.SmsCustomerMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.concurrent.ThreadSafe;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 功能：业务方配置
 * 详细：
 *
 * @author bingyi
 * @blame Android Team
 */
@Slf4j
@Component("SmsCustomerCache")
@ThreadSafe
public class SmsCustomerCache implements ConfigCache, InitializingBean {

    @Autowired
    SmsCustomerMapper smsCustomerMapper;

    /**
     * 缓存业务方到此处
     */
    private Map<String, SmsCustomer> smsCustomerMap = new HashMap<>(63);

    @Override
    public boolean refresh() {
        try {
            load();
        } catch (Exception e) {
            log.error("短信业务方刷新配置失败", e.getMessage(), e);
            return false;
        }
        return true;
    }

    /**
     * 获取整个业务方配置
     *
     * @return
     */
    public Map<String, SmsCustomer> getSmsCustomers() {
        return this.smsCustomerMap;
    }

    /**
     * 根据业务方标识获取业务方营销短信发送频率
     *
     * @param sign
     * @return
     */
    public int getMkFreqBySign(String sign) {
        if(StringUtil.isEmpty(sign)){
            return 0;
        }
        //判断是否存在业务方标识
        if (smsCustomerMap != null && smsCustomerMap.containsKey(sign)) {
               SmsCustomer smsCustomer=smsCustomerMap.get(sign);
               return smsCustomer.getMkInterceptFreq();
        }
        //返回0默认没有配置
        return 0;
    }

    /**
     * 获取营销短信的时间间隔
     * @param sign
     * @return
     */
    public int getMkDuration(String sign){
        //验参
        if(StringUtil.isEmpty(sign)||!smsCustomerMap.containsKey(sign)){
            return 0;
        }
        return smsCustomerMap.get(sign).getMkFreqDuration();
    }

    /**
     * 通过业务方标识查看是否开启营销拦截规则
     * @param sign
     * @return
     */
    public boolean hasOpenMkFreq(String sign){
        //判断是否存在key或者空标识
        if(StringUtil.isEmpty(sign)||!smsCustomerMap.containsKey(sign)){
            return false;
        }
        //查看是否开启
        SmsCustomer smsCustomer=smsCustomerMap.get(sign);
        return smsCustomer.getHasOpenMkFreq()==1;
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        //预加载
        load();
    }

    private synchronized void load() {
        List<SmsCustomer> temp = smsCustomerMapper.selectAll();
        Map<String, SmsCustomer> smsCustomerMapTemp = new HashMap<>(63);
        smsCustomerMapTemp = temp.stream().collect(Collectors.toMap(SmsCustomer::getSign, SmsCustomer -> SmsCustomer));
        smsCustomerMap = smsCustomerMapTemp;
    }
}
