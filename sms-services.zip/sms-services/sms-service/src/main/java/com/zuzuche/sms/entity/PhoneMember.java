package com.zuzuche.sms.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Table;

/**
 * 功能：The type Phone member.
 * 详细：
 *
 * @author Created on 2019.01.31 by chaodian
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "zuzuche_sms_db.phone_member_tbl")
public class PhoneMember {
    private Integer id;

    private String mobile;

    private Byte type;

    private String remark;

    private Integer addTime;

    private String smsTypes;

    private String fromTypes;
}