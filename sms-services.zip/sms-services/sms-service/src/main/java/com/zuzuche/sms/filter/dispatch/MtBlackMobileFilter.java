package com.zuzuche.sms.filter.dispatch;


import com.google.common.base.Joiner;
import com.google.common.base.Splitter;
import com.zuzuche.commons.base.util.StringUtil;
import com.zuzuche.sms.cache.BlackWiteMobileCache;
import com.zuzuche.sms.cache.co.BlackMobileCo;
import com.zuzuche.sms.common.enums.FilterTypes;
import com.zuzuche.sms.dto.FilterMtDto;
import com.zuzuche.sms.dto.MtDto;
import com.zuzuche.sms.filter.MtFilter;
import com.zuzuche.sms.service.KafkaService;
import com.zuzuche.sms.service.SmsMtService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/**
 * 功能：下行黑名单手机过滤器.
 * 详细：
 *
 * @author Created on 2019.03.16 by chaodian
 */
@Component
@Slf4j
@Order(4)
public class MtBlackMobileFilter implements MtFilter {

    /**
     * The Cache.
     */
    @Autowired
    BlackWiteMobileCache cache;

    /**
     * The Kafka service.
     */
    @Autowired
    KafkaService kafkaService;

    /**
     * The Sms mt service.
     */
    @Autowired
    SmsMtService smsMtService;

    @Override
    public boolean doFilter(MtDto mtDto) {
        // 没有需要发送的手机号码， 但是有白名单，白名单需要绕过黑名单检测
        if (StringUtil.isBlank(mtDto.getMobiles())) {
            return StringUtil.isNotBlank(mtDto.getWhiteMobiles());
        }

        List<String> mobileList = Splitter.on(",").splitToList(mtDto.getMobiles());

        // 初始化可以通过的手机和被黑名单拦截的手机列表
        List<String> passMobileList = new ArrayList<>();
        List<String> blackMobileList = new ArrayList<>();

        mobileList.forEach(mobile->{
            if (cache.containsBlackMob(mobile)) {
                BlackMobileCo blackMobileCo = cache.getBlackMobConfig(mobile);
                //　找得到黑名单手机的话，如果该黑名单配置的短信类型为空或者该此短信请求的类型是含在这个配置的短信类型里，则被拦截
                if (StringUtil.isEmpty(blackMobileCo.getSmsTypes())
                        || StringUtil.contains(blackMobileCo.getSmsTypes(), mtDto.getType() + "")) {
                    // 如果黑名单配置含有业务方参数
                    // 则判断短信的业务方是否在配置的业务方里, 存在的话则加入黑名单
                    // 如果黑名单配置不含有业务方参数,则默认标识所有业务方都拦截, 加入黑名单
                    if (StringUtil.isEmpty(blackMobileCo.getFromTypes())) {
                        blackMobileList.add(mobile);
                    } else {
                        if (StringUtil.isNotBlank(mtDto.getFrom()) && StringUtil.contains(blackMobileCo.getFromTypes(), mtDto.getFrom())) {
                            blackMobileList.add(mobile);
                        } else {
                            passMobileList.add(mobile);
                        }
                    }

                } else {
                    passMobileList.add(mobile);
                }
            } else {
                passMobileList.add(mobile);
            }
        });

        if (CollectionUtils.isNotEmpty(blackMobileList)) {
            int errorCode = FilterTypes.黑名单过滤器.code();
            FilterMtDto filterMtDto = FilterMtDto.builder()
                    .content(mtDto.getContent())
                    .errorCode(errorCode)
                    .mobileList(blackMobileList)
                    .build();
            kafkaService.sendToFilterTopic(filterMtDto);
        }

        boolean resetState = smsMtService.resetMtMobiles(mtDto, passMobileList);
        // 识别到有白名单，还是会返回true
        return  StringUtil.isNotBlank(mtDto.getWhiteMobiles()) || resetState;
    }
}
