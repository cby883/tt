package com.zuzuche.sms.rest.request;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * desc:状态报告码详情请求体
 *
 * @author bingyi
 * @date 2019/08/20
 */
@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
@ApiModel(value = "状态报告码详情请求体")
public class SmsReportErrorReq {
    @ApiModelProperty(value = "错误码Json")
    public String  jsonList;
}
