package com.zuzuche.sms.rest;


import com.zuzuche.commons.base.annotation.Check;
import com.zuzuche.commons.base.resp.RespResult;
import com.zuzuche.sms.cache.SmsConfigCache;
import com.zuzuche.sms.dto.RefreshConfigDto;
import com.zuzuche.sms.entity.SmsConfig;
import com.zuzuche.sms.rest.request.CustomerMkFreqReq;
import com.zuzuche.sms.rest.request.RefreshSmsMtConfigReq;
import com.zuzuche.sms.rest.response.SmsLimiterResp;
import com.zuzuche.sms.service.RefreshConfigService;
import com.zuzuche.sms.service.SmsCustomerService;
import com.zuzuche.sms.service.SmsMtService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.constraints.Min;
import java.util.List;

/**
 * 功能：短信配置操作接口.
 * 详细：
 *
 * @author Created on 2019.03.18 by chaodian
 */
@RestController
@RequestMapping("/smsConfig")
@Slf4j
@Api(value = "smsConfig", description = "短信下行配置", tags = {"smsConfig"})
public class SmsConfigRest {

    @Autowired
    RefreshConfigService refreshConfigService;
    @Autowired
    SmsMtService smsMtService;

    @Autowired
    SmsConfigCache smsConfigCache;

    @Autowired
    SmsCustomerService smsCustomerService;

    /**
     * 重新刷新载入下行短信配置
     *
     * @param req the req
     * @return resp result
     */
    @GetMapping("/refreshSmsMtConfig")
    @ApiOperation(value = "重新刷新载入下行短信配置", notes = "重新刷新载入下行短信配置")
    @Check
    public RespResult refreshSmsMtConfig(RefreshSmsMtConfigReq req) {
        List<RefreshConfigDto> result = smsMtService.refreshMtConfig(req);
        return RespResult.success(result);
    }

    @GetMapping("/refreshRate")
    @ApiOperation(value = "重新载入限流器配置", notes = "重新载入限流器配置")
    public RespResult refreshRate() {
        List<RefreshConfigDto> result = smsMtService.refreshMtConfig(RefreshSmsMtConfigReq.builder()
                .configName("SmsConfigCache")
                .build());
        return RespResult.success(result);
    }

    /**
     * 重新刷新短信消费速率配置
     *
     * @return resp result
     */
    @GetMapping("/refreshSmsRateConfig")
    @ApiOperation(value = "重新刷新短信消费速率配置(弃用)", notes = "重新刷新短信消费速率配置(弃用)")
    @Check
    public RespResult refreshSmsRateConfig() {
        try {
            smsConfigCache.afterPropertiesSet();
            return RespResult.success();
        } catch (Exception e) {
            return RespResult.error(e.getMessage());
        }
    }

    @GetMapping(value = "/refresh/{configName}")
    public RefreshConfigDto refresh(@PathVariable(value = "configName") String configName) {
        RefreshConfigDto refreshConfigDto = refreshConfigService.refresh(configName);
        return refreshConfigDto;
    }

    @PostMapping(value = "/updateRate")
    @ApiOperation(value = "更新限流器速率", notes = "更新限流器速率")
    public RespResult updateRateLimiter(@ApiParam(value = "限流器配置名") @RequestParam(value = "rateConfigName") String rateConfigName
            , @ApiParam(value = "速率值") @RequestParam(value = "rateVal") @Min(0) int rateVal) {
        SmsLimiterResp smsLimiterResp = refreshConfigService.updateRate(rateConfigName, rateVal);
        return RespResult.success(smsLimiterResp);
    }

    @GetMapping(value = "/getAllLimiter")
    @ApiOperation(value = "获取所有的限流器的当前内存值", notes = "获取所有的限流器的当前内存值")
    public RespResult getLimiter() {
        List<SmsConfig> list = refreshConfigService.getAllRate();
        return RespResult.success(list);
    }

    @PostMapping(value = "/updateCustomerMkFreq")
    @ApiOperation(value = "更新业务方营销短信发送拦截数量", notes = "更新业务方营销短信发送拦截数量")
    public RespResult updateCustomerMkFreq(CustomerMkFreqReq req) {
        //刷新
        List<RefreshConfigDto> result=smsCustomerService.updateMkFreqBySign(req);
        if(result!=null){
            return RespResult.success(result);
        }
        return RespResult.error("更新数据库配置失败(缓存没做更新)");
    }
}
