package com.zuzuche.sms.report.mq.puller;

import com.alicom.mns.tools.DefaultAlicomMessagePuller;
import com.alicom.mns.tools.MessageListener;
import com.aliyuncs.exceptions.ClientException;
import com.zuzuche.commons.base.resp.Status;
import com.zuzuche.commons.base.resp.StatusServiceCnException;
import lombok.extern.slf4j.Slf4j;

import java.text.ParseException;

/**
 * desc:拉取回执消息抽象父类
 *
 * @author bingyi
 * @date 2019/08/23
 */
@Slf4j
public class AliYunMessagePuller {
    public static void startListener(String accessKeyId, String accessKeySecret, String messageType, String queueName, MessageListener messageListener){
        DefaultAlicomMessagePuller defaultAlicomMessagePuller=new DefaultAlicomMessagePuller();
        try {
            defaultAlicomMessagePuller.startReceiveMsg(accessKeyId,accessKeySecret,messageType,queueName,messageListener);
        }catch (ClientException ce){
        log.error("【重要,阿里云短信状态报告和上行短信拉取类加载失败！！！】",ce.getMessage(),ce);
        throw new StatusServiceCnException(Status.BUSY,"【重要,阿里云短信状态报告和上行短信拉取类加载失败！！！】");
        }catch (ParseException pe){
        log.error("【重要,阿里云短信状态报告和上行短信拉取类加载失败！！！】",pe.getMessage(),pe);
        throw new StatusServiceCnException(Status.BUSY,"【重要,阿里云短信状态报告和上行短信拉取类加载失败！！！】");
    }
    }

}
