package com.zuzuche.sms.rest.request;

/**
 * @desc:
 * @author: panqiong
 * @date: 2018/10/24
 */
public class RetriveInboundSmsReq {
}
