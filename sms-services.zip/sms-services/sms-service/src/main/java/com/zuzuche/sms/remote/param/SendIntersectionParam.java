package com.zuzuche.sms.remote.param;

import com.alibaba.fastjson.annotation.JSONField;
import com.zuzuche.commons.feign.annotation.PhpRequest;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * 功能：插入交互记录提交参数.
 * 详细：
 *
 * @author Created on 2019.03.15 by chaodian
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@PhpRequest
public class SendIntersectionParam {
    /**
     * 交互记录的唯一id
     */
    @JSONField(name = "bussiness_id")
    private String businessId;

    /**
     * 客服账号
     */
    @JSONField(name = "admin_id")
    private String adminId;

    /**
     * 手机号码
     */
    private String phone;

    /**
     * 提交时间
     */
    @JSONField(name = "start_time")
    private int startTime;

    /**
     * 短信下行/上行类型，1为下行，2为上行
     */
    @JSONField(name = "sms_type")
    @Builder.Default
    private int smsType = 1;

    /**
     * 短信内容
     */
    private String content;

    /**
     * 来源网站
     */
    @Builder.Default
    private String website = "zuzuche";

    /**
     * 项目渠道
     */
    @Builder.Default
    private String project = "sms";
}
