package com.zuzuche.sms.executors;

import com.zuzuche.sms.common.utils.SpringBeanFactory;
import com.zuzuche.sms.dto.SmsDto;
import com.zuzuche.sms.task.AbstractSendTask;
import com.zuzuche.sms.task.MiaoXinSendTask;
import com.zuzuche.threadpool.ThreadPoolExecutorFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * @desc: 秒信的工作线程池
 * @author: bingyi
 * @date: 2019/12/14
 */
@Component
@Slf4j
public class MiaoxinExecutor extends AbstractOutboundExecutor {
    public MiaoxinExecutor() {
        super(
                ThreadPoolExecutorFactory.Config.builder()
                        .corePoolSize(20)
                        .maximumPoolSize(25)
                        .keepAliveTime(2)
                        .workQueue(new ArrayBlockingQueue<>(100))
                        .unit(TimeUnit.MINUTES)
                        .handler(new ThreadPoolExecutor.CallerRunsPolicy())
                        .threadPoolName("MiaoxinExecutor")
                        .build()
        );
    }


    /**
     * @param sms
     */
    @Override
    public AbstractSendTask packingSendTask(SmsDto sms) {
        // 获取一个实例化的原型任务对象
        MiaoXinSendTask miaoXinSendTask = SpringBeanFactory.getBean(MiaoXinSendTask.class, sms);

        return miaoXinSendTask;
    }
}
