package com.zuzuche.sms.remote.dto;


import com.zuzuche.sms.vo.SmsTemplateText;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * 功能：The type Sms template dto.
 * 详细：
 *
 * @author Created on 2019.02.13 by chaodian
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SmsTemplateDto {
    /**
     * 短信模板id
     */
    private String tempId;

    /**
     * 短信模板标识
     */
    private String tempUid;

    /**
     * 短信模板名称
     */
    private String name;

    /**
     * 短信类型
     */
    private Integer sendType;

    /**
     * 短信模板内容
     */
    private List<SmsTemplateText> text;
}
