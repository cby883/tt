package com.zuzuche.sms.remote;

import com.zuzuche.commons.base.resp.PhpResult;
import com.zuzuche.sms.remote.dto.SmsTemplateDto;
import com.zuzuche.sms.remote.param.PhpParam;
import feign.Headers;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.cloud.openfeign.FeignClient;

import java.util.List;

/**
 * 短信模板请求api
 * @author chaodian
 * @date 2019-02-13
 *
 */
@FeignClient(name="zcsTemp",url="${zcs.url}")
@Headers({"Content-Type: application/x-www-form-urlencoded","Cookie:allow_test_ip=1,header_code=1"})
public interface SmsTemplateRemote {

    /**
     * 根据模板ID获取模板
     * @param param the param
     * @return php result
     */
    @PostMapping(value = "/zcsTemp/getAllSmsTemplates",consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
    PhpResult<List<SmsTemplateDto>> getAllTemplates(PhpParam param);
}