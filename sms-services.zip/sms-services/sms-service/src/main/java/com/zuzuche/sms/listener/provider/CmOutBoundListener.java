package com.zuzuche.sms.listener.provider;

import com.google.common.util.concurrent.RateLimiter;
import com.zuzuche.sms.cache.SmsConfigCache;
import com.zuzuche.sms.common.enums.RateLimiterKeyTypes;
import com.zuzuche.sms.dto.SmsDto;
import com.zuzuche.sms.executors.CmExecutor;
import com.zuzuche.sms.service.KafkaService;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import java.util.concurrent.RejectedExecutionException;

/**
 * 功能：CM供应商短信消费监听器.
 * 详细：
 *
 * @author Created on 2019.09.08 by chaodian
 */
@Component
@Slf4j
public class CmOutBoundListener  {

    private static String RATE_KEY = "cm_sms_outbound_topic_rate";

    private static RateLimiter rateLimiter;

    @Autowired
    SmsConfigCache configCache;

    @Autowired
    CmExecutor outboundExecutor;

    /**
     * 注意:
     *  - 如果消息处理超时,spring默认最多会重新处理三次
     *  - 如果对消息保障性要求高,发生异常要预警,可以把处理失败的消息转发到dlq队列
     *  - 优雅退出应用,不然会可能丢失已消费未处理的消息
     * 短信下发队列
     * @param consumer
     */
    @KafkaListener(topics = KafkaService.CM_SMS_OUTBOUND_TOPIC)
    public void consume(ConsumerRecord<String, SmsDto> consumer) {
        if(log.isDebugEnabled()){
            log.debug("[receive cm_sms_outbound_topic]:" +consumer.value());
        }
        rateLimiter=configCache.getLimiter(RateLimiterKeyTypes.CM_SMS_OUTBOUND_TOPIC_RATE);
        rateLimiter.acquire();
        try{
            // 1个短信实体
            SmsDto sms = consumer.value();
            // 下行业务处理
            outboundExecutor.handle(sms);

        }catch (RejectedExecutionException e){
            log.error("[CM线程池拒绝策略触发-cm_sms_outbound_topic]message:"+consumer.value(),e.getMessage(),e);
            // 发送到dlq队列 并预警人工接入
            //kafkaService.sendToDlq(consumer.value());
        }catch (Exception e){
            // 发送到dlq队列 并预警人工接入
            log.error("[CM消息处理出现异常-cm_sms_outbound_topic]message:"+consumer.value(),e.getMessage(),e);
            //kafkaService.sendToDlq(consumer.value());
        }


    }
}
