package com.zuzuche.sms.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Table;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "zuzuche_sms_db.safe_monitor_rule_tbl")
public class SafeMonitorRule {
    private Integer id;

    private String func;

    private String name;

    private Byte status;

    private String desc;

    private String extraParam;

    private Integer addTime;
}