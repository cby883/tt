package com.zuzuche.sms.service;

import com.zuzuche.commons.base.util.StringUtil;
import com.zuzuche.sms.cache.SmsCustomerCache;
import com.zuzuche.sms.common.enums.ConfigNameTypes;
import com.zuzuche.sms.dto.RefreshConfigDto;
import com.zuzuche.sms.entity.SmsCustomer;
import com.zuzuche.sms.mapper.SmsCustomerMapper;
import com.zuzuche.sms.rest.request.CustomerMkFreqReq;
import com.zuzuche.sms.rest.request.RefreshSmsMtConfigReq;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * 功能：业务方service.
 * 详细：
 *
 * @author Created on bingyi
 * @blame Android Team
 */
@Service
@Slf4j
public class SmsCustomerService {
    @Autowired
    private SmsCustomerMapper smsCustomerMapper;
    @Autowired
    private SmsCustomerCache smsCustomerCache;
    @Autowired
    SmsMtService smsMtService;

    /**
     * 更新营销拦截数量配置
     *
     * @param req
     * @return
     */
    public List<RefreshConfigDto> updateMkFreqBySign(CustomerMkFreqReq req) {
        Map<String, SmsCustomer> map = smsCustomerCache.getSmsCustomers();
        //设置返回值
        List<RefreshConfigDto> result = null;
        if (StringUtil.isNotEmpty(req.getCustomerSign()) && map.containsKey(req.getCustomerSign()) && req.getInterceptFreq() > 0) {
            //更新值
            SmsCustomer smsCustomer = map.get(req.getCustomerSign());
            smsCustomer.setMkInterceptFreq(req.getInterceptFreq());
            smsCustomer.setHasOpenMkFreq(req.getHasOpenMkFreq());
            smsCustomer.setMkFreqDuration(req.getMkFreqDuration());
            int operate = smsCustomerMapper.updateByPrimaryKeySelective(smsCustomer);
            if (operate > 0) {
                //刷新配置
                result = smsMtService.refreshMtConfig(RefreshSmsMtConfigReq.builder()
                        .configName(ConfigNameTypes.SMS_CUSTOMER_CACHE.code())
                        .build());
            }
        }
        //返回
        return result;
    }
}
