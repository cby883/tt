package com.zuzuche.sms.report.mq.listener;

import com.alicom.mns.tools.MessageListener;
import com.aliyun.mns.model.Message;
import com.zuzuche.commons.base.util.JsonUtil;
import com.zuzuche.sms.cache.ProviderAccountCache;
import com.zuzuche.sms.entity.ProviderAccountInfo;
import com.zuzuche.sms.entity.StatusReport;
import com.zuzuche.sms.report.dto.AliYunReportDto;
import com.zuzuche.sms.report.mq.AbstractListener;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * @desc:阿里云接收云通信消息的监听器
 *
 * @author bingyi
 * @date 2019/08/20
 */
@Slf4j
@Component
@Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class AliYunReportListener extends AbstractListener implements MessageListener {
    private int accountId=0;
    private int provideId=0;

    public AliYunReportListener(int accountId){
        this.accountId=accountId;
    }
    /**
     * 返回true,则此条消息从队列中删除
     * @param message
     * @return
     */
    @Override
    public boolean dealMessage(Message message) {
        String result;
        List<StatusReport> list=new ArrayList<>();
        try {

            result=message.getMessageBodyAsString();
            AliYunReportDto aliYunReportDto= JsonUtil.stringToObj(result,AliYunReportDto.class);
            ProviderAccountInfo accountInfo=null;
            // 查询有效账号列表
            try{
                 accountInfo = ProviderAccountCache.getAccountById(accountId);
            }catch (Exception e){
                log.warn("状态报告中无accountId,无法加载账号信息");
            }
            if(accountInfo!=null){
                accountId=accountInfo.getAccountId();
                provideId=accountInfo.getProviderId();
            }else {
                log.warn("配置表中无次accountId的配置信息，默认填充状态报告的accountId为0");
            }

            String respCode = "";
            if (aliYunReportDto.isSuccess()) {
                respCode = "DELIVRD";
            } else {
                // 大于30个字符，进行截取
                if (aliYunReportDto.getErrCode().length() > 29) {
                    respCode = aliYunReportDto.getErrCode().substring(4,25);
                } else {
                    respCode = aliYunReportDto.getErrCode();
                }
            }

            StatusReport statusReport=StatusReport.builder()
                    .accountId(accountId)
                    .batchNo(aliYunReportDto.getBizId())
                    .createTime(LocalDateTime.now())
                    .phone(aliYunReportDto.getPhoneNumber())
                    .status(respCode)
                    .recvTime(aliYunReportDto.getReportTime()).build();
            list.add(statusReport);
            //执行收尾工作
            super.mqStatusReport(provideId,list);
        }catch (com.google.gson.JsonSyntaxException e){
            log.error("error_json_format:"+message.getMessageBodyAsString(),e);
            //理论上不会出现格式错误的情况，所以遇见格式错误的消息，只能先delete,否则重新推送也会一直报错
            return true;
        }catch (Throwable e){
            log.error("【AliYunReportListener】监听器错误",e.getMessage());
           //代码部分导致的异常，应该return false,这样消息不会被delete掉，而会根据策略进行重推
            return false;
        }
        return true;
    }
}
