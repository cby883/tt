package com.zuzuche.sms.rest;

import com.zuzuche.commons.base.resp.RespResult;
import com.zuzuche.sms.cache.ProviderAccountCache;
import com.zuzuche.sms.common.enums.CmStatusReportType;
import com.zuzuche.sms.report.callback.CmCallbackService;
import com.zuzuche.sms.report.callback.HengxinCallbackService;
import com.zuzuche.sms.common.constant.Constants;
import com.zuzuche.sms.entity.ProviderAccountInfo;
import com.zuzuche.sms.report.callback.TeleSignCallbackService;
import com.zuzuche.sms.rest.request.*;
import com.zuzuche.sms.rest.response.JuchnCallbackRsp;
import com.zuzuche.sms.report.syn.JuchnSynService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @desc: 巨辰状态报告回调
 * @author: panqiong
 * @date: 2018/9/30
 */
@RestController
@RequestMapping("/expose/callback")
@Api(value = "回调接口", description = "提供给供应商回调接口", tags = {"callback"})
@Slf4j
public class CallbackRest {

    @Autowired
    JuchnSynService juchnService;

    @Autowired
    HengxinCallbackService hengxinCallbackService;

    @Autowired
    CmCallbackService cmCallbackService;

    @Autowired
    TeleSignCallbackService teleSignCallbackService;


    /**
     * 状态报告
     * 提供给巨辰回调
     * 暂未启用
     *
     * @param req
     * @return
     */
    @PostMapping("/juchn/status")
    @ApiOperation(value = "状态报告回调", notes = "状态报告回调")
    public RespResult<JuchnCallbackRsp> statusCallback(JuchnStatusCallbackReq req) {
        juchnService.synStatusReport(Constants.JUCHN_PROVIDER_ID);
        return RespResult.success(new JuchnCallbackRsp(0));
    }

    /**
     * 上行短信
     * 提供给巨辰回调
     * 暂未启用
     *
     * @param req
     * @return
     */
    @PostMapping("/juchn/inbound")
    @ApiOperation(value = "上行短信回调", notes = "上行短信回调")
    public RespResult<JuchnCallbackRsp> smsCallback(JuchnSmsCallbackReq req) {
        juchnService.synInboundSms(Constants.JUCHN_PROVIDER_ID);
        return RespResult.success(new JuchnCallbackRsp(0));
    }

    /**
     * 状态报告
     * 提供给卓越恒信供应商回调
     *
     * @param req the req
     * @return resp result
     */
    @PostMapping("/hengxin/status")
    @ApiOperation(value = "恒信状态报告回调", notes = "恒信状态报告回调")
    public RespResult hengxinStatusCallBack(HengxinStatusCallbackReq req) {
        // 卓越恒新供应商的回调请求协议，带上account账户名称
        ProviderAccountInfo account = ProviderAccountCache.getAccountByNameAndProviderId(req.getAccountId(), Constants.HENGXIN_PROVIDER_ID);
        hengxinCallbackService.callbackStatusReport(account, req);
        return RespResult.success();
    }

    /**
     * 状态报告
     * 提供给CM供应商回调
     *
     * @param req the req
     * @return resp result
     */
    @GetMapping("/cm/status")
    @ApiOperation(value = "cm状态报告回调", notes = "cm状态报告回调")
    public RespResult cmStatusCallBack(CmStatusCallbackReq req) {
        if (CmStatusReportType.SUBMIT_SUCCESS.getCode().equals(req.getSTATUS())) {
            log.info("CM短信的提交成功报告不需要接收:" + req.toString());
        } else {
            int accountId = cmCallbackService.getAccountIdByBatchNo(req.getREFERENCE());
            ProviderAccountInfo account = ProviderAccountCache.getAccountById(accountId);
            cmCallbackService.callbackStatusReport(account, req);
        }
        return RespResult.success();
    }

    @PostMapping("/teleSign/status")
    @ApiOperation(value = "teleSign状态报告回调", notes = "teleSign状态报告回调")
    public RespResult teleSignReportStatus(@RequestBody TeleSignCallbackReq teleSignCallbackReq) {
        //转换session_id
        TeleSignCallbackReq teleSignCallbackReq1 = teleSignCallbackService.completion(teleSignCallbackReq);
        //获取ProviderAccountId
        ProviderAccountInfo account = ProviderAccountCache.getAccountById(teleSignCallbackReq.getAccoundId());
        //调用回调
        teleSignCallbackService.callbackStatusReport(account, teleSignCallbackReq1);
        return RespResult.success();
    }


}
