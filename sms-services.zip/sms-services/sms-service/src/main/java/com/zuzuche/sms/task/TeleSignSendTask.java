package com.zuzuche.sms.task;

import com.zuzuche.sms.cache.ProviderAccountCache;
import com.zuzuche.sms.dto.InvokeResultDto;
import com.zuzuche.sms.dto.SmsDto;
import com.zuzuche.sms.entity.ProviderAccountInfo;
import com.zuzuche.sms.remote.AliYunPushApi;
import com.zuzuche.sms.remote.TeleSignPushApi;
import com.zuzuche.sms.remote.dto.AliYunSmsSendDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.time.LocalDateTime;


/**
 * @desc: teleSign发送短信任务
 *        原型模式
 * @author: bingyi
 * @date: 2019/08/30
 */
@Slf4j
@Component
@Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class TeleSignSendTask extends AbstractSendTask{

    @Autowired
    TeleSignPushApi teleSignPushApi;

    TeleSignSendTask(SmsDto sms) {
        super(sms);
    }


    /**
     * 过滤器链
     */
    @Override
    public boolean beforeSend(SmsDto sms) {
        return super.beforeSend( sms);
    }

    /**
     * 发送给供应商
     */
    @Override
    public InvokeResultDto invokeApi(SmsDto sms) {
        InvokeResultDto result=teleSignPushApi.sendSms(sms);
       return result;

    }

    public static void main(String[] args) {

    }

}
