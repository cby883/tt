package com.zuzuche.sms.service;

import com.zuzuche.commons.base.resp.RespResult;
import com.zuzuche.commons.base.resp.Status;
import com.zuzuche.commons.base.resp.StatusServiceCnException;
import com.zuzuche.commons.base.util.JsonUtil;
import com.zuzuche.shutdown.ShutdownHook;
import com.zuzuche.sms.common.enums.SmsBatchSendTaskType;
import com.zuzuche.sms.entity.SmsBatchTask;
import com.zuzuche.sms.mapper.SmsBatchTaskMapper;
import com.zuzuche.sms.remote.BatchSendApi;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.*;

/**
 * desc:大批量发送任务容器类
 *
 * @author bingyi
 * @date 2019/11/07
 */
@Slf4j
@Service
public class BatchTaskContainerService implements ShutdownHook {

    private static final String REMOVE_ULR = "/batchSend/remove";
    @Autowired
    SmsBatchTaskMapper smsBatchTaskMapper;

    @Autowired
    DiscoveryClient discoveryClient;

    @Autowired
    BatchSendApi batchSendApi;
    /**
     * 初始值size 20
     */
    Map<Integer, SmsBatchTask> container = new HashMap<>(20);

    /**
     * 添加任务到容器中
     *
     * @param list
     * @return
     */
    public synchronized List<SmsBatchTask> add(List<SmsBatchTask> list) {
        List<SmsBatchTask> temp=new ArrayList<>();
        try {
            list.forEach(e -> {
                int preStatus = e.getStatus();
                e.setStatus(SmsBatchSendTaskType.SMS_BATCH_SEND_TASK_TYPE_RUNNING.code());
                //利用乐观锁控制任务状态
                if(smsBatchTaskMapper.updateStatus(e.getId(), e.getStatus(),preStatus)>0){
                    container.put(e.getId(),e);
                    temp.add(e);
                }
            });
            return temp;
        } catch (Exception e) {
            log.error("添加任务到执行容器中失败", e.getMessage(), e);
            return temp;
        }
    }

    /**
     * 删除任务
     *
     * @param smsBatchTask
     * @return
     */
    public synchronized boolean remove(SmsBatchTask smsBatchTask) {
        try {
            Map<Integer, SmsBatchTask> temp = new HashMap<>(container);
            if (temp.containsKey(smsBatchTask.getId())) {
                int updCount = smsBatchTaskMapper.updateStatus(smsBatchTask.getId(), smsBatchTask.getStatus(), SmsBatchSendTaskType.SMS_BATCH_SEND_TASK_TYPE_RUNNING.code());
                if (updCount <= 0) {
                    return false;
                }
                temp.remove(smsBatchTask.getId());
                container = temp;
                return true;
            } else {
                return false;
            }
        } catch (Exception e) {
            log.error("执行容器中删除任务失败", e.getMessage(), e);
            return false;
        }
    }

    /**
     * 获取任务
     *
     * @param key
     * @return
     */
    public SmsBatchTask get(int key) {
        if (container.containsKey(key)) {
            return container.get(key);
        }
        return null;
    }

    /**
     * 前端控制任务状态
     *
     * @param smsBatchTask
     * @return
     */
    public boolean updateStatus(SmsBatchTask smsBatchTask) {
        //设置更新时间
        smsBatchTask.setUpdateTime(LocalDateTime.now());
        //查出任务当前状态
        SmsBatchTask task = smsBatchTaskMapper.selectByPrimaryKey(smsBatchTask.getId());
        if (task == null) {
            throw new StatusServiceCnException(Status.PARAMS_OUT_OF_RANGE_ERROR, "找不到当前任务");
        }
        if (task.getStatus().equals(SmsBatchSendTaskType.SMS_BATCH_SEND_TASK_TYPE_RUNNING.code())) {
            //处于running中，调用两个节点的remove方法,是否命中当前节点
            if (!remove(smsBatchTask)) {
                return remote(smsBatchTask);
            }
        } else {
            //不是处于running状态，直接更新库
            int count = smsBatchTaskMapper.updateStatus(smsBatchTask.getId(), smsBatchTask.getStatus(), task.getStatus());
            if (count <= 0) {
                //任务状态更新失败
                return false;
            }
        }
        return true;
    }

    /**
     * 调用其他节点的remove方法
     *
     * @param smsBatchTask
     * @return
     */
    public boolean remote(SmsBatchTask smsBatchTask) {
        //获取eureka得节点信息
        List<ServiceInstance> serviceInstances = discoveryClient.getInstances("SMS-SERVICE");
        Iterator<ServiceInstance> it = serviceInstances.iterator();
        while (it.hasNext()) {
            ServiceInstance e = it.next();
            String requestUrl = e.getUri().toString() + REMOVE_ULR+"/"+smsBatchTask.getId()+"/"+smsBatchTask.getStatus();
            String res = batchSendApi.get(requestUrl);
            RespResult result = JsonUtil.stringToObj(res, RespResult.class);
            if (result.getCode() == Status.SUCCESS.code()) {
                return true;
            }
        }
        return false;
    }

    /**
     * 项目停机触发的钩子函数
     */
    @Override
    public void execute() {
        //把容器中的所有正在执行的任务清空
        container.keySet().forEach(e->{
            container.get(e).setStatus(SmsBatchSendTaskType.SMS_BATCH_SEND_TASK_TYPE_READY.code());
            remove(container.get(e));
        });
    }
}
