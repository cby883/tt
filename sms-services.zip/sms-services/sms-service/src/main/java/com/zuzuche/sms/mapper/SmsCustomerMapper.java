package com.zuzuche.sms.mapper;

import com.zuzuche.commons.mybatis.BaseMapper;
import com.zuzuche.sms.entity.SmsCustomer;
import org.springframework.stereotype.Repository;

/**
 * The interface Sms customer mapper.
 */
@Repository
public interface SmsCustomerMapper extends BaseMapper<SmsCustomer> {
}