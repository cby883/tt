package com.zuzuche.sms.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Table;
import java.math.BigDecimal;


/**
 * 功能：The type Supplier config.
 * 详细：
 *
 * @author Created on 2019.01.31 by chaodian
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "zuzuche_sms_db.supplier_config_tbl")
public class SupplierConfig {
    private Integer id;

    private String supplier;

    private Byte smsType;

    private Byte regionType;

    private BigDecimal price;

    private Short unitMaxCount;

    private Short unitCutCount;

    private String prefix;

    private String suffix;

    private Byte costType;

    private int cleanSignType;

    private Byte unknowStatusReportCostType;

    private Integer addTime;

    private Integer accountId;
}