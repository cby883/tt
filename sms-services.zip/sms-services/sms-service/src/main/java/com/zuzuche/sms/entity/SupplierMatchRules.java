package com.zuzuche.sms.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Table;

/**
 * 功能：The type Supplier match rules.
 * 详细：
 *
 * @author Created on 2019.01.31 by chaodian
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "zuzuche_sms_db.supplier_match_rules_tbl")
public class SupplierMatchRules {
    private Integer id;

    private String sign;

    private String name;

    private Short level;

    private Byte status;

    private Byte cutStandard;

    private Byte isOnly;

    private Integer addTime;

    private String desc;
}