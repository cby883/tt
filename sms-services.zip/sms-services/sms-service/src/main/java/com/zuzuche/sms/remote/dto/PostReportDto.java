package com.zuzuche.sms.remote.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @desc: 百唔短信报告
 * @author: panqiong
 * @date: 2018/11/5
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PostReportDto {
    private String code;
    private String desc;
    private List<Report> reportList;

    public PostReportDto(String code,String desc){
        this.code = code;
        this.desc = desc;
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class Report{

        private String corpId;

        private String mobile;
        /**
         * (0表示整条，其余数字表示一条长短信被拆分的第几条)
         */
        private String subSeq;

        /**
         * 我们传过去的
         */
        private String msgId;
        /**
         * 表示具体的错误码，其中err为0或000均表示为成功）
         */
        private String err;
        /**
         * （表示具体的错误描述）
         */
        private String failDesc;
        /**
         * 2010-07-02 00:00:00
         */
        private String reportTime;
    }
}
