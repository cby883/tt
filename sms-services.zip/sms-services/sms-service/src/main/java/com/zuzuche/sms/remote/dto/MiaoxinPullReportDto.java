package com.zuzuche.sms.remote.dto;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @desc: 秒信状态报告拉取
 * @author: bingyi
 * @date: 2019/12/13
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MiaoxinPullReportDto {
    /**
     * 请求状态。0成功，其他状态为失败
     */
    private int code;
    private String msg;
    /**
     * 总数量
     */
    private int total;
    /**
     * 营销数量
     */
    @JsonFormat(pattern = "total_mt_report")
    private String totalMtReport;
    /**
     * 普通通知数量
     */
    @JsonFormat(pattern = "total_mo_report")
    private String totalMoReport;

    /**
     * 上限拉取100条
     */
    private List<Report> reports;

    /**
     * 上行用户回复s
     */
    private List<Mos> mos;

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public  class Report{
        /**
         * 提交id号
         */
        @JsonFormat(pattern = "order_id")
        private String orderId;
        /**
         * 手机号
         */
        @JsonFormat(pattern = "mobile")
        private String mobile;
        /**
         * 错误详情
         */
        private String msg;
        /**
         * 状态码
         */
        private int status;
        /**
         * 短信发送时间
         */
        @JsonFormat(pattern = "received_time")
        private String receivedTime;
        /**
         * 完成时间
         */
        @JsonFormat(pattern = "done_time")
        private String doneTime;

        private int pieces;
        /**
         * 拓展号
         */
        private String ext;
        /**
         * 拓展
         */
        private String ref;
    }
    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public class Mos{
        /**
         * 上行用户手机
         */
        @JsonFormat(pattern = "user_mobile")
        private String userMobile;

        /**
         * 上行内容
         */
        @JsonFormat(pattern = "user_content")
        private String userContent;
        /**
         * 上行通道号码
         */
        @JsonFormat(pattern = "channel_num")
        private String channelNum;
        /**
         * 上行时间
         */
        @JsonFormat(pattern = "mo_time")
        private String moTime;
    }
}
