package com.zuzuche.sms.remote;
import com.aliyun.mns.common.ClientException;
import com.aliyuncs.CommonRequest;
import com.aliyuncs.CommonResponse;
import com.aliyuncs.DefaultAcsClient;
import com.aliyuncs.IAcsClient;
import com.aliyuncs.dysmsapi.model.v20170525.SendBatchSmsRequest;
import com.aliyuncs.dysmsapi.model.v20170525.SendBatchSmsResponse;
import com.aliyuncs.dysmsapi.model.v20170525.SendSmsRequest;
import com.aliyuncs.dysmsapi.model.v20170525.SendSmsResponse;
import com.aliyuncs.exceptions.ServerException;
import com.aliyuncs.http.MethodType;
import com.aliyuncs.profile.DefaultProfile;
import com.aliyuncs.profile.IClientProfile;
import com.google.common.base.Splitter;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.zuzuche.commons.base.util.JsonUtil;
import com.zuzuche.sms.cache.ProviderAccountCache;
import com.zuzuche.sms.cache.SmsSignCache;
import com.zuzuche.sms.cache.co.SmsSignCo;
import com.zuzuche.sms.common.constant.ErrorMessage;
import com.zuzuche.sms.dto.SmsDto;
import com.zuzuche.sms.entity.ProviderAccountInfo;
import com.zuzuche.sms.remote.dto.AliYunSmsSendDto;
import com.zuzuche.sms.remote.dto.SmsContentDto;
import com.zuzuche.sms.remote.param.AliYunPushParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;
import org.springframework.web.client.ResourceAccessException;
import java.nio.charset.Charset;
import java.util.*;

/**
 * @desc: 阿里云的推送api
 * @author: chenbingyi
 * @date: 2019/8/12
 */
@Service
@Slf4j
public class AliYunPushApi extends AbstractHttpInvoke {

    @Value(value = "${provider.aliYun.pushurl}")
    private String pushurl ;
    @Autowired
    SmsSignCache smsSignCache;

    /**
     * 配置参数
     */
    private static final String PRODUCT="Dysmsapi";
    private static final String DOMAIN="dysmsapi.aliyuncs.com";
    private static final String REGIONID="cn-hangzhou";
    private static final String ENDPOINTNAME="cn-hangzhou";
    private static final String CONNECTION_TIMEOUT="5000";
    private static final String READ_TIMEOUT="8000";


    /**
     * 额外的header设置 比如编码
     *
     * @param header
     */
    @Override
    protected void setHeader(HttpHeaders header) {
        header.setAcceptCharset(Arrays.asList(Charset.forName("UTF-8")));
    }


    /**
     1、获取签名值
     2、调用供应商短信接口
     3、封装返回体
     * @param smsDto
     * @return
     */
    @HystrixCommand(groupKey = "aLiYunApiGroup", commandKey="aLiYunSend")
    public AliYunSmsSendDto aLiYunSend(SmsDto smsDto) {
        //构造阿里云请求参数
        AliYunPushParam aliYunPushParam=formData(smsDto);

        //发送短信
        AliYunSmsSendDto result=postInvoke(aliYunPushParam);

        return result;
    }

    public  AliYunSmsSendDto postInvoke(AliYunPushParam aliYunPushParam) throws ResourceAccessException {
             String success="OK";
             //设置超时时间
             System.setProperty("sun.net.client.defaultConnectTimeout", CONNECTION_TIMEOUT);
             System.setProperty("sun.net.client.defaultReadTimeout", READ_TIMEOUT);

             //初始化ascClient,暂时不支持多region（请勿修改）
             IClientProfile profile = DefaultProfile.getProfile(REGIONID, aliYunPushParam.getAccount(),
                     aliYunPushParam.getPassword());
             try {
                 DefaultProfile.addEndpoint(ENDPOINTNAME, REGIONID, PRODUCT, DOMAIN);
             }catch (com.aliyuncs.exceptions.ClientException ce){
                 log.error("阿里云短信接口调用失败 addEndpoint",ce.getErrMsg(),ce);
                 throw new ResourceAccessException(ErrorMessage.NETWORK_CONNECT_TIME_OUT_PHRASE);
             }
             IAcsClient acsClient = new DefaultAcsClient(profile);
             //组装请求对象
             SendBatchSmsRequest request = new SendBatchSmsRequest();
             //使用post提交
             request.setMethod(MethodType.POST);
             //待发送手机号。支持JSON格式的批量调用，批量上限为100个手机号码,批量调用相对于单条调用及时性稍有延迟,验证码类型的短信推荐使用单条调用的方式
             request.setPhoneNumberJson(aliYunPushParam.getPhoneNumbers());
             //短信签名
             request.setSignNameJson(aliYunPushParam.getSign());
             //短信模板
             request.setTemplateCode(aliYunPushParam.getTemplateCode());
             request.setTemplateParamJson(aliYunPushParam.getContent());
             //上行短信扩展码 填入accountId
             request.setSmsUpExtendCodeJson(aliYunPushParam.getSmsUpExtendCodeJson());
             //请求失败这里会抛ClientException异常
             SendBatchSmsResponse sendSmsResponse=null;
             try {
                  sendSmsResponse= acsClient.getAcsResponse(request);
             }catch (com.aliyuncs.exceptions.ClientException ce){
                 log.error("阿里云短信接口调用失败 getAcsResponse",ce.getErrMsg(),ce);
                 throw new ResourceAccessException(ce.getErrMsg());
             }

             if(sendSmsResponse!=null){
                 int len=sendSmsResponse.getCode().length();
                 String respCode="";
                 //大于30个字符，进行截取
                 if(len>29){
                     respCode=sendSmsResponse.getCode().substring(4,25);
                 }
                 AliYunSmsSendDto aliYunSmsSendDto= AliYunSmsSendDto.builder()
                         .bizId(sendSmsResponse.getBizId())
                         .code(success.equalsIgnoreCase(sendSmsResponse.getCode())?"0":respCode)
                         .requestId(sendSmsResponse.getRequestId())
                         .message(sendSmsResponse.getMessage()).build();
                 return aliYunSmsSendDto;
             }
             return null;

         }

    /**
     * 截取状态码，以兼容系统中的字段长短
     * @param respCode
     * @return
     */
    public String cutResp(String respCode){
        String success="OK";
           if(success.equalsIgnoreCase(respCode)){
               return "0";
           }
           //截取20个字符
           return respCode.substring(4,respCode.length());
         }

    /**
     * @desc:根据smsDto构造阿里云请求参数
     * @param smsDto
     * @return
     */
    private  AliYunPushParam formData(SmsDto smsDto){
        //获取账号信息
       ProviderAccountInfo account = ProviderAccountCache.getAccountById(smsDto.getAccountId());

        //获取签名信息
       SmsSignCo smsSignCo = smsSignCache.get(smsDto.getSignType()+"");

        //构造阿里云请求参数
        AliYunPushParam aliYunPushParam=AliYunPushParam.builder()
                .account(account.getAccountName())
                .action("SendBatchSms")
                .signatureNonce(java.util.UUID.randomUUID().toString())
                .timestamp(getTimestamp())
                .password(account.getAccountPwd())
                .templateCode(account.getTemplateCode())
                .build();

        //手机号转换List
        List<String> phonesList= Splitter.on(",").splitToList(smsDto.getMobile());
        //内容List
        List<SmsContentDto> contents=new ArrayList<>(phonesList.size()+10);
        //签名List
        List<String> signList=new ArrayList<>();
        phonesList.forEach(e->{
            signList.add(smsSignCo.getName().trim().replace("【","").replace("】",""));
            contents.add(SmsContentDto.builder().msg(smsDto.getContent()).build());
        });

        //构造请求内容
        aliYunPushParam.setContent(JsonUtil.listToString(contents));

        //构造签名
        aliYunPushParam.setSign(JsonUtil.listToString(signList));

        //构造手机号
        aliYunPushParam.setPhoneNumbers(JsonUtil.listToString(phonesList));

        return aliYunPushParam;
    }

    /**
     * desc:请求参数->短信时间参数生成方法
     * @return
     */
    public  String getTimestamp(){
        java.text.SimpleDateFormat df = new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
        // 这里一定要设置GMT时区
        df.setTimeZone(new java.util.SimpleTimeZone(0, "GMT"));
        return df.format(new java.util.Date());
    }
}
