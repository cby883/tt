package com.zuzuche.sms.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Table;
import java.time.LocalDateTime;

/**
 * @desc 供应商账户信息
 * @author panqiong
 * @date 20181019
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "provider_account_info")
public class ProviderAccountInfo {

    private int accountId ;

    private String accountName;

    private String accountPwd;

    /**
     *  1：验证码类型  2:营销短信类型
     */
    private int accountType;

    private String accountTypeDesc;

    private int providerId;

    private String remark;

    private LocalDateTime createTime;

    private LocalDateTime updateTime;

    /**
     *  1:有效 2:无效
     */
    private int validState;
    /**
     * 账户业务代码
     * 百唔需要
     */
    private String accountServCode;

    /**
     * 地区 1:国内  2:国际
     */
    private int areaType;
    /**
     * 账号对应的阿里云短信模板Code
     */
    private String templateCode;
    /**
     * 短信上行队列名称
     */
    private String inboundQueueName;
    /**
     * 短信下行队列名称
     */
    private String outboundQueueName;





}
