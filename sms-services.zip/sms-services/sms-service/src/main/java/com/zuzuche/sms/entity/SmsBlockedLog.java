package com.zuzuche.sms.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Table;
import java.time.LocalDateTime;

/**
 * @desc: 短信拦截记录
 * @author: panqiong
 * @date: 2018/10/29
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "sms_blocked_log")
public class SmsBlockedLog {

    private int id;

    private String taskId;

    private String phone;
    /**
     * 拦截器名称
     */
    private String blockFilter;

    private LocalDateTime createTime;
}
