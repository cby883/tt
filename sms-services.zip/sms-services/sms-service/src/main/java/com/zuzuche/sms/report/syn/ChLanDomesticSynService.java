package com.zuzuche.sms.report.syn;

import com.zuzuche.sms.common.utils.DateUtil;
import com.zuzuche.sms.common.utils.PerformUtil;
import com.zuzuche.sms.entity.ProviderAccountInfo;
import com.zuzuche.sms.entity.SmsInbound;
import com.zuzuche.sms.entity.StatusReport;
import com.zuzuche.sms.remote.ChuangLanApi;
import com.zuzuche.sms.remote.dto.PullMoDto;
import com.zuzuche.sms.remote.dto.PullReportDto;
import com.zuzuche.sms.remote.param.PullMoParam;
import com.zuzuche.sms.remote.param.PullReportParam;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @desc: 创蓝的国内账户同步数据服务
 * @author: panqiong
 * @date: 2018/11/12
 */
@Service("chLanDomesticSynService")
@Slf4j
public class ChLanDomesticSynService extends AbstractSynService{

    private static String SUCCESS_RET = "0";

    private static String PULL_NUM = "500";

    @Autowired
    ChuangLanApi chLanApi;



    @Override
    protected List<StatusReport> doInvokeStatusReportApi(ProviderAccountInfo account) {
        int accountId = account.getAccountId();
        String name = account.getAccountName();
        String pwd = account.getAccountPwd();
        PullReportParam param = PullReportParam.builder()
              .account(name)
                .password(pwd)
                .count(PULL_NUM)
                .build();
        long start = Instant.now().toEpochMilli();
        PullReportDto dto = chLanApi.pullReport(param);
        if(log.isDebugEnabled()){
            log.debug("[response]"+dto.toString());
        }
        long end = Instant.now().toEpochMilli();
        PerformUtil.logTime("chLanApi.pullReport",start,end);
        if(SUCCESS_RET.equals(dto.getRet())) {
            if (CollectionUtils.isEmpty(dto.getResult())) {
                log.warn("[ChLanStatusReportJob]:accountName:" + account.getAccountName() + " 本次拉取List为空");
                return null;
            }
            log.info("[ChLanStatusReportJob]:accountName:" + account.getAccountName() + " 拉取到状态记录 " + dto.getResult().size() + " 条");

            List<StatusReport> list = dto.getResult().stream()
                    .map(report ->
                            StatusReport.builder()
                                    // 这里返回的uid 就是我们传过去的taskId
                                    .batchNo(report.getUid())
                                    .createTime(LocalDateTime.now())
                                    .phone(report.getMobile())
                                    .recvTime(dateTrans(report.getNotifyTime()))
                                    .status(report.getStatus())
                                    .accountId(accountId)
                                    .build()
                    ).collect(Collectors.toList());
            return list;
        }
        return null;

    }


    @Override
    protected List<SmsInbound> doInvokeInboundApi(ProviderAccountInfo account) {
        int accountId = account.getAccountId();
        String name = account.getAccountName();
        String pwd = account.getAccountPwd();
        PullMoParam param = PullMoParam.builder()
                .account(name)
                .password(pwd)
                .count(PULL_NUM)
                .build();

        long start = Instant.now().toEpochMilli();
        PullMoDto dto = chLanApi.pullMo(param);
        if(log.isDebugEnabled()){
            log.debug("[response]"+dto.toString());
        }
        long end = Instant.now().toEpochMilli();
        PerformUtil.logTime("chLanApi.pullMo",start,end);

        if(SUCCESS_RET.equals(dto.getRet())) {
            if(CollectionUtils.isEmpty(dto.getResult())){
                log.warn("[ChLanInboundJob]:accountName:"+account.getAccountName()+" 本次拉取List为空");
                return null;
            }
            log.info("[ChLanInboundJob]:accountName:"+account.getAccountName()+" 拉取上行短信 "+dto.getResult().size()+" 条");

            List<SmsInbound> list = dto.getResult().stream()
                    .map(report ->
                            SmsInbound.builder()
                                    .msg(report.getMessageContent())
                                    .createTime(LocalDateTime.now())
                                    .phone(report.getMobile())
                                    .port(report.getSpCode())
                                    .accountId(accountId)
                                    .build()
                    ).collect(Collectors.toList());

            return list;
            // 发送kafka队列 供上游需要订阅的服务收听

        }
        return null;
    }

    /**
     * 时间格式转换
     * @return
     */
    private String dateTrans(String origin){
        try{
            LocalDateTime dateTime = LocalDateTime.parse(origin,DateTimeFormatter.ofPattern(DateUtil.PATTERN_3));
            String date = dateTime.format(DateTimeFormatter.ofPattern(DateUtil.PATTERN_1));
            return date;
        }catch (Exception e){
            log.error("[报告日期转换异常]reportTime:"+origin);
            return origin;
        }
    }



}
