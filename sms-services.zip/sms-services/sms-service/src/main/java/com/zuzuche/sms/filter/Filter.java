package com.zuzuche.sms.filter;


import com.zuzuche.sms.dto.SmsDto;

/**
 * @desc: 过滤器接口
 * 注意指定实现类的顺序
 * @author: panqiong
 * @date: 2018/10/26
 */
public interface Filter {

    /**
     * 返回false将导致整个下发流程中断
     * @param sms
     * @return
     */
    boolean doFilter(SmsDto sms);


}
