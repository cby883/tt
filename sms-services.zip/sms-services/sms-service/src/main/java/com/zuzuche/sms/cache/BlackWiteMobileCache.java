package com.zuzuche.sms.cache;

import com.zuzuche.sms.cache.co.BlackMobileCo;
import com.zuzuche.sms.entity.PhoneMember;
import com.zuzuche.sms.mapper.PhoneMemberMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.*;

/**
 * 功能：黑白名单手机配置缓存操作.
 * 详细：
 *
 * @author Created on 2019.03.16 by chaodian
 */
@Component("BlackWiteMobileCache")
@Slf4j
public class BlackWiteMobileCache implements InitializingBean ,ConfigCache{
    /**
     * The Mapper.
     */
    @Autowired
    PhoneMemberMapper mapper;

    /**
     * 白名单的类型值
     */
    private static final int WHITE_TYPE_VAL = 1;

    /**
     * 黑名单的类型值
     */
    private static final int BLACK_TYPE_VAL = 2;

    /**
     * 所有黑名单手机配置信息
     */
    private static Map<String, BlackMobileCo> blackMobiles = new HashMap<>();

    /**
     * 白名单手机配置信息
     */
    private static Set<String> whiteMobiles = new HashSet<>();

    /**
     * Contains black mob boolean.
     *
     * @param mobile the mobile
     * @return the boolean
     */
    public boolean containsBlackMob(String mobile) {
        return blackMobiles.containsKey(mobile);
    }

    /**
     * Gets black mob config.
     *
     * @param mobile the mobile
     * @return the black mob config
     */
    public BlackMobileCo getBlackMobConfig(String mobile) {
        return blackMobiles.get(mobile);
    }

    /**
     * Contains white mob boolean.
     *
     * @param mobile the mobile
     * @return the boolean
     */
    public boolean containsWhiteMob(String mobile) {
        return whiteMobiles.contains(mobile);
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        loadAll();
    }

    /**
     * Load all.
     */
    public synchronized void loadAll() {
        List<PhoneMember> list = mapper.selectAll();
        Set<String> newWhiteMobiles = new HashSet<>();
        Map<String, BlackMobileCo> newBlackMobiles = new HashMap<>();
        if (CollectionUtils.isNotEmpty(list)) {
            list.forEach(e->{
                if (e.getType() == WHITE_TYPE_VAL) {
                    newWhiteMobiles.add(e.getMobile());
                } else if (e.getType() == BLACK_TYPE_VAL) {
                    BlackMobileCo co = BlackMobileCo.builder()
                            .mobile(e.getMobile())
                            .smsTypes(e.getSmsTypes())
                            .fromTypes(e.getFromTypes())
                            .build();
                    newBlackMobiles.put(e.getMobile(), co);
                }
            });
        }

        whiteMobiles = newWhiteMobiles;
        blackMobiles = newBlackMobiles;
    }

    @Override
    public boolean refresh() {
        try {
            loadAll();
            return true;
        } catch (Exception e) {
            log.error("【BlackWiteMobileCache】配置刷新失败",e.getMessage(),e);
            return false;
        }
    }
}
