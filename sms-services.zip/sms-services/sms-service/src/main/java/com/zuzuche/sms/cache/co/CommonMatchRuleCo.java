package com.zuzuche.sms.cache.co;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 功能：常规的短信下发供应商匹配规则缓存信息.
 * 详细：
 *
 * @author Created on 2019.03.11 by chaodian
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CommonMatchRuleCo {
    /**
     * 签名值
     */
    private int sign;

    /**
     * 短信类型
     */
    private int smsType;

    /**
     * 国内/国际类型
     */
    private int regionType;

    /**
     * 供应商
     */
    private String supplier;

    /**
     * 权重/优先级
     */
    private int level;

    /**
     * acount_id
     */
    private int accountId;
}
