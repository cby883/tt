package com.zuzuche.sms.common.enums;

import com.zuzuche.commons.base.constants.BaseEnum;
import lombok.Getter;
/**
 * 短信文件记录状态枚举类
 *
 * @author bingyi
 * @date 2019/11-06
 */
@Getter
public enum SmsFileRecordType implements BaseEnum<Integer> {
    /**
     * 文件首次导入
     */
    SMS_FILE_RECORD_TYPE_FIRST(2,"文件未导入"),
    /**
     * 文件已经导入
     */
    SMS_FILE_RECORD_TYPE_IS_IMPORT(1,"文件已导入"),
    /**
     * 文件导入中
     */
    SMS_FILE_RECORD_TYPE_IMPORTING(0,"文件导入中");

    /**
     * 状态code
     */
    private Integer code;

    /**
     * 描述
     */
    private String desc;


    SmsFileRecordType(Integer code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    @Override
    public Integer code() {
        return code;
    }
}