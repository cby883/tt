package com.zuzuche.sms.mapper;

import com.zuzuche.commons.mybatis.BaseMapper;
import com.zuzuche.sms.entity.SmsBatchTask;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

/**
 * desc:
 *
 * @author bingyi
 * @date 2019/10/30
 */
@Repository
public interface SmsBatchTaskMapper extends BaseMapper<SmsBatchTask> {
    /**
     *
     * @param id
     * @param updStatus
     * @param preStatus
     * @return
     */
    public int updateStatus(@Param("id") int id,@Param("updStatus") int updStatus ,@Param("preStatus") int preStatus);

    /**
     * desc:
     * @param smsBatchTask
     * @return
     */
    public int updateOffset(SmsBatchTask smsBatchTask);

    /**
     * 量级不大，可以全部查出全部记录
     * @param status
     * @param nowTime
     * @return
     */
    public List<SmsBatchTask> selectStatusAndPlanTime(@Param(value = "status") int status
            , @Param(value = "nowTime")LocalDateTime nowTime);

    /**
     * desc:分页查询
     * @param id
     * @return
     */
    public List<SmsBatchTask> selectList(@Param("id") Integer id,@Param("startTime") String startTime,@Param("endTime") String endTime);

    /**
     * 查询范围以内的记录
     * @param startTime
     * @param endTime
     * @return
     */
    public List<SmsBatchTask> selectInDays(@Param("startTime") LocalDateTime startTime
            ,@Param("endTime")LocalDateTime endTime);
}