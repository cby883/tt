package com.zuzuche.sms.rest.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @desc: 巨辰状态报告回调接口
 * @author: panqiong
 * @date: 2018/10/17
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class JuchnStatusCallbackReq {


    private List<Report> reports;



    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class Report {
        private String batchno;
        private String phone;
        private String status;
        private String accesscode;
        private String recvtime;
    }
}
