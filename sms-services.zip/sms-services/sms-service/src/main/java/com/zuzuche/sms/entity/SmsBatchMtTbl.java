package com.zuzuche.sms.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.Table;
import java.time.LocalDateTime;
import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "zuzuche_sms_db.sms_batch_mt_tbl")
public class SmsBatchMtTbl {
    @Id
    private int id;

    @Column(name = "add_time")
    private LocalDateTime addTime;

    @Column(name = "type")
    private int type;

    @Column(name = "region_type")
    private int regionType;

    @Column(name = "sign_type")
    private int signType;

    @Column(name = "from_unique_id")
    private String fromUniqueId;

    @Column(name = "from_type")
    private String fromType;

    @Column(name = "admin")
    private String admin;
    @Column(name = "extra_param")
    private String extraParam;
    @Column(name = "content")
    private String content;


}