package com.zuzuche.sms.report.callback;

import com.zuzuche.commons.base.util.BeanConverter;
import com.zuzuche.commons.base.util.StringUtil;
import com.zuzuche.kafka.sentry.EventDto;
import com.zuzuche.kafka.sentry.SentryReport;
import com.zuzuche.sms.common.utils.DateUtil;
import com.zuzuche.sms.common.utils.TimeUtil;
import com.zuzuche.sms.dto.StatusReportDto;
import com.zuzuche.sms.entity.ProviderAccountInfo;
import com.zuzuche.sms.entity.StatusReport;
import com.zuzuche.sms.mapper.StatusReportMapper;
import com.zuzuche.sms.service.KafkaService;
import com.zuzuche.sms.service.StatusReportService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.kafka.dsl.Kafka;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * 功能：供应商回调的抽象类.
 * 详细：
 *
 * @author Created on 2019.06.28 by chaodian
 */
@Slf4j
public abstract class AbstractCallbackService implements CallbackService {
    @Autowired
    StatusReportMapper statusReportMapper;

    @Autowired
    StatusReportService statusReportService;

    @Autowired
    SentryReport sentryReport;
    @Autowired
    KafkaService kafkaService;

    public final static String EMPTY_NULL_STRING = "null";

    /**
     * 状态报告回调
     * @param account      the account 供应商账号信息
     * @param callbackData the callback data 回调数据
     */
    @Override
    public void callbackStatusReport(ProviderAccountInfo account, Object callbackData) {

        if(account == null){
            log.warn("[AbstractCallbackService] 没有任何有效account,本次回调解析状态报告终止");
            return;
        }

        // 每次回调记录下info信息
        log.info("[AbstractCallbackService] 状态报告报告回调, account: " + account.toString() + ", data: " + callbackData.toString());

        try{

            List<StatusReport> list = doAnalyzeCallbackStatusReport(account, callbackData);

            statusReportService.pushToReportKafka(list);

            // 埋点预警系统
            toSentry(account.getProviderId(), list);

        } catch (Exception e){
            log.error("[callbackStatusReport]状态报告回调处理异常:accountName:"+account.getAccountName(),e.getMessage(),e);
        }

    }

    /**
     * 状态报告回调上报预警系统
     * @param providerId 供应商的账户id
     * @param list 状态报告列表
     */
    private void toSentry(int providerId, List<StatusReport> list) {
        try{
            if(list==null){
                return;
            }
            list.forEach(e->{
                long reciveTime = Instant.now().toEpochMilli();
                if(StringUtil.isNotEmpty(e.getRecvTime())&&!EMPTY_NULL_STRING.equals(e.getRecvTime())){
                    reciveTime = LocalDateTime.parse(e.getRecvTime(), DateTimeFormatter.ofPattern(DateUtil.PATTERN_1))
                            .toInstant(ZoneOffset.of("+8")).toEpochMilli();
                }else{
                    log.error("[状态报告回调的接收时间为空:]"+e.toString());
                }
                EventDto eventDto = EventDto.builder()
                        .metric("sms_status_callback_total")
                        .time(reciveTime)
                        .addLabel("status", e.getStatus())
                        .addLabel("providerId", String.valueOf(providerId))
                        .value(1)
                        .build();
                sentryReport.incrCounter(eventDto);
            });
        }catch (Exception e){
            log.error("[状态报告回调预警埋点异常]",e.getMessage(),e);
        }

    }

    /**
     * 上行数据回调
     * @param account      the account 供应商账户信息
     * @param callbackData the callback data 回调数据
     */
    @Override
    public void callbackInboundSms(ProviderAccountInfo account, Object callbackData) {
    }

    /**
     * 解析状态报告数据
     *
     * @param account      the account
     * @param callbackData the callback data 供应商回调过来的状态报告数据
     * @return list list
     */
    protected abstract List<StatusReport> doAnalyzeCallbackStatusReport(ProviderAccountInfo account, Object callbackData);
}
