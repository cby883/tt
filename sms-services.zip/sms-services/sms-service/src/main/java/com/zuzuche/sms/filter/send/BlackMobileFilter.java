package com.zuzuche.sms.filter.send;

import com.google.common.base.Charsets;
import com.google.common.base.Splitter;
import com.google.common.hash.BloomFilter;
import com.google.common.hash.Funnel;
import com.google.common.hash.PrimitiveSink;
import com.zuzuche.sms.cache.SmsSpecialPhoneCache;
import com.zuzuche.sms.common.constant.Constants;
import com.zuzuche.sms.dto.BlockedSmsDto;
import com.zuzuche.sms.dto.SmsDto;
import com.zuzuche.sms.filter.Filter;
import com.zuzuche.sms.service.KafkaService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.annotation.Order;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * @desc: 黑名单过滤器
 * @author: panqiong
 * @date: 2018/10/26
 */
// @Component
// @Slf4j
// @Order(1)
public class BlackMobileFilter implements Filter {

    private static final Constants.FilterTypes FILTER = Constants.FilterTypes.黑名单过滤器;

    // private static long expireTime = 24*60*60;

    @Value("${envi}")
    private String env;

    @Autowired
    KafkaService kafkaService;

    /**
     *
     * @param sms
     * @return
     */
    @Override
    public boolean doFilter(SmsDto sms) {

        boolean isBlack = SmsSpecialPhoneCache.isBlackUser(sms.getMobile());

        // 黑名单被拒绝  给与通知
        if(isBlack){
            reportKafka(sms);
        }

        return !isBlack;
    }

    /**
     * 布隆过滤器
     * 不在的话,一定不在
     * 在的话,可能不在(概率极小)
     */
    private final BloomFilter<String> dealIdBloomFilter = BloomFilter.create(new Funnel<String>() {

        private static final long serialVersionUID = 1L;

        @Override
        public void funnel(String arg0, PrimitiveSink arg1) {

            arg1.putString(arg0, Charsets.UTF_8);
        }

    }, 1024*1024*32, 0.0000001d);


    private void reportKafka(SmsDto sms){
        List<String> list = Splitter.on(",").splitToList(sms.getMobile());
        if(list!=null&&list.size()>0) {
            Set set = list.stream().collect(Collectors.toSet());
            BlockedSmsDto duSmsDto = BlockedSmsDto.builder()
                    .mobileList(set)
                    .taskId(sms.getTaskId())
                    .filterType(FILTER)
                    .build();
            kafkaService.sendToBlockedTopic(duSmsDto);
        }
    }
}
