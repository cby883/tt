package com.zuzuche.sms.cache;

import com.zuzuche.commons.base.resp.Status;
import com.zuzuche.commons.base.resp.StatusServiceCnException;
import com.zuzuche.sms.entity.SmsSpecialPhone;
import com.zuzuche.sms.mapper.SmsSpecialPhoneMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;
import java.util.stream.Collectors;

/**
 * @desc: 特殊号码 黑白名单
 * @author: panqiong
 * @date: 2018/11/9
 */
@Component("SmsSpecialPhoneCache")
@Slf4j
public class SmsSpecialPhoneCache implements InitializingBean,ConfigCache {
    @Autowired
    SmsSpecialPhoneMapper mapper;
    /***
     * 黑名单
     */
    private static Set<String> blackUser = new HashSet<>(16);

    /**
     * 白名单
     */
    private static Set<String> whiteUser = new HashSet<>(16);

    /**
     * 是否黑名单
     * @param phone
     * @return
     */
    public static boolean isBlackUser(String phone){
        return blackUser.contains(phone);
    }

    /**
     * 是否白名单
     * @param phone
     * @return
     */
    public static boolean isWhiteUser(String phone){
        return whiteUser.contains(phone);
    }



    /**
     * 载入配置到内存
     */
    private void load(){
        List<SmsSpecialPhone> list = mapper.queryAllList();
        if(CollectionUtils.isEmpty(list)){
            log.info("[载入黑白名单] 没有配置任何黑白名单号码");
        }

        Map<Integer,List<SmsSpecialPhone>> partionMap = list.stream().collect(Collectors.groupingBy(SmsSpecialPhone::getPhoneType));

        int blackType = 1;
        int whiteType = 2;

        if(partionMap.containsKey(blackType)){
            blackUser = partionMap.get(blackType).stream().map(e->e.getPhone()).collect(Collectors.toSet());
        }else{
            blackUser.clear();
        }

        if(partionMap.containsKey(whiteType)){
            whiteUser = partionMap.get(whiteType).stream().map(e->e.getPhone()).collect(Collectors.toSet());
        }else{
            whiteUser.clear();
        }

    }

    /**
     * 重新载入配置
     * 线程安全
     */
    public synchronized boolean reload() {
        try{
            load();
            return true;
        } catch (Exception e){
            log.error("【SmsSpecialPhoneCache】配置刷新失败",e.getMessage(),e);
            return false;
        }
    }

    /**
     * 初始化配置信息
     * @throws Exception
     */
    @Override
    public void afterPropertiesSet() throws Exception {
        load();
    }

    @Override
    public boolean refresh() {
        return reload();
    }
}
