package com.zuzuche.sms.report.syn;

/**
 * @desc: 同步数据服务类
 * @author: panqiong
 * @date: 2018/11/7
 */
public interface SynService {

    /**
     * 同步状态报告
     * @param providerId
     */
    void synStatusReport(int providerId);

    /**
     * 同步上行短信
     * @param providerId
     */
    void synInboundSms(int providerId);

}
