package com.zuzuche.sms.rest;

import com.zuzuche.commons.base.resp.RespResult;
import com.zuzuche.sms.rest.response.SmsResp;
import com.zuzuche.sms.service.InboundService;
import com.zuzuche.sms.service.RetriveOffsetService;
import com.zuzuche.sms.service.StatusReportService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * @desc: 偏移量管理
 * @author: panqiong
 * @date: 2018/10/24
 */
@RestController
@RequestMapping("/offset")
@Api(value = "offset", description = "拉取偏移量管理", tags = {"offset"})
@Slf4j
public class OffsetRest {

    @Autowired
    KafkaTemplate<String,String> kafkaTemplate;


    @Autowired
    StatusReportService statusReportService;

    @Autowired
    InboundService inboundService;

    @Autowired
    RetriveOffsetService offsetService;

    @Autowired
    RetriveOffsetService retriveOffsetService;

    /**
     * 获取用户状态报告 拉取位置 偏移量手动设置
     * @param
     * @return
     */
    @GetMapping("/getAllOffsetInfo")
    @ApiOperation(value = "偏移量信息查询", notes = "偏移量信息查询")
    public RespResult<Map> getAllOffsetInfo() {
        Map<String,String> map = retriveOffsetService.retriveOffsetList();
        // 同步入队 并返回taskId
        return RespResult.success(map);
    }

    /**
     * 获取用户状态报告 拉取位置 偏移量手动设置
     * @param
     * @return
     */
    @PostMapping("/setRetrivePushStatusOffset")
    @ApiOperation(value = "设置拉取位置偏移量", notes = "设置拉取位置偏移量 即数据的id,手动设置 用于异常情况处理")
    public RespResult<SmsResp> setRetriveStatusOffset(@ApiParam(value = "偏移量") @RequestParam("offset") String offset) {

        offsetService.setPushStatusOffset(offset);
        // 同步入队 并返回taskId
        return RespResult.success();
    }


    /**
     * 获取用户状态报告 拉取位置 偏移量手动设置
     * @param
     * @return
     */
    @PostMapping("/setRetriveInboundOffset")
    @ApiOperation(value = "设置拉取位置偏移量", notes = "设置拉取位置偏移量 即数据的id,手动设置 用于异常情况处理")
    public RespResult setRetriveInboundOffset(@ApiParam(value = "偏移量") @RequestParam("offset") String offset) {

        offsetService.setInboundOffset(offset);
        // 同步入队 并返回taskId
        return RespResult.success();
    }

}
