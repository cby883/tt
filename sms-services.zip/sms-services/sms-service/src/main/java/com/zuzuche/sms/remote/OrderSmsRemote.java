package com.zuzuche.sms.remote;


import com.zuzuche.commons.base.resp.PhpResult;
import com.zuzuche.sms.remote.param.AddOrderSmsLogParam;
import feign.Headers;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;

/**
 * 订单相关短信请求api.
 *
 * @author Created on 2019-03-26 by chaodian
 */
@FeignClient(name="orderSms",url="${zcs.url}")
@Headers({"Content-Type: application/x-www-form-urlencoded","Cookie:allow_test_ip=1,header_code=1"})
public interface OrderSmsRemote {

    /**
     * 添加主站订单短信日志.
     *
     * @param param the param
     * @return the php result
     */
    @PostMapping(value = "/world/addSmsLog",consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
    PhpResult addOrderSmsLog(AddOrderSmsLogParam param);
}
