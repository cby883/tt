package com.zuzuche.sms.cache.co;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 功能：供应商配置信息.
 * 详细：
 *
 * @author Created on 2019.03.12 by chaodian
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SupplierConfigCo {
    /**
     * 提交给供应商是否需要加上的前缀，比如百唔供应商需要自动加上【租租车】签名
     */
    private String preFix;

    /**
     * 提交给供应商是否需要加上的后缀
     */
    private String postFix;

    /**
     * 供应商短信性质，这里仅有1普通行业和2营销
     */
    private int supplierSmsType;

    /**
     * 国内/国际
     */
    private int regionType;

    /**
     * 一条短信不切割的最大字符数，如百唔为70
     */
    private int unixMaxCount;

    /**
     * 短信超过字符数后(如百唔超过70)，将会切割，切割以多少字符数进行切割
     */
    private int unixCutCount;

    /**
     * 对应的供应商账户id
     */
    private int accountId;

    /**
     * 是否额外的处理短信内容签名，如阿里的短信需要在短信内容前加上签名
     */
    private int cleanSignType;
}
