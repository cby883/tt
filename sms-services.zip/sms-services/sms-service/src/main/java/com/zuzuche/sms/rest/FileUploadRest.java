package com.zuzuche.sms.rest;

import com.zuzuche.commons.base.resp.RespResult;
import com.zuzuche.commons.redis.RedisLock;
import com.zuzuche.sms.entity.SmsUploadFileLog;
import com.zuzuche.sms.rest.request.FileUploadReq;
import com.zuzuche.sms.service.FileManagementService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;


/**
 * @desc: 文件管理
 * @author: bingyi
 * @date: 2019-10-31
 */
@RestController
@RequestMapping("/file")
@Slf4j
@Api(value = "fileManagement", description = "文件管理", tags = {"fileManagement"})
public class FileUploadRest {

    @Autowired
    FileManagementService fileManagementService;

    private static final String UPLOAD_LOCK_KEY = "SMS::UPLOAD_LOCK_KEY";

    /**
     * 文件上传
     * @param req
     * @return
     */
    @PostMapping(value = "/upload")
    public RespResult upload(FileUploadReq req) {
        SmsUploadFileLog fileLog = null;
        RedisLock redisLock = new RedisLock(UPLOAD_LOCK_KEY);
        if (redisLock.lock()) {
            try {
                fileLog = fileManagementService.upload(req);
            } finally {
                redisLock.unlock();
            }
        }
        return RespResult.success(fileLog);
    }

    /**
     * 删除文件
     *
     * @param fileId
     * @return
     */
    @PostMapping(value = "/delFile")
    public RespResult delete(@ApiParam(value = "文件id") @RequestParam(value = "id") String fileId) {
        return fileManagementService.delFile(fileId);
    }

    /**
     * 查询所有文件
     *
     * @return
     */
    @GetMapping(value = "search")
    public RespResult search() {
        List<SmsUploadFileLog> logList = fileManagementService.search();
        return RespResult.success(logList);
    }
}
