package com.zuzuche.sms.report.syn;
import com.zuzuche.sms.common.utils.DateUtil;
import com.zuzuche.sms.common.utils.Md5Util;
import com.zuzuche.sms.common.utils.PerformUtil;
import com.zuzuche.sms.entity.*;
import com.zuzuche.sms.remote.JuchnPullApi;
import com.zuzuche.sms.remote.dto.PullSmsReportDto;
import com.zuzuche.sms.remote.dto.PullSmsUplinkDto;
import com.zuzuche.sms.remote.param.PullSmsReportParam;
import com.zuzuche.sms.remote.param.PullSmsUplinkParam;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @desc: 巨辰的短信发送服务类
 * @author: panqiong
 * @date: 2018/10/18
 */
@Service("juchnSynService")
@Slf4j
public class JuchnSynService extends AbstractSynService {

    private static String PULL_NUM = "500";

    @Autowired
    JuchnPullApi juchnPullApi;




    @Override
    protected List<StatusReport> doInvokeStatusReportApi(ProviderAccountInfo account) {
        int accountId = account.getAccountId();
        String name = account.getAccountName();
        String pwd = account.getAccountPwd();
        String time = LocalDateTime.now().format(DateTimeFormatter.ofPattern(DateUtil.PATTERN_1));
        String md5pwd = Md5Util.string2MD5(pwd+time);
        PullSmsReportParam param = PullSmsReportParam.builder()
                .datetime(time)
                .num(PULL_NUM)
                .username(name)
                .passwd(md5pwd)
                .build();
        long start = Instant.now().toEpochMilli();
        PullSmsReportDto dto = juchnPullApi.pullSmsReport(param);
        if(log.isDebugEnabled()){
            log.debug("[response]"+dto.toString());
        }
        long end = Instant.now().toEpochMilli();
        PerformUtil.logTime("juchnPullApi.pullSmsReport",start,end);
        if(dto.getRespcode()==0) {
            if (CollectionUtils.isEmpty(dto.getReports())) {
                log.warn("[JuchnStatusReportJob]:accountName:" + account.getAccountName() + " 本次拉取List为空");
                return null;
            }
            log.info("[JuchnStatusReportJob]:accountName:" + account.getAccountName() + " 拉取到状态记录 " + dto.getReports().size() + " 条");

            List<StatusReport> list = dto.getReports().stream()
                    .map(report ->
                            StatusReport.builder()
                                    .batchNo(report.getBatchno())
                                    .createTime(LocalDateTime.now())
                                    .phone(report.getPhone())
                                    .recvTime(report.getRecvtime())
                                    .status(report.getStatus())
                                    .accountId(accountId)
                                    .build()
                    ).collect(Collectors.toList());
            return list;
        }
        return null;

    }


    @Override
    protected List<SmsInbound> doInvokeInboundApi(ProviderAccountInfo account) {
        int accountId = account.getAccountId();
        String name = account.getAccountName();
        String pwd = account.getAccountPwd();
        String time = LocalDateTime.now().format(DateTimeFormatter.ofPattern(DateUtil.PATTERN_1));
        String md5pwd = Md5Util.string2MD5(pwd+time);
        PullSmsUplinkParam param = PullSmsUplinkParam.builder()
                .username(name)
                .passwd(md5pwd)
                .num(PULL_NUM)
                .datetime(time)
                .build();

        long start = Instant.now().toEpochMilli();
        PullSmsUplinkDto dto = juchnPullApi.pullSmsuplink(param);
        log.info("[response]"+dto.toString());
        long end = Instant.now().toEpochMilli();
        PerformUtil.logTime("juchnPullApi.pullSmsuplink",start,end);

        if(dto.getRespcode()==0){
            if(CollectionUtils.isEmpty(dto.getUplinks())){
                log.warn("[JuchnInboundJob]:accountName:"+account.getAccountName()+" 本次拉取List为空");
                return null;
            }
            log.info("[JuchnInboundJob]:accountName:"+account.getAccountName()+" 拉取上行短信 "+dto.getUplinks().size()+" 条");

            List<SmsInbound> list = dto.getUplinks().stream()
                    .map(report ->
                            SmsInbound.builder()
                                    .msg(report.getMsg())
                                    .createTime(LocalDateTime.now())
                                    .phone(report.getPhone())
                                    .port(report.getPort())
                                    .accountId(accountId)
                                    .build()
                    ).collect(Collectors.toList());

            return list;
            // 发送kafka队列 供上游需要订阅的服务收听

        }
        return null;
    }


}
