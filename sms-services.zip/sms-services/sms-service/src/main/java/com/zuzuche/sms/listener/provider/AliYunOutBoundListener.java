package com.zuzuche.sms.listener.provider;

import com.google.common.util.concurrent.RateLimiter;
import com.zuzuche.logback.util.MDCUtil;
import com.zuzuche.sms.cache.SmsConfigCache;
import com.zuzuche.sms.common.enums.RateLimiterKeyTypes;
import com.zuzuche.sms.dto.SmsDto;
import com.zuzuche.sms.executors.AliYunExecutor;
import com.zuzuche.sms.service.KafkaService;
import com.zuzuche.sms.report.syn.JuchnSynService;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.messaging.Sink;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import java.util.concurrent.RejectedExecutionException;

/**
 * @desc:
 * @author: bingyi
 * @date: 2019/08/14
 */
@Component
@Slf4j
@EnableBinding(Sink.class)
public class AliYunOutBoundListener  {

    private static String RATE_KEY = "aliyun_sms_outbound_topic_rate";


    private static RateLimiter rateLimiter;

    @Autowired
    JuchnSynService juchnService;


    @Autowired
    KafkaService kafkaService;

    @Autowired
    SmsConfigCache configCache;


    @Autowired
    AliYunExecutor outboundExecutor;

    /**
     * 注意:
     *  - 如果消息处理超时,spring默认最多会重新处理三次
     *  - 如果对消息保障性要求高,发生异常要预警,可以把处理失败的消息转发到dlq队列
     *  - 优雅退出应用,不然会可能丢失已消费未处理的消息
     * 短信下发队列
     * @param consumer
     */
    @KafkaListener(topics = KafkaService.ALIYUN_SMS_OUTBOUND_TOPIC)
    public void consume(ConsumerRecord<String, SmsDto> consumer) {
        MDCUtil.set();
        if(log.isDebugEnabled()){
            log.debug("[receive aliyun_sms_outbound_topic]:" +consumer.value());
        }
        rateLimiter=configCache.getLimiter(RateLimiterKeyTypes.ALIYUN_SMS_OUTBOUND_TOPIC_RATE);
        rateLimiter.acquire();
        try{
            // 1个短信实体
            SmsDto sms = consumer.value();
            // 下行业务处理
            outboundExecutor.handle(sms);

        }catch (RejectedExecutionException e){
            log.error("[阿里云线程池拒绝策略触发-aliyun_sms_outbound_topic]message:"+consumer.value(),e.getMessage(),e);
            // 发送到dlq队列 并预警人工接入
            //kafkaService.sendToDlq(consumer.value());
        }catch (Exception e){
            // 发送到dlq队列 并预警人工接入
            log.error("[阿里云消息处理出现异常-aliyun_sms_outbound_topic]message:"+consumer.value(),e.getMessage(),e);
            //kafkaService.sendToDlq(consumer.value());
        }finally {
            MDCUtil.clear();
        }

    }
}
