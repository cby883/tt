package com.zuzuche.sms.mapper;

import com.zuzuche.commons.mybatis.BaseMapper;
import com.zuzuche.sms.entity.CommonMatchRule;


/**
 * The interface Common match rule mapper.
 */
public interface CommonMatchRuleMapper extends BaseMapper<CommonMatchRule> {
}