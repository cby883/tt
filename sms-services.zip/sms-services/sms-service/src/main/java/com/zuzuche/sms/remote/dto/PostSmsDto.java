package com.zuzuche.sms.remote.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @desc: 提交短信dto
 * @author: panqiong
 * @date: 2018/11/7
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PostSmsDto {
    private String code;
    private String count;

}
