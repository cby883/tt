package com.zuzuche.sms.cache.co;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 功能：拦截安全规则缓存信息.
 * 详细：
 *
 * @author Created on 2019.03.07 by chaodian
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SafeMonitorRuleCo {
    /**
     * 规则名称
     */
    private String ruleName;

    /**
     * 规则状态
     */
    private int status;

    /**
     * 内容
     */
    private String desc;

    /**
     * 频率
     */
    private RuleFrequency ruleFrequency;

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class RuleFrequency {
        /**
         * 距离现在到过去的时间范围长度，精确到s
         */
        private String duration;

        /**
         * 频数， 结合duration为1800，若freqNum为3，则表示在过去3分钟内，频数为3
         */
        private String freqNum;
    }
}
