package com.zuzuche.sms.service;

import com.google.common.base.Splitter;
import com.netflix.hystrix.exception.HystrixRuntimeException;
import com.zuzuche.commons.base.util.StringUtil;
import com.zuzuche.kafka.sentry.EventDto;
import com.zuzuche.kafka.sentry.SentryReport;
import com.zuzuche.sms.cache.SupplierConfigCache;
import com.zuzuche.sms.common.utils.Md5Util;
import com.zuzuche.sms.common.utils.PerformUtil;
import com.zuzuche.sms.dto.InvokeResultDto;
import com.zuzuche.sms.dto.SourceEventDto;
import com.zuzuche.sms.mapper.SmsMtMapper;
import com.zuzuche.sms.mapper.SmsMtMarketMapper;
import com.zuzuche.sms.mapper.SmsOutboundMapper;
import com.zuzuche.sms.mapper.SmsOutboundPhoneMapper;
import com.zuzuche.sms.remote.JuchnPushApi;
import com.zuzuche.sms.remote.CallBackBusiApi;
import com.zuzuche.sms.remote.dto.CommonSmsBusiDto;
import com.zuzuche.sms.remote.param.NotifySendStatusParam;
import com.zuzuche.threadpool.ThreadPoolExecutorFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.data.redis.core.RedisOperations;
import org.springframework.data.redis.core.SessionCallback;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.integration.util.CallerBlocksPolicy;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;
import java.util.stream.Collectors;

/**
 * @desc: 发送供应商后的结果处理
 *
 * @author: panqiong
 * @date: 2018/11/1
 */
@Service
@Slf4j
public class SendResultService {

    private static ExecutorService executor = ThreadPoolExecutorFactory
            .create(ThreadPoolExecutorFactory.Config.builder()
                    .corePoolSize(250)
                    .maximumPoolSize(300)
                    .keepAliveTime(5)
                    .workQueue(new ArrayBlockingQueue<>(1000))
                    .unit(TimeUnit.MINUTES)
                    .handler(new ThreadPoolExecutor.CallerRunsPolicy())
                    .threadPoolName("DuplicatedFilterRedisSetExecutor")
                    .build());


    private static long expireTime = (long) 24*60*60;

    @Autowired
    StringRedisTemplate redisTemplate;

    @Autowired
    JuchnPushApi pushApi;

    @Autowired
    SmsOutboundMapper smsOutboundMapper;

    @Autowired
    SmsOutboundPhoneMapper outboundPhoneMapper;


    @Autowired
    CallBackBusiApi smsbusiRemote;


    @Autowired
    KafkaService kafkaService;

    @Autowired
    SentryReport sentryReport;

    @Autowired
    SupplierConfigCache supplierConfigCache;

    @Autowired
    SmsMtMarketMapper smsMtMarketMapper;

    @Autowired
    SmsMtMapper smsMtMapper;

    @Autowired
    SmsMtService smsMtService;

    public void process(InvokeResultDto dto){
        // 更新数据库结果
        updateDb(dto);

        // 回调上游短信服务
        // notifySmsBusiService(dto);
        // 更新mt短信表
        updateSmsMtDb(dto);

    }

    /**
     * 设置redis标识
     * @param dto
     */
    public void setRedisMark(InvokeResultDto dto) {
        String success = "0";
        String splitter = ",";
        String mobiles = dto.getMobiles();
        String md5Content = dto.getMd5Content();
        if(success.equals(dto.getRespCode())){
            // 手机列表
            if(mobiles.contains(splitter)){
                List<String> mobileList = Splitter.on(splitter).splitToList(mobiles);
                // 采用线程池方式并行设置到redis
                mobileList.stream().forEach(mobile->
                    executor.submit(()->{
                        // 标记位key
                        String markKey = mobile+md5Content;
                        // 设置防重复位
                        redisTemplate.opsForValue().set(markKey,mobile,expireTime,TimeUnit.SECONDS);
                    })
                );
            }else{
                // 标记位key
                String markKey = mobiles+md5Content;
                // 设置防重复位
                redisTemplate.opsForValue().set(markKey,mobiles,expireTime,TimeUnit.SECONDS);
            }
        }
    }



    /**
     * 回调上游短信服务
     * @param dto
     */
    private void notifySmsBusiService(InvokeResultDto dto) {
        try {
            long time = LocalDateTime.now().toEpochSecond(ZoneOffset.ofHours(8));
            String md5token = Md5Util.string2MD5(CallBackBusiApi.SECRETE + time);
            NotifySendStatusParam param = NotifySendStatusParam.builder()
                    .status("0".equals(dto.getRespCode()) ? "1" : "2")
                    .taskId(dto.getTaskId())
                    .token(md5token)
                    .mobiles(dto.getMobiles())
                    .t(String.valueOf(time))
                    .build();

            long start = Instant.now().toEpochMilli();
            CommonSmsBusiDto result = smsbusiRemote.notifySendStatus(param);
            long end = Instant.now().toEpochMilli();
            PerformUtil.logTime("notifySmsBusiService",start,end);

        }catch(HystrixRuntimeException e){
            log.error("[asynSendStatus]回调上游短信服务发生Hystrix异常:",e.getMessage(),e);
        }catch (Exception e){
            log.error("[asynSendStatus]回调上游短信服务发生异常:",e.getMessage(),e);
        }
    }

    /**
     * 更新下行短信的请求状态和供应商信息
     * @param dto the dto
     */
    private void updateSmsMtDb(InvokeResultDto dto) {
        int requestStatus = "0".equals(dto.getRespCode()) ? 1 : 2;

        //  通过accountId查找下供应商supplier信息
        String supplier = supplierConfigCache.getSupplierByAccountId(dto.getUpdatedAccountId());
        List<String> mobileList = StringUtil.asList(dto.getMobiles());
        smsMtService.updateMtRequestStatus(Integer.valueOf(dto.getTaskId()), requestStatus, supplier, mobileList);
    }

    /**
     *
     * @param dto
     */
    private void updateDb(InvokeResultDto dto) {
        try{
            smsOutboundMapper.updateResultByTaskId( dto.getBachNo(), dto.getRespCode(), dto.getExtra(), dto.getTaskId(), dto.getUpdatedAccountId(), LocalDateTime.now());
        }catch (Exception e){
            log.error("[asynSendStatus-updateDb]更新发送状态异常:",e.getMessage(),e);
        }
    }

    /**
     * 上报数据给监控系统
     * @param dto
     */
    public void reportToSentry(InvokeResultDto dto) {
        try {
            EventDto eventDto = EventDto.builder()
                    .metric("sms_send_result_total")
                    .time(dto.getTimestamp())
                    .value(1)
                    .addLabel("status",dto.getRespCode())
                    .addLabel("providerId",String.valueOf(dto.getProviderId()))
                    .build();
            sentryReport.incrCounter(eventDto);
        } catch (Exception e) {
            log.error("[监控系统提交数据异常]:{}",dto.toString(),e.getMessage(),e);
        }
        ///kafkaService.sendToSentry(eventDto);
    }

}
