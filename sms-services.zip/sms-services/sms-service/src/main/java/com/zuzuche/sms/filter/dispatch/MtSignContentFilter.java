package com.zuzuche.sms.filter.dispatch;

import com.google.common.base.Splitter;
import com.zuzuche.commons.base.resp.Status;
import com.zuzuche.commons.base.resp.StatusServiceCnException;
import com.zuzuche.commons.base.util.StringUtil;
import com.zuzuche.sms.cache.SmsSignCache;
import com.zuzuche.sms.cache.co.SmsSignCo;
import com.zuzuche.sms.common.enums.FilterTypes;
import com.zuzuche.sms.dto.FilterMtDto;
import com.zuzuche.sms.dto.MtDto;
import com.zuzuche.sms.filter.MtFilter;
import com.zuzuche.sms.service.KafkaService;
import com.zuzuche.sms.service.SmsMtService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * 功能：短信签名内容格式化处理过滤器.
 * 详细：
 *
 * @author Created on 2019.03.20 by chaodian
 */
@Component
@Slf4j
@Order(1)
public class MtSignContentFilter implements MtFilter {
    /**
     * The Kafka service.
     */
    @Autowired
    KafkaService kafkaService;

    /**
     * The Sms sign cache.
     */
    @Autowired
    SmsSignCache smsSignCache;

    @Autowired
    SmsMtService smsMtService;

    /**
     * 格式化处理短信.
     *
     * 1. 先将短信文案自带的所有签名去除
     * 2. 去除所有转义字符
     * 3. 供应商统一将windows的\r\n、linux的\n、mac的\r看成一个字符，由于mb_length计算时会将\r\n看成两个，短信内容将windows的换行字符\r\n换成\n，以便计算
     * 4. 其它类签名的格式化，将【】替换成[]
     *
     * @param sms the sms
     */
    @Override
    public boolean doFilter(MtDto sms) {
        if (StringUtil.isBlank(sms.getContent())) {
            log.error("短信文案不能为空, 数据为:" + sms.toString());
            kafkaService.sendToFilterTopic(sms.getMobiles(), sms.getContent(), FilterTypes.短信内容为空过滤器);
            smsMtService.trashMtAllMobiles(sms);
            return false;
        }

        SmsSignCo smsSignCo = smsSignCache.get(sms.getSignType()+"");
        if (smsSignCo == null) {
            log.error("根据短信签名值"+sms.getSignType()+"找不到对应的名称, 数据为:" + sms.toString());
            kafkaService.sendToFilterTopic(sms.getMobiles(), sms.getContent(), FilterTypes.签名不存在过滤器);
            smsMtService.trashMtAllMobiles(sms);
            return false;
        }

        List<String> allFormatNames = Splitter.on(",").splitToList(smsSignCo.getAllFormatNames());
        for (String formatName : allFormatNames) {
            sms.setContent(sms.getContent().replace(formatName, ""));
        }
        String newContent = sms.getContent()
                .replace("\\", "")
                .replace("\r\n", "\n")
                .replace("【", "[")
                .replace("】", "]");

        if (StringUtil.isBlank(newContent)) {
            log.error("处理后的短信文案为空, 数据为:" + sms.toString());
            kafkaService.sendToFilterTopic(sms.getMobiles(), sms.getContent(), FilterTypes.短信内容为空过滤器);
            smsMtService.trashMtAllMobiles(sms);
            return false;
        }

        sms.setContent(newContent);
        return true;
    }
}
