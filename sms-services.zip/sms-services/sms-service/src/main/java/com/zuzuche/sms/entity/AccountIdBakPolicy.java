package com.zuzuche.sms.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Table;
import java.util.Date;


/**
 * 功能：The type Account id bak policy.
 * 详细：
 *
 * @author Created on 2019.07.31 by chaodian
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "account_id_bak_policy")
public class AccountIdBakPolicy {
    private Integer id;

    private Integer accountId;

    private Integer backUp1;

    private Integer backUp2;

    private Date createTime;

    private Date updateTime;
}