package com.zuzuche.sms.task;

import com.zuzuche.commons.base.util.DateUtils;
import com.zuzuche.commons.base.util.StringUtil;
import com.zuzuche.sms.cache.ProviderAccountCache;
import com.zuzuche.sms.dto.InvokeResultDto;
import com.zuzuche.sms.dto.SmsDto;
import com.zuzuche.sms.entity.ProviderAccountInfo;
import com.zuzuche.sms.entity.StatusReport;
import com.zuzuche.sms.mapper.StatusReportMapper;
import com.zuzuche.sms.remote.CmPushApi;
import com.zuzuche.sms.remote.dto.PostCmSmsDto;
import com.zuzuche.sms.remote.param.PostCmSmsParam;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 功能：Cm的发送任务实现类.
 * 详细：
 *
 * @author Created on 2019.09.06 by chaodian
 */
@Slf4j
@Component
@Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class CmSendTask extends AbstractSendTask {
    /**
     * 提交短信成功响应的状态码
     */
    private static final String SUCCESS_CODE = "0";

    @Autowired
    CmPushApi cmPushApi;

    @Autowired
    StatusReportMapper statusReportMapper;

    CmSendTask(SmsDto sms) {
        super(sms);
    }

    /**
     * 过滤器链
     */
    @Override
    public boolean beforeSend(SmsDto sms) {
        return super.beforeSend( sms);
    }

    @Override
    public InvokeResultDto invokeApi(SmsDto sms) {
        // 构造批次号，便于CM回调短信状态报告
        String batchNo = sms.getAccountId() + "_" + sms.getTaskId();


        // 取账号密码
        ProviderAccountInfo account = ProviderAccountCache.getAccountById(sms.getAccountId());

        // 构造短信的token
        PostCmSmsParam.CmAuth token = PostCmSmsParam.CmAuth.builder()
                .producttoken(account.getAccountName())
                .build();
        // 构造短信的号码
        List<String> mobileList = StringUtil.asList(sms.getMobile());
        List<PostCmSmsParam.CmMobile> cmMobiles = mobileList.stream()
                .map(mobile -> PostCmSmsParam.CmMobile.builder().number(mobile).build())
                .collect(Collectors.toList());
        // 构造短信的内容、所带批次号
        PostCmSmsParam.CmBody cmBody = PostCmSmsParam.CmBody.builder()
                .content(sms.getContent())
                .build();
        // 构造短信完整主体
        PostCmSmsParam.CmMsg cmMsg = PostCmSmsParam.CmMsg.builder()
                .to(cmMobiles)
                .body(cmBody)
                .reference(batchNo)
                .build();
        // 有senderId，就设置from，作为提交给到国际手机中断短信显示的号码串，国外的支持如ERC字符串
        if (StringUtil.isNotBlank(sms.getSenderId())) {
            cmMsg.setFrom(sms.getSenderId());
        }

        // 构建消息主体
        List<PostCmSmsParam.CmMsg> cmMsgList = new ArrayList<>(2);
        cmMsgList.add(cmMsg);
        PostCmSmsParam.CmMessages cmMessages = PostCmSmsParam.CmMessages.builder()
                .authentication(token)
                .msg(cmMsgList)
                .build();

        PostCmSmsParam param = PostCmSmsParam.builder()
                .messages(cmMessages)
                .build();

        PostCmSmsDto result = cmPushApi.send(param);

        // 检查下提交状态
        boolean submitState = checkSubmitState(result);

        return InvokeResultDto.builder()
                .bachNo(batchNo)
                .extra(sms.getTaskId())
                .respCode(submitState ? "0" : result.getErrorCode())
                .taskId(sms.getTaskId())
                .mobiles(sms.getMobile())
                .md5Content(sms.getMd5Content())
                .timestamp(Instant.now().toEpochMilli())
                .providerId(account.getProviderId())
                .build();
    }

    /**
     * 检查判断短信提交状态
     *
     * @param dto the dto
     * @return boolean
     */
    private boolean checkSubmitState(PostCmSmsDto dto) {
        if (dto.getErrorCode().equals(SUCCESS_CODE)) {
            return true;
        }

        // 针对此家供应商的短信接口提交，下面的处理有点特殊:
        // 由于接口提交可以带上多个手机号，所以有一个号码提交成功，都认为此次批量短信提交成功，
        // 但是，其他提交失败的手机就需要当做失败的状态报告记录
        boolean state = false;
        List<StatusReport> statusReportList = new ArrayList<>();
        LocalDateTime nowTime = LocalDateTime.now();
        if (CollectionUtils.isNotEmpty(dto.getMessages())) {
            for (PostCmSmsDto.Message message : dto.getMessages()) {
                if (message.getMessageErrorCode().equals(SUCCESS_CODE)) {
                    state = true;
                } else {

                    StatusReport report = StatusReport.builder()
                            .batchNo(message.getReference())
                            .createTime(nowTime)
                            .phone(message.getTo())
                            .recvTime(DateUtils.format(nowTime))
                            .status(message.getStatus() + "_" + message.getMessageErrorCode())
                            .accountId(sms.getAccountId())
                            .build();
                    statusReportList.add(report);
                }
            }
        }

        // 如果此次批量提交成功, 并且提交失败的短信如果不为空，则当做状态报告插入
        if(state && CollectionUtils.isNotEmpty(statusReportList)){
            statusReportMapper.insertList(statusReportList);
        }

        return state;
    }

}
