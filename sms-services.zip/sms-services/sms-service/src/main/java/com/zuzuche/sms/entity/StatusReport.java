package com.zuzuche.sms.entity;

import com.zuzuche.kafka.message.BaseMessage;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Table;
import java.time.LocalDateTime;

/**
 * @desc 状态报告日志
 * @author panqiong
 * @date 20181019
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "status_report")
public class StatusReport  {
    private int id;

    private String batchNo;

    private String phone;

    private String status;

    private String recvTime;

    private LocalDateTime createTime;

    private int accountId;


}