package com.zuzuche.sms.mapper;

import com.zuzuche.commons.mybatis.BaseMapper;
import com.zuzuche.sms.entity.StatusReport;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @desc ~
 * @author panqiong
 * @date 20181019
 */
@Repository
public interface StatusReportMapper extends BaseMapper<StatusReport> {

    /**
     * ~
     * @param batchNo
     * @return
     */
    List<StatusReport> queryListByBatchNo(String batchNo);

    /**
     * 根据id范围查询 返回条数limit
     * @param id
     * @param count
     * @return
     */
    List<StatusReport> queryListByIdLimit(@Param("id") String id, @Param("count") int count);
}