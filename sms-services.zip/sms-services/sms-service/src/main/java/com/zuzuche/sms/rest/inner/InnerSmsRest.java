package com.zuzuche.sms.rest.inner;

import com.zuzuche.commons.base.annotation.Check;
import com.zuzuche.commons.base.resp.RespResult;
import com.zuzuche.sms.rest.SmsRest;
import com.zuzuche.sms.rest.request.MtTemplateReq;
import com.zuzuche.sms.rest.response.MtResp;
import com.zuzuche.sms.service.SmsMtService;
import com.zuzuche.threadpool.ThreadPoolExecutorFactory;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;


/**
 * @desc: protected安全级别的接口,暴露给外部门,网关会针对/protected验签
 * @author: panqiong
 * @date: 2019-08-19
 */
@RestController
@RequestMapping("/inner")
@Slf4j
@Api(value = "inner", description = "inner安全级别的接口", tags = {"inner"})
public class InnerSmsRest {


    @Autowired
    SmsMtService smsMtService;

    /**
     * 纯转发
     * @param req
     * @return
     */
    @PostMapping("/json/sendByTemplate")
    @ApiOperation(value = "根据模板下发业务短信", notes = "根据模板下发业务短信")
    @Check
    public RespResult<MtResp> sendByTemplateJson(@RequestBody MtTemplateReq req) {
        MtResp mtResp = smsMtService.sendWithTemplate(req);
        return RespResult.success(mtResp);
    }

    /**
     * 纯转发
     * @param req
     * @return
     */
    @PostMapping("/sendByTemplate")
    @ApiOperation(value = "根据模板下发业务短信", notes = "根据模板下发业务短信")
    @Check
    public RespResult<MtResp> sendByTemplateForm(MtTemplateReq req) {
        MtResp mtResp = smsMtService.sendWithTemplate(req);
        return RespResult.success(mtResp);
    }



    /**
     * 纯转发
     * @param req
     * @return
     */
    @PostMapping("/nothing")
    @ApiOperation(value = "根据模板下发业务短信", notes = "根据模板下发业务短信")
    @Check
    public RespResult<MtResp> nothing(MtTemplateReq req) {
        return RespResult.success();
    }


    /**
     * 用于测试超时
     * @param req
     * @return
     */
    @PostMapping("/timeout")
    @ApiOperation(value = "根据模板下发业务短信", notes = "根据模板下发业务短信")
    @Check
    public RespResult<MtResp> timeout(MtTemplateReq req) {
        try {
            Thread.sleep(60000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return RespResult.success();
    }

    /**
     * 用于测试耗时的请求
     * @param req
     * @return
     */
    @PostMapping("/time")
    @ApiOperation(value = "根据模板下发业务短信", notes = "根据模板下发业务短信")
    @Check
    public RespResult<MtResp> time(MtTemplateReq req) {
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return RespResult.success();
    }
}
