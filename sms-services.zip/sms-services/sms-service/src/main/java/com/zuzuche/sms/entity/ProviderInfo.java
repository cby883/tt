package com.zuzuche.sms.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Table;
import java.time.LocalDateTime;


/**
 * @desc 供应商信息
 * @author panqiong
 * @date 20181019
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "provider_info")
public class ProviderInfo {

    private int providerId;

    private String providerName;

    private String remark;

    private LocalDateTime createTime;

    private int validState;

}