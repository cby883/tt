package com.zuzuche.sms.remote.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @desc:
 * @author: panqiong
 * @date: 2018/10/17
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PullSmsReportDto {

    private int respcode;
    private String respdesc;
    private List<Report> reports;

    public PullSmsReportDto(int respcode,String respdesc){
        this.respcode = respcode;
        this.respdesc = respdesc;
    }
    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class Report {
        private String batchno;
        private String phone;
        private String status;
        private String accesscode;
        private String recvtime;
    }



}
