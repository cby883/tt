package com.zuzuche.sms.remote.param;


import com.zuzuche.commons.feign.annotation.PhpRequest;

/**
 * 功能：The type Php param.
 * 详细：
 *
 * @author Created on 2019.02.13 by chaodian
 */
@PhpRequest
public class PhpParam {
}
