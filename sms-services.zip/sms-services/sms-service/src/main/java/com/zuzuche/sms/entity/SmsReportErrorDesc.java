package com.zuzuche.sms.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Table;
import java.time.LocalDateTime;

/**
 * desc: 短信状态报告错误码详情
 *
 * @author bingyi
 * @date 2019/11/27
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "sms_report_error_desc")
public class SmsReportErrorDesc {
    private int id;

    private String errorCode;

    private String errorDesc;

    private int providerId;

    private LocalDateTime createTime;
}