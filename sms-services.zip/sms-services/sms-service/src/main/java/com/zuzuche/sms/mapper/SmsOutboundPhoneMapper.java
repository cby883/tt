package com.zuzuche.sms.mapper;

import com.zuzuche.commons.mybatis.BaseMapper;
import com.zuzuche.sms.entity.SmsOutboundPhone;
import org.springframework.stereotype.Repository;

/**
 * @desc ~
 * @author panqiong
 * @date 20181019
 */
@Repository
public interface SmsOutboundPhoneMapper extends BaseMapper<SmsOutboundPhone> {

}