package com.zuzuche.sms.filter.dispatch;


import com.alibaba.fastjson.JSONException;
import com.zuzuche.commons.base.util.JsonUtil;
import com.zuzuche.commons.base.util.StringUtil;
import com.zuzuche.sms.cache.SmsTemplateCache;
import com.zuzuche.sms.common.enums.FilterTypes;
import com.zuzuche.sms.dto.MtDto;
import com.zuzuche.sms.filter.MtFilter;
import com.zuzuche.sms.service.KafkaService;
import com.zuzuche.sms.service.SmsMtService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * 功能：短信模板处理过滤器.
 * 详细：
 *
 * @author Created on 2019.03.20 by chaodian
 */
@Component
@Slf4j
@Order(0)
public class MtTemplateFilter implements MtFilter {
    @Autowired
    SmsTemplateCache smsTemplateCache;

    @Autowired
    KafkaService kafkaService;

    @Autowired
    SmsMtService smsMtService;

    /**
     * 短信模板替换.
     *
     * 1. 从模板id或模板标识获取对应的文案
     * 2. 从接口提交的json格式的varibales变量，转为map格式并对文案进行替换
     *
     * @param sms the sms
     */
    @Override
    public boolean doFilter(MtDto sms) {
        String content = null;
        boolean isHasTemp = false;
        if (StringUtil.isNotBlank(sms.getTempId())) {
            content = smsTemplateCache.getTemplateById(sms.getTempId(), sms.getLanguage());
            if (StringUtil.isBlank(content)) {
                log.error("通过模板id"+sms.getTempId()+"获取不到模板内容, 数据如:" + sms.toString());
                kafkaService.sendToFilterTopic(sms.getMobiles(), "", FilterTypes.模板替换出错过滤器);
                smsMtService.trashMtAllMobiles(sms);
                return false;
            }
            isHasTemp = true;
        } else if (StringUtil.isNotBlank(sms.getTempUid())) {
            content = smsTemplateCache.getTemplateByUId(sms.getTempUid(), sms.getLanguage());
            if (StringUtil.isBlank(content)) {
                log.error("通过模板标识"+sms.getTempUid()+"获取不到模板内容, 数据如:" + sms.toString());
                kafkaService.sendToFilterTopic(sms.getMobiles(), "", FilterTypes.模板替换出错过滤器);
                smsMtService.trashMtAllMobiles(sms);
                return false;
            }
            isHasTemp = true;
        } else {
            content = sms.getContent();
        }
        sms.setContent(content);


        String variables = sms.getVariables();
        if (StringUtil.isNotEmpty(variables) && isHasTemp) {
            try {
                Map<String, Object> variMap = JsonUtil.stringToMap(variables);
                for (String varikey : variMap.keySet()) {
                    String variVal = variMap.get(varikey).toString();
                    sms.setContent(sms.getContent().replace(varikey, variVal));
                }
            } catch (JSONException e) {
                log.info("短信模板变量格式有误，数据如:" + sms.toString());
            } catch (Exception e) {
                log.error("短信模板变量解析异常，不允许替换模板, 数据如:" + sms.toString(), e, e.getMessage());
            }
        }

        return true;
    }
}
