package com.zuzuche.sms.executors;

import com.zuzuche.threadpool.ThreadPoolExecutorFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.integration.util.CallerBlocksPolicy;
import org.springframework.stereotype.Component;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;


/**
 * 功能：营销通知业务短信的工作线程池.
 * 详细：
 *
 * @author Created on 2019.03.01 by chaodian
 */
@Slf4j
@Component
public class MarketMtExecutor extends AbstractMtExecutor{

    public MarketMtExecutor() {
        super(ThreadPoolExecutorFactory.Config.builder()
                .corePoolSize(20)
                .maximumPoolSize(25)
                .keepAliveTime(5)
                .workQueue(new ArrayBlockingQueue<>(100))
                .unit(TimeUnit.MINUTES)
                .handler(new ThreadPoolExecutor.CallerRunsPolicy())
                .threadPoolName("MarketMtExecutor")
                .build());
    }
}
