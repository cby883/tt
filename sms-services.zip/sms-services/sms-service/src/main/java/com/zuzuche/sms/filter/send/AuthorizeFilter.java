package com.zuzuche.sms.filter.send;

import com.google.common.base.Splitter;
import com.zuzuche.commons.base.util.StringUtil;
import com.zuzuche.sms.common.constant.Constants;
import com.zuzuche.sms.common.utils.Md5Util;
import com.zuzuche.sms.dto.BlockedSmsDto;
import com.zuzuche.sms.dto.SmsDto;
import com.zuzuche.sms.filter.Filter;
import com.zuzuche.sms.service.KafkaService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * @desc: 权限检查过滤器
 * @author: panqiong
 * @date: 2018/10/30
 */
// @Component
// @Slf4j
// @Order(0)
public class AuthorizeFilter implements Filter {
    private static final Constants.FilterTypes FILTER = Constants.FilterTypes.权限检查过滤器;

    @Value("${auth.secret}")
    private String secret ;

    @Value("${auth.open}")
    private boolean open;

    @Autowired
    KafkaService kafkaService;


    /**
     * 返回false将导致整个下发流程中断
     *
     * @param sms
     * @return
     */
    @Override
    public boolean doFilter(SmsDto sms) {
        if(open){
            if(sms.getTime()==0){
                reportKafka(sms);
                return false;
            }
            if(StringUtil.isEmpty(sms.getAuthKey())){
                reportKafka(sms);
                return false;
            }

            String md5 = Md5Util.string2MD5(secret+sms.getTime());
            if(!md5.equals(sms.getAuthKey())){
                reportKafka(sms);
                return false;
            }
            return true;
        }

        return true;
    }

    private void reportKafka(SmsDto sms){
//        List<String> list = Splitter.on(",").splitToList(sms.getMobile());
//        BlockedSmsDto duSmsDto = BlockedSmsDto.builder()
//                .mobileList(list)
//                .taskId(sms.getTaskId())
//                .filterType(FILTER)
//                .build();
//        kafkaService.sendToBlockedTopic(duSmsDto);
    }
}
