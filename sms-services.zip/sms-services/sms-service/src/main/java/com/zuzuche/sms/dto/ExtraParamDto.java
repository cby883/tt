package com.zuzuche.sms.dto;

import com.alibaba.fastjson.annotation.JSONField;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
/**
 * desc:MtDto extraParam字段对象类
 *
 * @author bingyi
 * @date 2019/08/28
 */
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ExtraParamDto {

    /**
     * 提交给供应商的下发来源，比如ERC，也即用户终端手机的短信显示的来源号码串
     */
    private String senderId;

    private String ticketIdStr;
    List<OrderRelate> associateOrder;
    /**
     * 模板id
     */
    private String tempId;

    /**
     * 模板tempUid
     */
    private String tempUid;

    @AllArgsConstructor
    @NoArgsConstructor
    @Data
    @Builder
    public static class OrderRelate {
        @JSONField(name = "order_type")
        String orderType;
        @JSONField(name = "order_id")
        String orderId;
    }
}