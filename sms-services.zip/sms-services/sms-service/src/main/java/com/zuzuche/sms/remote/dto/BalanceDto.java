package com.zuzuche.sms.remote.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @desc:
 * @author: panqiong
 * @date: 2018/11/12
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class BalanceDto {

    /**
     * 状态码
     */
    private String code;

    /**
     * 剩余可用余额条数
     */
    private String balance;

    /**
     * 状态码说明（成功返回空）
     */
    private String errorMsg;

    private String time;
}
