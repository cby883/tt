package com.zuzuche.sms.cache;

import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.ListMultimap;
import com.google.common.collect.Maps;
import com.google.common.util.concurrent.RateLimiter;
import com.zuzuche.commons.base.constants.BaseEnum;
import com.zuzuche.commons.base.resp.Status;
import com.zuzuche.commons.base.resp.StatusServiceCnException;
import com.zuzuche.sms.common.enums.RateLimiterKeyTypes;
import com.zuzuche.sms.entity.ProviderAccountInfo;
import com.zuzuche.sms.entity.SmsConfig;
import com.zuzuche.sms.mapper.ProviderAccountInfoMapper;
import com.zuzuche.sms.mapper.SmsConfigMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

/**
 * @desc:
 * @author: panqiong
 * @date: 2018/11/2
 */
@Component("SmsConfigCache")
@Slf4j
public class SmsConfigCache implements InitializingBean, ConfigCache {


    @Autowired
    SmsConfigMapper mapper;

    /***
     * key:accountId
     * value:账户信息
     */
    private static Map<String, String> configMap = new HashMap<>(16);

    /**
     * 速率
     */
    private static Map<String, RateLimiter> limiterMap = new HashMap<>(16);

    public boolean containsKey(String key) {
        return configMap.containsKey(key);
    }

    public String get(String key) {
        return configMap.get(key);
    }


    @Override
    public void afterPropertiesSet() throws Exception {
        load();
        limiterRoad();
    }


    /**
     * 载入配置到内存
     */
    private synchronized void load() {
        Map<String, String> configMapTemp = new HashMap<>(16);
        List<SmsConfig> list = mapper.selectAll();
        if (CollectionUtils.isNotEmpty(list)) {
            list.stream().forEach(config -> configMapTemp.put(config.getConfigKey(), config.getConfigValue()));
        }
        configMap = configMapTemp;

    }

    @Override
    public boolean refresh() {
        try {
            load();
            limiterRoad();
            return true;
        } catch (Exception e) {
            log.error("【SmsConfigCache】配置刷新失败", e.getMessage(), e);
            return false;
        }
    }


    /**
     * 载入限流器配置
     */
    public synchronized void limiterRoad() {
        //临时缓存
        Map<String, RateLimiter> temp = null;
        List<SmsConfig> list = mapper.selectAll();
        if (CollectionUtils.isNotEmpty(list)) {
            //加载限流器
            temp = list.stream().filter(e -> {
                RateLimiterKeyTypes rateLimiterKeyTypes = BaseEnum.parse(RateLimiterKeyTypes.class, e.getConfigKey());
                //如果不为空，则配置项为限流器配置，理应加载到内存中
                return rateLimiterKeyTypes != null;
            }).collect(Collectors.toMap(config -> config.getConfigKey(), config -> createLimiter(config.getConfigValue())));
            if (temp != null && temp.size() > 0) {
                limiterMap = temp;
            }
            return;
        }
        throw new StatusServiceCnException(Status.BUSY, "加载速率出错");
    }

    /**
     * @param rateLimiterKeyTypes
     * @return
     */
    public RateLimiter getLimiter(RateLimiterKeyTypes rateLimiterKeyTypes) {

        RateLimiter rateLimiter = limiterMap.get(rateLimiterKeyTypes.code());
        if (rateLimiter != null) {
            return rateLimiter;
        }
        //保证获取到的Limiter一定存在
        limiterMap.put(rateLimiterKeyTypes.code(), createLimiter(50 + ""));
        return limiterMap.get(rateLimiterKeyTypes.code());
    }

    /**
     * 创建限流器,默认创建50
     *
     * @param count
     * @return
     */
    private static RateLimiter createLimiter(String count) {
        int rate = 0;
        try {
            rate = Integer.parseInt(count);
        } catch (Exception e) {
            log.error("SmsCofigCache转换限流器速率错误", e.getMessage(), e);
        }
        if (rate > 0) {
            return RateLimiter.create(rate);
        } else {
            return RateLimiter.create(50);
        }
    }

    /**
     * 获取map
     *
     * @return
     */
    public Map<String, RateLimiter> getLimiterMap() {
        return limiterMap;
    }
}
