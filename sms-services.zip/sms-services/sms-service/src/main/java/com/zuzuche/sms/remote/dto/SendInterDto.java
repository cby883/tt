package com.zuzuche.sms.remote.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @desc:
 * @author: panqiong
 * @date: 2018/11/12
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SendInterDto {
    /**
     * 状态码
     */
    private String code;

    /**
     *  "17041010383624511", //消息Id
     */
    private String msgId;

    /**
     * "error" : "", //失败状态码说明（成功返回空）
     */
    private String error;

}
