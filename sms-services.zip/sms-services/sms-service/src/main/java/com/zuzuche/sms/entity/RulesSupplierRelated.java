package com.zuzuche.sms.entity;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Table;

/**
 * 功能：The type Rules supplier related.
 * 详细：
 *
 * @author Created on 2019.01.31 by chaodian
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "zuzuche_sms_db.rules_supplier_related_tbl")
public class RulesSupplierRelated {
    private Integer id;

    private Integer ruleId;

    private String supplier;

    private Short level;

    private Byte status;

    private int accountId;

    private Integer addTime;

    private Integer updateTime;
}