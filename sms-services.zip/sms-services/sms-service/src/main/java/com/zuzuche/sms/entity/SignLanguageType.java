package com.zuzuche.sms.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Id;
import javax.persistence.Table;
import java.time.LocalDateTime;

/**
 * SignLanguageType
 *
 * @blame 短信简繁体签名关联表
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "zuzuche_sms_db.sign_language_type")
public class SignLanguageType {
    @Id
    private int id;

    /**
     * 简体签名id
     */
    private int simplifiedSignId;

    /**
     * 关联的语言版本，例如：zh-cn,zh-hk
     */
    private String language;

    /**
     * 关联的真实签名id
     */
    private int realSignId;

    /**
     * 创建时间
     */
    private LocalDateTime createTime;

    /**
     * 0默认有效，1删除
     */
    private int deleted;
}