package com.zuzuche.sms.mapper;

import com.zuzuche.commons.mybatis.BaseMapper;
import com.zuzuche.sms.entity.AccountIdBakPolicy;
import org.springframework.stereotype.Repository;


/**
 * The interface Account id bak policy mapper.
 * @author Chaodian
 */
@Repository
public interface AccountIdBakPolicyMapper extends BaseMapper<AccountIdBakPolicy> {
}