package com.zuzuche.sms.vo;


import com.alibaba.fastjson.annotation.JSONField;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 功能：恒信供应商回调的每条状态报告细节.
 * 详细：
 *
 * @author Created on 2019.06.28 by chaodian
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class HengxinStatusCallbackDetail {
    /**
     * 手机号码
     */
    private String mobile;

    /**
     * 批次号
     */
    private String batchId;

    /**
     * 短信的唯一id标识
     */
    private String msgId;

    /**
     * 短信的接收时间
     */
    private String recvTime;

    /**
     * 短信的具体状态报告
     */
    private String status;
}
