package com.zuzuche.sms.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Table;
import java.util.Date;


/**
 * 功能：短信下发重试日志.
 * 详细：
 *
 * @author Created on 2019.07.30 by chaodian
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "sms_outbound_retry_log")
public class SmsOutboundRetryLog {
    private Integer id;

    private String taskId;

    private Short accountId;

    private Short nextAccountId;

    private Byte retryNo;

    private String respCode;

    private String batchNo;

    private Date createTime;
}