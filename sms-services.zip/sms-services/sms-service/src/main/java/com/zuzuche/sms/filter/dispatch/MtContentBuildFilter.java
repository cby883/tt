package com.zuzuche.sms.filter.dispatch;


import com.zuzuche.commons.base.util.StringUtil;
import com.zuzuche.sms.cache.SmsSignCache;
import com.zuzuche.sms.cache.SupplierConfigCache;
import com.zuzuche.sms.cache.co.SmsSignCo;
import com.zuzuche.sms.cache.co.SupplierConfigCo;
import com.zuzuche.sms.common.enums.FilterTypes;
import com.zuzuche.sms.common.enums.SmsRegionType;
import com.zuzuche.sms.common.enums.SmsType;
import com.zuzuche.sms.dto.MtDto;
import com.zuzuche.sms.filter.MtFilter;
import com.zuzuche.sms.service.KafkaService;
import com.zuzuche.sms.service.SmsMtService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

/**
 * 功能：短信完整内容构造过滤器.
 * 详细：
 *
 * @author Created on 2019.03.20 by chaodian
 */
@Component
@Slf4j
@Order(8)
public class MtContentBuildFilter implements MtFilter {
    @Autowired
    SupplierConfigCache supplierConfigCache;

    @Autowired
    SmsSignCache smsSignCache;

    @Autowired
    KafkaService kafkaService;

    @Autowired
    SmsMtService smsMtService;

    @Override
    public boolean doFilter(MtDto mtDto) {
        // 获取供应商配置项
        SupplierConfigCo co = supplierConfigCache.getConfig(mtDto.getSupplier(), mtDto.getRegionType(), mtDto.getType());
        // 获取签名配置
        SmsSignCo signCo = smsSignCache.get(Integer.toString(mtDto.getSignType()));

        //设置重发短信内容
        mtDto.setRetryContent(mtDto.getContent());

        // 签名配置不存在则不允许发送
        if (signCo == null) {
            log.error("签名值配置不存在"+mtDto.toString());
            kafkaService.sendToFilterTopic(mtDto.getMobiles(), mtDto.getContent(), FilterTypes.签名不存在过滤器);
            smsMtService.trashMtAllMobiles(mtDto);
            return false;
        }

        //需要进行特殊供应商，短信内容签名匹配的。如阿里
        if(co != null && co.getCleanSignType()==1){
            SmsSignCo smsSignCo=smsSignCache.get(mtDto.getSignType()+"");
            String aliyunPrefix=smsSignCo.getName();
            mtDto.setSendContent(mtDto.getContent());
            mtDto.setContent(aliyunPrefix+mtDto.getContent());
        } else if (co != null && StringUtil.isNotBlank(co.getPreFix())) {
            // 入库的短信内容加上前缀
            // 提交给供应商的短信内容不需要加前缀
            // 此时标识该供应商在最终发给用户的短信会自动加上此前缀，比如百唔会加上【租租车】
            // 以便两边对账
            mtDto.setSendContent(mtDto.getContent());
            mtDto.setContent(co.getPreFix() + mtDto.getContent());
        } else {
            mtDto.setContent(signCo.getName() + mtDto.getContent());
            mtDto.setSendContent(mtDto.getContent());
        }

        if (co != null && StringUtil.isNotBlank(co.getPostFix())) {
            // 入库的短信内容加上后缀
            // 提交给供应商的短信内容不需要加后缀
            // 此时后缀标识该供应商在最终发给用户的短信会自动加上此后缀，比如某个供应商营销会自动加上 回复TD退订
            // 以便两边对账
            mtDto.setContent(mtDto.getContent() + co.getPostFix());
        }

        // 营销统一加上" 。回TD退订"
        if (mtDto.getType() == SmsType.营销.getCode() && mtDto.getRegionType() != SmsRegionType.国际.code()) {
            mtDto.setContent(mtDto.getContent() + " 。回TD退订");
            mtDto.setSendContent(mtDto.getSendContent() + " 。回TD退订");
        }

        return true;
    }
}
