package com.zuzuche.sms.report.callback;

import com.google.common.base.Splitter;
import com.zuzuche.commons.base.util.DateUtils;
import com.zuzuche.commons.base.util.StringUtil;
import com.zuzuche.sms.entity.ProviderAccountInfo;
import com.zuzuche.sms.entity.StatusReport;
import com.zuzuche.sms.rest.request.TeleSignCallbackReq;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * 功能：CM供应商的数据回调服务层.
 * 详细：
 *
 * @author Created on 2019.09.08 by chaodian
 */
@Service("teleSignCallbackService")
@Slf4j
public class TeleSignCallbackService extends AbstractCallbackService {

    /**
     * 切割teleSign供应商回馈的短信状态报告的分隔符.
     * 1. 短信发送提交给供应桑接口的批次号格式为自定义的如 126_10064955，即账户Id + _ + taskid
     * 2. 第1步这样做的好处是便于状态报告回调，使用_切割，获取到accountId，能具体定位到是哪个账户id发送的短信
     */
    private static final String STATUS_REPORT_TEXT_SPLIT_SIGN = "_";

    @Override
    protected List<StatusReport> doAnalyzeCallbackStatusReport(ProviderAccountInfo account, Object callbackData) {
        // 先强制转换下类型
        TeleSignCallbackReq req = (TeleSignCallbackReq) callbackData;

        //打印状态报告信息
        log.warn("teleSign状态报告数据:" + req.toString());

        //构造report
        StatusReport report = StatusReport.builder()
                .batchNo(req.getBatchNo())
                .createTime(LocalDateTime.now())
                .phone(req.getNumber())
                .recvTime(DateUtils.formatDateStr(req.getStatus().getUpdatedOn()))
                .status(getStatus(req))
                .accountId(account.getAccountId())
                .build();

        List<StatusReport> statusReportList = new ArrayList<>(2);
        statusReportList.add(report);
        return statusReportList;
    }


    private String getStatus(TeleSignCallbackReq req) {
        int[] successCodes={200,293};
        if (req.getStatus().getCode() == successCodes[0] || req.getStatus().getCode() == successCodes[1]) {
            return "DELIVRD";
        }
        if (CollectionUtils.isNotEmpty(req.getErrors())) {
            TeleSignCallbackReq.Error error = req.getErrors().get(0);
            String errorMsg = cutErrorMessage(error.getCode() + "_" + error.getDescription());
            return errorMsg;
        }
        return "failure";
    }

    /**
     * 截取错误信息length<30
     *
     * @param errorMessage
     * @return
     */
    private static String cutErrorMessage(String errorMessage) {
        int len = 29;
        if (errorMessage.length() <= len) {
            //如果小于,直接返回
            return errorMessage;
        }
        return errorMessage.substring(0, 29);
    }

    /**
     * desc:从sessionId中获取
     *
     * @param sessionId
     * @return
     */
    private List splitSessionId(String sessionId) {

        List<String> result = new ArrayList<>(5);
        if (StringUtil.isNotBlank(sessionId)) {
            result = Splitter.on(STATUS_REPORT_TEXT_SPLIT_SIGN).splitToList(sessionId);
        }

        return result;
    }

    /**
     * 拆分sessionId
     *
     * @param teleSignCallbackReq
     * @return
     */
    public TeleSignCallbackReq completion(TeleSignCallbackReq teleSignCallbackReq) {
        //获取sessionId拆分后的信息
        List<String> infoList = splitSessionId(teleSignCallbackReq.getSessionId());
        if (CollectionUtils.isNotEmpty(infoList) && infoList.size() >= 3) {
            try {
                //填充accoundId
                teleSignCallbackReq.setAccoundId(Integer.parseInt(infoList.get(0)));
                //填充taskId
                teleSignCallbackReq.setBatchNo(infoList.get(1));
                //填充number
                teleSignCallbackReq.setNumber(infoList.get(2));
            } catch (NumberFormatException e) {
                log.error("[TeleSignCallbackService-completion]转化sessionId出错:{}", teleSignCallbackReq.toString(), e.getMessage(), e);
            }
        }
        return teleSignCallbackReq;
    }

}
