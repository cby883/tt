package com.zuzuche.sms.cache;
/**
 * desc:配置接口类
 *
 * @author bingyi
 * @date 2019/09/23
 */
public interface ConfigCache {
    /**
     * desc:加载配置
     * @return
     */
     boolean refresh ();
}
