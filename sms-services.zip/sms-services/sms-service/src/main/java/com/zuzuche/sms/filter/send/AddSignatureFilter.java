package com.zuzuche.sms.filter.send;

import com.google.common.base.Charsets;
import com.google.common.base.Joiner;
import com.google.common.base.Splitter;
import com.google.common.hash.BloomFilter;
import com.google.common.hash.Funnel;
import com.google.common.hash.PrimitiveSink;
import com.zuzuche.sms.common.utils.Md5Util;
import com.zuzuche.sms.dto.SmsDto;
import com.zuzuche.sms.filter.Filter;
import com.zuzuche.sms.rest.request.SmsReq;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

/**
 * @desc: 添加签名过滤器
 * @author: panqiong
 * @date: 2018/10/26
 */
// @Component
// @Slf4j
// @Order(3)
public class AddSignatureFilter implements Filter {
    @Autowired
    StringRedisTemplate redisTemplate;


    /**
     * @param sms
     * @return
     */
    @Override
    public boolean doFilter(SmsDto sms) {
        return true;
    }





    /**
     * 布隆过滤器 不在的话 一定不在,在的话,可能不在(概率小)
     */
    private final BloomFilter<String> dealIdBloomFilter = BloomFilter.create(new Funnel<String>() {

        private static final long serialVersionUID = 1L;

        @Override
        public void funnel(String arg0, PrimitiveSink arg1) {

            arg1.putString(arg0, Charsets.UTF_8);
        }

    }, 1024*1024*32, 0.0000001d);

}
