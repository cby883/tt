package com.zuzuche.sms.rest.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.validator.constraints.Range;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.constraints.NotBlank;

/**
 * desc:批量发送请求dto
 *
 * @author bingyi
 * @date 2019/10-31
 */
@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
@ApiModel(value = "文件上传接口")
public class FileUploadReq {

    @ApiModelProperty(value = "文件",required = true)
    @NotBlank(message = "文件不能为空")
    private MultipartFile file;

    @ApiModelProperty(value = "上传人")
    private String creator;

    private String remark;

    /**
     * 文件类型
     */
    @ApiModelProperty(value = "文件类型，1默认表示不带变量的大批量文件，2表示带变量替换的文件")
    @Builder.Default
    private int fileType=1;




}
