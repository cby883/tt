package com.zuzuche.sms.listener.inner;

import com.google.common.util.concurrent.RateLimiter;
import com.zuzuche.sms.cache.SmsConfigCache;
import com.zuzuche.sms.common.enums.RateLimiterKeyTypes;
import com.zuzuche.sms.common.utils.SpringBeanFactory;
import com.zuzuche.sms.dto.StatusReportDto;
import com.zuzuche.sms.service.KafkaService;
import com.zuzuche.sms.task.SmsReportTask;
import com.zuzuche.threadpool.ThreadPoolExecutorFactory;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * 功能：状态报告回馈消费监听器.
 * 详细：
 *
 * @author Created on 2019.07.30 by chenbingyi
 */
@Component
@Slf4j
@Data
public class StatusReportListener {

    @Value("${report.isOpen}")
    public boolean isOpen;

    private static RateLimiter rateLimiter1=RateLimiter.create(1);

    public static AtomicInteger timeSize=new AtomicInteger(-1);
    /**
     * 状态报告连续睡眠计数器
     */
    public static AtomicInteger count=new AtomicInteger(0);
    ExecutorService executorService = ThreadPoolExecutorFactory.create(ThreadPoolExecutorFactory.Config.builder()
            .corePoolSize(1)
            .maximumPoolSize(1)
            .keepAliveTime(5)
            .workQueue(new ArrayBlockingQueue(500))
            .unit(TimeUnit.MINUTES)
            .handler(new ThreadPoolExecutor.CallerRunsPolicy())
            .threadPoolName("StatusReportExecutor")
            .build());
    @Autowired
    SmsConfigCache configCache;

    @Autowired
    SmsConfigCache smsConfigCache;


    /**
     * 注意:
     * - 如果消息处理超时,spring默认最多会重新处理三次
     * - 发生异常要预警,把处理失败的消息转发到dlq队列
     * - 优雅退出应用,不然会可能丢失消息未处理
     * 重复短信处理,这些消息是由 filters 送进去的
     *  暂时关闭，后面再详细测试
     * @param consumer
     */
    @KafkaListener(topics = KafkaService.STATUS_REPORT_TOPIC_NAME)
    public void consume(ConsumerRecord<String, StatusReportDto> consumer) {
        if (isOpen) {
            //如果开关打开，直接返回
            return;
        }
        RateLimiter rateLimiter=getLimiter(timeSize);
        rateLimiter.acquire();
        try {
            //获取状态报告
            StatusReportDto statusReport = consumer.value();
            //生成任务
            SmsReportTask smsReportTask = packingTask(statusReport);
            executorService.execute(smsReportTask);
        } catch (RejectedExecutionException re) {
            log.error("[状态报告StatusReportListener线程池拒绝策略触发-sms_status_report_cycle_topic]message:" + consumer.value(), re.getMessage(), re);
        } catch (Exception e) {
            log.error("[状态报告StatusReportListener处理出现异常-sms_status_report_cycle_topic]message:" + consumer.value(), e.getMessage(), e);
            //重新入队
        }
    }

    /**
     * desc:调速
     * @param timeSize
     * @return
     */
    private RateLimiter getLimiter(AtomicInteger timeSize){
        if(timeSize.get()<=0){
            return smsConfigCache.getLimiter(RateLimiterKeyTypes.STATUS_REPORT_CYCLE_TOPIC_RATE);
        }else{
            timeSize.decrementAndGet();
            return rateLimiter1;
        }
    }

    public SmsReportTask packingTask(StatusReportDto statusReport) {
        SmsReportTask smsReportTask = SpringBeanFactory.getBean(SmsReportTask.class, statusReport);
        return smsReportTask;
    }

}
