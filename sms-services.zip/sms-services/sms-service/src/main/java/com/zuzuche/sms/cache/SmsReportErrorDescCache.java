package com.zuzuche.sms.cache;

import com.zuzuche.commons.base.util.StringUtil;
import com.zuzuche.sms.entity.SmsReportErrorDesc;
import com.zuzuche.sms.mapper.SmsReportErrorDescMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;

import java.text.MessageFormat;
import java.util.concurrent.TimeUnit;

/**
 * 功能： 短信状态报告状态详情码缓存
 * 详细：
 *
 * @author Created on 2019.11.27 by bingyi
 */
@Slf4j
@Component("SmsReportErrorDescCache")
public class SmsReportErrorDescCache{

    @Autowired
    StringRedisTemplate redisTemplate;

    @Autowired
    SmsReportErrorDescMapper mapper;

    private static String SMS_REPORT_ERROR_REDIS_KEY="SMS_REPORT_ERROR_REDIS_KEY_{0}_{1}";

    /**
     * desc:根据错误码和accountId去获取详情
     * @param errorCode
     * @param accountId
     * @return
     */
    public  String getErrorDesc(String errorCode,int accountId){
        try {
            //构造key
            String errorKey=MessageFormat.format(SMS_REPORT_ERROR_REDIS_KEY,errorCode,accountId);
            //判断是否在redis中
            String errorDesc=redisTemplate.opsForValue().get(errorKey);
            if(StringUtil.isNotBlank(errorDesc)){
                //命中缓存，直接返回
                return errorDesc;
            }else {
                int random=(int)(1+Math.random()*10);
                //查库
                SmsReportErrorDesc smsReportErrorDesc=mapper.selectByCode(errorCode,accountId);
                //防止缓存击穿
                if(smsReportErrorDesc==null){
                    redisTemplate.opsForValue().set(errorKey,errorCode,30L*random, TimeUnit.MINUTES);
                    return errorCode;
                }
                //设置缓存
                redisTemplate.opsForValue().set(errorKey,smsReportErrorDesc.getErrorDesc(),30L*random, TimeUnit.MINUTES);
                return smsReportErrorDesc.getErrorDesc();
            }
        } catch (Exception e) {
            log.error("【SmsReportErrorDescCache】获取状态报告状态详情出错",e.getMessage(),e);
            return errorCode;
        }
    }
}
