package com.zuzuche.sms.dto;

import com.zuzuche.kafka.message.BaseMessage;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Queue;

/**
 * 功能：对接业务方的下行短信信息.
 * 详细：
 *
 * @author Created on 2019.01.30 by chaodian
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class MtDto extends BaseMessage {
    /**
     * 短信模板id
     */
    private String tempId;

    /**
     * 模板标识
     */
    private String tempUid;

    /**
     * 替换短信模板的变量json，格式如{"[username]" : '张先生', "[order_id]" : '233431',...}，注意包括中括号一并当作键值
     */
    private String variables;

    /**
     * 模板语言版本，目前只有zh-cn(简体中文)、zh-hk(香港繁体)、zh-tw(台湾繁体)，如果是英文版本或其他语言版本，先另建模板指定zh-cn
      */
    private String language;

    /**
     * 批量手机号码， 多个以英文逗号分割
     */
    private String mobiles;

    /**
     * 准确匹配的唯一一个区号，用于匹配国际供应商
     */
    private String exactAreaCode;

    /**
     * 批量的绕过所有拦截的白名单手机，多个以英文逗号分割
     */
    private String whiteMobiles;

    /**
     * 短信内容
     */
    private String content;

    /**
     * 短信类型
     */
    @Builder.Default
    private int type = 1;

    /**
     * 国家类型
     */
    @Builder.Default
    private int regionType = 1;

    /**
     * 签名类型
     */
    @Builder.Default
    private int signType = 1;

    /**
     * 自定义命名批次号
     */
    @Builder.Default
    private String batch = "";

    /**
     * 短信发送者
     */
    @Builder.Default
    private String admin = "system";

    /**
     * 发送短信携带的额外参数json串
     */
    private String extraParam;

    /**
     * 额外参数dto
     */
    private ExtraParamDto extraParamDto;

    /**
     * 来自上层业务名称
     */
    @Builder.Default
    private String from = "";

    /**
     * 来自上层业务唯一标识
     */
    private String uniqueId;

    /**
     * 供应商名称
     */
    private String supplier;

    /**
     * 匹配到供应商的规则标识
     */
    @Builder.Default
    private String sign = "";

    /**
     * 供应商映射的accountId，实际下发账户id
     */
    private int accountId = 0;

    /**
     * 短信内容的条数
     */
    private int sendCount = 0;

    /**
     * 最终提交转给供应商的短信内容.
     *
     * 由于百唔供应商会自动加上【租租车】签名前缀，因此需要与content字段区分出来
     * sendContent不需要加上【租租车】，但入库的content需要加上，以便两边对账
     *
     */
    private String sendContent;

    /**
     * 发送时间戳
     */
    private int sendTime;

    /**
     * 入库的短信标识taskId
     */
    private String taskId;

    /**
     * 入队状态
     */
    private String pushStatus;

    /**
     * 是否模拟 true的话将不会真实发送
     */
    @Builder.Default
    private boolean mock = false;

    /**
     * 模拟超时，该值表示重试到第n次才不会超时，0表示不会出现超时
     */
    @Builder.Default
    private int mockTimeOutUntilRetryNo = 0;

    /**
     * 重发供应商队列
     */
    private Queue<Integer> backup;
    /**
     * 重发短信初始内容
     */
    private String retryContent;

    /**
     * 判断是否为模板短信,默认0为不使用模板发送,1使用
     */
    @Builder.Default
    private int useTemplate=0;

}
