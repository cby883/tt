package com.zuzuche.sms.remote.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @desc: 创蓝状态报告拉取
 * @author: panqiong
 * @date: 2018/11/12
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PullReportDto {
    /**
     * 请求状态。0成功，其他状态为失败
     */
    private String ret;
    private String error;
    private List<Report> result;


    @Data
    @Builder
    @AllArgsConstructor
    @NoArgsConstructor
    public static class Report{
        /**
         * 用户在提交短信时传入的uid参数，状态报告会原样返回此参数，未提交则无该参数
         */
        private String uid;
        /**
         * 状态更新时间，格式yyMMddHHmm，其中yy=年份的最后两位
         */
        private String reportTime;
        /**
         * 253平台收到运营商回复状态报告的时间，格式yyMMddHHmmss
         */
        private String notifyTime;
        /**
         * 状态码
         */
        private String status;
        /**
         * 消息Id
         */
        private String msgId;
        /**
         * 状态说明
         */
        private String statusDesc;
        /**
         * 接收短信的手机号码
         */
        private String mobile;
    }
}
