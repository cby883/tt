package com.zuzuche.sms.remote.dto;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * 功能：TeleCm 供应商短信提交返回数据.
 * 详细：
 *
 * @author Created on 2019.09.06 by chaodian
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PostCmSmsDto {
    /**
     * 请求返回的详情信息
     */
    private String details;

    /**
     * 状态码
     */
    private String  errorCode;

    /**
     * 返回的具体详情
     */
    private List<Message> messages;

    /**
     * 单个手机具体下发返回的消息
     */
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class Message {
        /**
         * 提交的单个手机号码
         */
        private String to;

        /**
         * 提交的返回状态
         */
        private String status;

        private String reference;

        private String  parts;

        /**
         * 单条手机短信下发具体详情
         */
        private String messageDetails;

        /**
         * 单条手机短信下发的具体状态码
         */
        private String messageErrorCode;
    }
}
