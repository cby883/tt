package com.zuzuche.sms.remote.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * 一条上行xml字符串最多包含10个< deliver ></ deliver>节点
 * @desc: 拉取上行短信
 * @author: panqiong
 * @date: 2018/11/5
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PostDeliverMsgDto {
    private String code;
    private String desc;
    private List<Deliver> deliverList;

    public PostDeliverMsgDto(String code,String desc){
        this.code = code;
        this.desc = desc;
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class Deliver{

        private String corpId;

        private String mobile;

        private String ext;

        private String time;

        private String content;
    }
}
