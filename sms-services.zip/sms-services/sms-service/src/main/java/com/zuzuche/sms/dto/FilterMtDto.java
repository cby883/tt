package com.zuzuche.sms.dto;

import com.zuzuche.kafka.message.BaseMessage;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * 功能： 一次请求过滤拦截的手机信息.
 * 详细：
 *
 * @author Created on 2019.02.28 by chaodian
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class FilterMtDto extends BaseMessage {
    /**
     * 拦截错误码，对应enums/filterTypes
     */
    private int errorCode;

    /**
     * 发送的短信内容
     */
    private String content;

    /**
     * 拦截的所有手机号码
     */
    private List<String> mobileList;
}
