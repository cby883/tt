package com.zuzuche.sms.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Table;
import java.time.LocalDateTime;

/**
 * @desc:
 * @author: panqiong
 * @date: 2018/10/31
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "sms_config")
public class SmsConfig {

    private String id;

    private String configKey;

    private String configValue;

    private LocalDateTime createTime;

    private LocalDateTime updateTime;

    private String remark;
}
