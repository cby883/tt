package com.zuzuche.sms.task;

import com.zuzuche.sms.cache.ProviderAccountCache;
import com.zuzuche.sms.dto.InvokeResultDto;
import com.zuzuche.sms.dto.SmsDto;
import com.zuzuche.sms.entity.ProviderAccountInfo;
import com.zuzuche.sms.remote.ChuangLanApi;
import com.zuzuche.sms.remote.dto.SendDto;
import com.zuzuche.sms.remote.param.SendParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.time.Instant;

/**
 * 支持自己携带id
 * @desc: 创蓝短信发送任务
 * @author: panqiong
 * @date: 2018/11/12
 */
@Slf4j
@Component
@Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class ChLanSendTask extends AbstractSendTask{

    @Autowired
    ChuangLanApi chLanApi;

    ChLanSendTask(SmsDto sms) {
        super(sms);
    }


    /**
     * 过滤器链
     */
    @Override
    public boolean beforeSend(SmsDto sms) {
        return super.beforeSend( sms);
    }

    /**
     * 调用供应商的接口
     *
     * @param sms
     * @return
     */
    @Override
    public InvokeResultDto invokeApi(SmsDto sms) {

        // 取账号密码
        ProviderAccountInfo account = ProviderAccountCache.getAccountById(sms.getAccountId());

        SendParam sendParam = SendParam.builder()
                .account(account.getAccountName())
                .password(account.getAccountPwd())
                .msg(sms.getContent())
                .phone(sms.getMobile())
                .sendtime("")
                .report("true")
                .extend("")
                .uid(sms.getTaskId())
                .build();
        SendDto smdto = chLanApi.send(sendParam);

        // 封装返回对象
        InvokeResultDto resultDto = InvokeResultDto.builder()
                // 接口返回的msgid,用我们自己的taskid
                .bachNo(sms.getTaskId())
                // 自己的taskId
                .extra(smdto.getMsgId())
                //.extra("")
                .respCode(smdto.getCode())
                .taskId(sms.getTaskId())
                .mobiles(sms.getMobile())
                .md5Content(sms.getMd5Content())
                .timestamp(Instant.now().toEpochMilli())
                .providerId(account.getProviderId())
                .build();


        return resultDto;
    }
}
