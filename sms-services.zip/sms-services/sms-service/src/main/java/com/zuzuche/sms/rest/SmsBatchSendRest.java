package com.zuzuche.sms.rest;

import com.zuzuche.commons.base.resp.RespResult;
import com.zuzuche.commons.mybatis.PageData;
import com.zuzuche.sms.entity.SmsBatchTask;
import com.zuzuche.sms.job.SmsBatchImportFileJob;
import com.zuzuche.sms.job.SmsBatchTaskJob;
import com.zuzuche.sms.rest.request.BatchNormalSmsReq;
import com.zuzuche.sms.rest.request.BatchSendReq;
import com.zuzuche.sms.rest.request.BatchTaskReq;
import com.zuzuche.sms.rest.request.BatchTaskStatusReq;
import com.zuzuche.sms.rest.response.BatchTaskRsp;
import com.zuzuche.sms.service.BatchTaskContainerService;
import com.zuzuche.sms.service.SmsBatchTaskService;
import com.zuzuche.sms.service.StatusReportService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


/**
 * @desc: 批量发送rest
 * @author: bingyi
 * @date: 2019-11-06
 */
@RestController
@RequestMapping("/batchSend")
@Slf4j
@Api(value = "batchSend", description = "大批量文件导入", tags = {"batchSend"})
public class SmsBatchSendRest {
    @Autowired
    SmsBatchTaskService smsBatchTaskService;

    @Autowired
    BatchTaskContainerService batchTaskContainerService;

    @Autowired
    SmsBatchImportFileJob fileJob;

    @Autowired
    SmsBatchTaskJob smsBatchTaskJob;

    @Autowired
    StatusReportService statusReportService;

    /**
     * 创建任务
     *
     * @param batchSendReq
     * @return
     */
    @PostMapping(value = "/createTask")
    public RespResult createSendTask(BatchSendReq batchSendReq) {
        SmsBatchTask smsBatchTask = smsBatchTaskService.createBatchTask(batchSendReq);
        return RespResult.success(smsBatchTask);
    }

    @PostMapping(value = "/createBatchSms")
    public RespResult createBatchNormalSms(BatchNormalSmsReq req){
      return null;
    }

    @GetMapping(value = "/remove/{taskId}/{status}")
    public RespResult removeSendTask(@PathVariable(value = "taskId") String taskId,@PathVariable(value = "status") int status) {
        SmsBatchTask smsBatchTask=SmsBatchTask.builder()
                .id(Integer.parseInt(taskId))
                .status(status)
                .build();
        if (batchTaskContainerService.remove(smsBatchTask)) {
            return RespResult.success();
        } else {
            return RespResult.error("任务不存在|任务更新失败");
        }
    }

    /**
     * 更新任务状态
     * @param batchTaskStatusReq
     * @return
     */
    @PostMapping("/updateStatus")
    public RespResult updateStatus(BatchTaskStatusReq batchTaskStatusReq){
        SmsBatchTask smsBatchTask=SmsBatchTask.builder()
                .id(batchTaskStatusReq.getId())
                .status(batchTaskStatusReq.getStatus())
                .build();
           if(batchTaskContainerService.updateStatus(smsBatchTask)){
               return RespResult.success();
           }else{
               return RespResult.error("更新失败");
           }
    }

    @ApiOperation(value = "任务定时器手动触发")
    @PostMapping("/taskExecute")
    public RespResult tastExecute(){
        smsBatchTaskJob.execute();
        return null;
    }

    @ApiOperation(value = "导入数据定时器手动触发")
    @PostMapping("/importExecute")
    public RespResult importExecute(){
        fileJob.execute();
        return null;
    }

    @ApiOperation(value = "批量查询任务")
    @PostMapping("/searchBatchTask")
    public RespResult<PageData<BatchTaskRsp>> searchBatchTask(BatchTaskReq batchTaskReq){
        PageData<BatchTaskRsp> pageData=smsBatchTaskService.searchBatchTask(batchTaskReq);
        return RespResult.success(pageData);
    }

    @ApiOperation(value = "批量短信状态报告测试")
    @PostMapping(value = "/smsBatchReportExecute")
    public RespResult smsBatchReport(){
        statusReportService.updateSmsBatchReport();
        return RespResult.success();
    }

    @PostMapping(value = "testRemote")
    public RespResult testRemote(SmsBatchTask smsBatchTask){
        batchTaskContainerService.remote(smsBatchTask);
        return RespResult.success();
    }
}
