package com.zuzuche.sms.common.enums;

import com.zuzuche.commons.base.constants.BaseEnum;

/**
 * 短信国内/国际类型.
 */
public enum SmsRegionType implements BaseEnum<Integer> {
    /**
     * 国内.
     */
    国内(1),
    /**
     * 国际.
     */
    国际(2);
    private Integer code;

    SmsRegionType(Integer code) {
        this.code = code;
    }

    @Override
    public Integer code() {
        return code;
    }

}
