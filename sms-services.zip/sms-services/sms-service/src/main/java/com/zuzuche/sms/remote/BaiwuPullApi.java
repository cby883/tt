package com.zuzuche.sms.remote;

/**
 * @desc:
 * @author: panqiong
 * @date: 2018/11/5
 */

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.zuzuche.sms.common.utils.XmlParserUtil;
import com.zuzuche.sms.remote.dto.PostDeliverMsgDto;
import com.zuzuche.sms.remote.dto.PostReportDto;
import com.zuzuche.sms.remote.dto.SmsCountDto;
import com.zuzuche.sms.remote.param.PostDeliverMsgParam;
import com.zuzuche.sms.remote.param.PostReportParam;
import com.zuzuche.sms.remote.param.SmsCountParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;

import java.nio.charset.Charset;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

/**
 * @desc: 百唔的拉取api
 * @author: panqiong
 * @date: 2018/11/5
 */
@Component
@Slf4j
public class BaiwuPullApi extends AbstractHttpInvoke {

    @Value("${provider.baiwu.pullurl}")
    private String pullurl ;

    /**
     * 状态报告接口响应编码
     */
    private static Map<String,String> errorCodeMap = new HashMap();



    public BaiwuPullApi(){
        errorCodeMap.put("0","暂时没有待推送的数据");
        errorCodeMap.put("9","访问地址不存在");
        errorCodeMap.put("-11","账户关闭");
        errorCodeMap.put("-16","用户名错误或用户名不存在");
        errorCodeMap.put("-17","密码错误");
        errorCodeMap.put("-18","不支持客户主动获取");
        errorCodeMap.put("-19","用户访问超过我方限制频率（间隔200毫秒访问一次)");
        errorCodeMap.put("106","接口文档未定义这个编码");
        errorCodeMap.put("108","指定访问IP错误");
    }



    /**
     * 额外的header设置 比如编码
     *
     * @param header
     */
    @Override
    protected void setHeader(HttpHeaders header) {
        header.setAcceptCharset(Arrays.asList(Charset.forName("GBK")));
    }


    /**
     * 4.3余额返回参数说明
     * 1）正常返回状态：ok#余额
     * 2）错误返回状态：
     * 参数	说明	备注
     * 101	账号关闭
     * 104	两次访问间隔小于200ms
     * 106	用户名不存在
     * 107	密码错误
     * 108	指定访问的IP错误	接口支持绑定单IP，多IP，IP号段及无IP
     * 9	访问地址不存在
     * @param countParam
     * @return
     */
    @HystrixCommand(groupKey = "baiwuApiGroup", commandKey="smsCount")
    public SmsCountDto smsCount(SmsCountParam countParam){
        String api = "/sms_count2.do";
        String url = pullurl+api;
        String result ;
        try {
            result = super.postForm(url,countParam);
        } catch (Exception e) {
            log.error("[拉取百唔短信数量-smsCount]接口调用异常 ",e.getMessage(),e);
            return new SmsCountDto("-98","接口调用异常");
        }

        String splitter = "#";
        String code ;
        String count ;
        if(result.contains(splitter)){
            code = result.split(splitter)[0];
            count = result.split(splitter)[1];
        }else{
            code = result;
            count = "";
        }
        SmsCountDto dto = SmsCountDto.builder()
                .code(code)
                .count(count)
                .build();
        return dto;

    }

    /**
     * 拉取状态报告
     * 6.3返回参数说明
     * 返回代码	代码说明
     * 0	暂时没有待推送的数据
     * 9	访问地址不存在
     * -11	账户关闭
     * -16	用户名错误或用户名不存在
     * -17	密码错误
     * -18	不支持客户主动获取
     * -19	用户访问超过我方限制频率（间隔200毫秒访问一次）
     * 108	指定访问IP错误
     * Xml格式字符串	有待推送的状态报告，并且状态报告以xml格式的字符串返回。
     * @param param
     * @return
     */
    @HystrixCommand(groupKey = "baiwuApiGroup", commandKey="postReport")
    public PostReportDto postReport(PostReportParam param){
        String api = "/post_report.do";
        String url = pullurl+api;
        String result;
        // 接口异常
        try {
            result = super.postForm(url,param);
        }catch (Exception e) {
            log.error("[拉取百唔状态报告-postReport]接口调用异常 ",e.getMessage(),e);
            return new PostReportDto("-98","接口调用异常");
        }

        // 业务异常
        if(errorCodeMap.containsKey(result)){
            return new PostReportDto(result, errorCodeMap.get(result));
        }

        // 调用xml解析
        try {
            PostReportDto dto =XmlParserUtil.parseReport(result);
            return dto;
        } catch (Exception e) {
            log.error("[拉取百唔状态报告]解析返回的响应xml报错 接口相应内容result:"+result);
            return new PostReportDto("-99","post_report接口返回xml解析异常");
        }
    }


    /**
     * 拉取上行短信
     * 8.3返回参数说明
     * 返回代码	代码说明
     * 0	暂时没有待推送的数据
     * 9	访问地址不存在
     * -11	账户关闭
     * -16	用户名错误或用户名不存在
     * -17	密码错误
     * -18	不支持客户主动获取
     * -19	用户访问超过我方限制频率 （间隔200毫秒访问一次）
     * 108	指定访问IP错误
     * Xml格式字符串	有待推送的上行信息，并且上行信息以xml格式的字符串返回。一条上行xml字符串可包含10个< deliver ></ deliver>节点
     * @param param
     * @return
     */
    @HystrixCommand(groupKey = "baiwuApiGroup", commandKey="postDeliverMsg")
    public PostDeliverMsgDto postDeliverMsg(PostDeliverMsgParam param){
        String api = "/post_deliverMsg.do";
        String url = pullurl+api;
        String result;
        // 接口异常
        try {
            result = super.postForm(url,param);
        } catch (Exception e) {
            log.error("[BaiwuPullApi-postDeliverMsg]接口调用异常 ",e.getMessage(),e);
            return new PostDeliverMsgDto("-98","接口调用异常");
        }

        // 业务异常
        if(errorCodeMap.containsKey(result)){
            return new PostDeliverMsgDto(result, errorCodeMap.get(result));
        }
        // xml结果解析
        try {
            PostDeliverMsgDto dto =XmlParserUtil.parseInbound(result);
            return dto;
        } catch (Exception e) {
            log.error("[拉取上行短信]解析返回的响应xml报错 接口响应内容 result:"+result);
            return new PostDeliverMsgDto("-99","xml解析异常");
        }
    }







    public void test(){
        try{
            String api = "http://www.baidu.com:8080";
            Map map = new HashMap<>();
            map.put("hello","world");
            String result = super.postForm(api,map);

        }catch (Exception e){
            log.error("[百唔拉取模拟测试接口出错]:", e.getMessage(), e);
        }

    }


    public static void main(String[] args) {
        boolean result = errorCodeMap.containsKey(null);

        log.info("result = " + result);
    }

}
