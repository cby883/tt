package com.zuzuche.sms.listener.inner;

import com.google.common.util.concurrent.RateLimiter;
import com.zuzuche.logback.util.MDCUtil;
import com.zuzuche.sms.cache.SmsConfigCache;
import com.zuzuche.sms.dto.MtDto;
import com.zuzuche.sms.dto.OrderSmsLogDto;
import com.zuzuche.sms.remote.OrderSmsRemote;
import com.zuzuche.sms.remote.RemarkRemote;
import com.zuzuche.sms.remote.param.AddOrderSmsLogParam;
import com.zuzuche.sms.remote.param.SendRemarkParam;
import com.zuzuche.sms.service.KafkaService;
import com.zuzuche.sms.service.SmsMtService;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * 功能：主站旧的短信日志记录消费监听器.
 * 详细：
 *
 * @author Created on 2019-03-26 by chaodian
 */
@Component
@Slf4j
public class OrderSmsLogListener implements InitializingBean {
    private static final String RATE_KEY = "order_sms_log_topic_rate";

    private static RateLimiter rateLimiter;

    @Autowired
    KafkaService kafkaService;

    @Autowired
    SmsConfigCache configCache;

    @Autowired
    SmsMtService smsMtService;

    @Autowired
    OrderSmsRemote remote;

    @KafkaListener(topics = KafkaService.ORDER_SMS_LOG_TOPIC)
    public void consume(ConsumerRecord<String, OrderSmsLogDto> consumer) {
        MDCUtil.set();
        if(log.isDebugEnabled()){
            log.debug("[receive order_sms_log_topic]:" +consumer.value());
        }

        rateLimiter.acquire();
        try {
            OrderSmsLogDto orderSmsLogDto = consumer.value();
            AddOrderSmsLogParam param = AddOrderSmsLogParam.builder()
                    .mobile(orderSmsLogDto.getMobile())
                    .content(orderSmsLogDto.getContent())
                    .uniqueId(orderSmsLogDto.getUniqueId())
                    .admin(orderSmsLogDto.getAdmin())
                    .build();
            remote.addOrderSmsLog(param);
        } catch (Exception e){
            // 发送到dlq队列 并预警人工接入
            log.error("[主站短信日志消息处理出现异常-order_sms_log_topic_topic]message:"+consumer.value(),e.getMessage(),e);
        } finally {
            MDCUtil.clear();
        }
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        if(configCache.containsKey(RATE_KEY)){
            int rate = Integer.parseInt(configCache.get(RATE_KEY));
            rateLimiter = RateLimiter.create(rate);
        }else{
            // 默认速度
            rateLimiter = RateLimiter.create(5);
        }
    }


}
