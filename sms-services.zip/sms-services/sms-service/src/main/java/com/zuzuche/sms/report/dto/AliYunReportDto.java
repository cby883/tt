package com.zuzuche.sms.report.dto;

import com.alibaba.fastjson.annotation.JSONField;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * desc:状态报告dto
 *
 * @author bingyi
 * @date 20108/19
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AliYunReportDto {
    /**
     * 短信接收号码
     */
    @JSONField(name = "phone_number")
    private String phoneNumber;
    /**
     * 发送是否成功
     */
    private boolean success;
    /**
     * 发送回执ID
     */
    @JSONField(name = "biz_id")
    private String bizId;
    /**
     * 调用发送短信接口时传的outId,默认为发送短信的taskId
     */
    @JSONField(name = "out_id")
    private String outId;
    /**
     * 转发给运营商的时间
     */
    @JSONField(name = "send_time")
    private String sendTime;
    /**
     * 收到运营商回执的时间
     */
    @JSONField(name = "report_time")
    private String reportTime;
    /**
     * 错误码
     */
    @JSONField(name = "err_code")
    private String errCode;
    /**
     * 错误信息
     */
    @JSONField(name = "err_msg")
    private String errMsg;
    /**
     * 140字节算一条短信，短信长度超过140字节时会拆分成多条短信发送
     */
    @JSONField(name = "sms_size")
    private String smsSize;
}
