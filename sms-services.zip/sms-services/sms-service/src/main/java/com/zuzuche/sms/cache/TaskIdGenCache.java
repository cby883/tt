package com.zuzuche.sms.cache;

import com.zuzuche.commons.base.resp.Status;
import com.zuzuche.commons.base.resp.StatusServiceCnException;
import com.zuzuche.commons.redis.RedisLock;
import com.zuzuche.sms.mapper.SmsOutboundMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;

/**
 * @desc: 全局唯一任务id生成
 * @author: panqiong
 * @date: 2018/10/25
 */
@Component
@Slf4j
public class TaskIdGenCache {
    /**
     * 暂时考虑这样生成taskId 因为要兼容上游系统的纯数字10位序列
     * 任务id生成 采用redis increby
     */
    public final static String TASK_ID_INCREMENT_KEY="SMS:TASK_ID_INCREMENT";

    @Autowired
    StringRedisTemplate redisTemplate;

    @Autowired
    SmsOutboundMapper smsOutboundMapper;


    /**
     * 获取taskId
     * @return
     */
    public Long increGet(){
        Long id = redisTemplate.opsForValue().increment(TASK_ID_INCREMENT_KEY,1);
        // redis内存序列丢失,taskId是从2亿起步 不可能小于1000w的,如果小于1000w,意味着内存id丢失了 ,需要重新从数据库同步
        int errNum=10000000;
        if(id<errNum){
            RedisLock lock = new RedisLock(redisTemplate,TASK_ID_INCREMENT_KEY);
            // 拿到锁
            if(lock.lock()){
                try{
                    // double check 二次检查
                    if(id<errNum){
                        long taskId = smsOutboundMapper.queryMaxTaskId();
                        redisTemplate.opsForValue().set(TASK_ID_INCREMENT_KEY,String.valueOf(taskId));
                    }
                    // +1
                    id = redisTemplate.opsForValue().increment(TASK_ID_INCREMENT_KEY,1);
                }finally {
                    lock.unlock();
                }
            }else{
                throw new StatusServiceCnException(Status.BUSY,"生成新的taskId时 , 获取锁超时");
            }

        }
        return id;
    }

    /**
     * 获取taskId
     * @return
     */
    public String increGetStr(){
        long id = increGet();
        return String.valueOf(id);
    }

}
