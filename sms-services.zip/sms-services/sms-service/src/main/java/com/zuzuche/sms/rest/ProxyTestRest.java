package com.zuzuche.sms.rest;

import com.zuzuche.commons.base.resp.RespResult;
import com.zuzuche.commons.base.util.OkHttpUtil;
import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;
import okhttp3.*;
import okhttp3.RequestBody;
import org.springframework.web.bind.annotation.*;

/**
 * @desc: 代理测试类
 * @author: bingyi
 * @date: 2019/09/04
 */
@RestController
@RequestMapping("/proxy")
@Slf4j
@Api(value = "proxy", description = "代理测试类", tags = {"proxy"})
public class ProxyTestRest {

    @PostMapping(value = "/test")
    public RespResult test(@RequestParam(value = "url") String url) throws Exception {
        Response re=OkHttpUtil.get(url);
        System.out.println();
        return RespResult.success(re.body().string());
    }


}
