package com.zuzuche.sms.mapper;

import com.zuzuche.commons.mybatis.BaseMapper;
import com.zuzuche.sms.entity.SmsReportErrorDesc;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * desc:
 *
 * @author bingyi
 * @date 2019/11/27
 */
@Repository
public interface SmsReportErrorDescMapper extends BaseMapper<SmsReportErrorDesc> {
    /**
     * desc:
     * @param errorCode
     * @param providerId
     * @return
     */
    @Select(value = "select * from sms_base.sms_report_error_desc where error_code=#{errorCode} and provider_id=#{providerId}")
    public SmsReportErrorDesc selectByCode(@Param("errorCode") String errorCode, @Param("providerId") int providerId);
}