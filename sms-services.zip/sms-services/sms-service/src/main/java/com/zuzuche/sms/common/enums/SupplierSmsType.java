package com.zuzuche.sms.common.enums;

import com.zuzuche.commons.base.constants.BaseEnum;
import lombok.Getter;

/**
 * 供应商的短信类型性质.
 */
@Getter
public enum SupplierSmsType implements BaseEnum<Integer> {
    /**
     * 行业通知 supplier sms type.
     */
    行业通知(1),
    /**
     * 营销 sms type.
     */
    营销通知(2);

    /**
     * 短信类型值
     */
    private Integer code;

    SupplierSmsType(Integer code) {
        this.code = code;
    }

    @Override
    public Integer code() {
        return code;
    }
}