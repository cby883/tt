package com.zuzuche.sms.mapper;

import com.zuzuche.sms.entity.SignLanguageType;
import org.springframework.stereotype.Repository;
import tk.mybatis.mapper.common.BaseMapper;

/**
 * SignLanguageTypeMapper
 *
 * @blame Android Team
 */
@Repository
public interface SignLanguageTypeMapper extends BaseMapper<SignLanguageType> {

}