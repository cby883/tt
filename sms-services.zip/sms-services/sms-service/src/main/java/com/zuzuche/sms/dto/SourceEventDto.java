package com.zuzuche.sms.dto;

import com.zuzuche.kafka.message.BaseMessage;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 *
 * 告警]==>[短信成功量监控]：最近3个时间窗口内,有1个窗口success指标触发告警,阈值:100,实际值:21  [发生时间:20180831182000]
 * 2018-08-31 18:23:05.494 [org.springframework.kafka.KafkaListenerEndpointContainer#1-0-C-1] ERROR com.zuzuche.sentry.service.AlarmCheckService -
 * [告警]==>[短信成功率监控]：最近3个时间窗口内,success指标触发告警,阈值:0.90,实际值:0.43  [发生时间:20180831182000]
 * 2018-08-31 18:23:05.510 [org.springframework.kafka.KafkaListenerEndpointContainer#1-0-C-1] ERROR com.zuzuche.sentry.service.AlarmCheckService - [告警]==>[短信成功量平均值监控]：最近5个时间窗口内,success指标触发告警,阈值:100,实际值:57.0  [发生时间:20180831182200]
 * 开始时间: 2018-08-31 18:21:00
 * metricGroupId=102, metricCountMap={failure=55, success=58}, metricPercentMap={failure=0.49, success=0.51}, sumCount=113)
 * @desc: 源事件
 * @author: panqiong
 * @date: 2018/8/10
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SourceEventDto extends BaseMessage {

    private String groupId;
    /**
     * 统计指标 如:成功/失败/无状态
     */
    private String metric;

    /**
     * 事件发生事件 毫秒
     */
    private long time;

    /**
     * 事件数量 默认1 也可以设值 因为原始数据可能是批量的
     */
    private int value;



}
