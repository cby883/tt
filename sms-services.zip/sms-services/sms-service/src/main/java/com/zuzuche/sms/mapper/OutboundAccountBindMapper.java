package com.zuzuche.sms.mapper;

import com.zuzuche.commons.mybatis.BaseMapper;
import com.zuzuche.sms.entity.OutboundAccountBind;
import org.springframework.stereotype.Repository;

/**
 * @desc ~
 * @author panqiong
 * @date 20181019
 */
@Repository
public interface OutboundAccountBindMapper extends BaseMapper<OutboundAccountBind> {

}