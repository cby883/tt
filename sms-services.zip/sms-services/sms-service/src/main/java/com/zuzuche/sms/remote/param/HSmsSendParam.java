package com.zuzuche.sms.remote.param;

import com.alibaba.fastjson.annotation.JSONField;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @desc: 百唔个性化短信
 * @author: panqiong
 * @date: 2018/11/5
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class HSmsSendParam {


    /**
     * 必填参数，访问接口账户id
     */
    @JSONField(name="corp_id")
    private String corpId;

    /**
     * 访问接口账户密码
     */
    @JSONField(name="corp_pwd")
    private String corpPwd;

    /**
     * 业务代码
     */
    @JSONField(name="corp_service")
    private String corpService;

    /**
     * 本次发送总条
     * 用来与接口拼凑完成后的实际条数进行校验。不大于200
     */
    @JSONField(name="total_count")
    private String totalCount;

    /**
     * 发送的实际内容
     * 1、每条个性化短信内容不能超过1000（包括1000字）字并且不能为空
     * 2、主叫扩展号码只支持数字。主叫扩展号码+主叫号码<20位
     * 单次不超过200条短信
     */
    @JSONField(name="send_param")
    private String sendParam;

    /**
     * 控制个性化提交的模式
     */
    @JSONField(name="ctrl_param")
    private String ctrlParam;

    @Override
    public String toString() {
        return "HSmsSendParam{" +
                "corpId='" + corpId + '\'' +
                ", corpService='" + corpService + '\'' +
                ", totalCount='" + totalCount + '\'' +
                ", sendParam='" + sendParam + '\'' +
                ", ctrlParam='" + ctrlParam + '\'' +
                '}';
    }
}
