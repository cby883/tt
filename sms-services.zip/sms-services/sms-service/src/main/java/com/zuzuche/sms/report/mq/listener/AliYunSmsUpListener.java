package com.zuzuche.sms.report.mq.listener;

import com.alicom.mns.tools.MessageListener;
import com.aliyun.mns.model.Message;
import com.zuzuche.commons.base.util.JsonUtil;
import com.zuzuche.sms.entity.SmsInbound;
import com.zuzuche.sms.report.dto.AliYunSmsUpDto;
import com.zuzuche.sms.report.mq.AbstractListener;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * desc:阿里云上行短信的监听类
 *
 * @author bingyi
 * @date 2019/08/20
 */
@Slf4j
@Component
@Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class AliYunSmsUpListener extends AbstractListener implements MessageListener {
    private int accountId=0;
    public AliYunSmsUpListener(int accountId){
        this.accountId=accountId;
    }
    @Override
    public boolean dealMessage(Message message) {
        String result;
        List<SmsInbound> list=new ArrayList<>();
        try {

            result=message.getMessageBodyAsString();
            AliYunSmsUpDto aliYunSmsUpDto= JsonUtil.stringToObj(result, AliYunSmsUpDto.class);
            //拿不到accountId,设为0
            SmsInbound smsInbound=SmsInbound.builder()
                    .accountId(accountId)
                    .msg(aliYunSmsUpDto.getContent())
                    .phone(aliYunSmsUpDto.getPhoneNumber())
                    .port(aliYunSmsUpDto.getDestCode())
                    .createTime(LocalDateTime.now())
                    .build();
            list.add(smsInbound);
            //执行收尾工作
            super.mqInboundSms(list);
        }catch (com.google.gson.JsonSyntaxException e){
            log.error("error_json_format:"+message.getMessageBodyAsString(),e);
            //理论上不会出现格式错误的情况，所以遇见格式错误的消息，只能先delete,否则重新推送也会一直报错
            return true;
        }catch (Throwable e){
            log.error("【AliYunSmsUpListener】监听器错误",e.getMessage(),e);
            //您自己的代码部分导致的异常，应该return false,这样消息不会被delete掉，而会根据策略进行重推
            return false;
        }
        return true;
    }
}
