package com.zuzuche.sms.mapper;

import com.zuzuche.commons.mybatis.BaseMapper;
import com.zuzuche.sms.entity.SmsSign;

/**
 * The interface Sms sign mapper.
 */
public interface SmsSignMapper extends BaseMapper<SmsSign> {
}