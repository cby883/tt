package com.zuzuche.sms.executors;

import com.zuzuche.sms.common.utils.SpringBeanFactory;
import com.zuzuche.sms.dto.SmsDto;
import com.zuzuche.sms.task.AbstractSendTask;
import com.zuzuche.sms.task.CmSendTask;
import com.zuzuche.sms.task.HengxinSendTask;
import com.zuzuche.threadpool.ThreadPoolExecutorFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * 功能：CM供应商的工作线程池.
 * 详细：
 *
 * @author Created on 2019.09.08 by chaodian
 */
@Component
@Slf4j
public class CmExecutor extends AbstractOutboundExecutor {

    /**
     * Instantiates a new Cm executor.
     */
    public CmExecutor(){
        super(
                ThreadPoolExecutorFactory.Config.builder()
                        .corePoolSize(20)
                        .maximumPoolSize(25)
                        .keepAliveTime(2)
                        .workQueue(new ArrayBlockingQueue<>(100))
                        .unit(TimeUnit.MINUTES)
                        .handler(new ThreadPoolExecutor.CallerRunsPolicy())
                        .threadPoolName("CmExecutor")
                        .build()
        );
    }

    @Override
    public AbstractSendTask packingSendTask(SmsDto sms) {
        // 获取一个实例化的原型任务对象
        CmSendTask cmSendTask = SpringBeanFactory.getBean(CmSendTask.class, sms);

        return cmSendTask;
    }
}
