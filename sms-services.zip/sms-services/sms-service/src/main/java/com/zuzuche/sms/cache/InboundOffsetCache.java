package com.zuzuche.sms.cache;

import com.zuzuche.commons.redis.CacheExecutor;
import com.zuzuche.commons.redis.CacheExpires;
import com.zuzuche.sms.entity.SmsConfig;
import com.zuzuche.sms.mapper.SmsConfigMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;
import java.time.LocalDateTime;

/**
 * @desc: 上行短信拉取offset偏移量
 * @author: panqiong
 * @date: 2018/10/24
 */
@Slf4j
@Component
public class InboundOffsetCache {

    /**
     * key 不能随意修改 因为数据库中也存的是一样的key
     * 若修改 需要在数据库中同步修改 , table: retrieve_Offset
     */
    public final static String RETRIVE_INBOUND_OFFSET_KEY="SMS:RETRIVE_INBOUND_SMS_OFFSET";

    @Autowired
    SmsConfigMapper smsConfigMapper;

    @Autowired
    StringRedisTemplate redisTemplate;

    CacheExecutor<String> userCacheExcutor = CacheExecutor.create(RETRIVE_INBOUND_OFFSET_KEY, String.class, CacheExpires.PERMANENT);
    /**
     * 从缓存获取
     * 弱没有则穿透db查询
     * @return
     */
    public String get(){
        String value = userCacheExcutor.get(RETRIVE_INBOUND_OFFSET_KEY,(key)->{
            SmsConfig offset = smsConfigMapper.queryOffset((String)key);
            if(offset!=null){
                return offset.getConfigValue();
            }
            return null;
        });
        return value;
    }

    /**
     * 更新缓存和db
     * @param value
     */
    public void set(String value){
        redisTemplate.opsForValue().set(RETRIVE_INBOUND_OFFSET_KEY,value);
        smsConfigMapper.updateOffset(RETRIVE_INBOUND_OFFSET_KEY,value,LocalDateTime.now());

    }
}
