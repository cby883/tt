package com.zuzuche.sms.dto;

import com.zuzuche.kafka.message.BaseMessage;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 功能：刷新配置dto
 * 详细：
 *
 * @author bingyi
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class RefreshConfigDto extends BaseMessage {
    /**
     * 配置名称
     */
    String configName;
    /**
     * 状态码 0 表示成功
     */
    int code;
    /**
     * 调用信息
     */
    String message;
    /**
     * 实例名称
     */
    String instanceHostAddress;
}
