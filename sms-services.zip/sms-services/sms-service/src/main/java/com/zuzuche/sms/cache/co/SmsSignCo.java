package com.zuzuche.sms.cache.co;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 功能：短信签名配置缓存信息.
 * 详细：
 *
 * @author Created on 2019.03.01 by chaodian
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SmsSignCo {
    /**
     * 短信签名值，如1表示【租租车】
     */
    private int signCode;

    /**
     * 短信签名，如【租租车】
     */
    private String name;

    /**
     * 短信签名对应的格式，如【租租车】,[租租车]，多个以英文逗号分割
     */
    private String allFormatNames;
}
