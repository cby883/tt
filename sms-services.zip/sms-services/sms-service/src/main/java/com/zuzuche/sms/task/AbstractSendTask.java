package com.zuzuche.sms.task;

import com.netflix.hystrix.exception.HystrixRuntimeException;
import com.zuzuche.commons.base.resp.StatusServiceCnException;
import com.zuzuche.commons.base.util.StringUtil;
import com.zuzuche.sms.cache.ProviderAccountCache;
import com.zuzuche.sms.common.constant.ErrorMessage;
import com.zuzuche.sms.common.constant.ErrorStatusEnum;
import com.zuzuche.sms.common.utils.PerformUtil;
import com.zuzuche.sms.dto.InvokeResultDto;
import com.zuzuche.sms.dto.SmsDto;
import com.zuzuche.sms.entity.ProviderAccountInfo;
import com.zuzuche.sms.filter.Filter;
import com.zuzuche.sms.filter.FilterManager;
import com.zuzuche.sms.remote.MockApi;
import com.zuzuche.sms.remote.dto.MockSendDto;
import com.zuzuche.sms.remote.dto.ShortMessageDto;
import com.zuzuche.sms.remote.param.MockSendParam;
import com.zuzuche.sms.service.KafkaService;
import com.zuzuche.sms.service.RetryingSmsService;
import com.zuzuche.sms.service.SendResultService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.ResourceAccessException;

import java.time.Instant;
import java.util.List;

/**
 * @desc: 抽象的发送任务 定义了发送任务的模板操作逻辑
 * @author: panqiong
 * @date: 2018/10/26
 */
@Slf4j
public abstract class AbstractSendTask implements Runnable{

    @Autowired
    KafkaService kafkaService;

    @Autowired
    FilterManager filterManager;

    @Autowired
    SendResultService sendResultService;

    @Autowired
    MockApi mockRemote;

    SmsDto sms;

    @Value("${retrying.listener.open}")
    private boolean retryingOpen;

    AbstractSendTask(SmsDto sms){
        this.sms = sms;
    }

    /**
     * 发送任务
     * 1.执行过滤器链
     * 2.调用供应商api
     * 3.收尾工作
     */
    @Override
    public void run() {

        try{
            // 1. filter链处理
            //boolean cntinue = beforeSend(sms);
            // 全部拦截
            if(!beforeSend(sms)){
                return;
            }
            // 2.调用供应商api
            InvokeResultDto resulDto ;
            // 如果是模拟短信 不调用接口
            //sms.setMock(true);
            if(sms.isMock()){
                resulDto = this.mockSend();
                // 如果当前重试次数小于等于模拟超时的最大重试次数，
                // 并且模拟超时参数必须大于0
                // 则表示需要模拟超时
                if (sms.getRetryNo() < sms.getMockTimeOutUntilRetryNo() && sms.getMockTimeOutUntilRetryNo() > 0) {
                    // 模拟抛出http 503异常
                    // throw new HttpServerErrorException(HttpStatus.GATEWAY_TIMEOUT);
                    String errorMsg = ErrorMessage.NETWORK_CONNECT_TIME_OUT_PHRASE;
                    resulDto = netWorkExceptionProcess(errorMsg);
                }
            }else{
                long start = Instant.now().toEpochMilli();
                // 模拟发送
                //resulDto = this.mockSendHttp(sms);
                resulDto = invokeApi(sms);
                long end = Instant.now().toEpochMilli();
                PerformUtil.logTime("invokeApi-"+sms.getAccountId(),start,end);
            }
            // 3.收尾工作
            afterSend(resulDto);
        }catch (ResourceAccessException e) {
            StringBuilder sb = new StringBuilder("[发送流程-供应商接口resource异常]").append(this.getSmsSimpleDebugInfo());
            log.error(sb.toString(), e.getMessage(), e);

            String errorMsg  = e.getMessage();
            // 连接异常处理 connect timeout异常 将进入重发队列
            InvokeResultDto dto = netWorkExceptionProcess(errorMsg);

            afterSend( dto);

        }catch (HttpServerErrorException e) {
            // http分类异常
            HttpStatus httpStatus = e.getStatusCode();
            StringBuilder sb = new StringBuilder("[发送流程-http状态码异常]")
                    .append("["+httpStatus.name()).append(":").append(httpStatus.getReasonPhrase()).append("]")
                    .append(this.getSmsSimpleDebugInfo());
            log.error(sb.toString(), e.getMessage(), e);
            // 熔断器异常处理 熔断器打开的异常信息 将进入重发队列
            InvokeResultDto dto = httpExceptionProcess(httpStatus);

            afterSend( dto);

        }catch (HystrixRuntimeException e) {
            // hystrix异常分类
            HystrixRuntimeException.FailureType failureType = e.getFailureType();

            StringBuilder sb = new StringBuilder("[发送流程-hystrix分类异常]")
                    .append("["+failureType.name()+"]")
                    .append(this.getSmsSimpleDebugInfo());
            log.error(sb.toString(), e.getMessage(), e);
            // 熔断器异常处理 熔断器打开的异常信息 将进入重发队列
            InvokeResultDto dto = hystrixExceptionProcess(failureType);

            afterSend( dto);

        }  catch (Exception e) {
            StringBuilder sb = new StringBuilder("[发送流程-未知异常]").append(this.getSmsSimpleDebugInfo());
            log.error(sb.toString(), e.getMessage(), e);

            InvokeResultDto dto = InvokeResultDto.builder()
                    .bachNo("")
                    .extra(ErrorStatusEnum.UNKOWN_EXCEPTION.name())
                    .respCode(ErrorStatusEnum.UNKOWN_EXCEPTION.code())
                    .taskId(sms.getTaskId())
                    .timestamp(Instant.now().toEpochMilli())
                    .build();
            afterSend( dto);
        }
    }

    /**
     * http异常处理
     * @param httpStatus
     * @return
     */
    private InvokeResultDto httpExceptionProcess(HttpStatus httpStatus) {
        InvokeResultDto dto ;
        // 50x异常 这部分会重发，排除504
        if(httpStatus.is5xxServerError() && !httpStatus.equals(HttpStatus.GATEWAY_TIMEOUT)){
            dto = InvokeResultDto.builder()
                    .bachNo("")
                    .extra(ErrorStatusEnum.HTTP_50X.name())
                    .respCode(ErrorStatusEnum.HTTP_50X.code())
                    .taskId(sms.getTaskId())
                    .mobiles(sms.getMobile())
                    .timestamp(Instant.now().toEpochMilli())
                    .build();
            return dto;
        }else{
            // 其他 这部分暂时不会 配置重发
            dto = InvokeResultDto.builder()
                    .bachNo("")
                    .extra(ErrorStatusEnum.HTTP_ERROR.name())
                    .respCode(ErrorStatusEnum.HTTP_ERROR.code())
                    .taskId(sms.getTaskId())
                    .mobiles(sms.getMobile())
                    .timestamp(Instant.now().toEpochMilli())
                    .build();
            return dto;
        }

    }


    /**
     * hystrix相关的异常
     * 熔断器异常处理
     * @param failureType
     */
    private InvokeResultDto hystrixExceptionProcess(HystrixRuntimeException.FailureType failureType) {
        InvokeResultDto dto ;
        switch (failureType){
            case SHORTCIRCUIT:
                dto = InvokeResultDto.builder()
                        .bachNo("")
                        .extra(ErrorStatusEnum.HYSTRIX_SHORT_CIRCUITED.name())
                        .respCode(ErrorStatusEnum.HYSTRIX_SHORT_CIRCUITED.code())
                        .taskId(sms.getTaskId())
                        .mobiles(sms.getMobile())
                        .timestamp(Instant.now().toEpochMilli())
                        .build();
                return dto;
            default:
                dto = InvokeResultDto.builder()
                        .bachNo("")
                        .extra(ErrorStatusEnum.HYSTRIX_EXCEPTION.name())
                        .respCode(ErrorStatusEnum.HYSTRIX_EXCEPTION.code())
                        .taskId(sms.getTaskId())
                        .mobiles(sms.getMobile())
                        .timestamp(Instant.now().toEpochMilli())
                        .build();
                return dto;

        }







    }

    /**
     * 网络异常处理
     * @param errorMsg
     */
    private InvokeResultDto netWorkExceptionProcess(String errorMsg) {
        if(StringUtil.isNotEmpty(errorMsg)&&
                errorMsg.contains(ErrorMessage.NETWORK_CONNECT_TIME_OUT_PHRASE)){
            InvokeResultDto dto = InvokeResultDto.builder()
                    .bachNo("")
                    .extra(ErrorStatusEnum.NETWORK_CONNETCT_TIME_OUT.name())
                    .respCode(ErrorStatusEnum.NETWORK_CONNETCT_TIME_OUT.code())
                    .taskId(sms.getTaskId())
                    .mobiles(sms.getMobile())
                    .timestamp(Instant.now().toEpochMilli())
                    .build();
            return dto;
        }else{
            // 不明确的超时异常
            InvokeResultDto dto = InvokeResultDto.builder()
                    .bachNo("")
                    .extra(ErrorStatusEnum.NETWORK_EXCEPTION.name())
                    .respCode(ErrorStatusEnum.NETWORK_EXCEPTION.code())
                    .taskId(sms.getTaskId())
                    .mobiles(sms.getMobile())
                    .timestamp(Instant.now().toEpochMilli())
                    .build();
            return dto;
        }
    }


    /**
     * 过滤器集合
     * @param sms
     */
    public boolean beforeSend(SmsDto sms){

        List<Filter> filters = filterManager.getFilters();
        if(CollectionUtils.isEmpty(filters)){
            return true;
        }
        for(Filter filter : filters){
            boolean isContinue = filter.doFilter(sms);
            if(!isContinue){
                return isContinue;
            }
        }
        return true;
    }

    /**
     * 调用供应商的接口
     * @param sms
     * @return
     */
    public abstract InvokeResultDto invokeApi(SmsDto sms) ;


    /**
     * 发送供应商后的收尾工作.
     *
     * 先判断是否需要重试，如果需要重试则进入重试队列，不需要重试则进行以下步骤:
     * 0.设置号码和md5(内容)到redis中,用作判重  同步处理
     * 1.上报监控系统kafka  同步处理
     * 2.更新库表发送状态  送进kafka后续处理
     * 3.回调上游服务  kafka通知 不再搞http回调
     */
    public void afterSend(InvokeResultDto dto){
        ProviderAccountInfo info=ProviderAccountCache.getAccountById(sms.getAccountId());
        if(info!=null){
            dto.setProviderId(info.getProviderId());
        }
        // 上报监控系统
        sendResultService.reportToSentry(dto);


        // 如果是连接超时异常以及熔断器打开的异常,进入重发流程
        // 同时满足这条短信的重试次数还未用完
        // 网络连接超时异常,熔断器其它异常,熔断器打开异常,http50x异常
        if (ErrorStatusEnum.NETWORK_CONNETCT_TIME_OUT.code().equals(dto.getRespCode())
                || ErrorStatusEnum.HYSTRIX_EXCEPTION.code().equals(dto.getRespCode())
                || ErrorStatusEnum.HYSTRIX_SHORT_CIRCUITED.code().equals(dto.getRespCode())
                || ErrorStatusEnum.HTTP_50X.code().equals(dto.getRespCode())) {

            //如果开关开了，才进行重试模块
            if (retryingOpen) {
                if (sms.getRetryNo() < RetryingSmsService.MAX_RETRY_NO) {
                    sms.setRespCode(dto.getRespCode());
                    sms.setBatchNo(dto.getBachNo());
                    kafkaService.sendToRetryingSmsTopic(sms);
                    return;
                }
            }
        }

        // 保存至redis 改成异步设置redis
        sendResultService.setRedisMark(dto);

        // 如果重试过，在异步回调更新Db时候，同时需要更新accountId
        if (sms.getRetryNo() > 0) {
            dto.setUpdatedAccountId(sms.getAccountId());
        }
        // 发送到kafka 供后续耗时处理
        kafkaService.sendToResultTopic(dto);
        // finishWorker.push(dto);
    }


    /**
     * 模拟发送
     * @return
     */
    protected InvokeResultDto mockSend() {
        ShortMessageDto smdto = ShortMessageDto.builder()
                .respcode("0")
                .logid("mock数据,不真实调用发送接口")
                .batchno("")
                .build();
        try {
            Thread.sleep(30);
        } catch (InterruptedException e) {
            log.error("[提交供应商模拟发送error]", e.getMessage(), e);
            Thread.currentThread().interrupt();
        }
        // 封装返回对象
        InvokeResultDto resultDto = InvokeResultDto.builder()
                .bachNo(smdto.getBatchno())
                .extra(smdto.getLogid())
                .respCode(smdto.getRespcode())
                .taskId(sms.getTaskId())
                .mobiles(sms.getMobile())
                .md5Content(sms.getMd5Content())
                .timestamp(Instant.now().toEpochMilli())
                .build();

        return resultDto;
    }

    /**
     * 模拟发送
     * @return
     */
    protected InvokeResultDto mockSendHttp(SmsDto sms) {
        MockSendParam param = MockSendParam.builder()
                .content(sms.getContent())
                .mobiles(sms.getMobile())
                .build();
        MockSendDto.Result smdto = mockRemote.mockSend(param);

        // 封装返回对象
        InvokeResultDto resultDto = InvokeResultDto.builder()
                .bachNo(smdto.getBatchno())
                .extra(smdto.getLogid())
                .respCode(smdto.getRespcode())
                .taskId(sms.getTaskId())
                .mobiles(sms.getMobile())
                .md5Content(sms.getMd5Content())
                .timestamp(Instant.now().toEpochMilli())
                .build();

        return resultDto;
    }


    /**
     * 短信基本信息 用于日志中调试检查
     * @return
     */
    private String getSmsSimpleDebugInfo(){
        StringBuilder sb = new StringBuilder();
        ProviderAccountInfo account = ProviderAccountCache.getAccountById(sms.getAccountId());
        sb.append("[accountId:").append(sms.getAccountId()).append("]")
                .append("[providerId:").append(account.getProviderId()).append("]")
                .append("[taskId:").append(sms.getTaskId()).append("]")
                .append("[mobile:").append(sms.getMobile()).append("]");
        return sb.toString();
    }
}
