package com.zuzuche.sms.remote.param;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 功能：卓越恒信短信供应商发送接口请求参数.
 * 详细：
 *
 * @author Created on 2019.06.27 by chaodian
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PostHxSmsParam {
    /**
     * 短信账户id, 普通和验证码为55，营销为63
     */
    private String account;

    /**
     * 手机号码，多个英文逗号(半角逗号)分割
     */
    private String mobile;

    /**
     * 具体的短信内容
     */
    private String content;

    /**
     * 短信账户密钥, 如55对应的为968lrBP5cBcLfjQgu1xszg==    63对应的为13OAOqWjm3KGBW90cFTvhQ==
     */
    private String secret;

    @Override
    public String toString() {
        return "PostHxSmsParam{" +
                "account='" + account + '\'' +
                ", mobile='" + mobile + '\'' +
                ", content='" + content + '\'' +
                ", secret='" + secret + '\'' +
                '}';
    }
}
