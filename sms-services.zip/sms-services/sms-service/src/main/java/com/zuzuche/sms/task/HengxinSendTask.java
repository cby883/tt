package com.zuzuche.sms.task;

import com.zuzuche.commons.base.util.StringUtil;
import com.zuzuche.sms.cache.ProviderAccountCache;
import com.zuzuche.sms.dto.InvokeResultDto;
import com.zuzuche.sms.dto.SmsDto;
import com.zuzuche.sms.entity.ProviderAccountInfo;
import com.zuzuche.sms.remote.HengXinPushApi;
import com.zuzuche.sms.remote.dto.PostHxSmsDto;
import com.zuzuche.sms.remote.param.PostHxSmsParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.time.Instant;

/**
 * 功能：卓越恒信的发送任务实现类.
 * 详细：
 *
 * @author Created on 2019.06.27 by chaodian
 */
@Slf4j
@Component
@Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class HengxinSendTask extends AbstractSendTask {
    @Autowired
    HengXinPushApi hengXinPushApi;


    HengxinSendTask(SmsDto sms) {
        super(sms);
    }

    /**
     * 过滤器链
     */
    @Override
    public boolean beforeSend(SmsDto sms) {
        return super.beforeSend( sms);
    }

    /**
     * 发送给供应商
     */
    @Override
    public InvokeResultDto invokeApi(SmsDto sms){
        // 取账号密码
        ProviderAccountInfo account = ProviderAccountCache.getAccountById(sms.getAccountId());

        PostHxSmsParam param = PostHxSmsParam.builder()
                .account(account.getAccountName())
                .content(sms.getContent())
                .mobile(sms.getMobile())
                .secret(account.getAccountPwd())
                .build();

        PostHxSmsDto result = hengXinPushApi.send(param);

        // 获取恒信返回的批次号
        String batchNo;
        if (result.getData() != null && StringUtil.isNotBlank(result.getData().getBatchId())) {
            batchNo = result.getData().getBatchId();
        } else {
            batchNo = "";
        }

        return InvokeResultDto.builder()
                .bachNo(batchNo)
                .extra(sms.getTaskId())
                .respCode(result.getCode())
                .taskId(sms.getTaskId())
                .mobiles(sms.getMobile())
                .md5Content(sms.getMd5Content())
                .timestamp(Instant.now().toEpochMilli())
                .providerId(account.getProviderId())
                .build();
    }
}
