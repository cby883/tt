package com.zuzuche.sms.cache;

import com.zuzuche.commons.base.util.StringUtil;
import com.zuzuche.sms.cache.co.SmsSignCo;
import com.zuzuche.sms.entity.SignLanguageType;
import com.zuzuche.sms.entity.SmsSign;
import com.zuzuche.sms.mapper.SignLanguageTypeMapper;
import com.zuzuche.sms.mapper.SmsSignMapper;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 功能：短信签名简繁体关联表缓存类.
 * 详细：
 *
 * @author bingyi
 * @blame Android Team
 */
@Component("SignLanguageTypeCache")
@Slf4j
@Data
public class SignLanguageTypeCache implements InitializingBean, ConfigCache {


    private static final String PREFIX_KEY = "SIGN_LANGUAGE_TYPE_";
    @Autowired
    SignLanguageTypeMapper mapper;
    public Map<String, SignLanguageType> typeMap = new HashMap<>(16);

    @Override
    public boolean refresh() {
        try {
            load();
            return true;
        } catch (Exception e) {
            log.error("【短信签名简繁体关联表缓存刷新失败】", e.getMessage(), e);
        }
        return false;
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        load();
    }

    private synchronized void load() {
        //查询出所有
        List<SignLanguageType> temp = mapper.selectAll();
        //构造typeMap
        Map<String, SignLanguageType> tempMap =
                temp.stream()
                .collect(Collectors.toMap(e -> spliceMapKey(e.getSimplifiedSignId(), e.getLanguage()), e -> e));
        typeMap = tempMap;
    }

    /**
     * desc:通过简体签名id和对应的语言版本获取签名
     * @param simplifiedSignId
     * @param languge
     * @return
     */
    public int getBySign(int simplifiedSignId, String languge) {
        if (simplifiedSignId > 0 && StringUtil.isNotEmpty(languge)) {
            //构造key
            String signKey = spliceMapKey(simplifiedSignId,languge);
            if(typeMap.containsKey(signKey)){
                return typeMap.get(signKey).getRealSignId();
            }
        }
        return simplifiedSignId;
    }

    /**
     * 构造mapKey
     *
     * @param simplifiedSignId
     * @return
     * @Desc:此处以：PREFIX_KEY+简体签名id+语言版本 构造成map的key
     */
    private String spliceMapKey(int simplifiedSignId, String languge) {
        return PREFIX_KEY + simplifiedSignId + languge;
    }
}

