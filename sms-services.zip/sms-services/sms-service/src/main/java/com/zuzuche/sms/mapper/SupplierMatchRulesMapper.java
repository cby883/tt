package com.zuzuche.sms.mapper;

import com.zuzuche.commons.mybatis.BaseMapper;
import com.zuzuche.sms.entity.SupplierMatchRules;

/**
 * The interface Supplier match rules mapper.
 */
public interface SupplierMatchRulesMapper extends BaseMapper<SupplierMatchRules> {
}