package com.zuzuche.sms.service;

import com.google.common.collect.Maps;
import com.google.common.util.concurrent.RateLimiter;
import com.zuzuche.commons.base.resp.Status;
import com.zuzuche.commons.base.resp.StatusServiceCnException;
import com.zuzuche.commons.base.util.BeanConverter;
import com.zuzuche.commons.base.util.StringUtil;
import com.zuzuche.commons.mybatis.PageData;
import com.zuzuche.commons.redis.RedisLock;
import com.zuzuche.sms.cache.PushStatusOffsetCache;
import com.zuzuche.sms.cache.SmsConfigCache;
import com.zuzuche.sms.common.enums.RateLimiterKeyTypes;
import com.zuzuche.sms.common.enums.SmsType;
import com.zuzuche.sms.entity.*;
import com.zuzuche.sms.common.utils.TimeUtil;
import com.zuzuche.sms.dto.StatusReportDto;
import com.zuzuche.sms.mapper.*;
import com.zuzuche.sms.rest.response.PushStatusRsp;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PostMapping;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * @desc: 状态报告相关
 * @author: panqiong
 * @date: 2018/10/24
 */
@Service
@Slf4j
public class StatusReportService {

    @Autowired
    KafkaService kafkaService;
    @Autowired
    SmsOutboundMapper smsOutboundMapper;

    @Autowired
    StatusReportMapper statusReportMapper;

    @Autowired
    StringRedisTemplate redisTemplate;

    @Autowired
    SmsMtMapper smsMtMapper;

    @Autowired
    SmsMtMarketMapper smsMtMarketMapper;

    @Autowired
    SmsConfigCache smsConfigCache;

    @Autowired
    SmsBatchSendReportMapper smsBatchSendReportMapper;

    @Autowired
    SmsBatchTaskService smsBatchTaskService;


    @Autowired
    PushStatusOffsetCache pushStatusOffsetCache;


    /**
     * 根据taskId查询该批次的用户推送状态
     *
     * @param taskId
     */
    public List<PushStatusRsp> queryPushStatus(String taskId) {
        SmsOutbound outbound = smsOutboundMapper.queryByTaskId(taskId);
        if (outbound == null) {
            throw new StatusServiceCnException(Status.OBJECT_NOT_EXIST, "taskId:" + taskId + " 不存在 ");
        }

        if (StringUtil.isEmpty(outbound.getBatchNo())) {
            //throw new StatusServiceCnException(Status.OBJECT_NOT_EXIST,"taskId:"+taskId+" 没有batchNo");
            log.info("[queryPushStatus]taskId: " + taskId + " 暂时还没有更新batchNo,需要稍后再查");
            return null;
        }

        List<StatusReport> list = statusReportMapper.queryListByBatchNo(outbound.getBatchNo());

        List<PushStatusRsp> rspList = transform(list, taskId);

        return rspList;
    }

    /**
     * 分布式锁控制 避免offset覆盖 冲突
     * 根据时间偏移量获取
     *
     * @return
     */
    public List<PushStatusRsp> queryPushStatusByOffset() {
        RedisLock lock = new RedisLock(redisTemplate, PushStatusOffsetCache.PUSH_STATUS_OFFSET_KEY);
        if (lock.lock()) {
            // 从redis获取最新的offset 即id
            try {
                String id = pushStatusOffsetCache.get();
                if (StringUtil.isEmpty(id)) {
                    throw new StatusServiceCnException(Status.OBJECT_NOT_EXIST, "状态拉取的offset丢失,需要检查重新设置offset");
                }
                List<StatusReport> list = statusReportMapper.queryListByIdLimit(id, 200);
                // 填充数据 并转换数据对象
                List<PushStatusRsp> rspList = enrichAndTransform(list);

                if (CollectionUtils.isNotEmpty(list)) {
                    // 设置最大的id 作为offset 存储到redis
                    int maxId = list.stream().mapToInt(e -> e.getId()).max().getAsInt();
                    pushStatusOffsetCache.set(String.valueOf(maxId));
                }
                return rspList;
            } finally {
                lock.unlock();
            }
        }
        return null;

    }

    /**
     * 数据对象转换
     *
     * @param list
     * @return
     */
    public List<PushStatusRsp> enrichAndTransform(List<StatusReport> list) {
        if (CollectionUtils.isEmpty(list)) {
            return null;
        }
        Set<String> batchNoSet = list.stream().map(e -> e.getBatchNo()).collect(Collectors.toSet());
        // 查询batchNo和taskId对应关系
        List<SmsOutbound> outboundList = smsOutboundMapper.queryByBatchNoList(batchNoSet);

        Map<String, SmsOutbound> outboundMap = Maps.uniqueIndex(outboundList, outbound -> outbound.getBatchNo());


        List<PushStatusRsp> rspList = list.stream().map(e -> {
            // 找到batchNo对应的taskid
            SmsOutbound sob = outboundMap.get(e.getBatchNo());
            String taskId = sob == null ? "" : sob.getTaskId();
            return PushStatusRsp.builder()
                    .reportId(e.getId())
                    .mobile(e.getPhone())
                    .status("DELIVRD".equals(e.getStatus()) ? "1" : "2")
                    .taskId(taskId)
                    .build();
        }).collect(Collectors.toList());
        return rspList;
    }

    /**
     * 数据对象转换
     *
     * @param list
     * @param taskId
     * @return
     */
    public List<PushStatusRsp> transform(List<StatusReport> list, String taskId) {
        if (CollectionUtils.isEmpty(list)) {
            return null;
        }
        List<PushStatusRsp> rspList = list.stream().map(e -> PushStatusRsp.builder()
                .mobile(e.getPhone())
                .status("DELIVRD".equals(e.getStatus()) ? "1" : "2")
                .taskId(taskId)
                .build()
        ).collect(Collectors.toList());
        return rspList;
    }

    /**
     * 根据任务号批量查询状态报告
     *
     * @param batchNo
     * @return
     */
    public SmsBatchSendReport batchReport(String batchNo) {
        if (StringUtil.isBlank(batchNo)) {
            return null;
        }
        return smsBatchSendReportMapper.selectByBatchNo(batchNo);
    }

    /**
     * 更新批量短信状态报告
     *
     * @return
     */
    public void updateSmsBatchReport() {
        //查出时间范围内的状态报告
        List<SmsBatchTask> list = smsBatchTaskService.selectInDays(LocalDateTime.now().minusDays(3)
                , LocalDateTime.now());

        List<SmsBatchSendReport> reportList = new ArrayList<>();
        //查询出状态报告记录
        list.forEach(e -> {
            //统计数量
            String batchNo = e.getId() + "";
            //初始化值
            int pushTotal = 0;
            int arrivalSuccess = 0;
            int arrivalFail = 0;
            int pushSuccess = 0;
            Integer billCount = null;
            //判断是普通短信还是营销短信
            if(e.getSmsType()== SmsType.营销.code()){
                pushTotal = smsMtMarketMapper.pushCountByBatchNo(batchNo);
                arrivalSuccess = smsMtMarketMapper.arrivalSuccessByBatchNo(batchNo);
                arrivalFail = smsMtMarketMapper.arrivalFailByBatchNo(batchNo);
                pushSuccess = smsMtMarketMapper.pushSuccessByBatchNo(batchNo);
                billCount = smsMtMarketMapper.searchBillCountByBatchNo(batchNo);
            }else{
                pushTotal = smsMtMapper.pushCountByBatchNo(batchNo);
                arrivalSuccess = smsMtMapper.arrivalSuccessByBatchNo(batchNo);
                arrivalFail = smsMtMapper.arrivalFailByBatchNo(batchNo);
                pushSuccess = smsMtMapper.pushSuccessByBatchNo(batchNo);
                billCount = smsMtMapper.searchBillCountByBatchNo(batchNo);
            }

            if(billCount==null){
                billCount=0;
            }
            int pushFail = pushTotal - pushSuccess;
            SmsBatchSendReport report = SmsBatchSendReport.builder()
                    .pushTotal(pushTotal)
                    .arrivalFail(arrivalFail)
                    .arrivalSuccess(arrivalSuccess)
                    .batchNo(batchNo)
                    .billCount(billCount)
                    .pushFail(pushFail)
                    .pushSuccess(pushSuccess)
                    .updateTime(LocalDateTime.now())
                    .build();
            reportList.add(report);
        });

        //更新或者插入
        reportList.forEach(e -> {
            int count =smsBatchSendReportMapper.updateByBatchNo(e);
            if(count<=0){
                //新增，做插入
                e.setCreateTime(LocalDateTime.now());
                smsBatchSendReportMapper.insert(e);
            }
        });
        return;
    }
    /**
     * 推送状态报告到循环队列
     * @param list
     */
    public void pushToReportKafka(List<StatusReport> list){
        //控制速度
        RateLimiter rateLimiter=smsConfigCache.getLimiter(RateLimiterKeyTypes.STATUS_REPORT_DB_RATE);
        rateLimiter.acquire();
        if(CollectionUtils.isNotEmpty(list)){
            //入库
            statusReportMapper.insertList(list);
            //推送到status_report队列
            list.forEach(e->{
                //尝试去更新
                StatusReportDto statusReportDto=BeanConverter.copy(e,StatusReportDto.class);
                if(!upStatusReport(statusReportDto)){
                    //设置入队时间,推送入队
                    statusReportDto.setEnQueueTime(TimeUtil.nowOfPatter(""));
                    statusReportDto.setEnQueueCount(1);
                    kafkaService.sendToStatusReportKafka(statusReportDto);
                }
            });
        }
    }

    /**
     * desc:
     *
     * @param statusReport
     * @return
     */
    public boolean upStatusReport(StatusReportDto statusReport) {

        if (statusReport == null || StringUtil.isBlank(statusReport.getBatchNo()) || StringUtil.isBlank(statusReport.getPhone())) {
            String errorMsg = "【SmsReportService】状态报告statusReport数据不完整:" + (statusReport == null ? "" : statusReport.toString());
            //直接抛出
            throw new StatusServiceCnException(Status.ILLEGAL_ARGUMENT, errorMsg);
        }

        //初始化
        SmsOutbound smsOutbound;
        String success = "DELIVRD";
        byte status = success.equalsIgnoreCase(statusReport.getStatus()) ? (byte) 1 : (byte) 2;


        //根据batchNo查询sms_outbound表中的taskId
        smsOutbound = smsOutboundMapper.queryByBatchNo(statusReport.getBatchNo());


        //拿不到，直接返回false
        if (smsOutbound == null) {
            return false;
        }

        //根据taskId-->更新sms_mt_tbl、sms_market_mt_tbl表的数据
        //①查询taskId是否在sms_mt_tbl中，如果存在更新，否则在sms_market_mt_tbl中
        SmsMt smsMt = SmsMt.builder()
                .taskId(Integer.parseInt(smsOutbound.getTaskId()))
                .mobile(statusReport.getPhone())
                .status(status)
                .updateTime(Integer.parseInt(Long.toString((System.currentTimeMillis()) / 1000))).build();
        //更新数据库
        int updCount = 0;
        updCount = smsMtMapper.updateStatusByMobileAndTaskId(smsMt);
        if (updCount > 0) {
            return true;
        }

        //更新smsMtMarket表
        SmsMtMarket smsMtMarket = SmsMtMarket.builder()
                .status(status)
                .taskId(Integer.parseInt(smsOutbound.getTaskId()))
                .mobile(statusReport.getPhone())
                .build();
        int updCountMarket = smsMtMarketMapper.updateStatusReportByMobileAndTaskId(smsMtMarket);
        if (updCountMarket > 0) {
            return true;
        }

        //查不到sms_mt表记录，直接抛出错误
        String errorMsg = "【SmsReportService】状态报告更新出错：找不到对应的SMS_MT类:" + statusReport.toString();
        throw new StatusServiceCnException(Status.BUSY, errorMsg);
    }
}
