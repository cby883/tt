package com.zuzuche.sms.remote.param;

import com.alibaba.fastjson.annotation.JSONField;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @desc: 主动获取上行接口参数
 * @author: panqiong
 * @date: 2018/11/5
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PostDeliverMsgParam {

    /**
     * 必填参数，访问接口账户id
     */
    @JSONField(name="corp_id")
    private String corpId;

    /**
     * 访问接口账户密码
     */
    @JSONField(name="corp_pwd")
    private String corpPwd;

    /**
     * 一级账户用户名
     */
    @JSONField(name="user_id")
    private String userId;


    @Override
    public String toString() {
        return "PostDeliverMsgParam{" +
                "corpId='" + corpId + '\'' +
                ", userId='" + userId + '\'' +
                '}';
    }
}
