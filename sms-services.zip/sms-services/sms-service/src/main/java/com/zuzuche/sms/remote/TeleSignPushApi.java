package com.zuzuche.sms.remote;

import com.alibaba.fastjson.annotation.JSONField;
import com.google.common.base.Splitter;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.zuzuche.commons.base.resp.Status;
import com.zuzuche.commons.base.resp.StatusServiceException;
import com.zuzuche.commons.base.util.JsonUtil;
import com.zuzuche.sms.cache.ProviderAccountCache;
import com.zuzuche.sms.common.enums.SmsType;
import com.zuzuche.sms.common.utils.Base64Util;
import com.zuzuche.sms.dto.InvokeResultDto;
import com.zuzuche.sms.dto.SmsDto;
import com.zuzuche.sms.entity.ProviderAccountInfo;
import com.zuzuche.sms.remote.dto.TeleSignResultDto;
import com.zuzuche.sms.remote.param.TeleSignPushParam;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import okhttp3.*;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.charset.Charset;
import java.time.Instant;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @desc: teleSign的推送api
 * @author: chenbingyi
 * @date: 2019/8/30
 */
@Service
@Slf4j
public class TeleSignPushApi extends AbstractHttpInvoke {

    @Value("${provider.teleSign.pushurl}")
    private String pushUrl;

    /**
     * 额外的header设置 比如编码
     *
     * @param header
     */
    @Override
    protected void setHeader(HttpHeaders header) {
        header.setAcceptCharset(Arrays.asList(Charset.forName("UTF-8")));
    }

    /**
     * 1、获取账号密码
     * 2、转换成请求对象
     * 3、发起http请求
     * 4、封装返回体
     *
     * @param smsDto
     * @return
     */
    @HystrixCommand(groupKey = "teleSignPushGroup", commandKey = "teleSignPush")
    public InvokeResultDto sendSms(SmsDto smsDto) {
        if (smsDto.getType() == SmsType.验证码.code()) {
            //验证码
            return sendVerificationSms(smsDto);
        }
        //普通通知、营销短信
        return null;
    }

    /**
     * 发送普通短信
     *
     * @return
     */
    private InvokeResultDto sendVerificationSms(SmsDto smsDto) {
        //拿到账号密码
        ProviderAccountInfo providerAccountInfo = ProviderAccountCache.getAccountById(smsDto.getAccountId());

        //转换成请求对象
        TeleSignPushParam requestParam = convertParam(smsDto);

        //构造额外参数
        String external = createRecipients(providerAccountInfo.getAccountId(), smsDto.getTaskId(), smsDto.getMobile());
        requestParam.setExternal_id(external);

        //basic认证，获得headers authorization
        String auth = authorization(providerAccountInfo.getAccountName(), providerAccountInfo.getAccountPwd());

        //发起请求
        TeleSignResultDto teleSignResultDto = postApi(pushUrl, requestParam, auth);

        //转化成InvokeResultDto
        return transfer(providerAccountInfo, smsDto, teleSignResultDto);
    }

    private InvokeResultDto sendMarketSms(SmsDto smsDto) {
        return null;
    }

    private static InvokeResultDto transfer(ProviderAccountInfo providerAccountInfo, SmsDto smsDto, TeleSignResultDto teleSignResultDto) {
        //如果为空，直接报错
        if (teleSignResultDto == null) {
            throw new StatusServiceException(Status.ILLEGAL_ARGUMENT, "【TeleSignPushApi】teleSign短信接口InvokeResultDto为空");
        }
        int success=290;
        InvokeResultDto result = InvokeResultDto.builder()
                .bachNo(smsDto.getTaskId())
                .mobiles(smsDto.getMobile())
                .providerId(providerAccountInfo.getProviderId())
                .taskId(smsDto.getTaskId())
                .md5Content(smsDto.getMd5Content())
                .extra(teleSignResultDto.getReferenceId())
                .timestamp(Instant.now().toEpochMilli())
                .build();
        if(teleSignResultDto.getStatus().getCode()==success){
            result.setRespCode("0");
        }else{
            if(CollectionUtils.isNotEmpty(teleSignResultDto.getErrors())){
                result.setRespCode(cutErrorMessage(teleSignResultDto.getErrors().get(0).getDescription()));
            }else{
                result.setRespCode(cutErrorMessage(teleSignResultDto.getStatus().getDescription()));
            }
        }
        return result;
    }

    /**
     * 截取错误信息length<30
     *
     * @param errorMessage
     * @return
     */
    private static String cutErrorMessage(String errorMessage) {
        int len = 29;
        if (errorMessage.length() <= len) {
            //如果小于,直接返回
            return errorMessage;
        }
        return errorMessage.substring(0, 29);
    }
    private  static TeleSignResultDto postApi(String url, TeleSignPushParam requestParam, String auth) {
        //封装headers
        Map<String, String> headers = new HashMap<>();
        headers.put("content-type", "application/x-www-form-urlencoded");
        headers.put("authorization", auth);
        //发送请求
        TeleSignResultDto teleSignResultDto = null;

        Response response = AbstractHttpInvoke.postWithHeader(url, requestParam, headers);
        //封装返回对象
        try {
            teleSignResultDto = JsonUtil.stringToObj(response.body().string(), TeleSignResultDto.class);
        } catch (IOException e) {
            log.error("[TeleSignPushApi-postApi]teleSign短信接口response获取失败", e.getMessage(), e);
        }
        //返回结果
        return teleSignResultDto;
    }

    public static void main(String[] args){
        SmsDto smsDto = SmsDto.builder()
                .taskId("333344444444")
                .mobile("008613827162860")
                .content("测试数据33334")
                .type(3)
                .accountId(124)
                .senderId("ERC")
                .build();

        ProviderAccountInfo providerAccountInfo = ProviderAccountInfo.builder()
                .accountId(124)
                .accountName("F77BF2D6-E56B-4A5F-84B7-E5095CB69A27")
                .accountPwd("ne8K3G8XZ05qG0HsTSWDtl4CiZeXoHIeBhUtP4ZZ56X1fMevzgROaZhCUjL/YemlQASlWxGPSULcQOdXrr8wiA==").build();
        //转换成请求对象
        TeleSignPushParam requestParam = convertParam(smsDto);

        //构造额外参数
        String external = createRecipients(providerAccountInfo.getAccountId(), smsDto.getTaskId(), smsDto.getMobile());
        requestParam.setExternal_id(external);

        //basic认证，获得headers authorization
        String auth = authorization(providerAccountInfo.getAccountName(), providerAccountInfo.getAccountPwd());

        //发起请求
        TeleSignResultDto teleSignResultDto = postApi("http://rest-ww.telesign.com/v1/messaging", requestParam, auth);

        //转化成InvokeResultDto
        InvokeResultDto resultDto = transfer(providerAccountInfo, smsDto, teleSignResultDto);
        System.out.println(resultDto);

        OkHttpClient client = new OkHttpClient();

        MediaType mediaType = MediaType.parse("application/x-www-form-urlencoded");
        RequestBody body = RequestBody.create(mediaType, "message=Hello%20from%20TeleSign!&message_type=ARN&phone_number=008613827162860&external_id=jjj");
        Request request = new Request.Builder()
                .url("https://rest-ww.telesign.com/v1/messaging")
                .post(body)
                .addHeader("content-type", "application/x-www-form-urlencoded")
                .addHeader("authorization", "Basic Rjc3QkYyRDYtRTU2Qi00QTVGLTg0QjctRTUwOTVDQjY5QTI3Om5lOEszRzhYWjA1cUcwSHNUU1dEdGw0Q2laZVhvSEllQmhVdFA0Wlo1NlgxZk1ldnpnUk9hWmhDVWpML1llbWxRQVNsV3hHUFNVTGNRT2RYcnI4d2lBPT0=")
                .build();

        try {
            Response response = client.newCall(request).execute();
            System.out.println(request);
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    /**
     * 转化为请求对象
     *
     * @param smsDto
     * @return
     */
    private  static TeleSignPushParam convertParam(SmsDto smsDto) {
        TeleSignPushParam teleSignPushParam = TeleSignPushParam.builder()
                .message(smsDto.getContent())
                .phone_number(smsDto.getMobile())
                .build();
        return teleSignPushParam;

    }

    private  static String createRecipients(int accountId, String taskId, String phoneStr) {
        List<String> phoneList = Splitter.on(",").splitToList(phoneStr);
        StringBuilder tem = new StringBuilder();
        if (CollectionUtils.isNotEmpty(phoneList)) {
            phoneList.forEach(e -> {
                tem.append(accountId + "_" + taskId + "_" + e + ",");
            });
        }
        return tem.substring(0, tem.length() - 1).toString();
    }

    /**
     * desc:请求头设置
     *
     * @param customerId
     * @param apiKey
     * @return
     */
    private static String authorization(String customerId, String apiKey) {
        String authorization = "Basic ";
        try {
            authorization += Base64Util.encode(customerId + ":" + apiKey, "utf-8");
        } catch (Exception e) {
            log.warn("[teleSign短信供应商验签转化失败]", e.getMessage(), e);
        }
        return authorization;
    }


}
