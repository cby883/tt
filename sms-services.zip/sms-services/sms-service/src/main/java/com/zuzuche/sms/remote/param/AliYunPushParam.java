package com.zuzuche.sms.remote.param;

import com.zuzuche.sms.dto.SmsDto;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang.StringUtils;

import java.util.UUID;

/**
 * @desc:阿里云短信请求参数
 * @author: bingyi
 * @date: 2018/11/12
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AliYunPushParam {

    /**
     *
     */
    private String outId;
    /**
     *
     */
    private String phoneNumbers;
    /**
     * 发送的短信内容
     */
    private String content;
    /**
     * 账号
     */
    private String account;

    /**
     * 密码
     */
    private String password;


    /**
     * 短信签名，阿里云自动加上签名：如自动加上【租租车】
     */
    private String sign;

    /**
     * 阿里云短信模板
     */
    private String templateCode;
    /**
     * 返回参数的语言类型。取值范围：json | xml。默认值：json。
     */
    @Builder.Default
    private String format="json";
    /**
     * 	供应商API 的名称
     */
    private String action;
    /**
     * API支持的RegionID，如短信API的值为：cn-hangzhou
     */
    @Builder.Default
    private String regionId="cn-hangzhou";

    /**
     * 签名方式。取值范围：HMAC-SHA1。
     */
    @Builder.Default
    private String signatureMethod="HMAC-SHA1";

    /**
     * 签名唯一随机数。用于防止网络重放攻击，建议您每一次请求都使用不同的随机数。
     */
    private String signatureNonce;
    /**
     * 签名算法版本。取值范围：1.0
     */
    @Builder.Default
    private String signatureVersion="1.0";
    /**
     * 请求的时间戳。按照ISO8601 标准表示，并需要使用UTC时间，格式为yyyy-MM-ddTHH:mm:ssZ。
     * 示例：2018-01-01T12:00:00Z 表示北京时间 2018 年 01 月 01 日 20 点 00 分 00 秒。
     */
    private String timestamp;
    /**
     * API 的版本号，格式为 YYYY-MM-DD。取值范围：2017-05-25。
     */
    @Builder.Default
    private String version="2017-05-25";

    /**
     * 短信上行拓展码
     */
    private String smsUpExtendCodeJson;

}
