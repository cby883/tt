package com.zuzuche.sms.job;

import com.zuzuche.commons.redis.RedisLock;
import com.zuzuche.logback.util.MDCUtil;
import com.zuzuche.sms.common.enums.SmsFileRecordType;
import com.zuzuche.sms.common.enums.SmsFileType;
import com.zuzuche.sms.entity.SmsUploadFileLog;
import com.zuzuche.sms.mapper.SmsUploadFileLogMapper;
import com.zuzuche.sms.service.FileManagementService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.List;

/**
 * @desc: 文件批量导入定时器(导入状态为0的文件任务)
 * @author: bingyi
 * @date: 2019/11/07
 */
@Component
@Slf4j
public class SmsBatchImportFileJob {
    @Autowired
    SmsUploadFileLogMapper smsUploadFileLogMapper;

    @Autowired
    FileManagementService fileManagementService;

    private static final String SMS_BATCH_IMPORT_FILE_KEY = "SMS_BATCH_IMPORT_FILE_SMS_KEY_";

    /**
     * 每30秒执行一遍
     */
    @Scheduled(cron = "30 * * * * ?")
    public void execute() {
        MDCUtil.set();
        RedisLock redisLock = new RedisLock(SMS_BATCH_IMPORT_FILE_KEY);
        if(redisLock.lock()){
            try {
                try {
                    //查出符合条件的文件任务
                    List<SmsUploadFileLog> fileLogs = smsUploadFileLogMapper.findByRecord(SmsFileRecordType.SMS_FILE_RECORD_TYPE_FIRST.code()
                            , LocalDateTime.now().minusDays(3));
                    //单线程去导入数据
                    fileLogs.forEach(e -> {
                        e.setRecorded(SmsFileRecordType.SMS_FILE_RECORD_TYPE_IMPORTING.code());
                        int count = smsUploadFileLogMapper.updateByPrimaryKeySelective(e);
                        if (count > 0) {
                            SmsUploadFileLog fileLog =null;
                            if(e.getFileType()== SmsFileType.SMS_FILE_TYPE_LARGE.code()){
                               fileLog=fileManagementService.importData(e);
                            }else{
                                fileLog=fileManagementService.importDataWithNormal(e);
                            }
                            if (fileLog != null) {
                                smsUploadFileLogMapper.updateByPrimaryKeySelective(e);
                            }else{
                                e.setRecorded(SmsFileRecordType.SMS_FILE_RECORD_TYPE_FIRST.code());
                                smsUploadFileLogMapper.updateByPrimaryKeySelective(e);
                            }
                        }

                    });
                } catch (Exception e) {
                    log.error("【文件导入定时器失败】", e.getMessage(), e);
                }
            } finally {
                   redisLock.unlock();
            }
        }
        MDCUtil.clear();
    }
}
