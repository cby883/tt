package com.zuzuche.sms.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Table;
import java.time.LocalDateTime;

/**
 * @desc 下行 app与供应商绑定关系
 * @author panqiong
 * @date 20181019
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "outbound_account_bind")
public class OutboundAccountBind {
    private int bindId;

    /**
     * 签名id
     */
    private int signId;

    /**
     * 短信类型
     */
    private String smsType;

    /**
     * 目标区域
     */
    private int areaType;

    /**
     *
     */
    private String accountId;

    private String remark;

    private LocalDateTime createTime;

    private LocalDateTime updateTime;

    private int validState;


}