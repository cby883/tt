package com.zuzuche.sms.common.enums;

import com.zuzuche.commons.base.constants.BaseEnum;
import lombok.Getter;


/**
 * The enum Need inter prefix suppliers.
 * @author Chaodian
 */
@Getter
public enum NeedInterPrefixSuppliers implements BaseEnum<String> {

    /**
     * Cm need inter prefix suppliers.
     */
    CM("CM", "00");

    /**
     * 供应商名称
     */
    private String code;

    /**
     * 添加的前缀
     */
    private String prefix;

    NeedInterPrefixSuppliers(String code, String prefix) {
        this.code = code;
        this.prefix = prefix;
    }

    @Override
    public String code() {
        return code;
    }
}
