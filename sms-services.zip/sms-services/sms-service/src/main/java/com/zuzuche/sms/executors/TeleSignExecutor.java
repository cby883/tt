package com.zuzuche.sms.executors;

import com.zuzuche.sms.common.utils.SpringBeanFactory;
import com.zuzuche.sms.dto.SmsDto;
import com.zuzuche.sms.task.AbstractSendTask;
import com.zuzuche.sms.task.TeleSignSendTask;
import com.zuzuche.threadpool.ThreadPoolExecutorFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * @desc: teleSign的工作线程池
 * @author: bingyi
 * @date: 2019/09/10
 */
@Slf4j
@Component
public class TeleSignExecutor extends AbstractOutboundExecutor{



    public TeleSignExecutor() {
        super(ThreadPoolExecutorFactory.Config.builder()
                        .corePoolSize(20)
                        .maximumPoolSize(25)
                        .keepAliveTime(5)
                        .workQueue(new ArrayBlockingQueue<>(100))
                        .unit(TimeUnit.MINUTES)
                        .handler(new ThreadPoolExecutor.CallerRunsPolicy())
                        .threadPoolName("TeleSignExecutor")
                        .build()
        );

    }



    /**
     * 打包发送任务  将sms包装成task
     * @param sms
     */
    @Override
    public AbstractSendTask packingSendTask(SmsDto sms)  {

        TeleSignSendTask sendTask = SpringBeanFactory.getBean(TeleSignSendTask.class,sms);

        return sendTask;

    }
}
