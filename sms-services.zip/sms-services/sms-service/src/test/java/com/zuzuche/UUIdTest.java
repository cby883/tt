package com.zuzuche;

import com.zuzuche.sms.dto.SmsDto;
import com.zuzuche.sms.remote.AliYunPushApi;
import com.zuzuche.sms.remote.dto.AliYunSmsSendDto;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;


/**
 * @desc:
 * @author: panqiong
 * @date: 2018/10/23
 */
@SpringBootTest
@RunWith(SpringRunner.class)
@Slf4j
public class UUIdTest {

//    @Autowired
//    AliYunPushApi aliYunPushApi;
//    @Test
//    public void test(){
//        SmsDto smsDto=SmsDto.builder()
//                .taskId("111")
//                .content("这是一条测试数据1345")
//                .mobile("13827162860")
//                .accountId(122)
//                .signType(1).build();
//        AliYunSmsSendDto aliYunSmsSendDto=aliYunPushApi.aLiYunSend(smsDto);
//        System.out.println(aliYunSmsSendDto);
////        System.out.println("1");
//    }
}
