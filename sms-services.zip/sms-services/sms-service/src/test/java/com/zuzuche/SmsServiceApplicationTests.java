package com.zuzuche;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

@RunWith(SpringRunner.class)
@SpringBootTest
public class SmsServiceApplicationTests {

    ThreadPoolExecutor executorService = new ThreadPoolExecutor(
            1,
            5,
            0L,
            TimeUnit.MILLISECONDS,
            new LinkedBlockingQueue<Runnable>()){
        protected void beforeExecute(Thread t, Runnable r) {}
        protected void afterExecute(Runnable r, Throwable t) {}
    };

    @Test
    public void contextLoads() {
    }



}
