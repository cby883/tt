package com.zuzuche.sms.remote;

import com.zuzuche.commons.base.resp.PhpResult;
import com.zuzuche.commons.base.util.JsonUtil;
import com.zuzuche.sms.common.constant.Constants;
import com.zuzuche.sms.common.enums.SmsRegionType;
import com.zuzuche.sms.common.utils.PerformUtil;
import com.zuzuche.sms.dto.ExtraParamDto;
import com.zuzuche.sms.dto.MtDto;
import com.zuzuche.sms.remote.param.SendRemarkParam;
import com.zuzuche.sms.service.JuchnServiceTest;
import com.zuzuche.sms.service.SmsMtService;
import org.checkerframework.checker.units.qual.A;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.time.Instant;
import java.util.*;

@RunWith(SpringRunner.class)
@SpringBootTest
public class RemarkRemoteTest {

    @Autowired
    RemarkRemote remarkRemote;
    @Autowired
    SmsMtService smsMtService;
    @Test
    public void test(){
        String exp="{\"ticketIdStr\":\"jj\",\"associateOrder\":[\"11\",\"2\"]}";
        MtDto mtDto=MtDto.builder()
                .taskId("2222")
                .accountId(1)
                .mobiles("13827162860,18902501093")
                .admin("zzc")
                .extraParam(exp).build();
        System.out.println("jjj");

    }


    @Test
    public void test1(){
        String exp="{\"associateOrder\":[{\"order_type\":\"11\",\"order_id\":\"2\"}]}";
        ExtraParamDto extraParamDto= JsonUtil.stringToObj(exp,ExtraParamDto.class);
        MtDto mtDto=MtDto.builder()
                .accountId(1)
                .taskId("11111")
                .mobiles("13827162860,18902501093")
                .from("zzc")
                .content("22")
                .extraParam(exp).build();
        System.out.println(extraParamDto);
    }
}