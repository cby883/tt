package com.zuzuche.sms.task;


import com.zuzuche.sms.common.utils.SpringBeanFactory;
import com.zuzuche.sms.dto.MtDto;
import com.zuzuche.sms.entity.SmsMt;
import com.zuzuche.sms.entity.SmsMtMarket;
import com.zuzuche.sms.entity.SmsOutbound;
import com.zuzuche.sms.mapper.SmsMtMapper;
import com.zuzuche.sms.mapper.SmsMtMarketMapper;
import com.zuzuche.sms.mapper.SmsOutboundMapper;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class MtDispatchTaskTest {

    // @Autowired
    // MtDispatchTask mtSendTask;

    @Autowired
    SmsOutboundMapper smsOutboundMapper;

    @Autowired
    SmsMtMapper smsMtMapper;

    @Autowired
    SmsMtMarketMapper smsMtMarketMapper;

    /**
     * 每次测试整体流程，都可以在这里修改短信前缀，防止重复或者其他拦截被过滤
     */
    private static int mobileItem = 11111102;

    // @Test
    // // public void testNormalInterSms() {
    // //     MtDto mtDto = MtDto.builder()
    // //             .tempUid("SMS190213175445")
    // //             .variables("{\"order_sn\" : \"232324343\"}")
    // //             .language("zh-cn")
    // //             .mobiles("8861-8819490467")
    // //             .type(1)
    // //             .regionType(2)
    // //             .signType(1)
    // //             .batch("test")
    // //             .admin("zhang_chao_dian")
    // //             .extraParam("{\"verify_code\" : \"294343\"}")
    // //             .from("monitor")
    // //             .uniqueId("234343")
    // //             .mock(true)
    // //             .build();
    // //
    // //     MtDispatchTask mtSendTask = SpringBeanFactory.getBean(MtDispatchTask.class, mtDto);
    // //     mtSendTask.run();
    // // }


    @Test
    public void testZzcInnerNormalSms() throws InterruptedException {
        int mobilePostFix = mobileItem + 1;
        MtDto mtDto = MtDto.builder()
                .mobiles("188"+mobilePostFix)
                .content("租租车国内短信测试流程，匹配供应商创蓝(新)或百唔(新)")
                .mock(true)
                .build();
        MtDispatchTask mtSendTask = SpringBeanFactory.getBean(MtDispatchTask.class, mtDto);
        mtSendTask.run();

        String supplierStr = "CL2,BW2";
        String accountIdStr = "113,115";

        boolean supplierState = supplierStr.contains(mtDto.getSupplier());
        Assert.assertTrue(supplierState);

        boolean accountIdMatchState = accountIdStr.contains(Integer.toString(mtDto.getAccountId()));
        Assert.assertTrue(accountIdMatchState);

        SmsMt smsMt = smsMtMapper.queryByTaskId(Integer.parseInt(mtDto.getTaskId()));
        boolean dbSupplierState = supplierStr.contains(smsMt.getSupplier());
        Assert.assertTrue(dbSupplierState);

        Thread.sleep(1000);

        SmsOutbound smsOutbound = smsOutboundMapper.queryByTaskId(mtDto.getTaskId());
        boolean dbAccountState = accountIdStr.contains(smsOutbound.getAccountId()+"");
        Assert.assertTrue(dbAccountState);
    }

    @Test
    public void testZzcInterMarketSms() throws InterruptedException {
        int mobilePostFix = mobileItem + 2;
        MtDto mtDto = MtDto.builder()
                .mobiles("1-88"+mobilePostFix)
                .content("租租车国际营销短信测试流程，匹配供应商创蓝(新)")
                .regionType(2)
                .type(2)
                .mock(true)
                .build();
        MtDispatchTask mtSendTask = SpringBeanFactory.getBean(MtDispatchTask.class, mtDto);
        mtSendTask.run();

        SmsMtMarket smsMtMarket = smsMtMarketMapper.queryByTaskId(Integer.parseInt(mtDto.getTaskId()));
        Assert.assertEquals("CL2", smsMtMarket.getSupplier());

        Thread.sleep(1000);

        SmsOutbound smsOutbound = smsOutboundMapper.queryByTaskId(mtDto.getTaskId());
        Assert.assertEquals("118", smsOutbound.getAccountId()+"");
    }

    @Test
    public void testTantuInterVerifySms() throws InterruptedException {
        int mobilePostFix = mobileItem + 3;
        MtDto mtDto = MtDto.builder()
                .mobiles("1-88"+mobilePostFix)
                .content("探途国际验证码短信测试流程，匹配供应商创蓝（新）")
                .regionType(2)
                .signType(2)
                .type(3)
                .mock(true)
                .build();
        MtDispatchTask mtSendTask = SpringBeanFactory.getBean(MtDispatchTask.class, mtDto);
        mtSendTask.run();

        SmsMt smsMt = smsMtMapper.queryByTaskId(Integer.parseInt(mtDto.getTaskId()));
        Assert.assertEquals("CL2", smsMt.getSupplier());

        Thread.sleep(1000);

        SmsOutbound smsOutbound = smsOutboundMapper.queryByTaskId(mtDto.getTaskId());
        Assert.assertEquals("117", smsOutbound.getAccountId() + "");
    }

    @Test
    public void testTantuInnerNormalSms() throws InterruptedException {
        int mobilePostFix = mobileItem + 4;
        MtDto mtDto = MtDto.builder()
                .mobiles("188"+mobilePostFix)
                .content("探途国内普通通知短信测试流程，匹配供应商巨辰")
                .signType(2)
                .mock(true)
                .build();
        MtDispatchTask mtSendTask = SpringBeanFactory.getBean(MtDispatchTask.class, mtDto);
        mtSendTask.run();

        SmsMt smsMt = smsMtMapper.queryByTaskId(Integer.parseInt(mtDto.getTaskId()));
        Assert.assertEquals("JC", smsMt.getSupplier());

        Thread.sleep(1000);

        SmsOutbound smsOutbound = smsOutboundMapper.queryByTaskId(mtDto.getTaskId());
        Assert.assertEquals("112", smsOutbound.getAccountId() + "");
    }

    @Test
    public void testBlackInnerMarketSms() throws InterruptedException {
        int mobilePostFix = mobileItem + 5;
        MtDto mtDto = MtDto.builder()
                .mobiles("188"+mobilePostFix)
                .content("黑卡国内营销短信测试流程，匹配供应商巨辰")
                .signType(3)
                .type(2)
                .mock(true)
                .build();
        MtDispatchTask mtSendTask = SpringBeanFactory.getBean(MtDispatchTask.class, mtDto);
        mtSendTask.run();

        SmsMtMarket smsMt = smsMtMarketMapper.queryByTaskId(Integer.parseInt(mtDto.getTaskId()));
        Assert.assertEquals("JC", smsMt.getSupplier());

        Thread.sleep(1000);

        SmsOutbound smsOutbound = smsOutboundMapper.queryByTaskId(mtDto.getTaskId());
        Assert.assertEquals("111", smsOutbound.getAccountId() + "");
    }

    @Test
    public void testMiyouInnerVerifySms() throws InterruptedException {
        int mobilePostFix = mobileItem + 6;
        MtDto mtDto = MtDto.builder()
                .mobiles("188"+mobilePostFix)
                .content("蜜柚即使国内验证码短信测试流程，匹配供应商巨辰")
                .signType(12)
                .mock(true)
                .build();
        MtDispatchTask mtSendTask = SpringBeanFactory.getBean(MtDispatchTask.class, mtDto);
        mtSendTask.run();

        SmsMt smsMt = smsMtMapper.queryByTaskId(Integer.parseInt(mtDto.getTaskId()));
        Assert.assertEquals("JC", smsMt.getSupplier());

        Thread.sleep(1000);

        SmsOutbound smsOutbound = smsOutboundMapper.queryByTaskId(mtDto.getTaskId());
        Assert.assertEquals("112", smsOutbound.getAccountId() + "");
    }

    @Test
    public void testBwSmsContentCountOne() throws InterruptedException {
        int mobilePostFix = mobileItem + 7;
        String smsContent = "测试百唔(新)的短信，使用验证码通道，这里是65个字符，百唔自动加上租租车签名5个字符，总共70字符，合计1条短信，aaaaaaa";
        MtDto mtDto = MtDto.builder()
                .mobiles("188"+mobilePostFix)
                .content(smsContent)
                .type(3)
                .mock(true)
                .build();
        MtDispatchTask mtSendTask = SpringBeanFactory.getBean(MtDispatchTask.class, mtDto);
        mtSendTask.run();

        SmsMt smsMt = smsMtMapper.queryByTaskId(Integer.parseInt(mtDto.getTaskId()));
        Assert.assertEquals("BW2", smsMt.getSupplier());
        Assert.assertEquals(1, (int) smsMt.getSendCount());
        Assert.assertEquals("【租租车】"+smsContent, smsMt.getContent());

        Thread.sleep(1000);

        SmsOutbound smsOutbound = smsOutboundMapper.queryByTaskId(mtDto.getTaskId());
        Assert.assertEquals("113", smsOutbound.getAccountId() + "");
        Assert.assertEquals(smsContent, smsOutbound.getContent());

    }

    @Test
    public void testCLInnerSmsMarketCountThree() throws InterruptedException {
        int mobilePostFix = mobileItem + 8;
        MtDto mtDto = MtDto.builder()
                .mobiles("188"+mobilePostFix)
                .content("[租租车]测试创蓝(新)的短信，使用营销通道，这里是194个字符，创蓝需要系统自动加租租车签名，并且有7个后缀，总共201字符，合计3条短信，aaaaa测试创蓝(新)的短信，使用营销通道，这里是194个字符，创蓝需要系统自动加租租车签名，并且有7个后缀，总共201字符，合计3条短信，aaaaa测试创蓝(新)的短信，使用营销通道，这里是194个字符，创蓝需要系统自动加租租车签名，并且有7")
                .type(2)
                .mock(true)
                .build();
        MtDispatchTask mtSendTask = SpringBeanFactory.getBean(MtDispatchTask.class, mtDto);
        mtSendTask.run();

        SmsMtMarket smsMtMarket = smsMtMarketMapper.queryByTaskId(Integer.parseInt(mtDto.getTaskId()));
        Assert.assertEquals("CL2", smsMtMarket.getSupplier());
        Assert.assertEquals(3, (int) smsMtMarket.getSendCount());

        Thread.sleep(1000);

        SmsOutbound smsOutbound = smsOutboundMapper.queryByTaskId(mtDto.getTaskId());
        Assert.assertEquals("116", smsOutbound.getAccountId() + "");

    }
}
