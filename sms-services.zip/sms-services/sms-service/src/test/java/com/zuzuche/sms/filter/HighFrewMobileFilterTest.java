package com.zuzuche.sms.filter;


import com.zuzuche.sms.cache.HighFreqMobileCache;
import com.zuzuche.sms.common.enums.HighFreqFilterTypes;
import com.zuzuche.sms.dto.MtDto;
import com.zuzuche.sms.filter.dispatch.HighFreqMobileFilter;
import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;


@RunWith(SpringRunner.class)
@SpringBootTest
@Slf4j
public class HighFrewMobileFilterTest {
    @Autowired
    HighFreqMobileFilter highFreqMobileFilter;

    @Autowired
    HighFreqMobileCache highFreqMobileCache;

    @Test
    public void testOneHighFreqMob() {
        String testMob = "18819490467";
        highFreqMobileCache.deleteMobileKey(testMob, HighFreqFilterTypes.短信发送频率过高);
        for (int i = 1; i <= 12; i++) {
            highFreqMobileCache.setMobileIncre(testMob, HighFreqFilterTypes.短信发送频率过高);
        }
        MtDto mtDto = MtDto.builder().mobiles(testMob).build();

        boolean executeStatus = highFreqMobileFilter.doFilter(mtDto);
        Assert.assertTrue(!executeStatus);
    }

    @Test
    public void testOneNoHighFreqMob() {
        String testMob = "18819490487";
        highFreqMobileCache.deleteMobileKey(testMob, HighFreqFilterTypes.短信发送频率过高);
        for (int i = 1; i <= 11; i++) {
            highFreqMobileCache.setMobileIncre(testMob, HighFreqFilterTypes.短信发送频率过高);
        }
        MtDto mtDto = MtDto.builder().mobiles(testMob).build();
        boolean executeStatus = highFreqMobileFilter.doFilter(mtDto);
        Assert.assertTrue(executeStatus);
    }

    @Test
    public void testMultiHighFreqMob() {
        String hopeToHighMob = "18819490001";
        String hopeToNoHighMob = "18819490002";
        highFreqMobileCache.deleteMobileKey(hopeToHighMob, HighFreqFilterTypes.短信发送频率过高);
        highFreqMobileCache.deleteMobileKey(hopeToNoHighMob, HighFreqFilterTypes.短信发送频率过高);
        for (int i = 1; i <= 12; i++) {
            highFreqMobileCache.setMobileIncre(hopeToHighMob, HighFreqFilterTypes.短信发送频率过高);
        }
        for (int i = 1; i <= 11; i++) {
            highFreqMobileCache.setMobileIncre(hopeToNoHighMob, HighFreqFilterTypes.短信发送频率过高);
        }
        MtDto mtDto = MtDto.builder().mobiles(hopeToHighMob+","+hopeToNoHighMob).build();
        boolean executeStatus = highFreqMobileFilter.doFilter(mtDto);
        Assert.assertTrue(executeStatus);
        Assert.assertEquals(hopeToNoHighMob, mtDto.getMobiles());
    }

    @Test
    public void testStringModify() {
        String a1 = "sssss";
        a1 = "ddddddd";
        Assert.assertEquals("ddddddd", a1);
    }

    @Test
    public void testVerifyHighFreqMob() {
        String canPassMob = "18819490467";
        String freqHighMob = "18819490001";
        String verifyHighMob = "18819490002";
        highFreqMobileCache.deleteMobileKey(canPassMob, HighFreqFilterTypes.短信发送频率过高);
        highFreqMobileCache.deleteMobileKey(canPassMob, HighFreqFilterTypes.验证码发送频率过高);
        highFreqMobileCache.deleteMobileKey(freqHighMob, HighFreqFilterTypes.短信发送频率过高);
        highFreqMobileCache.deleteMobileKey(freqHighMob, HighFreqFilterTypes.验证码发送频率过高);
        highFreqMobileCache.deleteMobileKey(verifyHighMob, HighFreqFilterTypes.短信发送频率过高);
        highFreqMobileCache.deleteMobileKey(verifyHighMob, HighFreqFilterTypes.验证码发送频率过高);
        for (int i = 1; i <= 11; i++) {
            highFreqMobileCache.setMobileIncre(canPassMob, HighFreqFilterTypes.短信发送频率过高);
        }
        // System.out.println(highFreqMobileCache.checkIsMobileOverLimit(canPassMob, HighFreqFilterTypes.短信发送频率过高));
        for (int i = 1; i <= 4; i++) {
            highFreqMobileCache.setMobileIncre(canPassMob, HighFreqFilterTypes.验证码发送频率过高);
        }
        for (int i = 1; i <= 12; i++) {
            highFreqMobileCache.setMobileIncre(freqHighMob, HighFreqFilterTypes.短信发送频率过高);
        }
        for (int i = 1; i <= 4; i++) {
            highFreqMobileCache.setMobileIncre(freqHighMob, HighFreqFilterTypes.验证码发送频率过高);
        }
        for (int i = 1; i <= 11; i++) {
            highFreqMobileCache.setMobileIncre(verifyHighMob, HighFreqFilterTypes.短信发送频率过高);
        }
        for (int i = 1; i <= 5; i++) {
            highFreqMobileCache.setMobileIncre(verifyHighMob, HighFreqFilterTypes.验证码发送频率过高);
        }
        MtDto mtDto = MtDto.builder().mobiles(canPassMob+","+freqHighMob+","+verifyHighMob).type(3).build();
        boolean executeStatus = highFreqMobileFilter.doFilter(mtDto);
        Assert.assertTrue(executeStatus);
        Assert.assertEquals(canPassMob, mtDto.getMobiles());
    }

    @Test
    public void testMarketHighFreqMob() {
        String passMob = "18819490001";
        String marketHighMob = "18819490002";
        highFreqMobileCache.deleteMobileKey(passMob, HighFreqFilterTypes.营销短信发送频率过高);
        highFreqMobileCache.deleteMobileKey(marketHighMob, HighFreqFilterTypes.营销短信发送频率过高);
        for (int i = 1; i <= 1; i++) {
            highFreqMobileCache.setMobileIncre(passMob, HighFreqFilterTypes.营销短信发送频率过高);
        }
        for (int i = 1; i <= 2; i++) {
            highFreqMobileCache.setMobileIncre(marketHighMob, HighFreqFilterTypes.营销短信发送频率过高);
        }
        MtDto mtDto = MtDto.builder().mobiles(passMob + "," + marketHighMob).type(2).build();
        boolean executeStatus = highFreqMobileFilter.doFilter(mtDto);
        Assert.assertTrue(executeStatus);
        Assert.assertEquals(passMob, mtDto.getMobiles());
    }
}
