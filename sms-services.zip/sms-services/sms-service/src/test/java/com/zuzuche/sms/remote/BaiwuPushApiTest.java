package com.zuzuche.sms.remote;

import com.zuzuche.sms.remote.param.SmsSendParam;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class BaiwuPushApiTest {

    @Autowired
    BaiwuPushApi baiwuPushApi;


    @Test
    public void smsSend() {
        SmsSendParam param = SmsSendParam.builder()
                .corpId("2e5f001")
                .corpPwd("wlkj51")
                .corpService("10690226yd")
                .mobile("18122720701")
                .msgContent("【租租车】hello world! 验证码是1245")
                .build();


        baiwuPushApi.smsSend(param);
    }
}