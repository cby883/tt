package com.zuzuche.sms.task;


import com.zuzuche.sms.common.utils.SpringBeanFactory;
import com.zuzuche.sms.dto.SmsDto;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class CmSendTaskTest {

    @Test
    public void testSend() {
        SmsDto dto  = SmsDto.builder()
                .accountId(126)
                .mobile("008618819490467")
                .content("【EasyRentCars】hi, test the right message1234")
                .senderId("ERC")
                .taskId("211231")
                .build();

        CmSendTask task = SpringBeanFactory.getBean(CmSendTask.class, dto);
        task.run();
    }

    @Test
    public void testSendPartErr() {
        SmsDto dto  = SmsDto.builder()
                .accountId(126)
                .mobile("008618819490467,08618819490467a,aasdasd122")
                .content("【EasyRentCars】just to test the error part of the numbers11122324455666")
                .senderId("ERC")
                .taskId("411232")
                .build();

        CmSendTask task = SpringBeanFactory.getBean(CmSendTask.class, dto);
        task.run();
    }

    @Test
    public void testSendTotal() {
        SmsDto dto  = SmsDto.builder()
                .accountId(126)
                .mobile("08618819490467a,aasdasd122")
                .content("【EasyRentCars】hi, test all error numbers")
                .senderId("ERC")
                .taskId("211233")
                .build();

        CmSendTask task = SpringBeanFactory.getBean(CmSendTask.class, dto);
        task.run();
    }
}
