package com.zuzuche.sms.cache;


import com.zuzuche.sms.cache.co.SafeMonitorRuleCo;
import com.zuzuche.sms.dto.SmsDto;
import com.zuzuche.sms.remote.AliYunPushApi;
import com.zuzuche.sms.remote.dto.AliYunSmsSendDto;
import okhttp3.*;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class ProxySelectorTest {
    @Test
   public void test() throws Exception{
       OkHttpClient client = new OkHttpClient();

       MediaType mediaType = MediaType.parse("application/x-www-form-urlencoded");
       RequestBody body = RequestBody.create(mediaType, "message=Hello%20from%20TeleSign!&message_type=ARN&phone_number=Enter%20your%20phone%20number%20with%20the%20complete%20country%20code%20and%20no%20special%20characters%20or%20spaces%20here.");
       Request request = new Request.Builder()
               .url("http://www.baidu.com/")
               .post(body)
               .addHeader("content-type", "application/x-www-form-urlencoded")
               .build();

       Response response = client.newCall(request).execute();
       System.out.println();
   }
}
