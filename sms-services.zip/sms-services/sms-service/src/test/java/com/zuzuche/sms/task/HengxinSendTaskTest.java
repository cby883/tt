package com.zuzuche.sms.task;

import com.zuzuche.sms.common.utils.SpringBeanFactory;
import com.zuzuche.sms.dto.SmsDto;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class HengxinSendTaskTest {

    @Test
    public void testSend() {
        SmsDto dto = SmsDto.builder()
                .accountId(119)
                .mobile("18819490467")
                .content("【全球购骑士特权】你的订单号为8822123232")
                .build();

        HengxinSendTask hengxinSendTask = SpringBeanFactory.getBean(HengxinSendTask.class, dto);
        hengxinSendTask.run();
    }
}
