package com.zuzuche.sms.service;


import com.zuzuche.sms.common.utils.Md5Util;
import com.zuzuche.sms.dto.MtDto;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class SupplierMatchServiceTest {
    @Autowired
    SupplierMatchService service;

    @Test
    public void carPayPressMatchTest() {
//        MtDto mtDto = MtDto.builder()
//                .mobiles("18819490467")
//                .signType(1)
//                .regionType(1)
//                .type(3)
//                .batch(Md5Util.string2MD5("car_extra_pay_press_2018-08-02"))
//                .build();
//
//        String supplier = service.getAccountIdFromRules(mtDto);
//        Assert.assertEquals("YP", supplier);
    }

    @Test
    public void hiXiaoXianMatchTest() {
//        MtDto mtDto = MtDto.builder()
//                .mobiles("18819490467")
//                .signType(10)
//                .regionType(1)
//                .type(2)
//                .build();
//
//        String supplier = service.getAccountIdFromRules(mtDto);
//        Assert.assertEquals("JC", supplier);
    }

//    @Test
//    public void normalInnerRandomMatch() {
//        MtDto mtDto = MtDto.builder()
//                .mobiles("18819490467")
//                .signType(1)
//                .regionType(1)
//                .type(1)
//                .build();
//        int BWCount = 0;
//        int CLCount = 0;
//        int count = 0;
//        for (int i = 1; i <= 1000; i++) {
//            ++count;
//            String supplier = service.getAccountIdFromRules(mtDto);
//            if (supplier.equals("BW2")) {
//                ++BWCount;
//            } else if (supplier.equals("CL2")) {
//                ++CLCount;
//            }
//        }
//
//        System.out.println(count);
//        System.out.println(BWCount);
//        System.out.println(CLCount);
//        boolean status = Math.abs(BWCount - CLCount) <= 100;
//        Assert.assertTrue(status);
//    }
//
//    @Test
//    public void noSupplierMatch() {
//        MtDto mtDto = MtDto.builder()
//                .mobiles("18819490467")
//                .signType(15)
//                .regionType(1)
//                .type(1)
//                .build();
//
//        System.out.println(service.getAccountIdFromRules(mtDto));
//    }
}
