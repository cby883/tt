package com.zuzuche.sms.remote;

import com.zuzuche.commons.base.util.JsonUtil;
import com.zuzuche.sms.cache.TaskIdGenCache;
import com.zuzuche.sms.dto.ExtraParamDto;
import com.zuzuche.sms.dto.InvokeResultDto;
import com.zuzuche.sms.dto.MtDto;
import com.zuzuche.sms.dto.SmsDto;
import com.zuzuche.sms.service.SmsMtService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class TeleSignRemoteTest {

    @Autowired
    TaskIdGenCache taskIdGenCache;
    @Autowired
    TeleSignPushApi teleSignPushApi;

    @Test
    public void pushTest() {
        SmsDto smsDto=SmsDto.builder()
                .taskId(taskIdGenCache.increGetStr())
                .mobile("008613827162860")
                .content("测试数据3333sfss4")
                .type(3)
                .accountId(124)
                .build();
        InvokeResultDto resultDto=teleSignPushApi.sendSms(smsDto);
        System.out.println(resultDto);
    }
}