package com.zuzuche.sms.cache;


import com.zuzuche.sms.cache.co.SafeMonitorRuleCo;
import com.zuzuche.sms.dto.SmsDto;
import com.zuzuche.sms.remote.AliYunPushApi;
import com.zuzuche.sms.remote.dto.AliYunSmsSendDto;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class SafeMonitorRuleCacheTest {
    @Autowired
    SafeMonitorRuleCache safeMonitorRuleCache;

    @Autowired
    HighFreqMobileCache highFreqMobileCache;

    @Test
    public void getMonitorSamePhoneVerify() {
        try {
            safeMonitorRuleCache.afterPropertiesSet();
            SafeMonitorRuleCo co = safeMonitorRuleCache.get("monitorSamePhoneFreq");
            System.out.println(co);
        } catch (Exception e) {

        }
    }

    @Autowired
    AliYunPushApi aliYunPushApi;
    @Test
    public void test(){
        SmsDto smsDto=SmsDto.builder()
                .taskId("111")
                .content("这是一条测试数据1345")
                .mobile("13827162860,18902501093")
                .accountId(122)
                .signType(1).build();
        AliYunSmsSendDto aliYunSmsSendDto=aliYunPushApi.aLiYunSend(smsDto);
        System.out.println(aliYunSmsSendDto);
//        System.out.println("1");
    }
    // @Test
    // public void getMobileFreq() {
    //     highFreqMobileCache.setMobileIncre("18819490467");
    //     System.out.println(highFreqMobileCache.getMobileReq("18819490467"));
    // }
}
