package com.zuzuche.sms.remote;

import com.zuzuche.sms.common.utils.PerformUtil;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.test.context.junit4.SpringRunner;

import java.time.Instant;
import java.util.List;

import static org.junit.Assert.*;

@RunWith(SpringRunner.class)
@SpringBootTest
public class BaiwuPullApiTest {

    @Autowired
    BaiwuPullApi baiwuPullApi;
    @Autowired
    DiscoveryClient discoveryClient;

    @Test
    public void smsCount() {
    }

    @Test
    public void postReport() {
    }

    @Test
    public void postDeliverMsg() {
    }

    @Test
    public void test1() {
        long start = Instant.now().toEpochMilli();
        baiwuPullApi.test();
        long end = Instant.now().toEpochMilli();
        PerformUtil.logTime("xx",start,end);

         start = Instant.now().toEpochMilli();
        baiwuPullApi.test();
         end = Instant.now().toEpochMilli();
        PerformUtil.logTime("xx",start,end);

         start = Instant.now().toEpochMilli();
        baiwuPullApi.test();
         end = Instant.now().toEpochMilli();
        PerformUtil.logTime("xx",start,end);

        start = Instant.now().toEpochMilli();
        baiwuPullApi.test();
        end = Instant.now().toEpochMilli();
        PerformUtil.logTime("xx",start,end);


        start = Instant.now().toEpochMilli();
        baiwuPullApi.test();
        end = Instant.now().toEpochMilli();
        PerformUtil.logTime("xx",start,end);
    }

    @Test
    public void tt(){
        List<ServiceInstance> serviceInstances= discoveryClient.getInstances("SMS-SERVICE");
        System.out.println(serviceInstances);
    }
}