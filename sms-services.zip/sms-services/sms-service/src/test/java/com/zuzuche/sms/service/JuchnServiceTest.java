package com.zuzuche.sms.service;

import com.zuzuche.sms.dto.SmsDto;
import com.zuzuche.sms.executors.JuchnExecutor;
import com.zuzuche.sms.remote.JuchnPushApi;
import com.zuzuche.sms.remote.CallBackBusiApi;
import com.zuzuche.sms.remote.dto.ShortMessageDto;
import com.zuzuche.sms.remote.param.NotifySendStatusParam;
import com.zuzuche.sms.remote.param.ShortMessageParam;
import com.zuzuche.sms.report.syn.JuchnSynService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;


@RunWith(SpringRunner.class)
@SpringBootTest
public class JuchnServiceTest {

    @Autowired
    JuchnSynService juchnService;

    @Autowired
    JuchnPushApi juchnPushApi;


    @Autowired
    CallBackBusiApi smsbusiRemote;


    @Autowired
    JuchnExecutor juchnExecutor;

    @Test
    public void synStatusReport(){

        juchnService.synStatusReport(1);
    }

    @Test
    public void processSend(){
        SmsDto sms = SmsDto.builder()
                .accountId(112)
                .content("【租租车】测试短信了解一下")
                .mobile("18122720701")
                .build();
        juchnExecutor.packingSendTask(sms);
    }



    @Test
    public void shortMessage(){

        ShortMessageParam param = ShortMessageParam.builder()
                .msg("【租租车】你好测试一下")
                .needstatus("true")
                .passwd("zzc#2018!@#")
                .username("zuzuche01")
                .phone("18122720701")
                .port("")
                .sendtime("")
                .build();

        ShortMessageDto dto = juchnPushApi.shortMessage(param);
        System.out.println("dto = " + dto.toString());

//         param = ShortMessageParam.builder()
//                .msg("【租租车】你好测试一下2")
//                .needstatus("true")
//                .passwd("zzc#2018!@#")
//                .username("zuzuche01")
//                .phone("18122720701")
//                .port("")
//                .sendtime("")
//                .build();
//
//         dto = juchnPushApi.shortMessage(param);
    }

    @Test
    public void asynSendStatus(){
        //juchnService.asynSendStatus("9999999","0", "logId","999999999");

        NotifySendStatusParam param = NotifySendStatusParam.builder()
                .status("0".equals(0)?"1":"2")
                .taskId("111")
                .token("111")
                .t(String.valueOf(12313))
                .build();
        smsbusiRemote.notifySendStatus(param);
    }

}