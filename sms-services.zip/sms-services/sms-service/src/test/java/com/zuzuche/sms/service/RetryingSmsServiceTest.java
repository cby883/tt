package com.zuzuche.sms.service;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class RetryingSmsServiceTest {
    @Autowired
    RetryingSmsService retryingSmsService;

    // @Test
    // public void getNextProviderId() {
    //     // 300是没有这个accountId
    //     int nextProviderId1 = retryingSmsService.getNextAccountId(113 1);
    //     Assert.assertEquals(300, nextProviderId1);
    //
    //     // 120虽然有这个accountId，但是没有配置备份
    //     int nextProviderId2 = retryingSmsService.getNextAccountId(120, 0, 1);
    //     Assert.assertEquals(120, nextProviderId2);
    //
    //     // 112有备份1为119，备份2为117
    //     int nextProviderId3 = retryingSmsService.getNextAccountId(112, 0, 1);
    //     Assert.assertEquals(119, nextProviderId3);
    //     int nextProviderId4 = retryingSmsService.getNextAccountId(119, 112, 2);
    //     Assert.assertEquals(117, nextProviderId4);
    //
    //     // 113有备份1为115，但是没有备份2
    //     int nextProviderId5 = retryingSmsService.getNextAccountId(115, 113, 1);
    //     Assert.assertEquals(115, nextProviderId5);
    //     int nextProviderId55 = retryingSmsService.getNextAccountId(115, 113, 2);
    //     Assert.assertEquals(113, nextProviderId55);
    //
    //     // accountId不存在，但是parentAccountId存在
    //     int nextProviderId6 = retryingSmsService.getNextAccountId(300, 113, 1);
    //     Assert.assertEquals(115, nextProviderId6);
    //
    //     // accountId没有配置备份，但是parentAccountId存在
    //     int nextProviderId7 = retryingSmsService.getNextAccountId(120, 113, 1);
    //     Assert.assertEquals(115, nextProviderId7);
    //
    //     // accountId没有配置备份，且parentAccountId也没有配置备份
    //     int nextProviderId8 = retryingSmsService.getNextAccountId(118, 120, 1);
    //     Assert.assertEquals(118, nextProviderId8);
    //
    //     // accountId不存在，且parentAccountId也不存在
    //     int nextProviderId9 = retryingSmsService.getNextAccountId(131, 138, 1);
    //     Assert.assertEquals(131, nextProviderId9);
    //
    //     // accountId配置备份，但是parentAccountId不存在
    //     int nextProviderId10 = retryingSmsService.getNextAccountId(113, 300, 1);
    //     Assert.assertEquals(113, nextProviderId10);
    //
    //     // accountId配置备份，且parentAccountId存在但是没有配置备份
    //     int nextProviderId11 = retryingSmsService.getNextAccountId(113, 120, 1);
    //     Assert.assertEquals(113, nextProviderId11);
    // }
}
