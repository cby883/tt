package com.zuzuche;

import com.google.common.base.Joiner;
import com.zuzuche.sms.dto.SmsDto;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.apache.kafka.common.serialization.StringSerializer;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

/**
 * @desc: 模拟生产者
 * @author: panqiong
 * @date: 2018/8/12
 */
public class TestProducer3 {

    public static KafkaProducer<String, SmsDto> producer = null;

    public static void main(String[] args) throws Exception {

        System.out.println("Press CTRL-C to stop generating data");


        // add shutdown hook
        Runtime.getRuntime().addShutdownHook(new Thread() {
            public void run() {
                System.out.println("Shutting Down");
                if (producer != null){
                    producer.close();
                }

            }
        });


        //JsonSerializer<SourceEvent> eventSerializer = new JsonSerializer<>();

        // Configuring producer
        Properties props = new Properties();

        props.put("bootstrap.servers", "192.168.100.96:9092");
        props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG,com.zuzuche.kafka.serializer.JsonSerializer.class);
        // Starting producer
        producer = new KafkaProducer<>(props);
        long iter = 60000;
        // Start generating events, stop when CTRL-C
        long start = LocalDateTime.now().toEpochSecond(ZoneOffset.ofHours(8));
        long mobile = 3110001000l;
        while (iter<90000) {
            iter= iter+1;
            String taskId = String.valueOf(iter);
            List<String> mobileList = new ArrayList<>();
            for(int j=0;j<1;j++){
                mobileList.add(String.valueOf(mobile++));
            }
            String mobiles = Joiner.on(",").join(mobileList);
            SmsDto req = SmsDto.builder()
                    .accountId(115)
                    .content("1333压dd短asdfxx测试短信测试短信测试短信短信测试短信测试短信测试短信测试短信测试短信测试短信测试短信测试短信测试短信测试短信测试短信"+iter)
                    .mobile(mobiles)
                    .taskId(taskId)
                    .build();

            ProducerRecord<String, SmsDto> record = new ProducerRecord("chlan_sms_outbound_topic",req);

            producer.send(record, (RecordMetadata r, Exception e) -> {
//                System.out.println("record = " + record.toString());
                if (e != null) {
                    System.out.println("Error producing to topic " + r.topic());
                    e.printStackTrace();
                }
            });

            //System.out.println("iter = " + iter);
            Thread.sleep(2);
        }
        long end = LocalDateTime.now().toEpochSecond(ZoneOffset.ofHours(8));
        System.out.println("end = " + (end-start));
    }


}
