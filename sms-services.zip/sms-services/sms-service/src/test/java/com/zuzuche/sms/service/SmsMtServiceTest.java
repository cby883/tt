package com.zuzuche.sms.service;

import com.zuzuche.sms.common.constant.Constants;
import com.zuzuche.sms.dto.MtDto;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@RunWith(SpringRunner.class)
@SpringBootTest
public class SmsMtServiceTest {
    @Autowired
    SmsMtService service;

    // @Test
    // public void testSmsContent() {
    //     MtDto mtDto1 = MtDto.builder()
    //             .supplier("BW2")
    //             .regionType(1)
    //             .type(1)
    //             .signType(1)
    //             .content("你们好，我是测试啊啊啊")
    //             .build();
    //     service.setCompleteContent(mtDto1);
    //     Assert.assertEquals("你们好，我是测试啊啊啊", mtDto1.getSendContent());
    //     Assert.assertEquals("【租租车】你们好，我是测试啊啊啊", mtDto1.getContent());
    //
    //     MtDto mtDto2 = MtDto.builder()
    //             .supplier("CL2")
    //             .regionType(2)
    //             .type(2)
    //             .signType(1)
    //             .content("你们好，我是测试啊啊啊")
    //             .build();
    //     service.setCompleteContent(mtDto2);
    //     Assert.assertEquals("【租租车】你们好，我是测试啊啊啊 。回TD退订", mtDto2.getSendContent());
    //     Assert.assertEquals("【租租车】你们好，我是测试啊啊啊 。回TD退订", mtDto2.getContent());
    // }
    //
    // @Test
    // public void testSetAccountId() {
    //     MtDto mtDto = MtDto.builder()
    //             .supplier("CL2")
    //             .regionType(2)
    //             .type(1)
    //             .build();
    //
    //     Assert.assertTrue(service.setAccountId(mtDto));
    //     Assert.assertEquals(117, mtDto.getAccountId());
    // }
    //
    // @Test
    // public void testSetContentCount() {
    //     MtDto mtDto = MtDto.builder()
    //             .supplier("CL2")
    //             .regionType(2)
    //             .type(1)
    //             .content("【租租车】你们好，我是测试啊啊啊 。回TD退订【租租车】你们好，我是测试啊啊啊 。回TD退订【租租车】你们好，我是测试啊啊啊 。回TD退订1")
    //             .build();
    //
    //     service.setContentCount(mtDto);
    //     Assert.assertEquals(1, mtDto.getSendCount());
    //     mtDto.setContent(mtDto.getContent() + "1");
    //     service.setContentCount(mtDto);
    //     Assert.assertEquals(2, mtDto.getSendCount());
    //     mtDto.setContent(mtDto.getContent() + "【租租车】你们好，我是测试啊啊啊 。回TD退订【租租车】你们好，我是测试啊啊啊 。回TD退订【租租车】你们好，我是测试啊啊啊 。回8");
    //     service.setContentCount(mtDto);
    //     Assert.assertEquals(3, mtDto.getSendCount());
    // }

    @Test
    public void testCurrentTime() {
        System.out.println(System.currentTimeMillis());
        System.out.println(new Date().getTime());
        System.out.println(System.currentTimeMillis() / 1000);
    }

    @Test
    public void testAreaCodeFetch() {
        String mobile = "1-8819490467";
        String pattern = Constants.INTER_AREA_CODE_PREG;
        Pattern r = Pattern.compile(pattern);
        Matcher m = r.matcher(mobile);
        if (m.find()) {
            System.out.println(m.group());
        }
    }

}
