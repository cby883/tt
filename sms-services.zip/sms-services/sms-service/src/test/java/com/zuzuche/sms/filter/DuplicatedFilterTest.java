package com.zuzuche.sms.filter;

import com.zuzuche.threadpool.ThreadPoolExecutorFactory;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.integration.util.CallerBlocksPolicy;
import org.springframework.test.context.junit4.SpringRunner;

import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.TimeUnit;

import static org.junit.Assert.*;

@RunWith(SpringRunner.class)
@SpringBootTest
@Slf4j
public class DuplicatedFilterTest {

    private static long expireTime = 24*60*60;


    private static ExecutorService setExecutor = ThreadPoolExecutorFactory
            .create(ThreadPoolExecutorFactory.Config.builder()
                    .corePoolSize(10)
                    .maximumPoolSize(20)
                    .keepAliveTime(5)
                    .workQueue(new ArrayBlockingQueue<>(1000))
                    .unit(TimeUnit.MINUTES)
                    .handler(new CallerBlocksPolicy(60*1000))
                    .threadPoolName("DuplicatedFilterRedisSetExecutor")
                    .build());

    private static ExecutorService getExecutor = ThreadPoolExecutorFactory
            .create(ThreadPoolExecutorFactory.Config.builder()
                    .corePoolSize(20)
                    .maximumPoolSize(40)
                    .keepAliveTime(5)
                    .workQueue(new ArrayBlockingQueue<>(100))
                    .unit(TimeUnit.MINUTES)
                    .handler(new CallerBlocksPolicy(60*1000))
                    .threadPoolName("DuplicatedFilterRedisGetExecutor")
                    .build());


    @Autowired
    StringRedisTemplate redisTemplate;

    @Test
    public void setToredis() {
        System.out.println(Instant.now());
        List<String> list = new ArrayList<>();
        String md5Content = "sfdasf12312lj2;as0[dfa32n3e2rc;nwsfdsaf";
        for(int i = 0;i<10000;i++){
            // 标记位key
            String mobile = "1188888899"+i;
            list.add(mobile);
        }

        List xxlist = getDupilcatedMobiles(list);
        
    }

    @Test
    public void test1() {
//        Map<String,Object> param = new HashMap<String,Object>();
//        param.put("hk1", "a");
//        param.put("hk2", "b");
//        param.put("hk3", "c");
//        redisTemplate.opsForHash().putAll("mainkey", param);
//        List<String> keys = new ArrayList<String>();
//        keys.add("hk3");
//        keys.add("hk2");
//        keys.add("hk1");
//        System.out.println(">>>>>>>>>> "+redisTemplate.opsForHash().multiGet("mainkey", keys));//[a, null, b]
//
//        List<String> keys2 = new ArrayList<String>();
//        keys2.add("hk1");
//        keys2.add("hk");
//        keys2.add("hk2");
//        System.out.println(">>>>>>>>>> "+redisTemplate.opsForHash().multiGet("mainkey", keys2));//[a, null, b]

    }


    /**
     * 从redis获取重复短信的手机号码
     * @param markKeyList 防重复标识位
     */
    public List<String> getDupilcatedMobiles(List<String> markKeyList) {
        // 结果集
        List<String> list = new ArrayList<>();

        CompletableFuture[] cfs = markKeyList.stream()
                .map(markKey ->
                        CompletableFuture.supplyAsync(() -> getFromRedis(markKey), getExecutor)
                                .whenComplete((s, e) -> list.add(s))
                ).toArray(CompletableFuture[]::new);
        // 封装后无返回值，必须自己whenComplete()获取
        CompletableFuture.allOf(cfs).join();

        //list.stream().forEach(System.out::println);
        return list;
    }


    /**
     * 根据防重复标识位 从redis获取关联的手机号码
     * 关系:
     * markkey:mobile
     * @param markKey
     * @return
     */
    private String getFromRedis(String markKey){
        return redisTemplate.opsForValue().get(markKey);
    }

}