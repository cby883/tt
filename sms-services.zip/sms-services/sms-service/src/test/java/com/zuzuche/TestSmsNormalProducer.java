package com.zuzuche;

import com.zuzuche.sms.common.utils.Md5Util;
import com.zuzuche.sms.dto.MtDto;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.apache.kafka.common.serialization.StringSerializer;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.Properties;

public class TestSmsNormalProducer {
    public static KafkaProducer<String, MtDto> producer = null;

    /**
     *
     * 场景:
     * 模拟推送5000个模板短信到kafka队列， 观察kafka消费速度， 每次推送一个号码.
     *
     * 过程: 关闭测试机的短信服务 => 执行该测试方法 => 测试机的短信服务开启
     * 模板文案: [driver_name]的换领香港驾照材料，香港运输署已审核通过，我们已将香港驾照和其他相关材料寄出到：[[ext_address]、[ext_username]、[ext_phone]]，快递单号为：顺丰[ext_express_no]，请您留意查收。
     * 模板uid: SMS190213179581
     */
    public static void main(String[] args) throws Exception {
        System.out.println("Press CTRL-C to stop generating data");


        // add shutdown hook
        Runtime.getRuntime().addShutdownHook(new Thread() {
            public void run() {
                System.out.println("Shutting Down");
                if (producer != null){
                    producer.close();
                }

            }
        });

        //JsonSerializer<SourceEvent> eventSerializer = new JsonSerializer<>();

        // Configuring producer
        Properties props = new Properties();
        props.put("bootstrap.servers", "192.168.100.96:9092");
        props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG,com.zuzuche.kafka.serializer.JsonSerializer.class);
        // Starting producer
        producer = new KafkaProducer<>(props);

        // Start generating events, stop when CTRL-C
        long start = LocalDateTime.now().toEpochSecond(ZoneOffset.ofHours(8));

        int beginMobile = 94600000;
        int num = 20000;
        MtDto mtDto = MtDto.builder()
                .tempUid("SMS190213179581")
                .type(1)
                .regionType(1)
                .signType(12)
                .language("zh-cn")
                .batch(Md5Util.string2MD5("normalTest7"))
                .mock(true)
                .build();
        for (int i = 1; i <= num; i++) {
            int mobile = beginMobile + i;
            mtDto.setMobiles(mobile + "");
            mtDto.setVariables("{\"[driver_name]\" : '" + i + "'}");

            ProducerRecord<String, MtDto> record = new ProducerRecord("sms_normal_topic", mtDto);

            System.out.println(mtDto);

            producer.send(record, (RecordMetadata r, Exception e) -> {
//                System.out.println("record = " + record.toString());
                if (e != null) {
                    System.out.println("Error producing to topic " + r.topic());
                    e.printStackTrace();
                }
            });


            Thread.sleep(5);
        }
        long end = LocalDateTime.now().toEpochSecond(ZoneOffset.ofHours(8));
        System.out.println("end = " + (end-start));
    }
}
